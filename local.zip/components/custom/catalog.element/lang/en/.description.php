<?
$MESS ['T_IBLOCK_DESC_CATALOG'] = "Catalog";
$MESS ['IBLOCK_ELEMENT_TEMPLATE_NAME'] = "Catalog element details";
$MESS ['IBLOCK_ELEMENT_TEMPLATE_DESCRIPTION'] = "Displays the detailed information on the catalog element";
?>