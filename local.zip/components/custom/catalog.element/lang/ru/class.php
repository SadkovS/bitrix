<?
$MESS["IBLOCK_MODULE_NOT_INSTALLED"] = "Модуль \"Информационные блоки\" не установлен";