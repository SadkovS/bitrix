<?
$MESS ['T_IBLOCK_DESC_CATALOG'] = "Каталог";
$MESS ['IBLOCK_ELEMENT_TEMPLATE_NAME'] = "Элемент каталога детально";
$MESS ['IBLOCK_ELEMENT_TEMPLATE_DESCRIPTION'] = "Выводит детальную информацию по элементу каталога";
?>