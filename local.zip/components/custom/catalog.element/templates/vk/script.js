var url_order = "/basket/order.php";

function redirectToPayment() {
    document.location.href = url_order;
}

const debounce = (fnc, ms) => {
	let timeout;
	function wrapper(){
		const fnCall = () => fnc.apply(this, arguments);
		clearTimeout(timeout);
		timeout = setTimeout(fnCall, ms);
	}

	return wrapper;
}
  
function onMessage(event) {
    var data = event.data;

    if (typeof window[data.func] == "function") {
          window[data.func].call(null, data.message);
        }
      }
 
 	if (window.addEventListener) {
        window.addEventListener("message", onMessage, false);
  } else if (window.attachEvent) {
    window.attachEvent("onmessage", onMessage, false);
}

$(function() {
	function calculate_sum()
	{
		var products = [];
		$(".jq-quantity").each(function (index, el){
			if($(el).val() > 0)
			{
				products.push({id: $(el).data("id"), quantity: $(el).val()});
			}
		});
		
		$.ajax({
			url: '',
			method: 'post',
			dataType: 'html',
			data: {'ajax_catalog':'Y', 'items': products},
			success: function(result){
				$("#catalog_item").find(".tickets").replaceWith($(result).find(".tickets"));
				$("#catalog_item").find(".popup__controls").replaceWith($(result).find(".popup__controls"));
			}
		});
		
		
		/*var sum = 0;
		var count = 0;
		
		$(".jq-quantity").each(function (index, el){
		    sum += $(el).val() * $(el).data("price");
		    count += parseInt($(el).val());
		});
		
		$(".jq-price-sum").html(sum);
		
		if(count > 0)
		{
			$(".jq-add-to-basket").removeAttr("disabled");
		}
		else
		{
			$(".jq-add-to-basket").attr("disabled", "disabled");
		}*/
	}

	function calculateSumClick() {
		var id = $(this).siblings(".jq-quantity").data("id")
		qnt = $(this).siblings(".jq-quantity").val(),
			catalog_avail = JSON.parse( localStorage.catalog_avail );

		if(parseInt(catalog_avail[id]["MAX_QUANTITY"]) >= parseInt(qnt) && parseInt(catalog_avail[id]["QUANTITY"]) >= parseInt(qnt))
		{
			calculate_sum();
		}
		else
		{
			if(parseInt(catalog_avail[id]["MAX_QUANTITY"]) > parseInt(catalog_avail[id]["QUANTITY"]))
				$(this).siblings(".jq-quantity").val(catalog_avail[id]["QUANTITY"]);
			else
				$(this).siblings(".jq-quantity").val(catalog_avail[id]["MAX_QUANTITY"]);
		}
	}
	
	$(document).on("click", ".jq-change-quantity",  debounce(calculateSumClick, 500));
	
	$(document).on("click", ".tickets__quantity-item-delete",  function () {
		$(this).siblings('.tickets__quantity-item-controls').find(".jq-quantity").val(0);
		
		calculate_sum();
	});
	
	$(document).on("click", ".jq-add-to-basket",  function () {
		
		var products = [];
		$(".jq-quantity").each(function (index, el){
			if($(el).val() > 0)
			{
				products.push({id: $(el).data("id"), quantity: $(el).val(), name: $(el).data("name")});
			}
		});
		
		if(products.length)
		{
			BX.ajax.runComponentAction("custom:basket", "add", {
			    mode: "class",
			    data: {items: products}
			}).then(function (response) {
				document.location.href = url_order;
			});
		}
	});

	$('.footer').hide();
	$('.header').hide();

	$(document).on("click", "[data-back]",  function () {
		window.history.back();
	})
});