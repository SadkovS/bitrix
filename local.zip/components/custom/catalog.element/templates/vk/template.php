<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Catalog\ProductTable;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>
<script>
	localStorage.catalog_avail = '<?=json_encode($arResult['JS_DATA'])?>';	
</script>


		<div id="catalog_item" class="section__container">
			<button type="button" class="popup__close back-btn" data-back>Назад</button>
			<div class="popup__tytle">
				<h2 class="h2"><?=$arResult["NAME"]?></h2>
				<p><?=$arResult["DATE_TIME"]["DATE_RU"]?> <?=$arResult["DATE_TIME"]["TIME"]?>.
					<?if($arResult['EVENT_TYPE'] == "online"):?>
						Онлайн
					<?else:?> 
						<?=$arResult["EVENT_TYPE_TEXT"]?>
					<?endif;?>
				</p>
			</div>
			
			<?if($arResult['FRAME_SRC']):?>
				<div class="seating" id="sizetracker">
					<iframe id="seats_frame" name="seats_frame" src="<?=$arResult['FRAME_SRC']?>" frameborder="0">
					    Ваш браузер не поддерживает плавающие фреймы!
					</iframe>
				</div>
			<?else:?>
				<?if($_REQUEST['ajax_catalog']=='Y')
   					$APPLICATION->RestartBuffer();?>
   				<div>
					<div class="tickets">
						<div class="tickets__quantity-list">
							<?foreach($arResult['OFFERS'] as $key => $item):?>
								<div class="tickets__quantity-item">
									<div class="tickets__quantity-item-info">
										<span class="tickets__item-label"><?=$item["PROPERTIES"]["TYPE"]["VALUE"]?></span>
										<?if($item["~PREVIEW_TEXT"]):?>
											<span class="tickets__item-description"><?=$item["~PREVIEW_TEXT"]?></span>
										<?endif;?>
										<div class="tickets__item-price">
											<span class="tickets__item-label"><?=$item["PRICE"]?>₽</span>
											<?if($item["PRICE"] != $item["ITEM_PRICES"][0]["PRICE"]):?>
												<span class="tickets__item-old-price"><?=$item["ITEM_PRICES"][0]["PRICE"]?>₽</span>
											<?endif;?>
											<?if($item["RULE"]):?>
												<span class="tickets__item-promo">Скидка «<?=$item["RULE"]["UF_NAME"]?>»</span>
											<?endif;?>
										</div>
									</div>
									<div class="tickets__quantity-item-controls" data-quantity>
										<button class="btn__icon jq-change-quantity" type="button"><i class="_icon-minus"></i></button>
										<input class="jq-quantity" type="text" data-id="<?=$item["ID"]?>" data-name="<?=$item["PROPERTIES"]["TYPE"]["VALUE"]?>" data-price="<?=$item["ITEM_PRICES"][0]["PRICE"]?>" value="<?=$item["SELECT_QUANTITY"]?>" readonly>
										<button class="btn__icon jq-change-quantity" type="button"><i class="_icon-plus"></i></button>
									</div>
									<button class="tickets__quantity-item-delete"><i class="_icon-cross"></i></button>
								</div>
							<?endforeach;?>
						</div>
						<div class="tickets__total">
							<span>Итого к оплате</span>
							<span><span class="jq-price-sum"><?=$arResult['SUMM']?></span> ₽</span>
						</div>
					</div>
					<div class="popup__controls">
						<button class="btn__popup jq-add-to-basket" type="button" <?if($arResult['BTN_DISABLED']):?>disabled<?endif;?>>
							Перейти к оформлению
						</button>
					</div>
				</div>
				<?if($_REQUEST['ajax_catalog']=='Y')
   					die();?>
			<?endif;?>
		</div>

<?
//echo "<pre>"; print_r($arResult['OFFERS']); echo "</pre>";
