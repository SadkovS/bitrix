<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

/**
 * @var CBitrixComponentTemplate $this
 * @var CatalogElementComponent  $component
 */

use Bitrix\Main\Loader;
use Bitrix\Main\ORM;
use Bitrix\Highloadblock as HL;

Loader::includeModule('custom.core');
Loader::includeModule('highloadblock');

$component = $this->getComponent();
$arParams  = $component->applyTemplateModifications();
if ((int)$arResult['PROPERTIES']['EVENT_ID']['VALUE'] > 0) {
	Custom\Core\Events::getEventData($arResult['PROPERTIES']['EVENT_ID']['VALUE'], $arResult, true);
}

$jsData = [];

$onlyFree = true;
$onlyPay = true;
$hasFree = false;
$hasPay = false;

$isAjax = $_REQUEST["ajax_catalog"] && $_REQUEST["ajax_catalog"] == "Y";
$selectCountItems = [];
if($isAjax)
{
	foreach ($_REQUEST["items"] as $item)
	{
		$selectCountItems[$item["id"]] = $item["quantity"];
	}
}

$arResult['SUMM'] = 0;
$arResult['BTN_DISABLED'] = true;
foreach($arResult['OFFERS'] as $key => &$item)
{
	$jsData[$item["ID"]] = [
		"ID" => $item["ID"],
		"MAX_QUANTITY" => $item["PROPERTIES"]["MAX_QUANTITY"]["VALUE"],
		"QUANTITY" => $item["CATALOG_QUANTITY"],
	];
	
	$item["SELECT_QUANTITY"] = 0;

	if($isAjax && $selectCountItems[$item["ID"]])
	{
		$item["SELECT_QUANTITY"] = $selectCountItems[$item["ID"]];
	}		
		
	if($item["ITEM_PRICES"][0]["PRICE"] > 0)
	{
		$onlyFree = false;
		$hasPay = true;
	}
	if($item["ITEM_PRICES"][0]["PRICE"] == 0)
	{
		$hasFree = true;
		$onlyPay = false;
	}
}
unset($item);

\Custom\Core\Discount::getOptimalPriceInCatalog($arResult['OFFERS'], $arResult['PROPERTIES']['EVENT_ID']['VALUE']);

foreach($arResult['OFFERS'] as $key => &$item)
{
	if($item["SELECT_QUANTITY"])
	{
		$item["PRICE"] = CurrencyFormat($item["PRICE"], "RUB");
		
		$arResult['SUMM'] += $item["SUMM"];
		$arResult['BTN_DISABLED'] = false;
	}
}

$arResult["SUMM"] = CurrencyFormat($arResult["SUMM"], "RUB");

$arResult['ONLY_FREE'] = $onlyFree;
$arResult['ONLY_PAY'] = $onlyPay;

if($hasFree && $hasFree)
{
	$arResult['HAS_FREE_PAY'] = true;
}
else
{
	$arResult['HAS_FREE_PAY'] = false;	
}

$eventTypeText = [];
if($arResult["LOCATION_ROOM"])
	$eventTypeText[] = $arResult["LOCATION_ROOM"];
if($arResult["LOCATION_ADDRESS"])
	$eventTypeText[] = $arResult["LOCATION_ADDRESS"];

if($eventTypeText)
	$arResult["EVENT_TYPE_TEXT"] = implode(". ", $eventTypeText);

$arResult['JS_DATA'] = $jsData;

$this->__component->SetResultCacheKeys(array_keys($arResult));
