<?

$MESS ['ONLINE'] = "Онлайн";
$MESS ['ONLY_FREE'] = "Бесплатно";
$MESS ['HAS_FREE'] = "Есть бесплатные";
$MESS ['PAY'] = "Купить билет";
$MESS ['ONLY_FREE_PAY'] = "Регистрация";
$MESS ['SOLD_OUT'] = "Распроданы";
?>