<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Catalog\ProductTable;

Loader::includeModule('custom.core');
/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);
$objImages     = new Custom\Core\Images;
$detailPicture = $objImages->processImageResizes($arResult['DETAIL_PICTURE_ID']);
$galleryIds = array_column($arResult["EVENT_FILES"] ?? [], 'ID');
$arGallery     = [];
foreach ($galleryIds as $id) {
    $arGallery[] = $objImages->processImageResizes($id);
}
$SEO_Event_JSON = [
	"@context" => "https://schema.org",
	"@graph" => []
];

\Custom\Core\Helper::addSeoEventItem($arResult, $SEO_Event_JSON);
?>
<script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>

<script>
    BX.message({
        TEMPLATE_PATH: '<? echo $this->GetFolder(); ?>'
    });
</script>

<div class="detail z-10 inline-flex flex-col xl:gap-10">
    <div class="inline-flex flex-col gap-c_lg lg:col-span-2 lg:gap-5 laptop:col-span-2 xl:gap-c_2xl">
        <div>
            <div class="card__item" data-mh data-auto-fs-source data-tooltip-parent="">
                <div class="card__item-banner">
                    <div class="card__item-type">
                        <i class="<?=$arResult["CATEGORY_ICON"]?>"></i>
                        <span class="text-mic font-medium dark:text-white lg:text-sm"><?=$arResult["CATEGORY_NAME"]?></span>
                    </div>
                    <div class="card__item-pic  img-skeleton">
	                    <picture>
		                    <!--
		                    //todo добавить webp
		                    <source
			                    srcset="
											      <?php /*=$arResult["DETAIL_PICTURE"]*/?> 500w,
											      <?php /*=$arResult["DETAIL_PICTURE"]*/?> 1000w,
											      <?php /*=$arResult["DETAIL_PICTURE"]*/?> 820w,
											      <?php /*=$arResult["DETAIL_PICTURE"]*/?> 1640w
											    "
			                    type="image/webp"
			                    sizes="(max-width: 600px) 500px, 820px"
		                    />-->

		                    <img
			                    src="<?=$arResult["DETAIL_PICTURE"]?>"
			                    class="fill-img"
                                srcset="
                                <? foreach ($detailPicture as $key => $value): ?>
		                                <? if ($key != 'thumb'): ?>
												              <?= $value['src'] ?> <?= $key ?>,
																		<? endif; ?>
																<? endforeach; ?>
												  "
			                    sizes="(max-width: 920px) 100vw, 1140px"
			                    alt=""
		                    />
	                    </picture>
                    </div>

                    <div class="card__item-share">
                       <i class="tooltip__icon font-medium icon__age"><?=$arResult["AGE"]?>+</i>
                        <button type="button" data-tooltip-button="">
                            <i class="svg_icon-share tooltip__icon"></i>
                        </button>
                    </div>
                </div>

                <div class="z-10 mb-c_sm inline-flex w-full flex-col gap-c_md px-3 md:gap-5 md:px-2.5 lg:rounded-c_xlg lg:bg-t-1 lg:p-c_lg dark:lg:bg-background-2 laptop:p-c_lg xl:gap-c_lg" data-in=".detail__aside, 999">
                    <div class="inline-flex flex-col gap-c_sm lg:gap-2.5">
                        <div class="inline-flex w-full justify-between items-center flex-row ">
                            <a href="javascript:void(0)" onclick="javascript:history.go(-1)" class="link__detail">
                                 <i class="svg_icon-arrow-r"></i>
                                 <span>Назад</span>
                            </a>
                            <?if($arResult['EVENT_TYPE'] == "online"):?>
                                <p class="text-xs md:text-sm dark:text-white">Онлайн событие</p>
                            <?elseif($arResult['EVENT_TYPE'] == "offline_online"):?>
                                <p class="text-xs md:text-sm dark:text-white">Доступна трансляция</p>
                            <?endif;?>
                         </div>
                        <div class="spacing font-montserrat text-xl font-bold leading-120 tracking-0.42 tracking-[0.72px] dark:text-white lg:text-2xl xl:text-3xl break-words" ><?=$arResult["NAME"]?></div>
                    </div>
                    <div class="inline-flex flex-col gap-c_md lg:order-1 lg:grid lg:grid-cols-2 lg:gap-c_md laptop:gap-2.5 xl:gap-5">
                        <?if($arResult['EVENT_TYPE'] != "online"):?>
                            <div class="inline-flex w-full items-center gap-c_md md:gap-5 lg:gap-c_md laptop:gap-5 lg:order-1">
                                <div
                                        class="svg_icon-location flex size-c_sxl flex-shrink-0 items-center justify-center rounded-c_lg bg-icons-1 bg-cover bg-center text-base text-icons dark:bg-background-1 dark:text-t-2 md:size-c_2xl md:text-lg lg:text-xl laptop:size-c_2xl laptop:rounded-c_xlg xl:size-[4.375rem]"></div>
                                <div class="inline-flex flex-col gap-0.5">
                                    <div class="text-c_xs font-medium leading-normal dark:text-white md:text-sm xl:text-lg"><?=$arResult["LOCATION_NAME"]?></div>
                                    <div class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 lg:text-sm xl:text-base"><?=$arResult["LOCATION_ADDRESS"]?></div>
                                </div>
                            </div>
                        <?else:?>
                            <div class="inline-flex w-full items-center gap-c_md md:gap-5 lg:gap-c_md laptop:gap-5 lg:order-1">
                                <div
                                        class="svg_icon-location flex size-c_sxl flex-shrink-0 items-center justify-center rounded-c_lg bg-icons-1 bg-cover bg-center text-base text-icons dark:bg-background-1 dark:text-t-2 md:size-c_2xl md:text-lg lg:text-xl laptop:size-c_2xl laptop:rounded-c_xlg xl:size-[4.375rem]"></div>
                                <div class="inline-flex flex-col gap-0.5">
                                    <div class="text-c_xs font-medium leading-normal dark:text-white md:text-sm xl:text-lg"><?=Loc::GetMessage("ONLINE")?></div>
                                </div>
                            </div>
                        <?endif;?>

                        <div class="inline-flex w-full items-center gap-c_md md:gap-5 lg:gap-c_md laptop:gap-5 lg:order-3">
                            <div class="svg_icon-calender flex size-c_sxl flex-shrink-0 items-center justify-center rounded-c_lg bg-icons-1 bg-cover bg-center text-base text-icons dark:bg-background-1 dark:text-t-2 md:size-c_2xl md:text-lg lg:text-xl laptop:size-c_2xl laptop:rounded-c_xlg xl:size-[4.375rem]"></div>
                            <div class="inline-flex flex-auto flex-col gap-c_sm laptop:gap-y-0.5 xl:gap-y-c_sm">
                                <?if($arResult['DATES_GROUP']):?>
                                    <div class="inline-flex flex-auto flex-col gap-c_sm laptop:gap-y-0.5 xl:gap-y-c_sm">
                                        <?foreach($arResult['DATES_GROUP'] as $dates):?>
                                            <div class="inline-flex items-baseline gap-2">
                                                 <div class="text-c_xs font-medium leading-normal text-t-3 dark:text-white md:text-sm xl:text-lg"><?=$dates["date"]?></div>
                                                <div class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 lg:text-sm xl:text-base"><?=$dates["time"]?></div>
                                            </div>
                                        <?endforeach;?>
                                    </div>
                                <?else:?>
                                    <div class="inline-flex items-baseline gap-2">
                                        <div class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 lg:text-sm xl:text-base">Начало:</div>
                                        <div class="text-c_xs font-medium leading-normal text-t-3 dark:text-white md:text-sm xl:text-lg">
                                            <?=$arResult["DATE_TIME"]["DATE_RU"]?> <?=$arResult["DATE_TIME"]["TIME"]?>
                                        </div>
                                    </div>
                                    <div class="inline-flex items-baseline gap-2">
                                        <div class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 lg:text-sm xl:text-base">Конец:</div>
                                        <div class="text-c_xs font-medium leading-normal text-t-3 dark:text-white md:text-sm xl:text-lg"><?=$arResult["DATE_TIME"]["DATE_END_RU"]?> <?=$arResult["DATE_TIME"]["TIME_END"]?></div>
                                    </div>
                                    <div class="inline-flex items-baseline gap-2">
                                        <div class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 lg:text-sm xl:text-base">Идёт:</div>
                                        <div class="text-c_xs font-medium leading-normal text-t-3 dark:text-white md:text-sm xl:text-lg"><?=$arResult["DURATION"]?></div>
                                    </div>
                                <?endif;?>
                            </div>
                        </div>

                        <div class="inline-flex w-full items-center gap-c_md md:gap-5 lg:gap-c_md laptop:gap-5 lg:order-2">
                            <? if ($arResult["COMPANY_LOGO_SRC"]): ?>
                                <div class="size-c_sxl flex-shrink-0 rounded-c_lg bg-contain bg-no-repeat bg-center md:size-c_2xl laptop:size-c_2xl laptop:rounded-c_xlg xl:size-[4.375rem]"
                                    style="background-image:url(<?=$arResult["COMPANY_LOGO_SRC"]?>)"></div>
                            <? else: ?>
                                 <div class="svg_icon-def flex size-c_sxl flex-shrink-0 items-center justify-center rounded-c_lg bg-icons-1 bg-cover bg-center text-base text-icons dark:bg-background-1 dark:text-t-2 md:size-c_2xl md:text-lg lg:text-xl laptop:size-c_2xl laptop:rounded-c_xlg xl:size-[4.375rem]"></div>
                            <? endif; ?>
                            <div class="inline-flex flex-auto flex-col gap-0.5">
                                <a target="_blank" href="<?=$arResult["ORGANIZER_PAGE_URL"]?>" class="inline-flex items-center gap-c_xs text-c_xs font-medium leading-normal dark:text-white md:text-sm xl:text-lg"><?=$arResult["COMPANY_NAME"]?>  <i class="svg_icon-arrow text-sm"></i></a>
                                <span class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 lg:text-sm xl:text-base">Организатор</span>
                            </div>
                            <?/*<a> class="link__icon-med dark:hover:bg-icons-1 dark:hover:text-primary" href="<?=$arResult["ORGANIZER_PAGE_URL"]?>" target="_blank">
                                <i class="svg_icon-arrow"></i>
                            </a>*/?>
                        </div>

                        <div
                                class="fixed bottom-0 left-0 mt-auto inline-flex w-screen items-center justify-between gap-c_md bg-t-1 px-c_at py-5 dark:bg-primary lg:static lg:order-4 lg:w-full lg:flex-row-reverse lg:items-center lg:justify-end lg:gap-c_md lg:bg-transparent lg:p-0 dark:lg:bg-transparent xl:gap-c_lg">
                            <div class="font-gothic text-xs  text-warning sm:text-lg md:text-xl lg:text-lg laptop:text-xl xl:text-2xl">
                                <?if(!$arResult['BTN_DISABLED']):?>
                                    <?if($arResult['ONLY_FREE']):?>
                                        <?=Loc::GetMessage("ONLY_FREE")?>
                                    <?elseif($arResult['HAS_FREE']):?>
                                        от&nbsp;&nbsp;0
                                        <b class="font-[Montserrat]">₽</b>
                                    <?else:?>
                                        от&nbsp;&nbsp;<?=$arResult["MIN_PRICE_FORMAT"]?>
                                        <b class="font-[Montserrat]">₽</b>
                                    <?endif;?>
                                <?endif;?>
                            </div>
                            <?if($arResult['BTN_DISABLED']):?>
                                <a type="button" class="btn__red btn__buy">
                                    <span class="hidden font-gothic text-xs sm:text-sm md:text-base lg:text-sm laptop:text-base xl:text-lg">
                                        <?=$arResult['BTN_DISABLED_TEXT']?>
                                    </span>
                                    <span class="font-gothic text-xs sm:text-sm md:text-base lg:text-sm laptop:text-base xl:text-lg">
                                        <?=$arResult['BTN_DISABLED_TEXT']?>
                                    </span>
                                </a>
                            <?else:?>
                                <a href="<?=$arParams["BASKET_URL"]?>" type="button" class="btn__red btn__buy">
                                    <span class="font-gothic text-xs sm:text-sm md:text-base lg:text-sm laptop:text-base xl:text-lg">
                                                    <?if($arResult['ONLY_FREE']):?>
                                                        <?=Loc::GetMessage("ONLY_FREE_PAY")?>
                                                    <?else:?>
                                                        <?=Loc::GetMessage("PAY")?>
                                                    <?endif;?>
                                                </span>
                                    <i class="svg_icon-arrow-r icon__round"></i>
                                </a>
                            <?endif;?>
                        </div>
                    </div>
                </div>

                <div class="card__item-tooltip z-20" data-tooltip>
                    <a href="<?=$arResult["SHARE"]["THIS"]?>" class="tooltip__link" data-link-copy="">
                        <span>Копировать ссылку</span>
                        <i class="svg_icon-copy"></i>
                    </a>
                    <a href="<?=$arResult["SHARE"]["VK"]?>" class="tooltip__link" target="_blank">
                        <span>Вконтакте</span>
                        <i class="svg_icon-vk"></i>
                    </a>
                    <a href="<?=$arResult["SHARE"]["TG"]?>" class="tooltip__link" target="_blank">
                        <span>Telegram</span>
                        <i class="svg_icon-telegram"></i>
                    </a>
                </div>
            </div>
            <div class="detail__aside relative hidden lg:col-span-1 lg:mt-5 lg:block laptop:col-span-1 laptop:mt-c_lg xl:mt-10" data-sticky="" data-sticky-header=""></div>
        </div>
        <?if($arResult["DETAIL_TEXT"]):?>
            <div class="article group/showmore inline-flex flex-col gap-2 px-c_narrow dark:text-white lg:p-0 xl:gap-c_lg" >
                <h2 class="">О событии</h2>
                <div class="line-clamp-4 break-words group-has-[input.showmore:checked]/showmore:line-clamp-none" data-clamp-block>
                    <?=htmlspecialchars_decode($arResult["DETAIL_TEXT"])?>
                </div>
                <div class="inline-flex flex-col gap-2" data-clamp-block-btn>
                    <div class="max-h-0 overflow-hidden group-has-[input.showmore:checked]/showmore:max-h-full">
                        <div class="inline-flex flex-col gap-c_md pb-c_sm pt-2.5 md:gap-5 lg:gap-c_af">
                        </div>
                    </div>
                    <label class="btn__more">
                        <input type="checkbox" class="showmore hidden">
                        <span class="block group-has-[input.showmore:checked]/showmore:hidden">Показать ещё</span>
                        <span class="hidden group-has-[input.showmore:checked]/showmore:block">Скрыть</span>
                        <i class="svg_icon-arrow-r rotate-90 group-has-[input.showmore:checked]/showmore:rotate-[-90deg]"></i>
                    </label>
                </div>
            </div>
        <?endif;?>

        <?if($arResult["EVENT_FILES"]):?>
            <div class="inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_sm dark:bg-background-2 md:p-2.5">
                <div class="detail__slider swiper w-full swiper-initialized swiper-horizontal swiper-backface-hidden" data-slider-detail="">
                    <div class="detail__wrapper swiper-wrapper">

                        <?php foreach ($arResult["EVENT_FILES"] as $file_key => $file):?>
                            <div class="detail__slide swiper-slide img-skeleton" style="margin-right: 15px;">


                                <picture>
		                            <!--
		                    //todo добавить webp
		                    <source
			                    srcset="
											      <?php /*=$file["PATH"]*/?> 500w,
											      <?php /*=$file["PATH"]*/?> 1000w,
											      <?php /*=$file["PATH"]*/?> 820w,
											      <?php /*=$file["PATH"]*/?> 1640w
											    "
			                    type="image/webp"
			                    sizes="(max-width: 920px) 100vw, 1140px"
		                    />-->

		                            <!--  //todo подставить разные размеры (размер указн в параметре после пробела)  -->
		                            <img
			                            src="<?=$file["PATH"]?>"
			                            class="fill-img fill-img--contain"
                                        srcset="
			                                    <? foreach ($arGallery[$file_key] as $key => $value): ?>
			                                        <? if ($key != 'thumb'): ?>
			                                            <?= $value['src'] ?> <?= $key ?>,
			                                        <? endif ?>
			                                    <? endforeach; ?>
												  "
			                            sizes="(max-width: 920px) 100vw, 1140px"
			                            alt=""
		                            />
	                            </picture>
                            </div>
                        <?php endforeach;?>
                    </div>
                    <div class="detail__slider-controls">
                        <button type="button" class="slider__btn prev swiper-button-disabled" data-slider-detail-prev="" disabled="">
                            <i class="svg_icon-arrow-r"></i>
                        </button>
                        <div class="detail-thumb__slider swiper swiper-initialized swiper-horizontal swiper-watch-progress swiper-backface-hidden swiper-thumbs" data-slider-detail-thumb="">
                            <div class="detail-thumb__wrapper swiper-wrapper" style="transform: translate3d(0px, 0px, 0px);">
                                <? $arThumbs = array_column($arGallery ?? [], 'thumb') ?>
                                <? foreach ($arThumbs as $file): ?>
                                    <div class="detail-thumb__slide swiper-slide img-skeleton" style="width: 76px; margin-right: 10px;">
	                                    <picture>
		                                    <!--
										                    //todo добавить webp
										                    <source
											                    srcset="<?php /*=$arResult["DETAIL_PICTURE"]*/?>"
											                    type="image/webp"
											                    sizes="(max-width: 600px) 500px, 820px"
										                    />-->

		                                    <!--  //todo подставить разные размеры (размер 140px)  -->
                                            <img src="<?= $file["src"] ?>" class="fill-img" alt=""/>
	                                    </picture>
                                    </div>
                                <?endforeach;?>
                            </div>
                        </div>
                        <button type="button" class="slider__btn next" data-slider-detail-next="">
                            <i class="svg_icon-arrow-r"></i>
                        </button>
                    </div>
                </div>
            </div>
        <?endif;?>
        <?if($arResult['EVENT_TYPE'] != "online"):?>
            <div class="inline-flex flex-col gap-c_md rounded-c_lg bg-t-1 p-c_sm dark:bg-background-2 dark:text-white md:gap-5 md:p-2.5 lg:gap-c_lg">
                <div class="px-[0.75rem] pt-2.5 lg:px-5 lg:pt-5">
                    <h2 class="mb-2.5">На карте</h2>
                    <div class="mb-c_xs text-c_xs font-medium leading-normal md:text-sm lg:text-base"><?=$arResult["LOCATION_NAME"]?></div>
                    <div class="text-xs font-medium text-t-3 dark:text-t-2 md:text-sm lg:text-base"><?=$arResult["LOCATION_ADDRESS"]?></div>
                </div>
                <div class="relative w-full pb-[30%]">
	                <div class="event_map-wrap">
                    <div id="event_map" style="width: 100%; height: 600px" data-coordinates="<?=$arResult["LOCATION_COORDINATES"]?>"></div>
	                </div>
                </div>
            </div>
        <?endif;?>
    </div>

</div>

<?php
$APPLICATION->AddHeadString('<script type="application/ld+json">' . json_encode($SEO_Event_JSON) . '</script>');


