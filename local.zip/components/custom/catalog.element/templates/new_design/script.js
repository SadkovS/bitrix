$(function() {
    const mapContainerId = "event_map";
    const mapContainer = $("#"+mapContainerId);
    const folderPath = BX.message('TEMPLATE_PATH');
    const iconPath = folderPath+"/img/marker.svg";

    if(mapContainer)
    {
        ymaps.ready(init);
    }

    async function init() {
        let coordinates = $(mapContainer).data("coordinates");
		if(!coordinates) return;
        let coordinatesArray = coordinates.split(',');

        var myMap = new ymaps.Map(mapContainerId,
            {
                center: coordinatesArray,
                zoom: 13,
                controls: ['zoomControl'],
            },
        );

        const zoomControllObject = myMap.controls.get('zoomControl');
        zoomControllObject.options.set('size', 'small');
        getBtnsPosition([mapContainer[0], zoomControllObject])

        var myPlacemark = new ymaps.Placemark(coordinatesArray, null,{
            iconLayout: 'default#image',
            iconImageHref: iconPath,
            iconImageSize: [50, 50],
            iconImageOffset: [-15, -44]
        });
        myMap.behaviors.disable('scrollZoom');
        myMap.geoObjects.add(myPlacemark);

        window.addEventListener('resize', () => getBtnsPosition([mapContainer[0], zoomControllObject]));
    }

});


function getBtnsPosition([container, object]) {
    const {height} = container.getBoundingClientRect();
    const top = height / 2 - 45
    object.options.set('position', {right: 10, top});
}
