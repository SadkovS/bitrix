<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

/**
 * @var CBitrixComponentTemplate $this
 * @var CatalogElementComponent  $component
 */

use Bitrix\Main\Loader;
use Bitrix\Main\ORM;
use Bitrix\Highloadblock as HL;
use Custom\Core\Helper;

Loader::includeModule('custom.core');
Loader::includeModule('highloadblock');

$component = $this->getComponent();
$arParams  = $component->applyTemplateModifications();
if ((int)$arResult['PROPERTIES']['EVENT_ID']['VALUE'] > 0) {
    Custom\Core\Events::getEventData($arResult['PROPERTIES']['EVENT_ID']['VALUE'], $arResult);
}

$jsData = [];

$onlyFree = true;
$hasFree = false;

$arResult['BTN_DISABLED'] = true;

$minPrices = [];

foreach ($arResult['OFFERS'] as $key => &$item) {
    if ($item["CATALOG_QUANTITY"] > 0) {
        $arResult['BTN_DISABLED'] = false;

        $minPrices[] = $item["ITEM_PRICES"][0]["PRICE"];

        if ($item["ITEM_PRICES"][0]["PRICE"] > 0) {
            $onlyFree = false;
        }
        if ($item["ITEM_PRICES"][0]["PRICE"] == 0) {
            $hasFree = true;
        }
    }
}
unset($item);

if($arResult['BTN_DISABLED'])
{
    $arResult['BTN_DISABLED_TEXT'] = \Custom\Core\Events::getTicketStatus($arResult['ID']);
}

$arResult['ONLY_FREE'] = $onlyFree;
$arResult['HAS_FREE'] = $hasFree;

if ($minPrices) {
    $arResult["MIN_PRICE"] = min($minPrices);
}
$arResult["MIN_PRICE_FORMAT"] = Helper::priceFormat($arResult["MIN_PRICE"]);

$eventTypeText = [];
if ($arResult["LOCATION_ROOM"])
    $eventTypeText[] = $arResult["LOCATION_ROOM"];
if ($arResult["LOCATION_ADDRESS"])
    $eventTypeText[] = $arResult["LOCATION_ADDRESS"];

if ($eventTypeText)
    $arResult["EVENT_TYPE_TEXT"] = implode(". ", $eventTypeText);

$arParams["BASKET_URL"] = str_replace("#ELEMENT_ID#", $arResult['ID'], $arParams["BASKET_URL"]);

$arResult["ORGANIZER_PAGE_URL"] = str_replace("#ORGANIZER_ID#", $arResult['COMPANY_ID'], $arParams["ORGANIZER_PAGE_URL"]);

$arResult["SHARE"] = Helper::getShareLinks($arResult['DETAIL_PAGE_URL'], $arResult["NAME"]);

$this->__component->SetResultCacheKeys(array_keys($arResult));
