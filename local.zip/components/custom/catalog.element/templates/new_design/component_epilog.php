<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if($arResult["CATEGORY_NAME"] && $arResult["CATEGORY_URL"])
{
    $APPLICATION->AddChainItem($arResult["CATEGORY_NAME"], $arResult["CATEGORY_URL"]);
}

if($arResult["DETAIL_PICTURE"])
{
    $APPLICATION->SetPageProperty('og_image', \Custom\Core\Helper::getSiteUrl().$arResult["DETAIL_PICTURE"]);
}