<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if(isset($arResult['SeatMap']['eventId']) && isset($arResult['SeatMap']['publicKey']))
{
    $APPLICATION->SetPageProperty('viewport', '<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1, maximum-scale=1,  user-scalable=no">');
}