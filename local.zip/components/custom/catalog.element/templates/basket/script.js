function redirectToPayment() {
	document.location.href = basketSettings.order_url;
}
const debounce = (fnc, ms) => {
	let timeout;
	function wrapper(){
		const fnCall = () => fnc.apply(this, arguments);
		clearTimeout(timeout);
		timeout = setTimeout(fnCall, ms);
	}

	return wrapper;
}

function onMessage(event) {
	var data = event.data;

	if (typeof window[data.func] == "function") {
		window[data.func].call(null, data.message);
	}
}

if (window.addEventListener) {
	window.addEventListener("message", onMessage, false);
} else if (window.attachEvent) {
	window.attachEvent("onmessage", onMessage, false);
}

function seat_delete()
{
	let id = $(this).parent("div[data-seat-map-id]").data("seat-map-id");
	let is_created_seat_map = $(this).parent("div[data-seat-map-id]").data("is-created-seat-map");

	if(id)
		seatmapDeleteFromCart(id);
	else if(is_created_seat_map)
	{
		id = $(this).parent("div[data-offer-id]").data("offer-id");
		seatmapDeleteFromGaCart(id);

		calculate_sum();
	}
	else
	{
		id = $(this).parent("div[data-offer-id]").data("offer-id");

		let quantityInput = $(".jq-quantity[data-id="+id+"]");
		$(quantityInput).val($(quantityInput).val() - 1);

		calculate_sum(id);
	}
}

function calculate_sum(offer_id) {
	const event_id = basketSettings.event_id;
	const session_key = "tickets_"+event_id;

	/*const buttonElement = document.querySelector('#basket_footer .btn__red.btn__buy.jq-add-to-basket');
	if (buttonElement) {
		buttonElement.classList.add('loading');
	} else {
		addLoader();
	}*/

	addLoader();

	let products = [];
	$(".jq-quantity").each(function (index, el){
		if($(el).val() > 0 || offer_id == $(el).data("id"))
			products.push({id: $(el).data("id"), quantity: $(el).val()});
	});

	if (products.length) {
		sessionStorage.setItem(session_key, JSON.stringify(products));
	} else {
		let ticketsInStorage = JSON.parse(sessionStorage.getItem(session_key));
		if(ticketsInStorage)
		{
			products = products.concat(ticketsInStorage);
		}
		else
		{
			sessionStorage.removeItem(session_key);
		}
	}

	const seatMapTickets = JSON.parse(sessionStorage.getItem('seatMapTickets'));
	if (seatMapTickets) {
		products = products.concat(seatMapTickets);
	}

	$.ajax({
		url: '',
		method: 'post',
		dataType: 'html',
		data: {'ajax_catalog':'Y', 'items': products},
		success: function(result){
			$("#basket").find("#basket_items").replaceWith($(result).find("#basket_items"));
			$("#basket").find("#basket_footer").replaceWith($(result).find("#basket_footer"));

			svgInit()

			/*if (buttonElement) {
				buttonElement.classList.remove('loading');
			} else {
				removeLoader();
			}*/

			removeLoader();
		}
	});
}



$(function() {
	calculate_sum();

	function calculateSumClick() {
		var id = $(this).data("id"),
			qnt = $(this).val(),
			catalog_avail = JSON.parse( basketSettings.catalog_avail );

		if(parseInt(catalog_avail[id]["MAX_QUANTITY"]) >= parseInt(qnt) && parseInt(catalog_avail[id]["QUANTITY"]) >= parseInt(qnt))
		{
			calculate_sum(id);
		}
		else
		{
			if(parseInt(catalog_avail[id]["MAX_QUANTITY"]) > parseInt(catalog_avail[id]["QUANTITY"]))
				$(this).siblings(".jq-quantity").val(catalog_avail[id]["QUANTITY"]);
			else
				$(this).siblings(".jq-quantity").val(catalog_avail[id]["MAX_QUANTITY"]);

			calculate_sum(id);

			//removeLoader();
		}


	}

	$(document).on("change", ".jq-quantity",  debounce(calculateSumClick, 1000));

	$(document).on("click", ".seat_delete",  debounce(seat_delete, 500));

	$(document).on("click", ".tickets__quantity-item-delete",  function () {
		$(this).siblings('.tickets__quantity-item-controls').find(".jq-quantity").val(0);

		calculate_sum();
	});

	$(document).on("click", ".jq-add-to-basket",  function () {
		const event_id = basketSettings.event_id;
		const session_key = "tickets_"+event_id;

		/*const buttonElement = document.querySelector('#basket_footer .btn__red.btn__buy.jq-add-to-basket');
		if (buttonElement) {
			buttonElement.classList.add('loading');
		} else {
			addLoader();
		}*/

		addLoader();

		var products = [];
		$(".jq-quantity").each(function (index, el){
			if($(el).val() > 0)
			{
				products.push({id: $(el).data("id"), quantity: $(el).val()});
			}
		});

		const seatMapTickets = JSON.parse(sessionStorage.getItem('seatMapTickets'));
		if (seatMapTickets) {
			products = products.concat(seatMapTickets);
			console.log(JSON.stringify(products));
		}

		if(products.length)
		{
			BX.ajax.runComponentAction("custom:basket", "add", {
				mode: "class",
				data: {items: products}
			}).then(function (response) {
				//sessionStorage.removeItem('seatMapTickets');
				//sessionStorage.removeItem(session_key);
				redirectToPayment();
			}, function (response) {
				showToast(response.data.ajaxRejectData);

				/*if (buttonElement) {
					buttonElement.classList.remove('loading');
				} else {
					removeLoader();
				}*/

				removeLoader();
			});
		}
		else
		{
			/*if (buttonElement) {
				buttonElement.classList.remove('loading');
			} else {
				removeLoader();
			}*/

			removeLoader();
		}
	});

	//$('.footer').hide();
	$('.header').hide();

	$(document).on("click", "[data-back]",  function () {
		window.history.back();
	})
});
