<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Catalog\ProductTable;
use Bitrix\Main\Config\Option;


/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>
<?php if (isset($arResult['SeatMap']['eventId']) && isset($arResult['SeatMap']['publicKey'])) : ?>
    <link rel="stylesheet" href="/local/templates/main/css/seatmap.css?<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/local/templates/main/css/seatmap.css') ?>">
    <script src="<?= Option::get('custom.core', 'SEAT_MAP_BOOKING_API_Host'); ?>/static/seatmap-booking-renderer.js"></script>
    <script src="/local/templates/main/js/seatmap.js?<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/local/templates/main/js/seatmap.js') ?>"></script>
    <script>
        const seatMapSettings = {
            pid: '<?= $arResult['ID'] ?>',
            publicKey: '<?= $arResult['SeatMap']['publicKey'] ?>',
            baseUrl: '<?= $arResult['SeatMap']['bookingUrl'] ?>',
            eventId: '<?= $arResult['SeatMap']['eventId'] ?>',
            reloadTimeout: <?= $arResult['SeatMap']['reloadTimeout'] ?>,
            disabled: <?= json_encode($arResult['SeatMap']['disabled']); ?>,
            pricesQuantity: <?= json_encode(($arResult['SeatMap']['pricesQuantity'])); ?>,
            pricesIds: <?= json_encode(($arResult['SeatMap']['pricesIds'])); ?>,
            pricesComments: <?= json_encode(($arResult['SeatMap']['pricesComments'])); ?>,
        };
    </script>
<?php endif; ?>

<script>
    const basketSettings = {
        event_id: '<?= $arResult['PROPERTIES']['EVENT_ID']['VALUE'] ?>',
        catalog_avail: '<?= json_encode($arResult['JS_DATA']) ?>',
        order_url: '<?= $arResult["ORDER_URL"] ?>',
    };
</script>
<main id="basket" class="flex flex-auto flex-col">
    <section id="basket_section" class="flex flex-auto flex-col">
        <?if($_REQUEST['ajax_catalog']=='Y')
            $APPLICATION->RestartBuffer();?>
        <div class="container__wide inline-flex h-full flex-auto flex-col gap-2.5 py-2.5 md:gap-5 md:pb-5 md:pt-2.5 lg:py-5">
            <div class="mb-2 inline-flex flex-col gap-2 px-c_narrow md:mb-0 lg:flex-row-reverse lg:items-start lg:justify-between">
                <a href="<?=$arResult["PRODUCT_URL"]?>" class="link__red" type="button">
                    <i class="svg_icon-arrow rotate-[215deg]"></i>
                    <span>Отмена</span>
                </a>
                <div class="inline-flex flex-col gap-c_sm">
                    <span class="text-sm font-medium dark:text-white md:text-sm lg:text-base"><?=$arResult["NAME"]?></span>
                    <div class="inline-flex flex-col gap-c_sm lg:flex-row lg:gap-5">
                        <?if($arResult['EVENT_TYPE'] != "online"):?>
                            <span class="text-c_xs font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm lg:text-base"><?=$arResult["LOCATION_ADDRESS"]?></span>
                        <?endif;?>
                        <?if($arResult['DATES_GROUP_STR']):?>
                            <span class="text-c_xs font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm lg:text-base"><?=$arResult['DATES_GROUP_STR']?></span>
                        <?else:?>
                            <span class="text-c_xs font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm lg:text-base"><?=$arResult["DATE_TIME"]["DATE_RU"]?> <?=$arResult["DATE_TIME"]["TIME"]?></span>
                        <?endif;?>
                    </div>
                </div>
            </div>
            <?if($arResult['SIT_MAP']):?>
            <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 laptop:p-c_lg">
                <?else:?>
                <div class="relative inline-flex flex-auto flex-col gap-5 overflow-y-auto rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 laptop:p-c_lg">
                    <?endif;?>

                    <?if($arResult['SIT_MAP'] && !$_REQUEST['ajax_catalog']):?>

                        <div class="h2 dark:text-white">Выбор места</div>
                        <div class="h-frame sm:h-frame-sm md:h-frame-md lg:h-frame-lg laptop:h-frame-laptop relative self-stretch overflow-hidden rounded-c_xlg">
                            <div class="absolute left-0 top-0 size-full">
                                <div id="seatmap-prices"></div>
                                <div id="seatmap-message"></div>
                                <div id="seatmap-schema"></div>
                                <div class="seatmap-zoom-button-list">
                                    <div class="seatmap-zoom-button" onclick="seatmapRenderer.zoomIn()">+</div>
                                    <div class="seatmap-zoom-button" onclick="seatmapRenderer.zoomOut()">–</div>
                                </div>
                            </div>
                        </div>
                        <div id="seatmap-ga-tooltip" class="ticket-buy-modal">
                            <div class="ticket-buy-modal__title"></div>
                            <div class="ticket-buy-modal__price"><span class="font-gothic"></span> <span class="ticket-buy-modal__currency">₽</span></div>
                            <form action="" class="ticket-buy-modal__foot">

                                <input type="hidden" name="id">
                                <div class="quantity" data-quantity data-max="1">
                                    <button class="quantity__btn jq-change-quantity minus" type="button">
                                        <i class="svg_icon-minus"></i>
                                    </button>
                                    <input class="ga-quantity" type="text" value="0" readonly="">
                                    <button class="quantity__btn jq-change-quantity plus" type="button">
                                        <i class="svg_icon-plus"></i>
                                    </button>
                                </div>

                                <button class="btn__red btn__buy">
                                    <span class="font-gothic">В корзину</span>
                                </button>
                            </form>
                        </div>

                    <?endif;?>

                        <?foreach($arResult['OFFERS_GROUP'] as $key => $group):?>
                            <?if(!$group["ITEMS"])continue;?>

                        <?if($key == "ADDITION"):?>
                            <div class="h2 dark:text-white"><?=$group["NAME"]?></div>
                        <?endif;?>

                        <?if(count($group["ITEMS"]) <= 3 && !$arResult['SIT_MAP']):?>
                            <div id="basket_items" class="inline-flex w-full gap-2.5 laptop:grid laptop:grid-cols-3">
                        <?elseif(count($group["ITEMS"]) == 4 && !$arResult['SIT_MAP']):?>
                            <div id="basket_items" class="inline-flex w-full">
                        <?elseif(count($group["ITEMS"]) > 4 || $arResult['SIT_MAP']):?>
                            <div id="basket_items" class="inline-flex w-full">
                        <?endif;?>

                            <?if(count($group["ITEMS"]) <= 3 && !$arResult['SIT_MAP']):?>
                                <div class="inline-flex w-full flex-col gap-2.5 md:gap-c_md lg:grid lg:grid-cols-2 laptop:col-start-2 laptop:flex laptop:flex-col">
                            <?elseif(count($group["ITEMS"]) == 4 && !$arResult['SIT_MAP']):?>
                                <div class="inline-flex w-full flex-col gap-2.5 md:gap-c_md lg:grid lg:grid-cols-2 laptop:mx-auto laptop:w-2/3">
                            <?elseif(count($group["ITEMS"]) > 4 || $arResult['SIT_MAP']):?>
                                <div class="inline-flex w-full flex-col gap-2.5 md:gap-c_md lg:grid lg:grid-cols-2 laptop:grid-cols-3">
                            <?endif;?>

                                <?foreach($group["ITEMS"] as $key => $item):?>
                                    <div class="group">
                                        <div class="group-[.active]:bg-stone inline-flex h-fit w-full cursor-pointer flex-col items-start justify-between gap-2 rounded-c_lg border bg-white p-c_md transition-colors duration-300 dark:border-background-1 dark:bg-primary dark:group-[.active]:bg-background-1 lg:gap-3 lg:p-5 h-full">
                                            <div class="inline-flex flex-col gap-1.5">
                                                <div class="inline-flex items-center gap-2.5">
                                                    <span class="text-sm font-medium dark:text-white md:text-base"><?=$item["PROPERTIES"]["TYPE"]["VALUE"]?></span>
                                                    <span class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm ">
                                                        <? if ($item["PROPERTIES"]['SHOW_STOCK']['VALUE']): ?>
                                                            <?=$item["CATALOG_QUANTITY_TEXT_DECLINATION"]?>
                                                        <? endif; ?>
                                                    </span>
                                                </div>
                                                <span class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm "><?=$item["~PREVIEW_TEXT"]?></span>
                                            </div>
	                                          <div class="flex-1"></div>
                                            <div class="inline-flex flex-col gap-[3px] md:flex-row md:items-center md:gap-c_md">
                                                <div class="inline-flex items-center gap-2.5">
                                                    <?if($item["PRICE"] != $item["ITEM_PRICES"][0]["PRICE"]):?>
                                                        <div class="old-price font-gothic text-base text-t-2 md:text-xl whitespace-nowrap">
                                                            <?=$item["ITEM_PRICES"][0]["PRICE"]?>
                                                            <b class="font-[Montserrat]">₽</b>
                                                        </div>
                                                    <?endif;?>
                                                    <div class="font-gothic text-base dark:text-white md:text-xl whitespace-nowrap">
                                                        <?=$item["PRICE"]?>
                                                        <b class="font-[Montserrat]">₽</b>
                                                    </div>
                                                </div>
                                                <?if($item["RULE"]):?>
                                                    <span class="text-xs font-medium leading-normal text-t-3 dark:text-t-2 lg:text-sm">Скидка «<?=$item["RULE"]["UF_NAME"]?>»</span>
                                                <?endif;?>
                                            </div>
                                            <div class="quantity" data-quantity data-max="<?=$item["MAX_QUANTITY"]?>">
                                                <button class="quantity__btn minus jq-change-quantity" type="button"><i class="svg_icon-minus"></i></button>
                                                <input class="jq-quantity" type="text" data-id="<?=$item["ID"]?>" data-name="<?=$item["PROPERTIES"]["TYPE"]["VALUE"]?>" data-price="<?=$item["ITEM_PRICES"][0]["PRICE"]?>" value="<?=$item["SELECT_QUANTITY"]?>" readonly />
                                                <button class="quantity__btn plus jq-change-quantity" type="button"><i class="svg_icon-plus"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                <?endforeach;?>
                            </div>
                            </div>
                        <?endforeach;?>






                </div>
                <div  id="basket_footer" class="inline-flex flex-col gap-2.5 pb-24 md:gap-5 laptop:flex-row laptop:gap-c_2xl laptop:pb-0">
                    <div class="mb-[-10px] inline-flex snap-x snap-mandatory gap-2.5 overflow-y-auto px-c_narrow pb-2.5 md:px-5 lg:gap-c_md lg:px-0 laptop:flex-auto">

                        <?foreach ($arResult['SEATS'] as $seat):?>
                            <div
                                    data-offer-id="<?=$seat["id"]?>"
                                    data-is-created-seat-map="<?=$seat["is_created_seat_map"]?>"
                                    data-seat-map-id="<?=$seat["seat_map_id"]?>"
                                    class="inline-flex flex-col gap-[3px] snap-center border-l-[5px] bg-white dark:bg-background-2 dark:hover:bg-background-1 transition-colors duration-300 border-warning relative py-c_sm pl-[12px] hover:bg-icons-1 md:pl-5 md:pr-c_lg pr-5 bg-background-2 rounded-l-c_xs rounded-r-c_sm lg:rounded-r-c_lg *:whitespace-nowrap md:py-2 md:whitespace-normal lg:pr-[32px]">
                                <?if($seat["props_str"]):?>
                                <span class="dark:text-white text-xs font-medium md:text-sm lg:text-base"><?=$seat["props_str"]?></span>
                                <?endif;?>
                                <span
                                        class="text-mic font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm lg:text-base md:text-xs lg:text-sm"><?=$seat["name"]?></span>
                                <span class="dark:text-white text-xs font-medium md:text-sm lg:text-base"><?=$seat["price"]?> ₽</span>
                                <button class="absolute text-warning top-0 right-0 p-c_sm text-[10px] md:py-2 md:px-2.5 lg:text-xs seat_delete">
                                    <i class="svg_icon-cross-s"></i>
                                </button>
                            </div>
                        <?endforeach;?>

                    </div>
                    <div
                            class="fixed inset-x-0 bottom-0 z-10 inline-flex flex-shrink-0 flex-wrap items-center justify-between gap-c_md bg-icons-1 px-c_at py-5 dark:bg-primary md:px-[44px] lg:px-10 lg:pb-5 lg:pt-2.5 laptop:sticky laptop:w-fit laptop:flex-col laptop:items-end laptop:justify-end laptop:p-0" style="z-index: 100;">
                        <div class="inline-flex items-center gap-c_sm lg:gap-2.5">
                            <span class="text-xs font-medium dark:text-white md:text-sm lg:text-base"><?=$arResult['SELECT_QUANTITY_TEXT_DECLINATION']?>:</span>
                            <div class="font-gothic text-base text-warning md:text-xl lg:text-3xl">
                                <?=$arResult['SUMM']?>
                                <b class="font-[Montserrat]">₽</b>
                            </div>
                        </div>
                        <button type="button" class="btn__red btn__buy jq-add-to-basket" <?= $arResult['SELECT_QUANTITY'] === 0 ? "disabled" : "" ?>>
                            <span class="font-gothic text-xs sm:text-sm md:text-base lg:text-xl xl:text-lg">Далее</span>
                            <i class="svg_icon-arrow-r icon__round"></i>
                        </button>
                    </div>
                </div>
            </div>

            <?if($_REQUEST['ajax_catalog']=='Y')
                die();?>

    </section>



</main>
