const debounce = (fnc, ms) => {
	let timeout;
	function wrapper(){
		const fnCall = () => fnc.apply(this, arguments);
		clearTimeout(timeout);
		timeout = setTimeout(fnCall, ms);
	}

	return wrapper;
}

$(function() {
	function calculate_sum()
	{
		var products = [];
		$(".jq-quantity").each(function (index, el){
			if($(el).val() > 0)
			{
				products.push({id: $(el).data("id"), quantity: $(el).val()});
			}
		});
		
		$.ajax({
			url: '',
			method: 'post',
			dataType: 'html',
			data: {'ajax_catalog':'Y', 'items': products},
			success: function(result){
				$("#quantity").find(".tickets").replaceWith($(result).find(".tickets"));
				$("#quantity").find(".popup__controls").replaceWith($(result).find(".popup__controls"));
			}
		});
	}

	function calculateSumClick() {
		var id = $(this).siblings(".jq-quantity").data("id")
		qnt = $(this).siblings(".jq-quantity").val(),
			catalog_avail = JSON.parse( localStorage.catalog_avail );

		if(parseInt(catalog_avail[id]["MAX_QUANTITY"]) >= parseInt(qnt) && parseInt(catalog_avail[id]["QUANTITY"]) >= parseInt(qnt))
		{
			calculate_sum();
		}
		else
		{
			if(parseInt(catalog_avail[id]["MAX_QUANTITY"]) > parseInt(catalog_avail[id]["QUANTITY"]))
				$(this).siblings(".jq-quantity").val(catalog_avail[id]["QUANTITY"]);
			else
				$(this).siblings(".jq-quantity").val(catalog_avail[id]["MAX_QUANTITY"]);
		}
	}
	
	$(document).on("click", ".jq-change-quantity",  debounce(calculateSumClick, 500));
	
	$(document).on("click", ".tickets__quantity-item-delete",  function () {
		$(this).siblings('.tickets__quantity-item-controls').find(".jq-quantity").val(0);
		
		calculate_sum();
	});
});

