<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$APPLICATION->IncludeComponent(
	"custom:basket",
	"basket",
	Array(
		"EVENT_DATA" => $arResult
	),
	$component
);