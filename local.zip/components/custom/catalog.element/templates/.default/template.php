<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Catalog\ProductTable;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>
<script>
	localStorage.catalog_avail = '<?=json_encode($arResult['JS_DATA'])?>';	
</script>


<?if(!empty($arResult["LOCATION_COORDINATES"])):?>
	<script src="<?=SITE_TEMPLATE_PATH?>/files/libs/mapbox/mapbox.js"></script>
	<link rel="stylesheet" href="<?=SITE_TEMPLATE_PATH?>/files/libs/mapbox/mapbox.css">
<?endif;?>

<div class="event__banner">
	<div class="event__pic">
		<?if($arResult['AGE']):?>
			<div class="event__pic-age icon-<?=$arResult['AGE']?>"></div>
		<?endif;?>
		<?if($arResult["DETAIL_PICTURE"]):?>
			<img src="<?=$arResult["DETAIL_PICTURE"]?>" alt="banner">
		<?else:?>
			<img src="<?=SITE_TEMPLATE_PATH?>/img/no_img.jpg" alt="banner">
		<?endif;?>
	</div>
	<?/*<div class="event__banner-controls">
		<button type="button" href="#" class="event__banner-button _icon-calendar"></button>
		<button type="button" href="#" class="event__banner-button _icon-net"></button>
		<button type="button" href="#" class="event__banner-button _icon-thumbup"></button>
	</div>*/?>
</div>
<div class="event__body">
    <div class="event__title">
        <h4 class="event__title-type"><?=$arResult["CATEGORY_NAME"]?></h4>
        <h1 class="h1"><?=$arResult["NAME"]?></h1>
        <div class="event__title-info">
            <?if($arResult['EVENT_TYPE'] == "online" || $arResult["LOCATION_ROOM"]):?>
                <div class="info__item">
                    <i class="_icon-point"></i>
                    <?if($arResult['EVENT_TYPE'] == "online"):?>
                        <div class="info__item-text">
                            <p>Онлайн</p>
                        </div>
                    <?else:?>
                        <div class="info__item-text">
                            <?if($arResult["LOCATION_NAME"]):?>
                                <p><?=$arResult["LOCATION_NAME"]?></p>
                            <?endif;?>
                            <?if($arResult["LOCATION_ADDRESS"]):?>
                                <p><?=$arResult["LOCATION_ADDRESS"]?></p>
                            <?endif;?>
                            <?if($arResult["LOCATION_ROOM"]):?>
                                <p><?=$arResult["LOCATION_ROOM"]?></p>
                            <?endif;?>
                        </div>
                    <?endif;?>
                </div>
            <?endif;?>
            <div class="info__item">
                <i class="_icon-clock"></i>
                <div class="info__item-text">
                    <?if($arResult["DATE_TIME"]["DATE"]):?>
                        <p><span>Начало:</span> <span><?=$arResult["DATE_TIME"]["DATE_RU"]?> <?=$arResult["DATE_TIME"]["TIME"]?></span></p>
                    <?endif;?>
                    <?if($arResult["DATE_TIME"]["DATE"]):?>
                        <p><span>Окончание:</span> <span><?=$arResult["DATE_TIME"]["DATE_END_RU"]?> <?=$arResult["DATE_TIME"]["TIME_END"]?></span></p>
                    <?endif;?>
                    <?if($arResult["DURATION"]):?>
                        <p><span>Длительность:</span> <span><?=$arResult["DURATION"]?></span></p>
                    <?endif;?>
                </div>
            </div>
        </div>
        <div class="event__detail">
            <?=$arResult["DETAIL_TEXT"]?>
        </div>
        <div class="event__title-info">
            <?if($arResult['EVENT_SITE'][0]):?>
                <div class="info__item">
                    <i class="_icon-screen"></i>
                    <div class="info__item-text">
                        <a target="_blank" href="<?=$arResult['EVENT_SITE'][0][1]?>"><?=$arResult['EVENT_SITE'][0][0]?></a>
                    </div>
                </div>
            <?endif;?>
            <?if($arResult['EVENT_FILES']):?>
                <div class="info__item">
                    <i class="_icon-document"></i>
                    <div class="info__item-text">
                        <?foreach($arResult['EVENT_FILES'] as $file):?>
                            <a target="_blank" href="<?=$file["PATH"]?>"><?=$file["ORIGINAL_NAME"]?></a>
                        <?endforeach;?>
                    </div>
                </div>
            <?endif;?>
        </div>
    </div>
    <?if(!empty($arResult["LOCATION_COORDINATES"])):?>
        <div class="event__map">
            <div class="event__map-top">
                <h3 class="h3">На карте</h3>
                <?/*<a href="#" class="btn__medium btn__blue">Купить билет от <?=$arResult["MIN_PRICE"]?> ₽</a>*/?>
            </div>
            <div id="map" class="map" data-map-icon="<?=$arResult['CATEGORY_ICON']?>" data-map="coords:[<?=$arResult["LOCATION_COORDINATES"]?>], price: [<?=$arResult["MIN_PRICE"]?>], grade: [4.8]"></div>
        </div>
    <?endif;?>
    <div class="event__buy">
        <button type="button" class="btn__big btn__blue" data-popup="#quantity" <?if($arResult['ONLY_FREE'] || $arResult['HAS_FREE_PAY']):?>style="width: 400px;"<?endif;?>>
            <?if($arResult['ONLY_FREE']):?>
                ЗАРЕГИСТРИРОВАТЬСЯ <br> БЕСПЛАТНО
            <?elseif($arResult['HAS_FREE_PAY']):?>
                ЗАРЕГИСТРИРОВАТЬСЯ
            <?elseif($arResult['ONLY_PAY']):?>
                КУПИТЬ БИЛЕТ
            <?endif;?>
        </button>
    </div>
</div>
<div class="event_buy-now" >
    <button type="button" data-sticky-item class="btn__medium btn__blue" data-popup="#quantity" <?if($arResult['ONLY_FREE'] || $arResult['HAS_FREE_PAY']):?><?endif;?>>
        <?if($arResult['ONLY_FREE']):?>
             <span style="font-size:16px;">ЗАРЕГИСТРИРОВАТЬСЯ <br> БЕСПЛАТНО</span>
        <?elseif($arResult['HAS_FREE_PAY']):?>
            <span style="font-size:16px;">ЗАРЕГИСТРИРОВАТЬСЯ</span>
        <?elseif($arResult['ONLY_PAY']):?>
            КУПИТЬ БИЛЕТ
        <?endif;?>
    </button>
</div>
<div id="popup" aria-hidden="true" class="popup">
	<div class="popup__wrapper">
		<div class="popup__content">
			<button data-close type="button" class="popup__close"><i class="_icon-cross"></i></button>
			<div class="popup__tytle">
				<h2 class="h2"><?=$arResult["NAME"]?></h2>
				<p><?=$arResult["DATE_TIME"]["DATE"]?> <?=$arResult["DATE_TIME"]["TIME"]?>. <?=$arResult["EVENT_TYPE_TEXT"]?></p>
			</div>
			<div class="prices">
				<div class="price"> <i class="green"></i> <span>800₽</span></div>
				<div class="price"> <i class="orange"></i> <span>1000₽</span></div>
				<div class="price"> <i class="blue"></i> <span>1500₽</span></div>
				<div class="price"> <i class="red"></i> <span>1700₽</span></div>
				<div class="price"> <i class="purple"></i> <span>2000₽</span></div>
			</div>
			<div class="popup__controls">
				<button class="btn__popup" type="button" data-popup="#card">Перейти к оплате</button>
			</div>
		</div>
	</div>
</div>

<div id="quantity" aria-hidden="true" class="popup <?if($arResult['FRAME_SRC']):?>seating__popup<?endif;?>">
	<div class="popup__wrapper">
		<div class="popup__content">
			<button data-close type="button" class="popup__close"><i class="_icon-cross"></i></button>
			<div class="popup__tytle">
				<h2 class="h2"><?=$arResult["NAME"]?></h2>
				<p><?=$arResult["DATE_TIME"]["DATE_RU"]?> <?=$arResult["DATE_TIME"]["TIME"]?>.
					<?if($arResult['EVENT_TYPE'] == "online"):?>
						Онлайн
					<?else:?> 
						<?=$arResult["EVENT_TYPE_TEXT"]?>
					<?endif;?>
				</p>
			</div>
			
			<?if($arResult['FRAME_SRC']):?>
				<div class="seating" id="sizetracker">
					<iframe id="seats_frame" name="seats_frame" src="<?=$arResult['FRAME_SRC']?>" frameborder="0">
					    Ваш браузер не поддерживает плавающие фреймы!
					</iframe>
				</div>
			<?else:?>
				<?if($_REQUEST['ajax_catalog']=='Y')
	   					$APPLICATION->RestartBuffer();?>
	   				<div>
						<div class="tickets">
							<div class="tickets__quantity-list">
								<?foreach($arResult['OFFERS'] as $key => $item):?>
									<div class="tickets__quantity-item">
										<div class="tickets__quantity-item-info">
											<span class="tickets__item-label"><?=$item["PROPERTIES"]["TYPE"]["VALUE"]?></span>
											<?if($item["~PREVIEW_TEXT"]):?>
												<span class="tickets__item-description"><?=$item["~PREVIEW_TEXT"]?></span>
											<?endif;?>
											<div class="tickets__item-price">
												<span class="tickets__item-label"><?=$item["PRICE"]?>₽</span>
												<?if($item["PRICE"] != $item["ITEM_PRICES"][0]["PRICE"]):?>
													<span class="tickets__item-old-price"><?=$item["ITEM_PRICES"][0]["PRICE"]?>₽</span>
												<?endif;?>
												<?if($item["RULE"]):?>
													<span class="tickets__item-promo">Скидка «<?=$item["RULE"]["UF_NAME"]?>»</span>
												<?endif;?>
											</div>
										</div>
										<div class="tickets__quantity-item-controls" data-quantity>
											<button class="btn__icon jq-change-quantity" type="button"><i class="_icon-minus"></i></button>
											<input class="jq-quantity" type="text" data-id="<?=$item["ID"]?>" data-name="<?=$item["PROPERTIES"]["TYPE"]["VALUE"]?>" data-price="<?=$item["ITEM_PRICES"][0]["PRICE"]?>" value="<?=$item["SELECT_QUANTITY"]?>" readonly>
											<button class="btn__icon jq-change-quantity" type="button"><i class="_icon-plus"></i></button>
										</div>
										<button class="tickets__quantity-item-delete"><i class="_icon-cross"></i></button>
									</div>
								<?endforeach;?>
							</div>
							<div class="tickets__total">
								<span>Итого к оплате</span>
								<span><span class="jq-price-sum"><?=$arResult['SUMM']?></span> ₽</span>
							</div>
						</div>
						<div class="popup__controls">
							<button class="btn__popup jq-add-to-basket" data-popup='#card' type="button" <?if($arResult['BTN_DISABLED']):?>disabled<?endif;?>>
								Перейти к оформлению
							</button>
						</div>
					</div>
				<?if($_REQUEST['ajax_catalog']=='Y')
   					die();?>
		    <?endif;?>
		</div>
	</div>
</div>
<?
//echo "<pre>"; print_r($arResult['OFFERS']); echo "</pre>";
