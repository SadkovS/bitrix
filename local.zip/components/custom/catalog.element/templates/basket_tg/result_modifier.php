<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

/**
 * @var CBitrixComponentTemplate $this
 * @var CatalogElementComponent  $component
 */

use Bitrix\Main\Loader;
use Bitrix\Main\ORM;
use Bitrix\Highloadblock as HL;
use Custom\Core\Helper as Helper;

Loader::includeModule('custom.core');
Loader::includeModule('highloadblock');

$component = $this->getComponent();
$arParams  = $component->applyTemplateModifications();
if ((int)$arResult['PROPERTIES']['EVENT_ID']['VALUE'] > 0) {
	Custom\Core\Events::getEventData($arResult['PROPERTIES']['EVENT_ID']['VALUE'], $arResult, true);
}

$jsData = [];

$arTextDeclination = ["билет", "билета", "билетов"];

$onlyFree = true;
$onlyPay = true;
$hasFree = false;
$hasPay = false;
$hideAdditions = true;

$isAjax = $_REQUEST["ajax_catalog"] && $_REQUEST["ajax_catalog"] == "Y";
$selectCountItems = [];

if($isAjax)
{
	foreach ($_REQUEST["items"] as $item)
	{
        if($item["quantity"] > 0)
		    $selectCountItems[$item["id"]] += $item["quantity"];
	}
}

$arResult['SUMM'] = 0;
$arResult['SELECT_QUANTITY'] = 0;

$arResult['BTN_DISABLED'] = true;
foreach($arResult['OFFERS'] as $key => &$item)
{
    if ($item["CATALOG_QUANTITY"] <= 0)
    {
        unset($arResult['OFFERS'][$key]);
    }
    else {
        $jsData[$item["ID"]] = [
            "ID" => $item["ID"],
            "MAX_QUANTITY" => $item["PROPERTIES"]["MAX_QUANTITY"]["VALUE"],
            "QUANTITY" => $item["CATALOG_QUANTITY"],
        ];

        $arResult['BTN_DISABLED'] = false;

        $item["SELECT_QUANTITY"] = 0;

        $item["MAX_QUANTITY"] = $item["CATALOG_QUANTITY"];

        $item["CATALOG_QUANTITY_TEXT_DECLINATION"] = ($item["CATALOG_QUANTITY"] == 1)? "остался": "осталось";
        $item["CATALOG_QUANTITY_TEXT_DECLINATION"] .= " " . Helper::declination($item["CATALOG_QUANTITY"], $arTextDeclination);

        if ($item["PROPERTIES"]["MAX_QUANTITY"]["VALUE"] < $item["MAX_QUANTITY"]) {
            $item["MAX_QUANTITY"] = $item["PROPERTIES"]["MAX_QUANTITY"]["VALUE"];
        }

        if ($isAjax && $selectCountItems[$item["ID"]]) {
            $item["SELECT_QUANTITY"] = $selectCountItems[$item["ID"]];
        }

        if ($item["ITEM_PRICES"][0]["PRICE"] > 0) {
            $onlyFree = false;
            $hasPay = true;
        }
        if ($item["ITEM_PRICES"][0]["PRICE"] == 0) {
            $hasFree = true;
            $onlyPay = false;
        }
    }
}
unset($item);

\Custom\Core\Discount::getOptimalPriceInCatalog($arResult['OFFERS'], $arResult['PROPERTIES']['EVENT_ID']['VALUE']);

$arResult['OFFERS_GROUP'] = [
    "MAIN" => ["NAME" => "Входной билет"],
    "ADDITION" => ["NAME" => "Прочие билеты и услуги"],
];

foreach($arResult['OFFERS'] as $key => &$item)
{
	if($item["SELECT_QUANTITY"])
	{
		$item["PRICE"] = CurrencyFormat($item["PRICE"], "RUB");

        $arResult['SELECT_QUANTITY'] += $item["SELECT_QUANTITY"];
		$arResult['SUMM'] += $item["SUMM"];
	}

    $item["PRICE"] = Helper::priceFormat($item["PRICE"]);
    $item["ITEM_PRICES"][0]["PRICE"] = Helper::priceFormat($item["ITEM_PRICES"][0]["PRICE"]);

    if($arResult['SIT_MAP'])
    {
        if($item['PROPERTIES']['IS_CREATED_SEAT_MAP']['VALUE'])
        {
            $arResult['OFFERS_SEAT_MAP'][$item["ID"]] = $item;
        }
        else
        {
            $arResult['OFFERS_GROUP']["ADDITION"]["ITEMS"][] = $item;
            $hideAdditions = false;
        }

    }
    else
    {
        if(!$item['PROPERTIES']['IS_CREATED_SEAT_MAP']['VALUE'])
        {
            $arResult['OFFERS_GROUP']["MAIN"]["ITEMS"][] = $item;
            $hideAdditions = false;
        }
    }

    $arResult['TICKET_BOTTOM'][$item["ID"]] = [
        "price" => $item["PRICE"],
        "name" => $item["PROPERTIES"]["TYPE"]["VALUE"],
        "is_created_seat_map" => $item["PROPERTIES"]["IS_CREATED_SEAT_MAP"]["VALUE"],
    ];
}
unset($item);

$arResult['SELECT_QUANTITY_TEXT_DECLINATION'] = Helper::declination($arResult['SELECT_QUANTITY'], $arTextDeclination);
$arResult['SUMM'] = Helper::priceFormat($arResult['SUMM']);

if($_REQUEST["items"])
{
    \CBitrixComponent::includeComponentClass("custom:basket");

    foreach ($_REQUEST["items"] as $item)
    {
        if($item["id"] && $arResult['TICKET_BOTTOM'][$item["id"]])
        {
            $item = array_merge($item, $arResult['TICKET_BOTTOM'][$item["id"]]);

            $props = [];
            foreach ($item["props"] as $k => $v)
            {
                if(\BasketCustom::basketPropsShow[$k] && $k != "sector")
                    $props[] = $v." ".\BasketCustom::basketPropsShow[$k];
            }

            if($props)
            {
                $item["props_str"] = implode(", ", $props);
            }

            for($i = 1; $i <= $item["quantity"]; $i++)
            {
                $arResult['SEATS'][] = $item;
            }

        }

    }
}

$arResult["SUMM"] = CurrencyFormat($arResult["SUMM"], "RUB");

$arResult['HIDE_ADDITIONS'] = $hideAdditions;
$arResult['ONLY_FREE'] = $onlyFree;
$arResult['ONLY_PAY'] = $onlyPay;

if($hasFree && $hasFree)
{
	$arResult['HAS_FREE_PAY'] = true;
}
else
{
	$arResult['HAS_FREE_PAY'] = false;	
}

$eventTypeText = [];
if($arResult["LOCATION_ROOM"])
	$eventTypeText[] = $arResult["LOCATION_ROOM"];
if($arResult["LOCATION_ADDRESS"])
	$eventTypeText[] = $arResult["LOCATION_ADDRESS"];

if($eventTypeText)
	$arResult["EVENT_TYPE_TEXT"] = implode(". ", $eventTypeText);

$arResult['JS_DATA'] = $jsData;

$arResult["ORDER_URL"] = str_replace(
    ["#ELEMENT_ID#", "#WIDGET_ID#"],
    [$_REQUEST["ELEMENT_ID"], $_REQUEST["WIDGET_ID"]],
    $arParams["ORDER_URL"]
);

if($_REQUEST["preview"] && $_REQUEST["preview"] == "Y")
{
    $arResult["ORDER_URL"] .= "?preview=Y";
}
else
{
    $arResult["REQUEST_PARAMS"] = (new \Custom\Core\Session())->makeRequest(session_id());
    $arResult["ORDER_URL"] .= "?".$arResult["REQUEST_PARAMS"][0]."=".$arResult["REQUEST_PARAMS"][1];
}


$this->__component->SetResultCacheKeys(array_keys($arResult));
