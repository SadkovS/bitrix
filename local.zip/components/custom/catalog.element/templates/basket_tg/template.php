<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Catalog\ProductTable;
use Bitrix\Main\Config\Option;


/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>
<?php if (isset($arResult['SeatMap']['eventId']) && isset($arResult['SeatMap']['publicKey'])) : ?>
    <link rel="stylesheet" href="/local/templates/main/css/seatmap.css?<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/local/templates/main/css/seatmap.css') ?>">
    <script src="<?= Option::get('custom.core', 'SEAT_MAP_BOOKING_API_Host'); ?>/static/seatmap-booking-renderer.js"></script>
    <script src="/local/templates/main/js/seatmap.js"></script>
    <script>
        const seatMapSettings = {
            pid: '<?= $arResult['ID'] ?>',
            publicKey: '<?= $arResult['SeatMap']['publicKey'] ?>',
            baseUrl: '<?= $arResult['SeatMap']['bookingUrl'] ?>',
            eventId: '<?= $arResult['SeatMap']['eventId'] ?>',
            reloadTimeout: <?= $arResult['SeatMap']['reloadTimeout'] ?>,
            disabled: <?= json_encode($arResult['SeatMap']['disabled']); ?>,
            pricesQuantity: <?= json_encode(($arResult['SeatMap']['pricesQuantity'])); ?>,
            pricesIds: <?= json_encode(($arResult['SeatMap']['pricesIds'])); ?>,
            pricesComments: <?= json_encode(($arResult['SeatMap']['pricesComments'])); ?>,
        };
    </script>
<?php endif; ?>

<script>
    window.basketSettings = {
        event_id: '<?= $arResult['PROPERTIES']['EVENT_ID']['VALUE'] ?>',
        catalog_avail: '<?= json_encode($arResult['JS_DATA']) ?>',
        order_url: '<?= $arResult["ORDER_URL"] ?>',
        key: '<?= $arResult["REQUEST_PARAMS"][0] ?>',
        val: '<?= $arResult["REQUEST_PARAMS"][1] ?>',
    };
</script>

<input name="WIDGET_ID" class="js-widget-uuid" value="<?=$_REQUEST["WIDGET_ID"]?>" style="display: none;">

<?if($_REQUEST['ajax_catalog']=='Y')
    $APPLICATION->RestartBuffer();?>
<div id="basket" class="iframe-widget">


    <div class="iframe-widget-header">
        <div class="iframe-widget-header__left">
            <div class="widget-event-info">
                <div class="widget-event-info__img">
                    <img src="<?=$arResult["DETAIL_PICTURE"]?>" alt="" class="fill-img">
                </div>
                <div class="widget-event-info__body">
                    <div class="widget-event-info__title"><?=$arResult["NAME"]?></div>

                    <div class="widget-event-info__desc">
                        <?if($arResult['EVENT_TYPE'] != "online"):?>
                            <p><?=$arResult["LOCATION_ADDRESS_FULL"]?></p>
                        <?endif;?>
                        <?if($arResult['DATES_GROUP']):?>
                            <?foreach($arResult['DATES_GROUP'] as $dates):?>
                                <p><?=$dates["date"]?> <?=$dates["time"]?></p>
                            <?endforeach;?>
                        <?else:?>
                            <p><?=$arResult["DATE_TIME"]["DATE_RU"]?> <?=$arResult["DATE_TIME"]["TIME"]?></p>
                        <?endif;?>
                    </div>

                </div>
            </div>
        </div>
        <div class="iframe-widget-header__right">
            <div class="iframe-widget-header__logo">
                <img class="svg" src="<?=SITE_TEMPLATE_PATH?>/assets/img/logo.svg" alt="">
            </div>
        </div>
    </div>
    <?if($arResult['BTN_DISABLED']):?>
        <div class="seatmap-widget seatmap-widget--center">
            <div class="h3 seatmap-widget__end-title">Все билеты уже распроданы</div>
            <p>Возможно, появятся новые. Следите за обновлениями!</p>
        </div>
    <?else:?>
       <?if($arResult['SIT_MAP'] && !$_REQUEST['ajax_catalog']):?>
           <div class="h3 seatmap-section-title">Выбор места</div>
           <div class="seatmap-widget seatmap-widget--margin">
               <div class="h-frame sm:h-frame-sm md:h-frame-md lg:h-frame-lg laptop:h-frame-laptop relative self-stretch overflow-hidden rounded-c_xlg">
                   <div class="absolute left-0 top-0 size-full">
                       <div id="seatmap-prices"></div>
                       <div id="seatmap-message"></div>
                       <div id="seatmap-schema"></div>
                       <div class="seatmap-zoom-button-list">
                           <div class="seatmap-zoom-button" onclick="seatmapRenderer.zoomIn()">+</div>
                           <div class="seatmap-zoom-button" onclick="seatmapRenderer.zoomOut()">–</div>
                       </div>
                   </div>
               </div>
               <div id="seatmap-ga-tooltip" class="ticket-buy-modal">
                   <div class="ticket-buy-modal__title"></div>
                   <div class="ticket-buy-modal__price"><span class="font-gothic"></span> <span class="ticket-buy-modal__currency">₽</span></div>
                   <form action="" class="ticket-buy-modal__foot">

                       <input type="hidden" name="id">
                       <div class="quantity" data-quantity data-max="1">
                           <button class="quantity__btn jq-change-quantity minus" type="button">
                               <i class="svg_icon-minus"></i>
                           </button>
                           <input class="ga-quantity" type="text" value="0" readonly="">
                           <button class="quantity__btn jq-change-quantity plus" type="button">
                               <i class="svg_icon-plus"></i>
                           </button>
                       </div>

                       <button class="btn__red btn__buy">
                           <span class="font-gothic">В корзину</span>
                       </button>
                   </form>
               </div>
           </div>
       <?endif;?>

        <?if(!$arResult['HIDE_ADDITIONS']):?>
            <div
                class="seatmap-body <?if($arResult['SIT_MAP']):?>seatmap-body--auto seatmap-body--margin<?else:?>seatmap-body--center<?endif;?>"
                id="basket_items">

                <?if($arResult['SIT_MAP']):?>
                    <div class="h3 seatmap-body__title">Прочие билеты и услуги</div>
                <?endif;?>

                <div class="seatmap-ticket-grid">

                    <?foreach ($arResult['OFFERS_GROUP'] as $group):?>
                        <?if(!$group["ITEMS"])continue;?>
                        <?foreach($group["ITEMS"] as $key => $item):?>
                            <div class="seatmap-ticket-grid-itm <?if($item["SELECT_QUANTITY"] > 0):?>has-val<?endif;?>">
                                <div class="seatmap-ticket-grid-itm__head">
                                    <div class="seatmap-ticket-grid-itm__title"><?=$item["PROPERTIES"]["TYPE"]["VALUE"]?></div>
                                    <? if ($item["PROPERTIES"]['SHOW_STOCK']['VALUE']): ?>
                                        <div class="seatmap-ticket-grid-itm__seats">
                                            <?=$item["CATALOG_QUANTITY_TEXT_DECLINATION"]?>
                                        </div>
                                    <? endif; ?>
                                </div>
                                <div class="seatmap-ticket-grid-itm__desc"><?=$item["~PREVIEW_TEXT"]?></div>
                                <div class="seatmap-ticket-grid-itm__sep"></div>
                                <div class="seatmap-ticket-grid-itm__info">
                                    <?if($item["PRICE"] != $item["ITEM_PRICES"][0]["PRICE"]):?>
                                        <span class="seatmap-ticket-grid-itm__price old"><?=$item["ITEM_PRICES"][0]["PRICE"]?>&nbsp;₽</span>
                                    <?endif;?>
                                    <span class="seatmap-ticket-grid-itm__price"><?=$item["PRICE"]?>&nbsp;₽</span>
                                    <?if($item["RULE"]):?>
                                        <div class="seatmap-ticket-grid-itm__info__desc">Скидка «<?=$item["RULE"]["UF_NAME"]?>»</div>
                                    <?endif;?>

                                </div>
                                <div class="seatmap-ticket-grid-itm__count">
                                    <div class="quantity" data-max="<?=$item["MAX_QUANTITY"]?>" data-quantity="0">
                                        <button class="quantity__btn minus jq-change-quantity <?=(int)$item["SELECT_QUANTITY"] <= 0 ? 'disabled' : ''?>" type="button"><i class="svg_icon-minus"></i></button>
                                        <input class="jq-quantity" data-id="<?=$item["ID"]?>" data-name="<?=$item["PROPERTIES"]["TYPE"]["VALUE"]?>" data-price="<?=$item["ITEM_PRICES"][0]["PRICE"]?>" value="<?=$item["SELECT_QUANTITY"]?>" readonly="" type="text">
                                        <button class="quantity__btn plus jq-change-quantity <?=(int)$item["MAX_QUANTITY"] <= (int)$item["SELECT_QUANTITY"] ? 'disabled' : ''?>" type="button"><i class="svg_icon-plus"></i></button>
                                    </div>
                                </div>
                            </div>
                        <?endforeach;?>
                    <?endforeach;?>

                </div>
            </div>
        <?endif;?>

        <div id="basket_footer" class="seatmap-foot">

            <div class="seatmap-ticket-list">
                <?foreach ($arResult['SEATS'] as $seat):?>
                    <div
                            data-offer-id="<?=$seat["id"]?>"
                            data-is-created-seat-map="<?=$seat["is_created_seat_map"]?>"
                            data-seat-map-id="<?=$seat["seat_map_id"]?>"
                            class="seatmap-ticket">
                        <div class="seatmap-ticket__place"><?=$seat["props_str"]?></div>
                        <div class="seatmap-ticket__desc"><?=$seat["name"]?></div>
                        <div class="seatmap-ticket__price"><?=$seat["price"]?> ₽</div>
                        <div class="seatmap-ticket__close seat_delete"></div>
                    </div>
                <?endforeach;?>

            </div>

            <div class="seatmap-foot-total">
                <div class="seatmap-foot-total__left">
                    <div class="seatmap-foot-total__tickets"><?=$arResult['SELECT_QUANTITY_TEXT_DECLINATION']?>:</div>
                    <div class="seatmap-foot-total__price"><?=$arResult['SUMM']?> ₽</div>
                </div>
                <div class="seatmap-foot-total__right">
                    <button type="button" class="btn jq-add-to-basket">
                        Далее
                        <span class="btn__ico"><img alt="" class="svg" src="<?=SITE_TEMPLATE_PATH?>/assets/img/ico/arrow.svg"></span>
                    </button>
                </div>
            </div>
        </div>
    <?endif;?>


</div>

<?if($_REQUEST['ajax_catalog']=='Y')
    die();?>


