$(function () {
	checkBtn()
})

const debounce = (fnc, ms) => {
	let timeout;
	function wrapper(){
		const fnCall = () => fnc.apply(this, arguments);
		clearTimeout(timeout);
		timeout = setTimeout(fnCall, ms);
	}

	return wrapper;
}

function redirectToPayment() {
	document.location.href = window.basketSettings.order_url;
}

function onMessage(event) {
	var data = event.data;

	if (typeof window[data.func] == "function") {
		window[data.func].call(null, data.message);
	}
}

if (window.addEventListener) {
	window.addEventListener("message", onMessage, false);
} else if (window.attachEvent) {
	window.attachEvent("onmessage", onMessage, false);
}

function seat_delete()
{
	let id = $(this).parent("div[data-seat-map-id]").data("seat-map-id");
	let is_created_seat_map = $(this).parent("div[data-seat-map-id]").data("is-created-seat-map");

	if(id)
		seatmapDeleteFromCart(id);
	else if(is_created_seat_map)
	{
		id = $(this).parent("div[data-offer-id]").data("offer-id");
		seatmapDeleteFromGaCart(id);

		calculate_sum();
	}
	else
	{
		id = $(this).parent("div[data-offer-id]").data("offer-id");

		let quantityInput = $(".jq-quantity[data-id="+id+"]");
		$(quantityInput).val($(quantityInput).val() - 1);

		calculate_sum(id);
	}
}

function calculate_sum(offer_id) {
	const event_id = window.basketSettings.event_id;
	const session_key = "tickets_"+event_id;

	const buttonElement = document.querySelector('#basket_footer .btn__red.btn__buy.jq-add-to-basket');
	if (buttonElement) {
		buttonElement.classList.add('loading');
	} else {
		document.body.classList.add('loading');
	}

	let products = [];
	$(".jq-quantity").each(function (index, el){
		if($(el).val() > 0 || offer_id == $(el).data("id"))
			products.push({id: $(el).data("id"), quantity: $(el).val()});
	});

	if (products.length) {
		sessionStorage.setItem(session_key, JSON.stringify(products));
	} else {
		let ticketsInStorage = JSON.parse(sessionStorage.getItem(session_key));
		if(ticketsInStorage)
		{
			products = products.concat(ticketsInStorage);
		}
		else
		{
			sessionStorage.removeItem(session_key);
		}
	}

	const seatMapTickets = JSON.parse(sessionStorage.getItem('seatMapTickets'));
	if (seatMapTickets) {
		products = products.concat(seatMapTickets);
	}

	const data = {'ajax_catalog':'Y', 'items': products};
	data[window.basketSettings.key] = window.basketSettings.val;

	$.ajax({
		url: '',
		method: 'post',
		dataType: 'html',
		data: data,
		success: function(result){
			$("#basket").find("#basket_items").replaceWith($(result).find("#basket_items"));
			$("#basket").find("#basket_footer").replaceWith($(result).find("#basket_footer"));

			if (buttonElement) {
				buttonElement.classList.remove('loading');
			} else {
				document.body.classList.remove('loading');
			}


			setTimeout(() => {
				sendHeight()
				checkBtn()
			}, 100)
		}
	});
}

function checkBtn() {
	let hasElem = false;

	var products = [];
	$(".jq-quantity").each(function (index, el){
		if($(el).val() > 0)
		{
			products.push({id: $(el).data("id"), quantity: $(el).val()});
		}
	});

	const seatMapTickets = JSON.parse(sessionStorage.getItem('seatMapTickets'));
	if (seatMapTickets) {
		products = products.concat(seatMapTickets);
	}

	if(products.length)
	{
		hasElem = true;
	}

	$('#basket_footer .jq-add-to-basket').toggleClass('disabled', !hasElem)

}

$(function() {
	analyticSend();

	calculate_sum();

	function calculateSumClick() {
		var id = $(this).data("id"),
			qnt = $(this).val(),
			catalog_avail = JSON.parse( window.basketSettings.catalog_avail );


		if(parseInt(catalog_avail[id]["MAX_QUANTITY"]) >= parseInt(qnt) && parseInt(catalog_avail[id]["QUANTITY"]) >= parseInt(qnt))
		{
			calculate_sum(id);
		}
		else
		{
			if(parseInt(catalog_avail[id]["MAX_QUANTITY"]) > parseInt(catalog_avail[id]["QUANTITY"])) {
				$(this).val(catalog_avail[id]["QUANTITY"]);
			}
			else {
				$(this).val(catalog_avail[id]["MAX_QUANTITY"]);
			}

			calculate_sum(id);

			//removeLoader();
		}


	}

	$(document).on("change", ".jq-quantity",  debounce(calculateSumClick, 1000));

	$(document).on("click", ".seat_delete",  debounce(seat_delete, 500));

	$(document).on("click", ".tickets__quantity-item-delete",  function () {
		$(this).siblings('.tickets__quantity-item-controls').find(".jq-quantity").val(0);

		calculate_sum();
	});

	$(document).on("click", ".jq-change-quantity.plus",  function () {
		let qnt_input = $(this).siblings('input'),
			val = parseInt(qnt_input.val()),
			block = $(this).closest('.quantity'),
			max = parseInt(block.attr('data-max'))

		$(this).toggleClass("disabled", val >= max - 1)
		block.find(".jq-change-quantity.minus").removeClass("disabled")

		if (val >= max) {
			return false
		}

		$(qnt_input).val(parseInt($(qnt_input).val()) + 1);
		$(qnt_input).trigger("change");

	});

	$(document).on("click", ".jq-change-quantity.minus",  function () {
		let qnt_input = $(this).siblings('input'),
			block = $(this).closest('.quantity'),
			val = parseInt($(qnt_input).val())

		block.find(".jq-change-quantity.plus").removeClass("disabled")
		$(this).toggleClass("disabled", val <= 1)

		if( val > 0)
		{
			$(qnt_input).val(val - 1);
			$(qnt_input).trigger("change");
		}

	});

	$(document).on("click", ".jq-add-to-basket",  function () {
		const event_id = window.basketSettings.event_id;
		const session_key = "tickets_"+event_id;

		const buttonElement = document.querySelector('#basket_footer .btn__red.btn__buy.jq-add-to-basket');
		if (buttonElement) {
			buttonElement.classList.add('loading');
		} else {
			document.body.classList.add('loading');
		}

		var products = [];
		$(".jq-quantity").each(function (index, el){
			if($(el).val() > 0)
			{
				products.push({id: $(el).data("id"), quantity: $(el).val()});
			}
		});

		const seatMapTickets = JSON.parse(sessionStorage.getItem('seatMapTickets'));
		if (seatMapTickets) {
			products = products.concat(seatMapTickets);
			console.log(JSON.stringify(products));
		}

		if(products.length)
		{
			var query = {
				c: 'custom:basket',
				action: 'add',
				mode: 'class',
			};

			query[window.basketSettings.key] = window.basketSettings.val;

			if(localStorage.getItem('_ym_uid'))
				query['_ym_uid'] = localStorage.getItem('_ym_uid').replaceAll('"','');

			var data = {
				items: products
			};
			var request = $.ajax({
				url: '/bitrix/services/main/ajax.php?' + $.param(query, true),
				method: 'POST',
				data: data,
				dataType: 'json',
			});
			request.done(function (response) {
				if(response.status == "error")
				{
					showToast(response);

					if (buttonElement) {
						buttonElement.classList.remove('loading');
					} else {
						document.body.classList.remove('loading');
					}
				}
				else
				{
					//sessionStorage.removeItem('seatMapTickets');
					//sessionStorage.removeItem(session_key);
					redirectToPayment();
				}
			});

			/*BX.ajax.runComponentAction("custom:basket", "add", {
				mode: "class",
				data: {items: products}
			}).then(function (response) {
				sessionStorage.removeItem('seatMapTickets');
				sessionStorage.removeItem(session_key);
				redirectToPayment();
			}, function (response) {
				showToast(response.data.ajaxRejectData);

				if (buttonElement) {
					buttonElement.classList.remove('loading');
				} else {
					document.body.classList.remove('loading');
				}
			});*/
		}
		else
		{
			if (buttonElement) {
				buttonElement.classList.remove('loading');
			} else {
				document.body.classList.remove('loading');
			}
		}
	});
});
