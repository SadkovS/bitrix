<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Bitrix\Main\Localization\Loc;

use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\ORM;


use Bitrix\Main\Page\Asset;
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
?>
<div class="admin-body">

    <form class="admin-body__item wide js-form-chart" data-dataset="no-sync">

        <? $APPLICATION->IncludeComponent(
            "custom:organizer.sales.statistics.graph",
            "sales",
            [
                "CACHE_GROUPS" => "Y",
                "CACHE_TIME"   => "180",
                "CACHE_TYPE"   => "A",
                "BLOCK_TITLE"   => "Продажи",
            ]
        ); ?>

    </form>

    <div class="admin-body__item wide events">
        <div class="admin-body__item-header">
            <div></div>
            <a class="btn btn__fix-width js-downloadLink" data-change-href href="<?=$APPLICATION->GetCurPageParam("action=export", array("action"))?>">Выгрузка</a>
        </div>
        <? if (isset($request['ajax']) && $request['ajax'] == 'Y') $APPLICATION->RestartBuffer(); ?>
        <table class="events__table">
            <thead>
            <tr>
                <td>
                    <div class="events__table-item">
                        <p>Мероприятие</p>
                        <div class="events__form-item">
                            <input type="text" class="events__form-input" name="q" placeholder="Найти" value="<?= $request['q'] ?>">
                            <i class="_icon-search"></i>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Сумма<br>
                            оборота, ₽ </p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Заказы</p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Билеты</p>
                    </div>
                </td>
                <?/*<td>
                    <div class="events__table-item">
                        <p>Сервисный сбор, ₽</p>
                    </div>
                </td>*/?>
                <td>
                    <div class="events__table-item">
                        <p>Доход, ₽</p>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <p>Комиссия
                            сервиса, ₽</p>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <p>Количество<br> возвратов</p>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <p>Сумма<br> возвратов,&nbsp;₽</p>
                    </div>
                </td>
            </tr>
            </thead>
            <tbody>
            <?foreach ($arResult["ITEMS"] as $item):?>
                <? $availableDetail = (int)($item['TICKETS_QUANTITY'] ?? 0) > 0; ?>
                <tr>
                    <td class="<?= $availableDetail ? ' table-accordion-cell js-table-accordion-toggle' : '' ?>"
                        data-accordion-url="<?= $APPLICATION->GetCurPage() . '?ajax=Y&action=getDetail&event=' . $item['ID'] ?>">
                        <div class="events__table-item">
                            <div class="table-accordion-cell__flex">
                                <div class="<?= $availableDetail ? ' _icon-chev table-accordion-cell__arrow' : '' ?>"></div>

                                <p><?= $item['UF_NAME'] ?? '' ?></p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><p><?=$item["ORDER_FULL_SUM_FORMAT"]?></p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?=$item["ORDER_COUNT"]?></p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?=$item["TICKETS_QUANTITY"]?></p>
                            </div>
                        </div>
                    </td>

                    <?/*<td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?=$item["SUM_SERVICE"]?></p>
                            </div>
                        </div>
                    </td>*/?>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?=$item["ORDER_SUM_FORMAT"]?></p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?=$item["ORDER_COMISSION_FORMAT"]?></p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?=$item["COUNT_REFUND"]?></p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?=$item["SUM_REFUND_FORMAT"]?></p>
                            </div>
                        </div>
                    </td>

                </tr>
            <?endforeach;?>


            </tbody>
        </table>

        <?=$arResult['NAV_STRING']?>
        <? if (isset($request['ajax']) && $request['ajax'] == 'Y') die(); ?>

    </div>

</div>