$(document).ready(function () {
    // Изменение фильтра
    async function getUrlVars() {
        let url = new Url(window.location.href);
        const [name, date] = [
            document.querySelector('[name="q"]').value,
            document.querySelector('[name="d"]').value.trim().replace(/ /g, ''),
        ];

        url.query.ajax = 'N';
        name === ''     ?   delete url.query.q  :   url.query.q = name;
        date === ''     ?   delete url.query.d  :   url.query.d = date;

        delete url.query.PAGEN_1;
        const address = url.toString();

        const response = await fetch(address);
        if (!response.ok) {
            return
        }
        const data = await response.text()
	    console.log(data)
        let doc = new DOMParser().parseFromString(data, "text/html");
        const tbody = doc.querySelector('tbody');
        const pagination = doc.querySelector('.pagination.events__pagination');
        delete url.query.ajax;

        window.history.pushState("event search", "", url.toString());
        document.querySelector('.events__table tbody').replaceWith(tbody);
        document.querySelector('.events__pagination').replaceWith(pagination);

        const h = doc.querySelector('[data-change-href]');
        document.querySelector('[data-change-href]').replaceWith(h);
    }
// Эвент фильтрации по инпуту
    function inputFilter(e) {
        const target = e.target;
        if (!target.closest('[name="q"]') && !target.closest('[name="n"]') && !target.closest('[name="c"]')) return;
        getUrlVars();
    }
// Эвент фильтрации по селекту
    function changeFilter(e) {
        const target = e.target;
        if (!target.closest('[name="d"]') && !target.closest('[name="os"]')) return;
        getUrlVars();
    }
// Бинд всех эвентов на страницу
    [
        ['change', changeFilter],
        ['input', debounce(inputFilter, 500)],
    ].forEach(([event, fn]) => {
        document.addEventListener(event, fn)
    });

// Функция дебаунса
    function debounce(func, wait, immediate) {
        let timeout;
        return function() {
            const context = this;
            const args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }
});

