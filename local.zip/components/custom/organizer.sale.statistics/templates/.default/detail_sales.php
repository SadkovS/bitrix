<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;

Loader::includeModule('custom.core');
$APPLICATION->RestartBuffer();
//echo "<pre>";
//print_r($arResult);
//echo "</pre>";
//die();
?>
<? foreach ($arResult['ITEMS'] as $item): ?>
    <tr class="table-accordion-additional js-table-accordion-additional">
        <td class="">
            <div class="events__table-item">
                <div class="table-accordion-cell__flex">
                    <div class=""></div>

                    <p><?= $item['TICKET_NAME'] ?? '' ?></p>
                </div>
            </div>
        </td>

        <td>
            <div class="events__table-item">
                <div class="events__table-item-name">
                    <p>
                    <p><?= $item["ORDER_FULL_SUM_FORMAT"] ?></p>
                </div>
            </div>
        </td>

        <td>
            <div class="events__table-item">
                <div class="events__table-item-name">
                    <p><?= $item["ORDER_COUNT"] ?></p>
                </div>
            </div>
        </td>

        <td>
            <div class="events__table-item">
                <div class="events__table-item-name">
                    <p><?= $item["TICKETS_QUANTITY"] ?></p>
                </div>
            </div>
        </td>

        <? /*<td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?=$item["SUM_SERVICE"]?></p>
                            </div>
                        </div>
                    </td>*/ ?>

        <td>
            <div class="events__table-item">
                <div class="events__table-item-name">
                    <p><?= $item["ORDER_SUM_FORMAT"] ?></p>
                </div>
            </div>
        </td>

        <td>
            <div class="events__table-item">
                <div class="events__table-item-name">
                    <p><?= $item["ORDER_COMISSION_FORMAT"] ?></p>
                </div>
            </div>
        </td>

        <td>
            <div class="events__table-item">
                <div class="events__table-item-name">
                    <p><?= $item["COUNT_REFUND"] ?></p>
                </div>
            </div>
        </td>

        <td>
            <div class="events__table-item">
                <div class="events__table-item-name">
                    <p><?= $item["SUM_REFUND_FORMAT"] ?></p>
                </div>
            </div>
        </td>

    </tr>

<?php endforeach; ?>
<? die(); ?>