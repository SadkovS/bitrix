<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arComponentParameters = array(
	'PARAMETERS' => array(
        "TICKETS_PER_PAGE" => [
            "PARENT" => "ADDITIONAL_SETTINGS",
            "NAME" => GetMessage("TICKETS_PER_PAGE"),
            "TYPE" => "STRING",
            "DEFAULT" => '10',
        ],
        "CACHE_TIME"  =>  ["DEFAULT"=>180],
    )
);