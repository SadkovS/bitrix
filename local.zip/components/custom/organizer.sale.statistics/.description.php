<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("ORG_TICKETS_LIST_NAME"),
	"DESCRIPTION" => GetMessage("ORG_TICKETS_LIST_DESCRIPTION"),
    "CACHE_PATH" => "Y",
    "SORT" => 40,
	"PATH" => array(
        "ID" => "custom",
        "CHILD" => array(
            "ID" => "orders",
            "NAME" => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT" => 20,
            "CHILD" => array(
                "ID" => 'organizer.tickets.list'
            )
        )
	),
);
?>