<?php
$MESS["ORG_TICKETS_LIST_NAME"] = "Просмотр билетов";
$MESS["FILEMAN_PDFVIEWER_COMPONENT_DESCRIPTION"] = "Выводит информацию о билетах";
$MESS ['C_HLDB_CAT_ORDERS'] = "Заказы";