<?php
$MESS['TICKETS_PER_PAGE'] = 'Количество билетов';