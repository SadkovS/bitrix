<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Custom\Core\ExportExcel;

$arDefColumns = [
    '_event'       => ['name' => 'Мероприятие'],
    '_ticket_type' => ['name' => 'Тип билета'],
    '_fullsum'     => ['name' => 'Сумма оборота'],
    '_orders'      => ['name' => 'Заказы'],
    '_tickets'     => ['name' => 'Билеты'],
    '_summ'        => ['name' => 'Доход'],
    '_comission'   => ['name' => 'Комиссия сервиса'],
    '_refund'      => ['name' => 'Количество возвратов'],
    '_refundsum'   => ['name' => 'Сумма возвратов'],
];

if (!is_array($this->arResult['ITEMS']) || count($this->arResult['ITEMS']) < 1) throw new Exception('Заказы не найдены');

$obExport = new ExportExcel();
$obExport->setFileName("sales.xlsx");
$date = new DateTime();
$date = $date->format('d.m.Y');
$obExport->setFilePath($_SERVER['DOCUMENT_ROOT'] . '/upload/tmp');
$xls = $obExport->createFile();
$xls->getProperties()->setTitle("Тестовый файл");
$xls->getProperties()->setCreated($date);
$xls->setActiveSheetIndex(0);
$sheet = $xls->getActiveSheet();
$sheet->setTitle('Отчет');
$sheet->getRowDimension("1")->setRowHeight(50);
$sheet->getRowDimension("2")->setRowHeight(30);
$sheet->getRowDimension("3")->setRowHeight(40);
$sheet->setCellValue("A1", "Продажи");
$sheet->mergeCells("A1:H1");
$sheet->getStyle("A1")->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$sheet->getStyle("A1")->getFont()->setSize(22);
$sheet->getStyle("A1")->getFont()->setBold(true);

$i            = 0;
$rowNum       = 4;
$columnsCount = 0;
$arTable      = [];

if ($this->arResult['TOTAL']) {
    $this->arResult['ITEMS'][] = $this->arResult['TOTAL'];
}

foreach ($this->arResult['ITEMS'] as $row) {

    if ($i == 0) {
        $arTable['HEAD'] = array_values($arDefColumns);
    }
    $arrColumns = $arDefColumns;
    foreach ($arrColumns as $key => &$col) {

        if ($key == '_event') $col['value'] = $row['UF_NAME'];
        elseif ($key == '_ticket_type') $col['value'] = $row['TICKET_NAME'];
        elseif ($key == '_fullsum') $col['value'] = $row['ORDER_FULL_SUM'];
        elseif ($key == '_orders') $col['value'] = $row['ORDER_COUNT'];
        elseif ($key == '_tickets') $col['value'] = $row['TICKETS_QUANTITY'];
        //elseif ($key == '_services') $col['value'] = $row['SUM_SERVICE'];
        elseif ($key == '_summ') $col['value'] = $row['ORDER_SUM'];
        elseif ($key == '_comission') $col['value'] = $row['ORDER_COMISSION'];
        elseif ($key == '_refund') $col['value'] = $row['COUNT_REFUND'];
        elseif ($key == '_refundsum') $col['value'] = $row['SUM_REFUND'];
    }

    $arTable['BODY'][] = $arrColumns;
}


foreach ($arTable['HEAD'] as $key => $headItem) {
    $colLetter = $obExport->getColumnLetter($key + 1);
    $sheet->setCellValue($colLetter . '3', $headItem['name'] ?? '');
    $sheet->getStyle($colLetter . '3')->getFont()->setSize(14);
    $sheet->getStyle($colLetter . '3')->getFont()->setBold(true);
    $sheet->getStyle($colLetter . '3')->getFont()->setItalic(true);
    $sheet->getStyle($colLetter . '3')->applyFromArray(
        [
            'fill' => [
                'type'  => PHPExcel_Style_Fill::FILL_SOLID,
                'color' => ['rgb' => 'e4efdc']
            ]
        ]
    );
    $sheet->getStyle($colLetter . '3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle($colLetter . '3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
unset($key, $row, $i);
foreach ($arTable['BODY'] as $key => $row) {
    $i = 0;
    foreach ($row as $keyCol => $colID) {
        $indexCol  = $i + 1;
        $colLetter = $obExport->getColumnLetter($indexCol);
        if (strlen(strip_tags(is_string($colID['value']) ? $colID['value'] : '')) > 300) {
            $sheet->getColumnDimension($colLetter)->setAutoSize(false);
            $sheet->getColumnDimension($colLetter)->setWidth(150);
        }
        $sheet->setCellValue($colLetter . $rowNum, strip_tags(is_array($colID['value']) ? implode(', ', $colID['value']) : $colID['value']));
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setWrapText(true);
        $sheet->getStyle($colLetter . $rowNum)->getFont()->setSize(14);
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $i++;
    }
    $rowNum++;
}
$endColLetter = $obExport->getColumnLetter(count($arTable['HEAD']));
$sheet->getStyle("A3:" . $endColLetter . ($rowNum - 1))->applyFromArray($obExport->getBorderStyle());
$obExport->downloadFile($xls);

exit;