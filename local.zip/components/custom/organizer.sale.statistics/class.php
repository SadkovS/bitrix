<?php
declare(strict_types = 1);

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\Entity\ReferenceField;
use Bitrix\Main\Entity\ExpressionField;
use Bitrix\Main\ORM\Query\Join;
use Custom\Core\Helper;

Loader::includeModule('custom.core');
Loader::includeModule('sale');
Loader::includeModule("catalog");

Loc::loadMessages(__FILE__);

class OrganizerSaleStatisticComponent extends \CBitrixComponent {
    private const TOTAL_NAME                = "Итого";
    private const DEFAULT_ITEMS_PER_PAGE    = 10;
    private const DEFAULT_DATE_RANGE_MONTHS = 1;

    // Коды свойств заказа
    private const ORDER_PROP_EVENT_CODE           = "EVENT_ID";
    private const ORDER_PROP_COMMISSION_CODE      = "COOPERATION_PERCENT";
    private const BASKET_PROP_REFUNDED_PRICE_CODE = "REFUNDED_PRICE";

    // Статусы заказа
    private const ORDER_STATUS_PAID     = "Y";
    private const ORDER_STATUS_CANCELED = "Y";
    private const ORDER_STATUS_EXCLUDED = "CD";

    private int $companyId;
    private array $filter = [];
    private int $limit = 0;
    private int $offset = 0;
    private int $currentPage = 1;

    // Поля для форматирования цен
    private array $priceFields = [
        "ORDER_FULL_SUM",
        "ORDER_SUM",
        "ORDER_COMISSION",
        "SUM_REFUND",
    ];

    public function __construct($component = null)
    {
        parent::__construct($component);

        $this->initializeCompanyId();
        $this->initializeRequest();
    }

    /**
     * Инициализация ID компании из сессии
     */
    private function initializeCompanyId(): void
    {
        $this->companyId = (int)($_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'] ?? 0);

        if ($this->companyId <= 0) {
            throw new \RuntimeException('Company ID not found in session');
        }
    }

    /**
     * Инициализация данных запроса
     */
    private function initializeRequest(): void
    {
        $app           = Application::getInstance();
        $context       = $app->getContext();
        $this->request = $context->getRequest()->toArray();

        $this->filter = $this->buildFilter();

        $action = $this->request['action'] ?? '';
        if (!empty($action)) {
            $this->executeAction($action);
        }
    }

    public function prepareArray(string $str = ""): array
    {
        if (empty($str)) {
            return [];
        }

        $result = [];
        $pairs = explode(";", $str);

        foreach ($pairs as $pair) {
            $keyValue = explode("-", $pair, 2);
            if (count($keyValue) === 2) {
                $result[$keyValue[0]] = $keyValue[1];
            }
        }

        return $result;
    }

    /**
     * Основной метод выполнения компонента
     */
    public function executeComponent(): void
    {
        try {
            $this->setupPagination();


            if (($this->request['action'] ?? '') === 'export') {
                $this->processExport();
                $this->handleExport();
                return;
            }

            $this->processStatistics();
            $this->setupNavigation();
            $this->includeComponentTemplate();

        } catch (\Exception $e) {
            $this->arResult['ERROR'] = $e->getMessage();
            $this->includeComponentTemplate();
        }
    }

    /**
     * Настройка пагинации
     */
    private function setupPagination(): void
    {
        $isExport = ($this->request['action'] ?? '') === 'export';
        $this->setLimit($isExport ? -1 : 0);
        $this->setCurrentPage();
        $this->setOffset();
    }

    /**
     * Обработка статистики продаж
     */
    private function processStatistics(): void
    {
        $dbResult = $this->getStatisticsQuery();

        $this->arResult['ITEMS'] = [];
        $this->arResult['TOTAL'] = $this->initializeTotalRow();

        while ($row = $dbResult->fetch()) {
            $processedRow                        = $this->processStatisticsRow($row);
            $this->arResult['ITEMS'][$row['ID']] = $processedRow;
            $this->updateTotalRow($processedRow);
        }

        // Форматирование итогов
        $this->formatPriceFields($this->arResult['TOTAL']);
        $this->arResult['ALL_COUNT'] = $dbResult->getCount();
    }

    /**
     * Получение данных статистики
     */
    private function getStatisticsQuery(): \Bitrix\Main\ORM\Query\Result
    {
        return \Custom\Core\Events\EventsTable::getList(
            [
                'select'        => $this->getSelectFields(),
                'filter'        => $this->filter,
                'runtime'       => $this->getRuntimeFields(),
                'limit'         => $this->limit,
                'group'         => ['ID'],
                'offset'        => $this->offset,
                'order'         => ['ID' => 'DESC'],
                'count_total'   => true,
                'data_doubling' => false,
            ]
        );
    }

    /**
     * Поля для выборки
     */
    private function getSelectFields(): array
    {
        return [
            'ID',
            'UF_NAME',
            'ORDER_COUNT',
            'TICKETS_QUANTITY',
            'ORDER_FULL_SUM',
            'ORDER_COMISSION',
            'ORDER_SUM',
            'ORDER_SERVICE_PRICES',
            'COUNT_REFUND',
            'SUM_REFUND',
        ];
    }

    /**
     * Runtime поля для запроса
     */
    private function getRuntimeFields(): array
    {
        return [
            // Связи с таблицами
            new ReferenceField(
                'ORDER_PROP_EVENT',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.VALUE'],
                ['join_type' => 'inner']
            ),
            new ReferenceField(
                'ORDER',
                '\Bitrix\Sale\Order',
                ['=this.ORDER_PROP_EVENT.ORDER_ID' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
            new ReferenceField(
                'ORDER_PROP_COMISSION',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ORDER.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new ReferenceField(
                'BASKET_REFS',
                'Bitrix\Sale\Internals\BasketTable',
                ['this.ORDER.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'left']
            ),
            new ReferenceField(
                'BASKET_PROPS_REFUNDED_PRICE',
                'Bitrix\Sale\Internals\BasketPropertyTable',
                Join::on('ref.BASKET_ID', 'this.BASKET_REFS.ID')
                    ->where("ref.CODE", "=", self::BASKET_PROP_REFUNDED_PRICE_CODE),
                ['join_type' => Join::TYPE_LEFT]
            ),

            // Вычисляемые поля
            new ExpressionField('ORDER_FULL_SUM', 'SUM(%s)', ['BASKET_REFS.PRICE']),
            new ExpressionField('ORDER_COMISSION', '%s * %s/100', ['ORDER_FULL_SUM', 'ORDER_PROP_COMISSION.VALUE']),
            new ExpressionField('ORDER_SUM', '%s - %s', ['ORDER_FULL_SUM', 'ORDER_COMISSION']),
            new ExpressionField('ORDER_COUNT', 'COUNT(DISTINCT %s)', ['ORDER.ID']),
            new ExpressionField('TICKETS_QUANTITY', 'COUNT(DISTINCT %s)', ['BASKET_REFS.ID']),
            new ExpressionField('ORDER_SERVICE_PRICES', 'SUM(%s)', ['ORDER.PRICE_DELIVERY']),
            new ExpressionField('COUNT_REFUND', 'COUNT(%s)', ['BASKET_PROPS_REFUNDED_PRICE.VALUE']),
            new ExpressionField('SUM_REFUND', 'SUM(%s)', ['BASKET_PROPS_REFUNDED_PRICE.VALUE']),
        ];
    }

    /**
     * Инициализация строки итогов
     */
    private function initializeTotalRow(): array
    {
        return [
            "UF_NAME"          => self::TOTAL_NAME,
            "ORDER_FULL_SUM"   => 0,
            "ORDER_COUNT"      => 0,
            "TICKETS_QUANTITY" => 0,
            "ORDER_SUM"        => 0,
            "ORDER_COMISSION"  => 0,
            "COUNT_REFUND"     => 0,
            "SUM_REFUND"       => 0,
        ];
    }

    /**
     * Обработка строки статистики
     */
    private function processStatisticsRow(array $row): array
    {
        $this->formatPriceFields($row);
        return $row;
    }

    /**
     * Форматирование денежных полей
     */
    private function formatPriceFields(array &$row): void
    {
        foreach ($this->priceFields as $field) {
            $row[$field]             = (float)($row[$field] ?? 0);
            $row[$field . "_FORMAT"] = Helper::priceFormat($row[$field], false) ?: "0.00";
        }
    }

    /**
     * Обновление строки итогов
     */
    private function updateTotalRow(array $row): void
    {
        $fieldsToSum = [
            "ORDER_FULL_SUM", "ORDER_COUNT", "TICKETS_QUANTITY",
            "ORDER_SUM", "ORDER_COMISSION", "COUNT_REFUND", "SUM_REFUND"
        ];

        foreach ($fieldsToSum as $field) {
            $this->arResult['TOTAL'][$field] += (float)($row[$field] ?? 0);
        }
    }

    /**
     * Обработка экспорта
     */
    private function handleExport(): void
    {
        if (file_exists(__DIR__ . '/export_excel.php')) {
            require_once __DIR__ . '/export_excel.php';
        } else {
            throw new \RuntimeException('Export module not found');
        }
    }

    /**
     * Настройка навигации
     */
    private function setupNavigation(): void
    {
        $this->nav = new \CDBResult();
        $this->nav->NavStart($this->limit);
        $this->nav->NavPageCount      = ceil((int)$this->arResult['ALL_COUNT'] / $this->limit);
        $this->nav->NavPageNomer      = $this->currentPage;
        $this->nav->NavRecordCount    = $this->arResult['ALL_COUNT'];
        $this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx(
            $navComponentObject, '', 'events_list_nav', 'Y'
        );
    }

    /**
     * Подготовка параметров компонента
     */
    public function onPrepareComponentParams($arParams): array
    {
        if ((int)($arParams['ITEM_PER_PAGE'] ?? 0) < 1) {
            $arParams['ITEM_PER_PAGE'] = self::DEFAULT_ITEMS_PER_PAGE;
        }
        return $arParams;
    }

    /**
     * Построение фильтра для запроса
     */
    private function buildFilter(): array
    {
        $filter = [
            "UF_COMPANY_ID"             => $this->companyId,
            "ORDER_PROP_EVENT.CODE"     => self::ORDER_PROP_EVENT_CODE,
            "ORDER_PROP_COMISSION.CODE" => self::ORDER_PROP_COMMISSION_CODE,
            'ORDER.PAYED'               => self::ORDER_STATUS_PAID,
            '!ORDER.CANCELED'           => self::ORDER_STATUS_CANCELED,
            '!ORDER.STATUS_ID'          => self::ORDER_STATUS_EXCLUDED,
        ];

        $this->addSearchFilter($filter);
        $this->addDateFilter($filter);

        return $filter;
    }

    /**
     * Добавление поискового фильтра
     */
    private function addSearchFilter(array &$filter): void
    {
        $searchQuery = trim($this->request['q'] ?? '');
        if (!empty($searchQuery)) {
            $filter['%UF_NAME'] = $searchQuery;
        }
    }

    /**
     * Добавление фильтра по дате
     */
    private function addDateFilter(array &$filter): void
    {
        $dateRange = trim($this->request['d'] ?? '');

        if (!empty($dateRange)) {
            $this->addCustomDateFilter($filter, $dateRange);
        } else {
            $this->addDefaultDateFilter($filter);
        }
    }

    /**
     * Добавление пользовательского фильтра по дате
     */
    private function addCustomDateFilter(array &$filter, string $dateRange): void
    {
        $dates = explode('-', $dateRange);

        if (count($dates) > 1) {
            // Диапазон дат
            $filter[] = [
                "LOGIC" => 'AND',
                [">=ORDER.DATE_INSERT" => trim($dates[0]) . ' 00:00:00'],
                ["<=ORDER.DATE_INSERT" => trim($dates[1]) . ' 23:59:59'],
            ];
        } else {
            // Одна дата
            $filter[] = [
                "LOGIC" => 'AND',
                [">=ORDER.DATE_INSERT" => trim($dates[0]) . ' 00:00:00'],
                ["<=ORDER.DATE_INSERT" => trim($dates[0]) . ' 23:59:59'],
            ];
        }
    }

    /**
     * Добавление фильтра по умолчанию (последний месяц)
     */
    private function addDefaultDateFilter(array &$filter): void
    {
        $endDate   = new \DateTime();
        $startDate = (clone $endDate)->modify('-' . self::DEFAULT_DATE_RANGE_MONTHS . ' month');

        $filter[] = [
            "LOGIC" => 'AND',
            [">=ORDER.DATE_INSERT" => $startDate->format('d.m.Y') . ' 00:00:00'],
            ["<=ORDER.DATE_INSERT" => $endDate->format('d.m.Y') . ' 23:59:59'],
        ];
    }

    /**
     * Установка лимита записей
     */
    private function setLimit(int $limit = 0): void
    {
        if ($limit === 0) {
            $this->limit = (int)($this->arParams['ITEM_PER_PAGE'] ?? self::DEFAULT_ITEMS_PER_PAGE);
        } elseif ($limit < 0) {
            $this->limit = 0; // Без лимита для экспорта
        } else {
            $this->limit = $limit;
        }
    }

    /**
     * Установка текущей страницы
     */
    private function setCurrentPage(): void
    {
        $this->currentPage = max(1, (int)($this->request['PAGEN_1'] ?? 1));
    }

    /**
     * Установка смещения для пагинации
     */
    private function setOffset(): void
    {
        $this->offset = ($this->currentPage - 1) * $this->limit;
    }

    /**
     * Выполнение действий
     */
    private function executeAction(string $action): void
    {
        switch ($action) {
            case 'getDetail':
                $eventId = (int)($this->request['event'] ?? 0);
                if ($eventId > 0) {
                    $this->getEventDetail($eventId);
                }
                break;
        }
    }

    /**
     * Получение детальной информации по событию
     */
    private function getEventDetail(int $eventId): void
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        $filter                           = $this->buildFilter();
        $filter['ORDER_PROP_EVENT.VALUE'] = $eventId;
        $dbResult                         = \Custom\Core\Events\EventsTable::getList(
            [
                'select'        => [
                    'ORDER_COUNT',
                    'TICKETS_QUANTITY',
                    'ORDER_FULL_SUM',
                    'ORDER_COMISSION',
                    'ORDER_SUM',
                    'ORDER_SERVICE_PRICES',
                    'COUNT_REFUND',
                    'SUM_REFUND',
                    'PRODUCT_ID'  => 'BASKET_REFS.PRODUCT_ID',
                    'TICKET_NAME' => 'BASKET_REFS.NAME',
                ],
                'filter'        => $filter,
                'runtime'       => [
                    // Связи с таблицами
                    new ReferenceField(
                        'ORDER_PROP_EVENT',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.VALUE'],
                        ['join_type' => 'inner']
                    ),
                    new ReferenceField(
                        'ORDER',
                        '\Bitrix\Sale\Order',
                        ['=this.ORDER_PROP_EVENT.ORDER_ID' => 'ref.ID'],
                        ['join_type' => 'inner']
                    ),
                    new ReferenceField(
                        'ORDER_PROP_COMISSION',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ORDER.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new ReferenceField(
                        'BASKET_REFS',
                        'Bitrix\Sale\Internals\BasketTable',
                        ['this.ORDER.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),
                    new ReferenceField(
                        'BASKET_PROPS_REFUNDED_PRICE',
                        'Bitrix\Sale\Internals\BasketPropertyTable',
                        Join::on('ref.BASKET_ID', 'this.BASKET_REFS.ID')
                            ->where("ref.CODE", "=", self::BASKET_PROP_REFUNDED_PRICE_CODE),
                        ['join_type' => Join::TYPE_LEFT]
                    ),

                    // Вычисляемые поля
                    new ExpressionField('ORDER_FULL_SUM', 'SUM(%s)', ['BASKET_REFS.PRICE']),
                    new ExpressionField('ORDER_COMISSION', '%s * %s/100', ['ORDER_FULL_SUM', 'ORDER_PROP_COMISSION.VALUE']),
                    new ExpressionField('ORDER_SUM', '%s - %s', ['ORDER_FULL_SUM', 'ORDER_COMISSION']),
                    new ExpressionField('ORDER_COUNT', 'COUNT(DISTINCT %s)', ['ORDER.ID']),
                    new ExpressionField('TICKETS_QUANTITY', 'COUNT(DISTINCT %s)', ['BASKET_REFS.ID']),
                    new ExpressionField('ORDER_SERVICE_PRICES', 'SUM(%s)', ['ORDER.PRICE_DELIVERY']),
                    new ExpressionField('COUNT_REFUND', 'COUNT(%s)', ['BASKET_PROPS_REFUNDED_PRICE.VALUE']),
                    new ExpressionField('SUM_REFUND', 'SUM(%s)', ['BASKET_PROPS_REFUNDED_PRICE.VALUE']),
                ],
                'group' => ['BASKET_REFS.PRODUCT_ID'],
                'data_doubling' => false,
            ]
        );

        $this->arResult['ITEMS'] = [];

        while ($row = $dbResult->fetch()) {
            $row['TICKET_NAME'] = $this->extractTextFromBrackets($row['TICKET_NAME']);
            $this->formatPriceFields($row);
            $this->arResult['ITEMS'][] = $row;
        }

        $this->includeComponentTemplate('detail_sales');
        die();
    }

    /**
     * Извлечение текста из квадратных скобок
     */
    private function extractTextFromBrackets(string $text): ?string
    {
        if (preg_match('/\[([^\]]+)\]/', $text, $matches)) {
            return $matches[1];
        }
        return null;
    }

    private function processExport(): void
    {
        $dbResult = $this->getExportStatisticsQuery();

        $this->arResult['ITEMS'] = [];
        $this->arResult['TOTAL'] = $this->initializeTotalRow();

        while ($row = $dbResult->fetch()) {
            // Извлекаем название типа билета из названия товара
            $row['TICKET_NAME'] = $this->extractTextFromBrackets($row['TICKET_NAME']) ?: $row['TICKET_NAME'];

            $processedRow              = $this->processStatisticsRow($row);
            $this->arResult['ITEMS'][] = $processedRow;
            $this->updateTotalRow($processedRow);
        }

        // Форматирование итогов для экспорта
        $this->formatPriceFields($this->arResult['TOTAL']);
    }

    /**
     * Получение данных статистики для экспорта (по типам билетов)
     */
    private function getExportStatisticsQuery(): \Bitrix\Main\ORM\Query\Result
    {
        return \Custom\Core\Events\EventsTable::getList(
            [
                'select'        => [
                    'UF_NAME',
                    'ORDER_COUNT',
                    'TICKETS_QUANTITY',
                    'ORDER_FULL_SUM',
                    'ORDER_COMISSION',
                    'ORDER_SUM',
                    'ORDER_SERVICE_PRICES',
                    'COUNT_REFUND',
                    'SUM_REFUND',
                    'PRODUCT_ID'  => 'BASKET_REFS.PRODUCT_ID',
                    'TICKET_NAME' => 'BASKET_REFS.NAME',
                ],
                'filter'        => $this->filter,
                'runtime'       => $this->getRuntimeFields(),
                'group' => ['BASKET_REFS.PRODUCT_ID'],
                'count_total'   => false,
                'data_doubling' => false,
            ]
        );
    }
}