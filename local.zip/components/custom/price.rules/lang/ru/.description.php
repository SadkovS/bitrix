<?
$MESS ['HLB_PRICE_RULES_NAME'] = "Ценовые правила";
$MESS ['HLB_PRICE_RULES_DESCRIPTION'] = "Раздел ценовых правил";
$MESS ['HLB_PRICE_RULES_DESC'] = "Ценовые правила";
?>