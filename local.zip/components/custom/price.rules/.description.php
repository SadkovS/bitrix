<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("HLB_PRICE_RULES_NAME"),
	"DESCRIPTION" => GetMessage("HLB_PRICE_RULES_DESCRIPTION"),
	"COMPLEX" => "Y",
	"PATH" => array(
        "ID" => "custom",
		"CHILD" => array(
			"ID" => "price_rules",
			"NAME" => GetMessage("HLB_PRICE_RULES_DESC"),
			"SORT" => 10,
			"CHILD" => array(
				"ID" => "price_rules_cmpx",
			),
		),
	),
);

?>