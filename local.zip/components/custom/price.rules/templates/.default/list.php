<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
{
	die();
}
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>

<? $APPLICATION->IncludeComponent(
	"custom:price.rules.list",
	$arParams['COMPONENT_TEMPLATE'] ?? 'promocodes',
	[
		"HLB_PROMOCODES_ID"      => HL_PROMOCODES_ID,
		"HLB_PRICE_RULES_ID"     => HL_PRICE_RULES_ID,
		//"FIELD_DISCOUNT_TYPE_ID" => FIELD_DISCOUNT_TYPE_ID,
		//"FIELD_TYPE_OF_APPLY_ID" => FIELD_TYPE_OF_APPLY_ID,
		"EVENT_TYPES"            => $arParams['EVENT_TYPES'], // todo
		"EVENT_ID"               => (int)$arParams['EVENT_ID'],
		"PRICE_RULES_COUNT" => $arParams['PRICE_RULES_COUNT'],
		"CACHE_TYPE" => $arParams['CACHE_TYPE'],
		"CACHE_TIME" => $arParams['CACHE_TIME'],
		"CACHE_GROUPS" => $arParams['CACHE_GROUPS'],
		"SEF_FOLDER" => $arParams['SEF_FOLDER'],
		"COMPONENT_TEMPLATE" => $arParams['COMPONENT_TEMPLATE'],
		"DISABLED" => $arParams['DISABLED'],
	]
); ?>
