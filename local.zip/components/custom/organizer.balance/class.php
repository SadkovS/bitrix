<?php

use Bitrix\Main\Localization\Loc;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

Loc::loadMessages(__FILE__);

class OrganizerBalanceComponent extends \CBitrixComponent {
    protected $companyID;
    public function __construct($component = null) {
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        if(!$this->companyID) return;
        parent::__construct($component);
    }

    public function executeComponent()
    {

        $date      = date('d.m.Y');
        $dateFrom  = date('01.m.Y 00:00:00', strtotime($date));
        $dateTo    = date('t.m.Y 23:59:59', strtotime($date));

        $this->arResult['SUM_MONTH']  = \Custom\Core\Act::getOrdersSum($this->companyID, $dateFrom, $dateTo, true);
        $this->arResult['SUM_MONTH']  = number_format($this->arResult['SUM_MONTH'], 2, ".", " ");

        $this->arResult['BALANCE'] = \Custom\Core\BalanceHistory::getBalanceForCompany($this->companyID);
        $this->arResult['BALANCE'] = number_format($this->arResult['BALANCE'], 2, ".", " ");

        $this->includeComponentTemplate();
    }
}