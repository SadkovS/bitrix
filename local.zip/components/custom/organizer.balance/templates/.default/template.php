<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>


<div class="adminpanel__header-item-title">
    <div class="adminpanel__header-tabs">
        <button class="h3 js-tab-itm">Оборот</button>
        <button class="h3 js-tab-itm active">Баланс</button>
    </div>
    <a href="#" class="btn" data-popup="#transfer">Вывести</a>
</div>
<div class="adminpanel__header-tab-content">
    <div class="adminpanel__header-tab-content__itm js-tab-content">
        <div class="adminpanel__header-item-data-big"><span class="green"><?=$arResult['SUM_MONTH']?> ₽</span>
        </div>
    </div>
    <div class="adminpanel__header-tab-content__itm js-tab-content active">
        <div class="adminpanel__header-item-data-big"><span class="green"><?=$arResult['BALANCE']?> ₽</span>
        </div>
    </div>
</div>