<?php
$MESS["ORGANIZER_BALANCE_NAME"] = "Просмотр баланса";
$MESS["ORGANIZER_BALANCE_DESCRIPTION"] = "Позволяет просмотреть баланс организатора";
$MESS["C_HLDB_CAT_ORDERS"] = "Заказы";