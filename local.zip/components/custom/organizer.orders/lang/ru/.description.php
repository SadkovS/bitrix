<?
$MESS ['HLB_ORDERS_ORGANIZER'] = "Заказы организатора";
$MESS ['HLB_ORDERS_ORGANIZER_DESC'] = "Показывает заказы организатора мероприятия";
$MESS ['C_HLDB_CAT_ORDERS'] = "Заказы";
?>