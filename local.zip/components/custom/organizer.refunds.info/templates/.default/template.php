<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); ?>

<div class="adminpanel__header-item-title">
    <h3>Заявки на возрат</h3><a href="/admin_panel/refunds/" class="btn">Возвраты</a>
</div>
<div class="adminpanel__header-item-data"><span class="c-text"><?=$arResult['TOTAL_COUNT']?> шт.</span></div>
<div class="adminpanel__header-item-foot-desc">Сумма возвратов: <strong class="c-error"><?=number_format(floatval($arResult['REFUNDS']), 2, '.', ' ')?> ₽</strong></div>