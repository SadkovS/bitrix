<?php

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\ORM;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

Loc::loadMessages(__FILE__);
Loader::includeModule('custom.core');
Loader::includeModule('iblock');
Loader::includeModule('catalog');
Loader::includeModule('sale');


class OrganizerRefundsInfoComponent extends \CBitrixComponent {

    protected $companyID;

    public function __construct($component = null)
    {
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        if (!$this->companyID) return;
        parent::__construct($component);
    }

    public function executeComponent()
    {
        $reviewStatusID = $this->getStatusIDByXmlID('pending');
        $query          = new ORM\Query\Query('Custom\Core\Tickets\TicketRefundRequestsTable');
        $resRefunds = $query
            ->setSelect(
                [
                    'ID',
                    'EVENT_ID'   => 'PROPERTY_EVENT_ID.VALUE',
                    'REFUND_SUM',
                    'UF_BASKET_ITEM_ID'
                ]
            )
            ->setFilter([
                            'UF_COMPANY_ID'          => $this->companyID,
                            "PROPERTY_EVENT_ID.CODE" => "EVENT_ID",
                            "UF_REVIEW_STATUS" => $reviewStatusID,
                        ])
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'ORDER_REF',
                    '\Bitrix\Sale\Order',
                    ['this.UF_ORDER_ID' => 'ref.ID'],
                    ['join_type' => 'left']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PROPERTY_EVENT_ID',
                    'Bitrix\Sale\Internals\OrderPropsValueTable',
                    ['=this.UF_ORDER_ID' => 'ref.ORDER_ID'],
                    ['join_type' => 'inner']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'EVENT',
                    'Custom\Core\Events\EventsTable',
                    ['=this.EVENT_ID' => 'ref.ID'],
                    ['join_type' => 'inner']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'REFUND_TICKETS_REF',
                    'Bitrix\Sale\Internals\BasketTable',
                    ['this.BASKET_ITEM_ID.VALUE' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'REFUND_SUM',
                    "SUM( %s)",
                    ['REFUND_TICKETS_REF.PRICE']
                )
            )
            ->setGroup(['ID'])
            ->countTotal(true)
            ->exec();
        $this->arResult['TOTAL_COUNT'] = (int)$resRefunds->getCount();
        $this->arResult['REFUNDS'] = 0;
        while ($refund = $resRefunds->fetch()) {
            $this->arResult['REFUNDS']     += $refund['REFUND_SUM'];
        }

        $this->includeComponentTemplate();
    }

    private function getPropertiesEnum(string $hlName, string $fieldName, string $xmlID = '')
    {
        $filter = [
            "HL.NAME"    => $hlName,
            "FIELD_NAME" => $fieldName,
        ];

        if (!empty($xmlID)) $filter["ENUM.XML_ID"] = $xmlID;

        $query = \Bitrix\Main\UserFieldTable::getList(
            [
                "filter"  => $filter,
                "select"  => [
                    "ENUM_ID"     => "ENUM.ID",
                    "ENUM_XML_ID" => "ENUM.XML_ID",
                    "ENUM_NAME"   => "ENUM.VALUE",
                ],
                "runtime" => [
                    new \Bitrix\Main\Entity\ExpressionField(
                        'HL_ID',
                        'REPLACE(%s, "HLBLOCK_", "")',
                        ['ENTITY_ID']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'HL',
                        '\Bitrix\Highloadblock\HighloadBlockTable',
                        ['this.HL_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'ENUM',
                        '\Custom\Core\FieldEnumTable',
                        ['this.ID' => 'ref.USER_FIELD_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ],
                'order'   => ['ENUM_ID' => 'ASC'],
                'cache'   => ['ttl' => 3600],
            ]
        );
        $res   = [];
        while ($item = $query->fetch()) {
            if (!empty($xmlID)) $res = $item['ENUM_ID'];
            else $res[$item['ENUM_ID']] = $item;
        }
        return $res;
    }

    private function getStatusIDByXmlID($xmlID): int
    {
        return (int)$this->getPropertiesEnum('TicketRefundRequests', 'UF_REVIEW_STATUS', $xmlID);
    }

    private function getTicketTypeEntity()
    {
        $offerEntity         = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $propFieldType       = $offerEntity->getField('TYPE');
        $propFieldTypeEntity = $propFieldType->getRefEntity();

        return $propFieldTypeEntity;
    }
}