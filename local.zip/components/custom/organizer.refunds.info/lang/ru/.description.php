<?php
$MESS["ORGANIZER_REFUNDS_INFO_NAME"] = "Просмотр суммы возвратов";
$MESS["ORGANIZER_REFUNDS_INFO_DESCRIPTION"] = "Позволяет просмотреть сумму возвратов";
$MESS["C_HLDB_CAT_ORDERS"] = "Заказы";