<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arComponentParameters = array(
	'PARAMETERS' => [
        "REFUNDS_COUNT" => [
            "PARENT"  => "BASE",
            "NAME"    => GetMessage("WIDGET_COUNT"),
            "TYPE"    => "STRING",
            "DEFAULT" => '10',
        ],
    ]
);