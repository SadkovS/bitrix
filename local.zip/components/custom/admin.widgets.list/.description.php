<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("ADMIN_WIDGET_COMPONENT_NAME"),
	"DESCRIPTION" => GetMessage("ADMIN_WIDGET_COMPONENT_DESCRIPTION"),
	"ICON" => "/images/icon.gif",
	"COMPLEX" => "N",
    "PATH"        => [
        "ID"    => "custom",
    ],
);
?>