<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
?>
<div class="grey__body p-0 js-event-widget-block">
    <div class="price__body">
        <div class="price__navigation">
            <div class="flex-fill"></div>
	        <?php if($arParams['DISABLED'] !== 'disabled'):?>
	        <div class="btn-dropdown-wrap">
		        <button  class="btn btn__fix-width js-btn-dropdown">
			        <span class="btn-text">Создать</span>
		        </button>
		        <div class="btn-dropdown">
			        <ul>
				        <li>
					        <a href="#" data-popup-src="<?=$arParams['SEF_FOLDER']?>0/?under_popup=y&event=<?=$arParams['EVENT_ID']?>" data-popup-second="#widget-add">Создать виджет</a>
				        </li>
				        <li>
					        <a href="#" data-popup-src="<?=$arParams['SEF_FOLDER']?>0/?under_popup=y&event=<?=$arParams['EVENT_ID']?>&type=telegram" data-popup-second="#widget-add">Создать телеграм-виджет</a>
				        </li>
			        </ul>
		        </div>
	        </div>
          <?php endif;?>
        </div>
        <table class="price__table">
            <thead>
            <tr>
                <th>
                    <div class="price__table-item">
                        <div class="clue__box">
                            <span>Название</span>
                            <span class="clue" data-clue="">
													<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
													<span class="clue-body" data-clue-body="" data-popper-placement="top">
														Пожалуйста, добавляйте отдельный виджет для каждого вашего сайта — это необходимо для корректной работы аналитики
														<span data-popper-arrow=""></span>
													</span>
												</span>
                        </div>
                    </div>
                </th>

                <th>
                    <div class="price__table-item">
                        <p>Тип</p>
                    </div>
                </th>
                <th>
                    <div class="price__table-item">
                        <p>Просмотры, шт</p>
                    </div>
                </th>
                <th>
                    <div class="price__table-item">
                        <p>Заказы, шт</p>
                    </div>
                </th>
                <th>
                    <div class="price__table-item">
                        <p>Сумма покупок, ₽</p>
                    </div>
                </th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?foreach ($arResult['ITEMS'] as $item):?>
            <tr>
                <td>
                    <div class="price__table-item">
                        <p><?=$item['UF_NAME']?></p>
                    </div>
                </td>
                <td>
                    <div class="price__table-item">
                        <p><?=$item['UF_TYPE']['ENUM_NAME']?></p>
                    </div>
                </td>
                <td>
                    <div class="price__table-item">
                        <p><?=$item['UF_VIEWS']?></p>
                    </div>
                </td>
                <td>
                    <div class="price__table-item">
                        <p><?=$item['CNT']?></p>
                    </div>
                </td>
                <td>
                    <div class="price__table-item">
                        <p><?=$item['SUM']?></p>
                    </div>
                </td>
                <td>
                    <div class="events__table-controls" data-event-controls="">
                        <button type="button" class="btn__icon" data-event-controls-btn="">
                            <i class="_icon-rounds"></i>
                        </button>
                        <div class="events__table-controls-body" data-event-controls-body="">
                            <ul>
                                <li>
                                    <a href="#" data-popup-second="#widget-add" data-popup-src="<?=$arParams['SEF_FOLDER']?><?=$item['ID']?>/?under_popup=y">Редактировать</a>
                                </li>
                                <?if((int)$item['CNT'] < 1):?>
                                    <li>
                                        <a class="js-ajax-link" data-popup-no-close="true" data-need-reload-event="true" data-need-reload=".js-event-widget-block" href="<?=$arParams['SEF_FOLDER']?><?=$item['ID']?>/?action=del">Удалить</a>
                                    </li>
                                <?endif;?>
                            </ul>
                        </div>
                    </div>
                </td>
            </tr>
            <?endforeach;?>
            </tbody>
        </table>
    </div>
</div>