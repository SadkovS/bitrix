<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

?>
<div class="admin-body__item wide events">
    <div class="admin-body__item-header">

        <div class="admin-body__item-header__left">
            <h1>Виджеты</h1>
        </div>
	    <div class="btn-dropdown-wrap">
        <button  class="btn btn__fix-width js-btn-dropdown">
	        <span class="btn-text">Создать</span>
        </button>
		    <div class="btn-dropdown">
			    <ul>
				    <li>
					    <a href="#" data-popup-src="<?=$arParams['SEF_FOLDER']?>0/" data-popup="#widget-add">Создать виджет</a>
				    </li>
				    <li>
					    <a href="#" data-popup-src="<?=$arParams['SEF_FOLDER']?>0/?type=telegram" data-popup="#widget-add">Создать телеграм-виджет</a>
				    </li>
			    </ul>
		    </div>
	    </div>

    </div>

    <table class="events__table">
        <thead>
        <tr>

            <td>
                <div class="events__table-item">
                    <p>Название мероприятия</p>
                    <div class="events__form-item">
                        <input class="events__form-input" placeholder="Найти" type="text" data-url-search="input" name="q"> <i
                                class="_icon-search"></i>
                    </div>
                </div>
            </td>

            <td>
                <div class="events__table-item widget-table-type-col">
                    <p>Тип</p>
                </div>
            </td>

            <td>
                <div class="events__table-item">
                    <p>Просмотры, шт</p>
                </div>
            </td>

            <td>
                <div class="events__table-item">
                    <p>Заказы, шт</p>
                </div>
            </td>

            <td>
                <div class="events__table-item">
                    <p>Сумма покупок, ₽</p>
                </div>
            </td>

            <td></td>

        </tr>
        </thead>
        <tbody>
        <? foreach ($arResult['ITEMS'] as $item): ?>
            <tr>
                <td class="table-accordion-cell js-table-accordion-toggle" data-accordion-url="?action=getWidgets&event=<?=$item['UF_EVENT_ID']?>">
                    <div class="events__table-item">
                        <div class="table-accordion-cell__flex">
                            <div class="_icon-chev table-accordion-cell__arrow"></div>

                            <p><?=$item['EVENT_NAME']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <p></p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p><?=$item['SUM_VIEWS']?></p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p><?=$item['CNT']?></p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <div>
                            <p><?=(int)$item['SUM']?> ₽</p>
                        </div>
                    </div>
                </td>

                <td>
	                <div class="events__table-controls hidden" data-event-controls="" style="visibility: hidden">
		                <button type="button" class="btn__icon" data-event-controls-btn="">
			                <i class="_icon-rounds"></i>
		                </button>
	                </div>
                </td>

            </tr>
        <? endforeach; ?>
        </tbody>
    </table>
    <?= $arResult['NAV_STRING'] ?>

</div>