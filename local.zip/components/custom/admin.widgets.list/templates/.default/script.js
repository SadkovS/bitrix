$(document).ready(function () {
	let promise


	function printFromData(data, pushState = 'page', url) {
		const doc = new DOMParser().parseFromString(data, "text/html");
		const tbody = doc.querySelector('tbody');
		const pagination = doc.querySelector('.pagination.events__pagination');

		window.history.pushState(pushState, "", url.toString());
		const pageTableBody = document.querySelector('.events__table tbody');
		if (pageTableBody && tbody) {
			pageTableBody.replaceWith(tbody);
		}
		const pagePagination = document.querySelector('.events__pagination');
		if (pagePagination && pagination) {
			pagePagination.replaceWith(pagination);
		}
	}

// Изменение фильтра
	async function pageTableSortFromUrl() {
		let reject, resolve;
		promise = new Promise((res, rej) => {
			resolve = res;
			reject = rej;
		});
		let url = new Url(window.location.href);
		url.search = '';
		url.query.ajax = 'Y';
		const inputs = [...document.querySelectorAll('input[data-url-search]')];
		for (let i = 0; i < inputs.length; i++) {
			const item = inputs[i];
			if (item.type === 'checkbox') {
				if (item.checked) {
					url.query[item.name] = item.value
				} else {
					delete url.query[item.name];
				}
			} else {
				item.value !== '' ? url.query[item.name] = item.value : delete url.query[item.name];
			}
		}
		url.query.PAGEN_1 = 1;

		const response = await fetch(url);
		if (!response.ok) {
			console.error(response.statusText);
			return
		}
		const data = await response.text();
		printFromData(data, "event search", url);

		resolve();
		return promise;
	}

	// Эвент фильтрации по инпуту
	function inputFilter(e) {
		const target = e.target;
		if (!target.closest('[data-url-search="input"]')) return;
		pageTableSortFromUrl();
	}
// Эвент фильтрации по селекту
	function changeFilter(e) {
		const target = e.target;
		if (!target.closest('[data-url-search="change"]')) return;
		pageTableSortFromUrl();
	}


// Бинд всех эвентов на страницу
	[
		['change', changeFilter],
		['input', debounce(inputFilter, 500)],
	].forEach(([event, fn]) => {
		document.addEventListener(event, fn);
	});

// Функция дебаунса
	function debounce(func, wait, immediate) {
		let timeout;
		return function() {
			const context = this;
			const args = arguments;
			const later = function() {
				timeout = null;
				if (!immediate) func.apply(context, args);
			};
			const callNow = immediate && !timeout;
			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
			if (callNow) func.apply(context, args);
		};
	}
})