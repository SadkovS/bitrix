<?php

use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

Loc::loadMessages(__FILE__);
Loader::includeModule('sale');

class AdminWidgetsComponent extends \CBitrixComponent {
    private $companyID;
    use \Custom\Core\Traits\PropertyEnumTrait;

    public function __construct($component = null)
    {
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        if ($this->companyID <= 0) return false;

        parent::__construct($component);

    }

    public function onPrepareComponentParams($arParams)
    {
        if (isset($this->request['show']) && in_array($this->request['show'], $this->showLimits))
            $arParams['WIDGET_COUNT'] = $this->request['show'];
        else
            $arParams['WIDGET_COUNT'] = 10;

        return $arParams;
    }

    public function executeComponent()
    {
        if (isset($this->request['action']) && $this->request['action'] != 'getForm') {
            $this->executeAction($this->request['action']);
            return false;
        }

        if ($this->getTemplateName() != 'simple') $this->getFullList();
        else $this->getSimpleList($this->arParams['EVENT_ID']);

        $this->includeComponentTemplate();
    }


    private function getSimpleList($eventID)
    {
        $typesList = $this->getPropertiesEnum('Widgets', 'UF_TYPE');

        $filter = [
            'UF_COMPANY_ID' => $this->companyID,
            'UF_EVENT_ID'   => $eventID
        ];

        $widgetEntity = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
        $query        = $widgetEntity
            ->setSelect(
                [
                    'ID',
                    'UF_NAME',
                    'UF_TYPE',
                    'UF_EVENT_ID',
                    'UF_VIEWS'
                ]
            )
            ->setFilter($filter)
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'EVENT_REF',
                    'Custom\Core\Events\EventsTable',
                    ['this.UF_EVENT_ID' => 'ref.ID'],
                    ['join_type' => 'left']
                )
            )
            ->exec();
        while ($widget = $query->fetch()) {

            $orders            = $this->getSales($widget['ID']);
            $widget['UF_TYPE'] = $typesList[$widget['UF_TYPE']];
            $widget['CNT']     = (int)$orders['CNT'];
            $widget['SUM']     = (int)$orders['SUM'];

            $this->arResult['ITEMS'][] = $widget;
        }
    }

    private function getFullList()
    {
        $curPage = (int)$this->request['PAGEN_1'] > 0 ? (int)$this->request['PAGEN_1'] : 1;
        if (isset($this->request['PAGEN_1']) && (int)$this->request['PAGEN_1'] > 1)
            $this->offset = ((int)$this->request['PAGEN_1'] - 1) * $this->arParams["WIDGET_COUNT"];

        $filter = ['UF_COMPANY_ID' => $this->companyID];

        if (!empty($this->request['q'])) $filter['%EVENT_NAME'] = trim($this->request['q']);

        $widgetEntity                = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
        $query                       = $widgetEntity
            ->setSelect(
                [
                    'UF_EVENT_ID',
                    'WIDGETS_IDs',
                    'EVENT_NAME' => 'EVENT_REF.UF_NAME',
                    'SUM_VIEWS'
                ]
            )
            ->setFilter($filter)
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'EVENT_REF',
                    'Custom\Core\Events\EventsTable',
                    ['this.UF_EVENT_ID' => 'ref.ID'],
                    ['join_type' => 'inner']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'WIDGETS_IDs', 'GROUP_CONCAT( DISTINCT %s)', ['ID']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'SUM_VIEWS', 'SUM(%s)', ['UF_VIEWS']
                ),
            )
            ->setLimit($this->arParams["WIDGET_COUNT"])
            ->setGroup(['UF_EVENT_ID'])
            ->setOffset($this->offset)
            ->countTotal(true)
            ->exec();
        $this->arResult['ALL_COUNT'] = $query->getCount();
        while ($widget = $query->fetch()) {
            $widget['WIDGETS_IDs'] = explode(',', $widget['WIDGETS_IDs']);
            $widget['CNT']         = 0;
            $widget['SUM']         = 0;
            foreach ($widget['WIDGETS_IDs'] as $widgetID) {
                $orders        = $this->getSales($widgetID);
                $widget['CNT'] += (int)$orders['CNT'];
                $widget['SUM'] += (int)$orders['SUM'];
            }
            $this->arResult['ITEMS'][] = $widget;
        }

        $this->nav = new \CDBResult();
        $this->nav->NavStart($this->arParams["WIDGET_COUNT"]);
        $this->nav->NavPageCount      = ceil((int)$this->arResult['ALL_COUNT'] / $this->arParams["WIDGET_COUNT"]);
        $this->nav->NavPageNomer      = $curPage;
        $this->nav->NavRecordCount    = $this->arResult['ALL_COUNT'];
        $this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');
    }

    private function getSales($widgetID): array
    {
        $dbRes  = \Bitrix\Sale\Order::getList(
            [
                'select'  => [
                    'ID',
                    'TICKET_PRICE_SUM',
                    'PRICE_REFUND_SUM',
                ],
                'filter'  => [
                    "PAYED"                    => "Y",
                    "PROPERTY_WIDGET_ID.CODE"  => 'WIDGET_ID',
                    "PROPERTY_WIDGET_ID.VALUE" => $widgetID,
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID',
                    "PROPERTY_ORGANIZER.VALUE" => $this->companyID,
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_WIDGET_ID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_REFS',
                        'Bitrix\Sale\Internals\BasketTable',
                        ['this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),
                    (new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_PROPS_IS_REFUNDED',
                        'Bitrix\Sale\Internals\BasketPropertyTable',
                        \Bitrix\Main\ORM\Query\Join::on('ref.BASKET_ID', 'this.BASKET_REFS.ID')
                            ->where("ref.CODE", "=", "IS_REFUNDED")
                    ))->configureJoinType(
                        \Bitrix\Main\ORM\Query\Join::TYPE_LEFT,
                    ),
                    (new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_PROPS_REFUNDED_PRICE',
                        'Bitrix\Sale\Internals\BasketPropertyTable',
                        \Bitrix\Main\ORM\Query\Join::on('ref.BASKET_ID', 'this.BASKET_REFS.ID')
                            ->where("ref.CODE", "=", "REFUNDED_PRICE")
                    ))->configureJoinType(
                        \Bitrix\Main\ORM\Query\Join::TYPE_LEFT,
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'TICKET_PRICE_SUM', 'SUM(%s)', ['BASKET_REFS.PRICE']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'PRICE_REFUND_SUM', 'SUM(%s)', ['BASKET_PROPS_REFUNDED_PRICE.VALUE']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'CNT', 'COUNT(%s)', ['ID']
                    ),
                ],
                'group'   => ['ID']
            ]
        );
        $result = [
            'CNT' => 0,
            'SUM' => 0
        ];
        while ($order = $dbRes->fetch()) {
            $result['CNT'] += 1;
            $result['SUM'] += ((int)$order['TICKET_PRICE_SUM'] - (int)$order['PRICE_REFUND_SUM']);
        }
        return $result;
    }

    public function getWidgetsByEventID(int $id)
    {
        $res          = [];
        $widgetEntity = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
        $query        = $widgetEntity
            ->setSelect(
                [
                    '*'
                ]
            )
            ->setFilter(
                [
                    'UF_COMPANY_ID' => $this->companyID,
                    'UF_EVENT_ID'   => $id
                ]
            )
            ->setGroup(['UF_EVENT_ID'])
            ->exec();
        while ($widget = $query->fetch()) {
            $sales         = $this->getSales($widget['ID']);
            $widget['CNT'] = $sales['CNT'];
            $widget['SUM'] = $sales['SUM'];
            $res[]         = $widget;
        }
        return $res;
    }

    private function getLayoutWidgetsList($arWidgets = [])
    {
        global $APPLICATION;
        $html      = '';
        $typesList = $this->getPropertiesEnum('Widgets', 'UF_TYPE');
        foreach ($arWidgets as $widget) {
            $type = $typesList[$widget['UF_TYPE']]['ENUM_NAME'];
            $html .= '<tr class="table-accordion-additional js-table-accordion-additional">
	            <td class="">
	            	<div class="events__table-item">' . $widget["UF_NAME"] . '</div>
	            </td>
            
	            <td>
	            	<div class="events__table-item">
	            		<p>' . $type . '</p>
	            	</div>
	            </td>
	            <td>
	            	<div class="events__table-item">
	            		<p>' . (int)$widget["UF_VIEWS"] . '</p>
	            	</div>
	            </td>
	            <td>
	            	<div class="events__table-item">
	            		<p>' . (int)$widget["CNT"] . '</p>
	            	</div>
	            </td>
	            <td>
	            	<div class="events__table-item">
	            		<div>
	            			<p>' . (int)$widget["SUM"] . ' ₽</p>
	            		</div>
	            	</div>
	            </td>
	            <td>
	            	<div class="events__table-controls" data-event-controls>
	            		<button type="button" class="btn__icon" data-event-controls-btn>
	            			<i class="_icon-rounds"></i>
	            		</button>
	            		<div class="events__table-controls-body" data-event-controls-body>
	            			<ul>
	            				<li>
	            					<a href="#" data-popup="#widget-add" data-popup-src="' . $this->arParams['SEF_FOLDER'] . $widget['ID'] . '/">Редактировать</a>
	            				</li>';

                                if ((int)$widget["CNT"] < 1) {
                                $html .= '<li><a class="js-ajax-link" data-need-reload=".admin-body__item.events" href="' . $this->arParams['SEF_FOLDER'] . $widget['ID'] . '/?action=del' . '">Удалить</a></li>';
                                }

            $html .= '</ul>
	            		</div>
	            	</div>
	            </td>
            </tr>';
        }
        $APPLICATION->RestartBuffer();
        echo $html;
        die;
    }


    private function executeAction(string $action)
    {
        switch ($action) {
            case 'getWidgets':
                $arWidgets = $this->getWidgetsByEventID($this->request['event']);
                $this->getLayoutWidgetsList($arWidgets);
                break;
            default:
                return false;
        }
    }

}