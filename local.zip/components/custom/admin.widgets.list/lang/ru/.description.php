<?php
$MESS["ADMIN_WIDGET_COMPONENT_NAME"] = "Виджеты";
$MESS["ADMIN_WIDGET_COMPONENT_DESCRIPTION"] = "Виджеты для работы с сайтом";