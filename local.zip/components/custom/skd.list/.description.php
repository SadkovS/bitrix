<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => GetMessage("HLB_SKD"),
    "DESCRIPTION" => GetMessage("HLB_SKD_DESC"),
    "CACHE_PATH" => "Y",
    "SORT" => 40,
    "PATH" => array(
        "ID" => "custom",
        "CHILD" => array(
            "ID" => "skd",
            "NAME" => GetMessage("C_HLDB_CAT_SKD"),
            "SORT" => 20,
            "CHILD" => array(
                "ID" => 'skd.list'
            )
        )
    ),
);

?>