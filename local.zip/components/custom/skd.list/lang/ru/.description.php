<?
$MESS ['HLB_SKD'] = "Доступ СКД";
$MESS ['HLB_SKD_DESC'] = "Показывает список доступов СКД";
$MESS ['C_HLDB_CAT_SKD'] = "СКД";
?>