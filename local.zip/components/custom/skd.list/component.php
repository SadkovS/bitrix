<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */


use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Highloadblock as HL;
use Custom\Core\EventStatistic;

$limit   = (int)$arParams['SKD_COUNT'];
$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
Loader::includeModule('custom.core');

$curPage = (int)$request['PAGEN_1'] > 0 ? (int)$request['PAGEN_1'] : 1;
if (!isset($_REQUEST['PAGEN_1']) || (int)$_REQUEST['PAGEN_1'] <= 1)
    $offset = 0;
else
    $offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $limit;

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"]))
    $arParams["CACHE_TIME"] = 180;

// SKD
$filter = [
    'UF_COMPANY_ID' => $companyID,
    //'EVENT_STATUS' => EVENT_STATUS_PUBLISHED,
];

if (isset($request['q']) && $request['q'] != '') require_once 'search.php';

if (isset($request['n']) && $request['n'] != '') {
    $filter['%EVENT_NAME'] = $request['n'];
}

if (isset($request['ds']) && $request['ds'] != '') {
    $date_start = DateTime::createFromFormat('d.m.Y', $request['ds'])->format('d.m.Y');
    $filter[] = [">=ACCESS_ITEMS.DATES.VALUE" => $date_start];
}

if (isset($request['de']) && $request['de'] != '') {
    $date_end = DateTime::createFromFormat('d.m.Y', $request['de'])->format('d.m.Y');
    $filter[] = ["<=ACCESS_ITEMS.DATES.VALUE" => $date_end];
}

$offerEntity         = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
$propFieldType       = $offerEntity->getField('TYPE');
$propFieldTypeEntity = $propFieldType->getRefEntity();

$hlblock     = HL\HighloadBlockTable::getById(HL_EVENTS_ID)->fetch();
$entity      = HL\HighloadBlockTable::compileEntity($hlblock);
$entityClass = $entity->getDataClass();

$order = ['ACCESS_ID' => 'DESC'];

if(isset($request['q_sort'])) {
    $order = ['EVENT_NAME' => (int)$request['q_sort']?'ASC':'DESC'];
}

$res = $entityClass::getList(
    [
        'select'      => [
            'ID',
            'EVENT_NAME' => 'UF_NAME',
            'EVENT_STATUS' => 'UF_STATUS',
            'ACCESS_ID' => 'ACCESS_ITEMS.ID',
            'ACCESS_DATES' => 'ACCESS_ITEMS.UF_DATE',
            'ACCESS_TICKETS_TYPE' => 'ACCESS_ITEMS.UF_TICKETS_TYPE',
            'TOKEN'      => 'USER.UF_REST_API_TOKEN',
            'USER_FIO',
            'TICKET_TYPES_NAME',
            //'VALIDATE_TICKET_COUNT',
            //'SOLD_TICKET_COUNT',
        ],
        'filter'      => $filter,
        'runtime'     => [
            new \Bitrix\Main\Entity\ReferenceField(
                'ACCESS_ITEMS',
                '\Custom\Core\Skd\AccessSKDTable',
                ['this.ID' => 'ref.UF_EVENT_ID'],
                ['join_type' => 'INNER'],
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'USER',
                '\Bitrix\Main\UserTable',
                ['this.ACCESS_ITEMS.UF_USER_ID' => 'ref.ID'],
                ['join_type' => 'LEFT']
            ),
            new \Bitrix\Main\Entity\ExpressionField(
                'USER_FIO',
                'CONCAT(%s, " ", %s, " ", %s)',
                [
                    'USER.LAST_NAME',
                    'USER.NAME',
                    'USER.SECOND_NAME'
                ]
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'TICKET_TYPE_REF',
                $propFieldTypeEntity,
                ['this.ACCESS_ITEMS.TICKETS_TYPE.VALUE' => 'ref.IBLOCK_ELEMENT_ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ExpressionField(
                'TICKET_TYPES_NAME',
                "GROUP_CONCAT(%s SEPARATOR ';')", // DISTINCT
                ['TICKET_TYPE_REF.VALUE']
            ),
        ],
        'offset' => $offset,
        'limit' => $limit,
        'group'=> ['ID'],
        'order' => $order,
        'count_total'=> true,
    ]
);

$eventsId = [];
$eventStatistic = new EventStatistic();

while ($skdItem = $res->fetch()) {
    $skdItem['ACCESS_DATES'] = array_map(fn($d) => (new \DateTime($d))->format('d.m.y'), $skdItem['ACCESS_DATES']);
    $skdItem['TICKET_TYPES_NAME'] = $skdItem['TICKET_TYPES_NAME'] ? explode(';', $skdItem['TICKET_TYPES_NAME']) : [];
    
    // не совсем оптимальное решение для получения провренных. Желательно перейти на один запрос
    $skdItem['VALIDATE_QUANTITY'] = $eventStatistic->getEventCountTicketValidated($skdItem['ID'], $skdItem['ACCESS_ID'], $skdItem['ACCESS_TICKETS_TYPE']);
    
    $this->arResult['ITEMS'][] = $skdItem;
    
    if (!in_array($skdItem['ID'], $eventsId)) {
        $eventsId[] = $skdItem['ID'];
    }
}

$countSold = $eventStatistic->getEventsCountTicketSold($eventsId);

foreach ($this->arResult['ITEMS'] as $key => $item) {
    $this->arResult['ITEMS'][$key] = itemAttachCounter($this->arResult['ITEMS'][$key], 'SOLD_QUANTITY', $countSold[$item['ID']] ?? []);
}

unset($eventsId, $countSold, $countValidate);

$this->arResult['ALL_COUNT'] = $res->getCount();
$this->nav                   = new \CDBResult();
$this->nav->NavStart($limit);
$this->nav->NavPageCount      = ceil((int)$arResult['ALL_COUNT'] / $limit);
$this->nav->NavPageNomer      = $curPage;
$this->nav->NavRecordCount    = $arResult['ALL_COUNT'];
$this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');

$this->IncludeComponentTemplate();

function itemAttachCounter(array $item, string $key, array $eventCounter): array {
 
    if (!isset($item[$key])) {
        $item[$key] = 0;
    }
    
    foreach ($eventCounter as $ticketTypeId => $count) {
        if (in_array($ticketTypeId, $item['ACCESS_TICKETS_TYPE'])) {
            $item[$key] += $count;
        }
    }
    
    return $item;
}
?>
