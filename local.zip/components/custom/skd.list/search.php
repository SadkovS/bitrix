<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Bitrix\Main\Application;
use Bitrix\Main\ORM;

$eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
$eventClass  = $eventEntity->getEntity()->getDataClass();
$query       = $eventEntity
	->setSelect(['ID', 'UF_NAME','*'])
	->setFilter([
        '%UF_NAME' => $request['q'],
        'UF_COMPANY_ID'=> $companyID,
        '!STATUS.UF_XML_ID' => ["completed", "cancelled"]
    ])
    ->registerRuntimeField(
        'STATUS',
        array(
            'data_type' => '\Custom\Core\Events\EventsStatusTable',
            'reference' => array('=this.UF_STATUS' => 'ref.ID'),
            'join_type' => 'LEFT'
        )
    )
	->exec();

$result = [];
while ($event = $query->fetch()) {
	$result[] = ['id' => $event['ID'],'name' => $event['UF_NAME'], 'event' => $event];
}

$APPLICATION->RestartBuffer();
echo json_encode($result, JSON_UNESCAPED_UNICODE);
die;
