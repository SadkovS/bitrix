<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
use Bitrix\Main\Application;
use Bitrix\Main\Page\Asset;
$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");
?>
<div class="admin-body__item wide events js-admin-skd-body">
	<div class="admin-body__item-header">
		<h1>Доступ СКД</h1>
		<button type="button" class="btn btn__fix-width" data-popup="#skd-add" data-popup-src="<?= $arParams['SEF_FOLDER']?>0/?action=getForm&ajax=y">Добавить</button>
	</div>
	<div class="admin-body__item-sort">
		<button type="button" class="reset-filter-btn" data-filters-reset-skd>
			<span>Сбросить фильтры</span>
			<i class="_icon-plus"></i>
		</button>
	</div>
	<?if(isset($request['ajax']) && $request['ajax'] == 'Y') $APPLICATION->RestartBuffer();?>
	<table class="events__table">
		<thead>
		<tr>
			<td>
				<div class="events__table-item">
					<label class="events__table-btn" data-table-sort="">
						<span>Название мероприятия</span>
						<input type="checkbox" class="d-none" name="q_sort" value="1"> <i class="_icon-vector"></i>
					</label>
					<div class="events__form-item">
						<input class="events__form-input" placeholder="Найти" type="text" name="n" value="<?=$request['n']?>"> <i class="_icon-search"></i>
					</div>
				</div>
			</td>
			<td>
				<div class="events__table-item">
					<p>Дата действия доступа</p>
					<div class="date__split">
						<input class="promo-date input__bordered" name="ds" data-date="" data-date-split-start="" placeholder="ДД.ММ.ГГ" readonly="" type="text" value="<?= $request['ds'] ?>"> -
						<input class="promo-date input__bordered" name="de" data-date="" data-date-split-end="" placeholder="ДД.ММ.ГГ" readonly="" type="text" value="<?= $request['de'] ?>">
					</div>
				</div>
			</td>
			<td>
				<div class="events__table-item">
					<p>ФИО</p>
				</div>
			</td>
			<td>
				<div class="events__table-item">
					<p>Код доступа</p>
				</div>
			</td>
			<td>
				<div class="events__table-item">
					<p>Типы билетов</p>
				</div>
			</td>
			<td colspan="2">
				<div class="events__table-item">
					<p class="tikets-count-top">Билеты, шт.</p>
					<div class="tikets-count-bot">
						<div class="tikets-count-bot__itm">Обработано</div>
						<div class="tikets-count-bot__itm">Всего</div>
					</div>
					<p class="tikets-count-bot-sep"></p>
				</div>
			</td>
			<td></td>
		</tr>
		</thead>
		<tbody>
		
		 <? foreach ($arResult['ITEMS'] as $item): ?>
			 <tr>
				 <td>
					 <div class="events__table-item">
						 <div class="events__table-item-name">
							 <p><?= $item['EVENT_NAME'] ?? ''?></p>
						 </div>
					 </div>
				 </td>
				 <td>
					 <div class="events__table-item">
						 <div class="events__table-item table-col-with-skd-widget js-skd-widget-select-wrap">
							 
							 <div class="events__table-item-name skd-widget-list js-skd-widget-select-list"></div>
							 
							 <div class="js-skd-widget-select" data-no-delete="true">
								
								 <div class="skd-widget-select-list skd-widget-select-list--left">
								
									 <? foreach ($item['ACCESS_DATES'] as $dateItem): ?>
										 <label class="skd-widget-select-itm">
											 <input checked type="checkbox" value="<?= $dateItem ?>"> <span class="skd-widget-select-itm__val"><?= $dateItem ?></span>
										 </label>
									 <? endforeach; ?>
								 </div>
							 </div>
						 </div>
					 </div>
				 </td>
				 <td>
					 <div class="events__table-item">
						 <p><?= $item['USER_FIO'] ?? ''?></p>
					 </div>
				 </td>
				 <td>
					 <div class="events__table-item">
						 <div class="copy-buffer">
							 <div class="copy-buffer__text"><?= strtoupper($item['TOKEN'] ?? '')?></div>
							 <div class="copy-buffer__btn js-copy-to-buffer" data-copy-text="<?= strtoupper($item['TOKEN'] ?? '')?>"></div>
						 </div>
					 </div>
				 </td>
				 <td>
					 <div class="events__table-item js-skd-widget-select-wrap">
						 <div class="events__table-item-name skd-widget-list">
							 <? if (isset($item['TICKET_TYPES_NAME']) && is_array($item['TICKET_TYPES_NAME']) && count($item['TICKET_TYPES_NAME']) > 0): ?>
								 <div class="skd-widget"><?= array_shift($item['TICKET_TYPES_NAME']); ?></div>
							    <? if (count($item['TICKET_TYPES_NAME']) > 0): ?>
									 <div class="skd-widget">+ <?= count($item['TICKET_TYPES_NAME']); ?></div>
							    <? endif; ?>
							 
							 <? endif; ?>
						 </div>
					 </div>
				 </td>
				 <td>
					 <div class="events__table-item">
						 <p><?= $item['VALIDATE_QUANTITY'] ?:0?></p>
					 </div>
				 </td>
				 <td>
					 <div class="events__table-item">
						 <p><?= $item['SOLD_QUANTITY'] ?:0?></p>
					 </div>
				 </td>
				 <td>
					 <div class="events__table-controls" data-event-controls>
						 <button class="btn__icon" data-event-controls-btn type="button">
							 <i class="_icon-rounds"></i>
						 </button>
						 <div class="events__table-controls-body" data-event-controls-body>
							 <ul>
								 <li>
									 <a data-popup-src="<?=$arParams['SEF_FOLDER'].$item['ACCESS_ID']?>/?action=getForm&ajax=y" data-popup="#skd-add" href="javascript:void(0)">Редактировать</a>
								 </li>
								 <li>
									 <a href="javascript:void(0);" data-delete-confirm-title="СКД доступ для <?= $item['USER_FIO'] ?? ''; ?>" data-delete-skd-link="<?=$arParams['SEF_FOLDER'] . $item['ACCESS_ID'] ?>/?action=del" data-delete-skd-confirm="<?=$item['ACCESS_ID']?>">Удалить</a>
								 </li>
							 </ul>
						 </div>
					 </div>
				 </td>
			 </tr>
		<? endforeach; ?>
		</tbody>
	</table>
	<?= $arResult['NAV_STRING'] ?>
	<?if(isset($request['ajax']) && $request['ajax'] == 'Y') die();?>
</div>