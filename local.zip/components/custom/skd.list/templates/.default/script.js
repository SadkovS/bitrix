
$(document).ready(function () {

    $(document).on('submit', '#create-skd-form', function (e) {
        e.preventDefault();

        let form = $(this);
        let url = form.attr('action');
        addLoader();
        $.ajax({
            method: 'post',
            url: url,
            data: form.serializeArray(),
        }).done(function (data) {
            const formattedData = JSON.parse(data);
            removeLoader();
            showToast(formattedData);
            if (formattedData.status === 'success') {
                document.dispatchEvent(new CustomEvent("closePopup", {
                    bubbles: true,
                    detail: {
                        popup: '#create-skd'
                    }
                }));
                skdBodyRefresh();
            }
        });
        return false;
    });

    // Изменение фильтра
    async function getUrlVars( sort = true) {
        let url = new Url(window.location.href);
        const [name, dateStart, dateEnd, qSort] = [
            document.querySelector('input[name="n"]').value,
            document.querySelector('input[name="ds"]').value,
            document.querySelector('input[name="de"]').value,
            document.querySelector('input[name="q_sort"]')
        ];

        url.query.ajax = 'Y';
        name === ''     ?   delete url.query.n  :   url.query.n = name;
        dateStart === ''     ?   delete url.query.ds  :   url.query.ds = dateStart;
        dateEnd === ''     ?   delete url.query.de  :   url.query.de = dateEnd;

        if (sort) {
            qSort.checked === true ? url.query.q_sort = '0' : url.query.q_sort = '1';
        } else {
            delete url.query.q_sort;
            delete url.query.PAGEN_1;
        }

        const address = url.toString();

        const response = await fetch(address);
        if (!response.ok) {
            return
        }
        const data = await response.text()
        let doc = new DOMParser().parseFromString(data, "text/html");
        const tbody = doc.querySelector('tbody');
        const pagination = doc.querySelector('.pagination.events__pagination');
        delete url.query.ajax;

        window.history.pushState("event search", "", url.toString());
        document.querySelector('.events__table tbody').replaceWith(tbody);
        document.querySelector('.events__pagination').replaceWith(pagination);
        skdWidgetSync();
    }
    // Эвент фильтрации по инпуту
    function inputFilter(e) {
        const target = e.target;
        if (!target.closest('[name="n"]')) return;
        getUrlVars(false);
    }

    function changeFilter(e) {
        const target = e.target;
        if (!target.closest('[name="ds"]') && !target.closest('[name="de"]') && !target.closest('[name="q_sort"]')) return;
        if (target.closest('[name="q_sort"]')) {
            getUrlVars(true);
        } else {
            getUrlVars(false);
        }
    }

    // Бинд всех эвентов на страницу
    [
        ['change', changeFilter],
        ['change', setEventCallback],
        ['input', debounce(inputFilter, 500)],
        ['click', openDeleteConfirmSkdPopup],
        ['click', deleteSkdConfirm],
    ].forEach(([event, fn]) => {
        document.addEventListener(event, fn)
    });

    async function getEventInfo(eventId) {

        const response = await fetch(`/admin_panel/skd/0/?action=eventGetInfo&eventId=${eventId}&ajax=y`);
        if (!response.ok) {
            return
        }

        const data = await response.json();

        if (data.status === 'success' && data.payload) {
            const lists = document.querySelectorAll('#create-skd-form .js-skd-widget-select-wrap');
            if( lists.length ) {
                for ( let i = 0; i < lists.length; i++ ) {
                    let select = lists[i].querySelector(' .skd-widget-select-list');
                    let selectedItems = lists[i].querySelector(' .js-skd-widget-select-list > .skd-widget:not(button)');

                    if( select ) {
						select.querySelectorAll('.skd-widget-select-itm').forEach((el) => {
							if( el.classList.contains('js-all-skd-widget-select') ) {
								return true
							}
							el.remove();
						})
                    }

                    if( selectedItems ) {
                        selectedItems.remove();
                    }


                    if( select.getAttribute('data-entry') === 'dates' && data.payload.dates ) {
                        for ( const [key, value] of Object.entries(data.payload.dates) ) {
                            select.insertAdjacentHTML("beforeend",
                                `
                                            <label class="skd-widget-select-itm">
                                            <input type="checkbox" value="${value.DATE_SHORT}" name="DATES[]"> <span
                                            class="skd-widget-select-itm__val">${value.DATE_SHORT}</span>
                                            </label>
                                            `
                            );
                        }
                    } else if( select.getAttribute('data-entry') === 'ticket_types' && data.payload.ticket_types ) {
                        for ( const [key, value] of Object.entries(data.payload.ticket_types) ) {
                            select.insertAdjacentHTML("beforeend",
                                `
                                            <label class="skd-widget-select-itm">
                                            <input type="checkbox" value="${value.ID}" name="TICKET_TYPES[]"> <span
                                            class="skd-widget-select-itm__val">${value.NAME}</span>
                                            </label>
                                            `
                            );
                        }
                    }
                }
            }
        }
    }


    function setEventCallback(e) {
        const target = e.target;
        if (target.getAttribute('type') !== "hidden" || !target.classList.contains('js-search-page-g-id')) return;

        getEventInfo(target.value);
    }

// Функция дебаунса
    function debounce(func, wait, immediate) {
        let timeout;
        return function() {
            const context = this;
            const args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    function openDeleteConfirmSkdPopup(e) {
        const target = e.target;
        const btn = target.closest('[data-delete-skd-confirm]');
        if(!btn) return;

        const link = btn.getAttribute('data-delete-skd-confirm');

        const url = target.getAttribute('data-delete-skd-link');

        const title = btn.getAttribute('data-delete-confirm-title') || '';
        const content = `<div class="popup__content">
      <button data-close type="button" class="popup__close profile__popup-close"><i class="_icon-plus"></i></button>
      <div class="popup__name h1">Вы точно хотите <br>
        удалить ${title}</div>
        <div class="row d-flex justify-content-center">
          <div class="col-auto">
            <button type="button" class="btn btn__blue btn__big" data-close>Оставить</button>
          </div>
          <div class="col-auto">
            <button type="button" class="btn btn__clean btn__big" data-skd-confirm-url="${url}" data-skd-confirm-delete="${link}">Удалить</button>
          </div>
        </div>
        </div>`;
        document.dispatchEvent(new CustomEvent('openPopup', {detail: {popup: '#delete-item', content}}));
    }

    async function deleteSkdConfirm(e) {
        const target = e.target;
        if (!target.closest('[data-skd-confirm-delete]')) return;
        e.preventDefault();
        const btn = target.closest('[data-skd-confirm-delete]');
        const url = btn.getAttribute('data-skd-confirm-url');
        const formData = new FormData();
        formData.append('ID', btn.getAttribute('data-skd-confirm-delete'));
        addLoader();
        const response = await fetch(url, {
            method: 'POST',
            body: formData
        })
        removeLoader();
        if (!response.ok) {
            return
            // throw new Error(response.statusText);
        }
        const data = await response.json();
        if (data.status === 'success') {
            document.dispatchEvent(new CustomEvent('closePopup', {detail: {popup: '#delete-item'}}));
            skdBodyRefresh();
        } else {
            showToast(data);
            document.dispatchEvent(new CustomEvent('closePopup', {detail: {popup: '#delete-item'}}));
        }
    }

    async function fetchSkdBody() {
        const url = new URL(window.location.href);
        url.searchParams.set('ajax', 'Y');
        const address = url.toString();
        addLoader();
        const response = await fetch(address);

        removeLoader();
        if (!response.ok) {
            return
        }
        const data = await response.text()
        return new DOMParser().parseFromString(data, "text/html");
    }
   // skdBodyRefresh();
    async function skdBodyRefresh() {
        const doc = await fetchSkdBody();
        if (!doc) {
            return
        }

        const domItems = [doc.querySelector('.events__table'), doc.querySelector('.pagination')];
        const skdBody = document.querySelector('.js-admin-skd-body');
        const pItems = [skdBody.querySelector('.events__table'), skdBody.querySelector('.pagination')];
        if (domItems.length) {
            for(let i = 0; i< pItems.length; i++){
                const element = pItems[i]
                while (element.firstChild) {
                    element.removeChild(element.firstChild);
                }
                for(let j = 0; j < domItems[i].childElementCount; j++){
                    const item = domItems[i].children[j].cloneNode(true);
                    element.appendChild(item);
                }
            }
            skdWidgetSync();
            document.dispatchEvent(new CustomEvent('airdatepickerInit', {
                bubbles: true,
                detail: {
                    element: skdBody
                }
            }))
        }
    }
    function addLoader() {
        document.body.classList.add('loading')
    }

    function removeLoader() {
        document.body.classList.remove('loading')
    }


    function resetFilters() {
        const url = new URL(window.location.href);
        url.search = '';
        document.querySelectorAll('.events__table thead input[type="text"], .events__table input[type="hidden"] ').forEach(el => el.value = '');
        document.querySelectorAll('.events__table thead .js-option-change').forEach(el => el.textContent = 'Все');
        getUrlVars(false);
    }

    function resetFiltersSkd(e) {
        const target = e.target;
        if (!target.closest('[data-filters-reset-skd]')) return;
        resetFilters();
    }


    // Бинд всех эвентов на страницу
    [
        ['click', debounce(resetFiltersSkd, 200)],
    ].forEach(([event, fn]) => {
        document.addEventListener(event, fn)
    });
});