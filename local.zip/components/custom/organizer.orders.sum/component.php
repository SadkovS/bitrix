<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\ORM;

$limit   = (int)$arParams['ORDER_PER_PAGE'];
$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
Loader::includeModule('custom.core');
Loader::includeModule('sale');
Loader::includeModule("catalog");

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"]))
    $arParams["CACHE_TIME"] = 180;
if ((int)$arParams["COUNT_DAYS"] < 1)
    $arParams["COUNT_DAYS"] = 28;

if (!CModule::IncludeModule("iblock")) {
    $this->AbortResultCache();
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

$filter = [
    'PROPS.CODE' => "ORGANIZER_ID",
    'PROPS.VALUE' => $companyID,
    'PAYED' => "Y",
    '!CANCELED' => "Y",
    '!STATUS_ID' => "CD",
    //"!=IS_REFUNDED" => "Y",
    [
        'LOGIC' => 'AND',
        ">=DATE_INSERT" => (new DateTime())->format('d.m.Y') . ' 00:00:00',
        "<=DATE_INSERT" => (new DateTime())->format('d.m.Y') . ' 23:59:59',
    ]
];


$ordersEntity = new ORM\Query\Query('\Bitrix\Sale\Internals\OrderTable');
$query       = $ordersEntity
    ->setSelect([
                    "BASKET_REFS_ID" => "BASKET_REFS.ID",
                    "BASKET_REFS_PRICE" => "BASKET_REFS.PRICE",
                    "IS_REFUNDED" => "BASKET_PROPS.VALUE",
                    "REFUND_PRICE" => "BASKET_PROPS_REFUND_PRICE.VALUE",
                    'PRICE',
                    'QUANTITY'
                ])
    ->setFilter($filter)
    ->registerRuntimeField(
        "PROPS",
        [
            'data_type' => 'Bitrix\Sale\Internals\OrderPropsValueTable',
            'reference' => array('=this.ID' => 'ref.ORDER_ID'),
            'join_type' => 'INNER'
        ]
    )
    ->registerRuntimeField(
        "BASKET_REFS",
        [
            'data_type' => 'Bitrix\Sale\Internals\BasketTable',
            'reference' => array('=this.ID' => 'ref.ORDER_ID'),
            'join_type' => 'INNER'
        ]
    )
    ->registerRuntimeField(
        '',
        (new \Bitrix\Main\Entity\ReferenceField(
            'BASKET_PROPS',
            'Bitrix\Sale\Internals\BasketPropertyTable',
            \Bitrix\Main\ORM\Query\Join::on('ref.BASKET_ID', 'this.BASKET_REFS.ID')
                ->where("ref.CODE", "=", "IS_REFUNDED")
        ))->configureJoinType(
            \Bitrix\Main\ORM\Query\Join::TYPE_LEFT,
        )
    )
    ->registerRuntimeField(
        '',
        (new \Bitrix\Main\Entity\ReferenceField(
            'BASKET_PROPS_REFUND_PRICE',
            'Bitrix\Sale\Internals\BasketPropertyTable',
            \Bitrix\Main\ORM\Query\Join::on('ref.BASKET_ID', 'this.BASKET_REFS.ID')
                ->where("ref.CODE", "=", "REFUNDED_PRICE")
        ))->configureJoinType(
            \Bitrix\Main\ORM\Query\Join::TYPE_LEFT,
        )
    )
    ->registerRuntimeField(
        new \Bitrix\Main\Entity\ExpressionField(
            'PRICE', 'SUM(%s)', ['BASKET_REFS.PRICE']
        )
    )
    ->registerRuntimeField(
        new \Bitrix\Main\Entity\ExpressionField(
            'QUANTITY', 'SUM(%s)', ['BASKET_REFS.QUANTITY']
        )
    )
    ->setCacheTtl(180)
    ->setDistinct()
    ->exec();
$this->arResult = [];
while($item = $query->fetch()){
    $arResult['SUM'] += $item['PRICE'];
    $arResult['SUM_QUANTITY'] += $item['QUANTITY'];
    if($item['IS_REFUNDED'] == 'Y'){
        $arResult['SUM'] -= $item['REFUND_PRICE'];
        $arResult['SUM_QUANTITY'] -= $item['QUANTITY'];
    }
}

//$this->SetResultCacheKeys([]);
$this->IncludeComponentTemplate();

//$this->AbortResultCache();
?>
