<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
?>
<div class="adminpanel__header-item-title">
    <h3>Продажи сегодня</h3><a href="/admin_panel/analytics/orders/" class="btn">Заказы</a>
</div>
<div class="adminpanel__header-item-data"><span class="green"><?= number_format(floatval($arResult['SUM']), 2, '.', ' ');?> ₽</span></div>
<div class="adminpanel__header-item-foot-desc">Продано билетов: <?= (int)$arResult['SUM_QUANTITY']?></div>
