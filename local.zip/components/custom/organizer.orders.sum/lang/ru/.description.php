<?
$MESS ['HLB_ORDERS_SUM_ORGANIZER'] = "Сумма продаж за период";
$MESS ['HLB_ORDERS_SUM_ORGANIZER_DESC'] = "Показывает сумму всех заказов организатора за период";
$MESS ['C_HLDB_CAT_ORDERS'] = "Заказы";
?>