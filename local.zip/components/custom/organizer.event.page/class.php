<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();

use Bitrix\Main;
use Bitrix\Iblock;
use Bitrix\Main\ORM;
use	Custom\Core\Events\EventsCategoryTable;
use	Custom\Core\Events\EventsTable;
use Custom\Core\Helper;

class Compilation extends CBitrixComponent
{
	public function onPrepareComponentParams($arParams)
	{
		return $arParams;
	}
	
	public function get404()
	{
		Bitrix\Iblock\Component\Tools::process404(
	       'Страница не найдена',
	       true,
	       true,
	       true,
	       false
		);
	}
	
	public function setFilter($filter = null)
	{
        $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"] = $filter;
	}
	
	public function getOrganizer()
	{
		$request = \Bitrix\Main\Context::getCurrent()->getRequest();
        $companyID = $request["organizer"];

		if($companyID)
		{
            $filter = [];

            if($GLOBALS[$this->arParams["FILTER_NAME"]] && array_key_exists("PROPERTY_EVENT_ID", $GLOBALS[$this->arParams["FILTER_NAME"]]))
            {
                $filter["=ID"] = $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"];
            }

            $productEntity     = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
            $productPropField  = $productEntity->getField('EVENT_ID');
            $productPropEntity = $productPropField->getRefEntity();
            $propFieldClosed       = $productEntity->getField('IS_CLOSED_EVENT');
            $propFieldClosedEntity = $propFieldClosed->getRefEntity();
            $propFieldModeration       = $productEntity->getField('MODERATION');
            $propFieldModerationEntity = $propFieldModeration->getRefEntity();

            $filter = array_merge(
                $filter,
                [
                    "=UF_COMPANY_ID" => $companyID,
                    "=STATUS_REF.UF_XML_ID" => ["published"],
                    "=ELEMENT.ACTIVE" => "Y",
                    "=PROP_CLOSED_REF.VALUE" => null,
                    "=PROP_MODERATION_REF.VALUE" => null,
                    [
                        'LOGIC' => 'OR',
                        ['ELEMENT.ACTIVE_FROM' => false],
                        ['<=ELEMENT.ACTIVE_FROM' => date('d.m.Y H:i:s')]
                    ],
                    [
                        'LOGIC' => 'OR',
                        ['ELEMENT.ACTIVE_TO' => false],
                        ['>=ELEMENT.ACTIVE_TO' => date('d.m.Y H:i:s')]
                    ],
                ]
            );

            $query = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
            $resCompany   = $query
                ->setFilter(["ID" => $companyID])
                ->setSelect([
                    'ID',
                    'UF_NAME',
                    'UF_DESCRIPTION',
                    'LOGO_SRC',
                ])
                ->registerRuntimeField(
                    'PICTURE',
                    array(
                        'data_type' => '\Bitrix\Main\FileTable',
                        'reference' => array('=this.UF_LOGO' => 'ref.ID'),
                        'join_type' => 'LEFT'
                    )
                )
                ->registerRuntimeField(
                    'LOGO_SRC',
                    new \Bitrix\Main\Entity\ExpressionField('LOGO_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['PICTURE.SUBDIR', 'PICTURE.FILE_NAME'])
                )
                ->exec();
            if($company = $resCompany->fetch()){
                $company["ORGANIZER_PAGE_URL"] = str_replace("#ORGANIZER_ID#", $companyID, $this->arParams["ORGANIZER_PAGE_URL"]);
                $company["SHARE"] = Helper::getShareLinks($company["ORGANIZER_PAGE_URL"], $company["UF_NAME"]);
                $this->arResult = $company;

                $dbRes = \Custom\Core\Events\EventsTable::getList(
                    [
                        'select'      => [
                            'ID',
                        ],
                        'filter'      => $filter,
                        'runtime'     => [
                            new \Bitrix\Main\Entity\ReferenceField(
                                'CATEGORY',
                                '\Custom\Core\Events\EventsCategoryTable',
                                ['=this.UF_CATEGORY' => 'ref.ID'],
                                ['join_type' => 'inner']
                            ),
                            new \Bitrix\Main\Entity\ReferenceField(
                                'STATUS_REF',
                                '\Custom\Core\Events\EventsStatusTable',
                                ['=this.UF_STATUS' => 'ref.ID'],
                                ['join_type' => 'inner']
                            ),
                            new \Bitrix\Main\Entity\ReferenceField(
                                'EVENT_REF',
                                $productPropEntity,
                                ['=this.ID' => 'ref.VALUE'],
                                ['join_type' => 'inner']
                            ),
                            new \Bitrix\Main\Entity\ReferenceField(
                                'ELEMENT',
                                $productEntity,
                                ['=this.EVENT_REF.IBLOCK_ELEMENT_ID' => 'ref.ID'],
                                ['join_type' => 'left']
                            ),
                            new \Bitrix\Main\Entity\ReferenceField(
                                'PROP_CLOSED_REF',
                                $propFieldClosedEntity,
                                ['this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'],
                                ['join_type' => 'LEFT'],
                            ),
                            new \Bitrix\Main\Entity\ReferenceField(
                                'PROP_MODERATION_REF',
                                $propFieldModerationEntity,
                                ['this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'],
                                ['join_type' => 'LEFT'],
                            ),
                        ],
                    ]
                );

                $eventIds = [];

                while($obEvents = $dbRes->fetch())
                {
                    $eventIds[$obEvents["ID"]] = $obEvents["ID"];
                }

                if($eventIds)
                {
                    $this->setFilter($eventIds);
                }
                else
                {
                    $this->setFilter(false);
                }
            }
            else
            {
                $this->get404();
            }

		}
		else
		{
			$this->get404();
		}
	}
	
	public function executeComponent()
	{
		$componentPage = "section";
		
		$this->arResult["ORGANIZER"] = $this->getOrganizer();
		
		$this->IncludeComponentTemplate($componentPage);
	}
	
	protected static function getSession(): ?Session
	{
		/** @var Session $session */
		$session = Application::getInstance()->getSession();
		if (!$session->isAccessible())
		{
			return null;
		}

		return $session;
	}

}
