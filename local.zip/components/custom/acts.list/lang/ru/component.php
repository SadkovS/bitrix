<?
$MESS ['ERROR_NO_COMPANY_FOR_USER'] = "У пользователя нет основной организации";
$MESS ['ERROR_COMPANY_NOT_FOUND'] = "Не найдена организация";
?>