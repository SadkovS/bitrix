<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>

<div class="admin-body__item wide events">
    <div class="admin-body__item-header">
        <h1>Акты</h1>
    </div>
    <table class="events__table table-standard-th">
        <thead>
        <tr>
            <td>Месяц и год</td>
            <td>Дата выставления</td>
            <td>Статус</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        </thead>
        <tbody>

        <?foreach ($arResult['ACTS'] as $act):?>
            <tr class="">
                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p class="wrap"><?=$act["RU_M_Y"]?></p>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$act["DATE_FORMAT"]?></p>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p class="table-status <?=$act["STATUS_CLASS"]?>"><?=$act["STATUS_VALUE"]?></p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <a class="btn btn__grey-transparent btn__medium-width" href='<?=$act["UF_LINK"]?>' target="_blank">Посмотреть акт</a>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <a class="btn btn__grey-transparent btn__medium-width" href='<?=$act["UF_FILE_UPD"]?>' target="_blank">Посмотреть УПД</a>
                    </div>
                </td>
                <td>
                    <?if($act["BTN_VERIF"]):?>
                        <div class="events__table-item">
                            <button data-popup="#submit-act" data-popup-src="<?=$arParams["SEF_FOLDER"]?>/verif.php?id=<?=$act["ID"]?>" class="btn btn__blue btn__medium-width">Подписать</button>
                        </div>
                    <?endif;?>
                </td>
                <td>
                    <div class="events__table-item">

                    </div>
                </td>
                <td>
                    <div class="events__table-controls" data-event-controls>
                        <button class="btn__icon" data-event-controls-btn type="button">
                            <i class="_icon-rounds"></i>
                        </button>
                        <div class="events__table-controls-body" data-event-controls-body>
                            <ul>
                                <li>
                                    <a download="" href='<?=$act["UF_LINK"]?>'>Скачать акт</a>
                                </li>
                                <li>
                                    <a download="" href='<?=$act["UF_FILE_UPD"]?>'>Скачать УПД</a>
                                </li>
                                <li>
                                    <a href="#">Отправить на почту</a>
                                </li>
                                <?if($act["BTN_VERIF"]):?>
                                    <li>
                                        <a data-popup="#doc-act-edit" data-popup-src="<?=$arParams["SEF_FOLDER"]?>/act.message.form.php?id=<?=$act["ID"]?>">Скорректировать</a>
                                    </li>
                                <?endif;?>
                            </ul>
                        </div>
                    </div>
                </td>
            </tr>
        <?endforeach;?>

        </tbody>
    </table>
    <?= $arResult['NAV_STRING'] ?>
</div>

<div id="doc-act-edit" aria-hidden="true" class="popup popup__under">
    <div class="popup__wrapper">

    </div>
</div>