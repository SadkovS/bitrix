$(document).ready(function () {
    function addLoader() {
        document.body.classList.add('loading')
    }

    function removeLoader() {
        document.body.classList.remove('loading')
    }
     function saveEventBody(resolve) {
        let url = "";
        let formData = [];

        if($(this).data('href'))
        {
            url = $(this).data('href');
        }
        else
        {
            let form = $(this).closest('form');

            url = form.attr('action');
            formData = new FormData(form.get(0));
        }

        addLoader();

        $.ajax({
            method: 'post',
            url: url,
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
        }).done(function (data) { 
            removeLoader();
            const formattedData = JSON.parse(data);
            showToast(formattedData);

            if(formattedData["status"] == "success")
            {
                location.reload();
            }
        });
    }

    $(document).on('click', '.btn_act_verif, .btn_act_add_message', function () {
       saveEventBody.call(this, null)
    });

    $(document).on('click', '._icon-trash2', function () {
        let img = $(this).closest(".upload").find("img");
        let input = $(this).closest(".upload").find("input[type='file']");

        $(input).val("");
        $(img).remove();
    });
});


