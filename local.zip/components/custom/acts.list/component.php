<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Custom\Core\Products;
use Custom\Core\PriceRules;
use \Bitrix\Main\Localization\Loc;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest()->toArray();;
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('catalog') ||
    !Loader::IncludeModule("iblock")
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    if (
        isset($request['action']) &&
        isset($request['id']) &&
        $request['action'] == 'verif'
    )
    {
        $APPLICATION->RestartBuffer();

        if(!check_bitrix_sessid())
        {
            echo json_encode(['status' => 'error', 'message' => 'Ошибка сессии'], JSON_UNESCAPED_UNICODE);
        }

        $query = new ORM\Query\Query('\Custom\Core\Users\ActsTable');
        $resAct   = $query
            ->setFilter(['ID' => $request['id'], 'UF_COMPANY' => $companyID])
            ->setSelect([
                'ID',
                'UF_XML_ID',
                'UF_FILE_UPD',
                'UF_LINK',
                'COMPANY_XML_ID' => 'COMPANY.UF_XML_ID',
                'COMPANY_UF_B24_DEAL_ID' => 'COMPANY.UF_B24_DEAL_ID'
            ])
            ->registerRuntimeField(
                'COMPANY',
                array(
                    'data_type' => '\Custom\Core\Users\CompaniesTable',
                    'reference' => array('=this.UF_COMPANY' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->setLimit(1)
            ->exec();

        if($elAct = $resAct->fetch()) {
            \Custom\Core\Act::sendActMessage([
                "id" => $elAct["UF_XML_ID"],
                "fields" => [
                    "ufCrm6_1732868727" => \Custom\Core\Act::ACT_VERIF["Y"],
                ]
            ]);

            if($elAct["UF_FILE_UPD"])
            {
                $path = $elAct["UF_FILE_UPD"];

                //$path = str_replace("crm.funtam.ru", "172.16.4.27", $path); //TODO потом убрать

                $fileName = explode("/", $path);
                $fileName = $fileName[count($fileName)-1];

                $bufferURL = explode("/", $path);
                $bufferURL[count($bufferURL)-1] = rawurlencode($bufferURL[count($bufferURL)-1]);
                $path = implode("/", $bufferURL);
                $base64File = base64_encode(file_get_contents($path));

                \Custom\Core\Act::sendDocs([
                    "fields" =>  [
                        'companyId' => $elAct["COMPANY_XML_ID"],
                        'parentId2' => $elAct["COMPANY_UF_B24_DEAL_ID"],
                        'ufCrm7_1732869721370' => [
                            '0' => [$fileName, $base64File]
                        ],
                        'ufCrm7_1732870068004' => \Custom\Core\Act::DOCUMENT_TYPE["upd"],
                    ]
                ]);
            }

            if($elAct["UF_LINK"])
            {
                $path = $elAct["UF_LINK"];
                $base64File = base64_encode(file_get_contents($path));

                $fileName = explode("/", $path);
                $fileName = $fileName[count($fileName)-1];

                \Custom\Core\Act::sendDocs([
                    "fields" =>  [
                        'companyId' => $elAct["COMPANY_XML_ID"],
                        'parentId2' => $elAct["COMPANY_UF_B24_DEAL_ID"],
                        'ufCrm7_1732869721370' => [
                            '0' => [$fileName, $base64File]
                        ],
                        'ufCrm7_1732870068004' => \Custom\Core\Act::DOCUMENT_TYPE["act"],
                    ]
                ]);
            }

            $arData["UF_STATUS"] = \Custom\Core\Contract::getHLfileldEnumId(
                \Custom\Core\Act::HL_NAME,
                \Custom\Core\Act::ACT_STATUS_XMLID,
                "accept"
            );

            $resUpdate = \Custom\Core\Users\ActsTable::update($request['id'], $arData);

            if (!$resUpdate->isSuccess())
            {
                echo json_encode(['status' => 'error', 'message' => str_replace("<br>", "\n", implode(', ', $resUpdate->getErrors()))], JSON_UNESCAPED_UNICODE);
            }
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => 'Акт не найден'], JSON_UNESCAPED_UNICODE);
        }

        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die();
    }

    if($companyID)
    {
        $query = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany   = $query
            ->setFilter(['ID' => $companyID])
            ->setSelect([
                'ID',
            ])
            ->setLimit(1)
            ->exec();
        if($company = $resCompany->fetch()){
            $curPage = (int)$request['PAGEN_1'] > 0 ? (int)$request['PAGEN_1'] : 1;
            if (!isset($_REQUEST['PAGEN_1']) || (int)$_REQUEST['PAGEN_1'] <= 1)
                $offset = 0;
            else
                $offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $arParams["ACTS_COUNT"];

            $queryActs = new ORM\Query\Query('\Custom\Core\Users\ActsTable');

            $resActsOb   = $queryActs
                ->setOrder([
                    "ID" => "DESC"
                ])
                ->setFilter([
                    'UF_COMPANY' => $companyID,
                    '!STATUS_XML_ID' => ["created"],
                ])
                ->setLimit($arParams["ACTS_COUNT"])
                ->setOffset($offset)
                ->setSelect([
                    '*',
                    'STATUS_' => 'STATUS',
                ])
                ->registerRuntimeField(
                    'STATUS',
                    array(
                        'data_type' => '\Custom\Core\FieldEnumTable',
                        'reference' => array('=this.UF_STATUS' => 'ref.ID'),
                        'join_type' => 'LEFT'
                    )
                )
                ->countTotal(1)
                ->exec();

            $resActs = $resActsOb->fetchAll();

            $statusClass = getActsStatusClass();

            foreach ($resActs as &$act)
            {
                if($act["UF_DATE"])
                {
                    $act["RU_M_Y"] = FormatDate("f Y", MakeTimeStamp($act["UF_DATE"]));
                    $act["DATE_FORMAT"] = $act["UF_DATE"]->format("d.m.Y, h:i");
                }

                if($act["STATUS_XML_ID"])
                {
                    $act["STATUS_CLASS"] = $statusClass[$act["STATUS_XML_ID"]];

                    if($act["STATUS_XML_ID"] == 'verif')
                    {
                        $act["BTN_VERIF"] = true;
                    }
                }

                if($act["UF_LINK"])
                {
                    $act["UF_LINK"] = str_replace($_SERVER['DOCUMENT_ROOT'], "", $act["UF_LINK"]);
                    $act["UF_LINK"] = str_replace("'", '"', $act["UF_LINK"]);
                }

                if($act["UF_FILE_UPD"])
                {
                    $act["UF_FILE_UPD"] = \CFile::GetPath($act["UF_FILE_UPD"]);;
                }
            }

            $this->arResult['ACTS'] = $resActs;

            if($arParams["ACTS_COUNT"]) {
                $this->arResult['ALL_COUNT'] = $resActsOb->getCount();
                $this->nav = new \CDBResult();
                $this->nav->NavStart($arParams["ACTS_COUNT"]);
                $this->nav->NavPageCount = ceil((int)$arResult['ALL_COUNT'] / $arParams["ACTS_COUNT"]);
                $this->nav->NavPageNomer = $curPage;
                $this->nav->NavRecordCount = $arResult['ALL_COUNT'];
                $this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');
            }
            //echo "<pre>"; print_r($resProfile); echo "</pre>";
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_COMPANY_NOT_FOUND")], JSON_UNESCAPED_UNICODE);
            die;
        }


    }
    else
    {
        echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_NO_COMPANY_FOR_USER")], JSON_UNESCAPED_UNICODE);
        die;
    }



    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}

function getActsStatusClass()
{
    return $class = [
        "created" => "table-status--dark",
        "verif" => "table-status--red",
        "adjustment" => "table-status--yellow",
        "accept" => "table-status--green",
        "original" => "table-status--gray",
        "edo" => "table-status--blue",
        "cancel" => "table-status--red",
    ];
}

?>