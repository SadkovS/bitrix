<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Catalog\ProductTable;

/**
 * @global CMain                 $APPLICATION
 * @var array                    $arParams
 * @var array                    $arResult
 * @var CatalogSectionComponent  $component
 * @var CBitrixComponentTemplate $this
 * @var string                   $templateName
 * @var string                   $componentPath
 * @var string                   $templateFolder
 */

$this->setFrameMode(true);

?>
<script>
    const basketSettings = {
        event_id: '<?=$arResult["EVENT_DATA"]["EVENT_ID"]?>',
        within_48: '<?=$arResult['IS_WITHIN_48_HOURS']?>'
    };

    const paySystemsData = <?= json_encode($arResult["PAY_SYSTEMS"] ?? []) ?>;
</script>

<script src="https://widget.cloudpayments.ru/bundles/cloudpayments/?cms=1CBitrix" async></script>

<form id="card_form" class="flex flex-auto flex-col" action="" method="POST" enctype="multipart/form-data">
    <? if ($_REQUEST['ajax_basket_full'] == 'Y')
        $APPLICATION->RestartBuffer(); ?>
    <section id="card" class="flex flex-auto flex-col js-step-ur-1">

        <? if (!$arResult["ORDER_ID"] && $arResult["BASKET"]["ITEMS"]): ?>

            <div
                    class="container__wide inline-flex h-full flex-auto flex-col gap-2.5 md:gap-5 js-form-validate">
                <?= bitrix_sessid_post(); ?>
                <input name="ORDER" value="Y" style="display: none;">
                <input name="EVENT_ID" value="<?= $arResult["EVENT_DATA"]["EVENT_ID"] ?>" style="display: none;">
                <input name="COMPANY_ID" value="<?= $arResult["EVENT_DATA"]["COMPANY_ID"] ?>" style="display: none;">
                <input name="event_item_id" value='<?= $arResult["BASKET_ITEM_IDS"] ?>' style="display: none;">

                <div class="mb-2 pt-2.5 inline-flex flex-col gap-2 px-c_narrow md:mb-0 lg:flex-row-reverse lg:items-start lg:justify-between">
                    <a href="<?= str_replace("order", "basket", $APPLICATION->GetCurPage(false)) ?>" class="link__red"
                       type="button"">
                    <i class="svg_icon-arrow rotate-[215deg]"></i>
                    <span>Отмена</span>
                    </a>
                    <div class="inline-flex flex-col gap-c_sm">
                        <span class="text-sm font-medium dark:text-white md:text-sm lg:text-base"><?= $arResult["EVENT_DATA"]["NAME"] ?></span>
                        <div class="inline-flex flex-col gap-c_sm lg:flex-row lg:gap-5">
                            <? if ($arResult["EVENT_DATA"]['EVENT_TYPE'] != "online"): ?>
                                <span class="text-c_xs font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm lg:text-base"><?= $arResult["EVENT_DATA"]["LOCATION_ADDRESS"] ?></span>
                            <? endif; ?>
                            <? if ($arResult["EVENT_DATA"]['DATES_GROUP_STR']): ?>
                                <span class="text-c_xs font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm lg:text-base"><?= $arResult["EVENT_DATA"]['DATES_GROUP_STR'] ?></span>
                            <? else: ?>
                                <span class="text-c_xs font-medium leading-normal text-t-3 dark:text-t-2 md:text-sm lg:text-base"><?= $arResult["EVENT_DATA"]["DATE_TIME"]["DATE_RU"] ?> <?= $arResult["EVENT_DATA"]["DATE_TIME"]["TIME"] ?></span>
                            <? endif; ?>

                        </div>
                    </div>
                </div>

                <div class="inline-flex flex-col gap-c_sm lg:grid lg:grid-cols-2 laptop:gap-10">
                    <div class="inline-flex flex-col gap-c_sm">
                        <div data-anketa
                             class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                            <span class="text-xs font-medium dark:text-white md:text-sm lg:text-lg"><?= $arResult["EVENT_DATA"]["QUESTIONNAIRE_DESCRIPTION"] ?></span>

                            <? if (
                                $arResult["EVENT_DATA"]["QUESTIONNAIRE_FOREACH_TICKETS"]
                                && count($arResult["BASKET"]["ITEMS"]) > 1): ?>

                                <input name="ANKETA_MULTIPLE" value="Y" style="display: none;">

                                <? foreach ($arResult["BASKET"]["ITEMS"] as $basketItem): ?>
                                    <div data-anketa-ticket="<?= $basketItem["ID"] ?>"
                                         data-product-id="<?= $basketItem["PRODUCT_ID"] ?>"
                                         class="group/showmore mx-[-12px] inline-flex flex-col rounded-c_lg bg-gray-custom p-3 dark:bg-primary md:mx-[-15px] md:p-c_md lg:mx-0 lg:rounded-c_xlg lg:p-5">
                                        <label class="inline-flex w-full cursor-pointer justify-between gap-2.5 group-has-[input.showmore-input:checked]/showmore:mb-c_md">
                                            <input type="checkbox" class="showmore-input hidden">
                                            <h2 class="dark:text-white text-base lg:text-xl">
                                                <? if ($basketItem["PROPS"] && is_array($basketItem["PROPS"])): ?>
                                                    <?= $basketItem["NAME"] ?><span>
                                                    , <?= implode(", ", $basketItem["PROPS"]); ?></span>
                                                <? else: ?>
                                                    <?= $basketItem["NAME"] ?>
                                                <? endif; ?>
                                            </h2>
                                            <i class="svg_icon-arrow-r flex rotate-90 items-center text-mic text-warning group-has-[input.showmore-input:checked]/showmore:rotate-[-90deg] lg:text-sm"></i>
                                        </label>
                                        <div class="inline-flex max-h-0 flex-col gap-c_md overflow-hidden group-has-[input.showmore-input:checked]/showmore:max-h-full md:gap-5 laptop:gap-c_af">
                                            <div data-buyer-block class="form__item">
                                                <div class="inline-flex items-center gap-2.5">
                                                    <label class="form-switch">
                                                        <input type="radio" name="buyer"
                                                               value="<?= $basketItem["ID"] ?>"/>
                                                        <i></i>
                                                    </label>
                                                    <p class="text-xs font-medium dark:text-white md:text-sm lg:text-base">
                                                        Покупатель</p>
                                                </div>
                                                <div class="form__item-error"></div>
                                            </div>
                                            <? foreach ($arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"] as $key => $item): ?>
                                                <?= add_questionnare($key, $item, $basketItem["ID"]); ?>
                                            <? endforeach; ?>

                                        </div>

                                    </div>
                                <? endforeach; ?>

                            <? else: ?>
                                <div class="inline-flex flex-col gap-c_md md:gap-5 laptop:gap-c_af">
                                    <input type="radio" name="buyer" value="1" checked style="display: none;"/>

                                    <? foreach ($arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"] as $key => $item): ?>
                                        <?= add_questionnare($key, $item); ?>
                                    <? endforeach; ?>

                                </div>
                            <? endif; ?>

                            <div class="inline-flex gap-2">
                                <span class="block text-warning">*</span>
                                <span class="form__item-label">— обязательный вопрос</span>
                            </div>
                        </div>

                        <div id="promocodes"
                             class="relative inline-flex flex-col gap-2.5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:gap-5 lg:p-c_lg laptop:p-c_lg">
                            <h2 class="dark:text-white">Промокод</h2>
                            <div class="form__item group/promo <? if ($arResult["ERROR"]): ?>error<? endif; ?>">
                                <input type="text"
                                       class="input input__bg font-bold placeholder:font-medium group-[.error]/promo:border-warning group-[.error]/promo:text-warning"
                                       placeholder="Введите промокод, если есть"/>
                                <? if ($arResult["ERROR"]): ?>
                                    <div class="form__item-error"><?= $arResult["ERROR"] ?></div>
                                <? endif; ?>
                                <div class="mt-2.5 text-xs font-medium text-success" style="display: none;">Промокод
                                    упешно применён!
                                </div>

                            </div>
                            <button type="button" class="btn__gray promo-apply-btn"><span
                                        class="font-gothic">Применить</span></button>
                            <div id="apply_promocodes" class="flex flex-wrap gap-c_sm">
                                <? foreach ($arResult["PROMOCODES"] as $promocode): ?>
                                    <a class="promo__tag">
                                        <span class="promo_item"><?= $promocode["PROMOCODE"]["UF_CODE"] ?></span>
                                        <i class="svg_icon-cross promo__item-delete"></i>
                                    </a>
                                <? endforeach; ?>
                            </div>
                        </div>

                        <? if ($arResult["BASKET"]["SUM"]): ?>
                            <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                                <h2 class="dark:text-white">Способ оплаты</h2>
                                <div class="inline-flex flex-col gap-c_sm md:gap-2.5 lg:grid lg:grid-cols-2">

                                    <? foreach ($arResult["PAY_SYSTEMS"] as $pay): ?>
                                        <label class="group ">
                                            <input type="radio" class="hidden js-change-type-payment" name="PAY_SYSTEM_ID"
                                                   value="<?= $pay["ID"] ?>"
                                                   data-code="<?= $pay["CODE"] ?>" <?= $pay["CHECKED"] ?>/>
                                            <span class="inline-flex h-full lg:p-5 md:rounded-c_xlg w-full gap-c_md rounded-c_sm bg-white p-c_md duration-300 *:transition-colors group-has-[input:checked]:bg-primary cursor-pointer dark:border-background-1 dark:border dark:bg-primary dark:group-has-[input:checked]:bg-t-1 items-center lg:min-h-[6rem] md:min-h-[5rem]">
                                                <i class="h-[2.0625rem] w-[3.25rem] bg-contain bg-center bg-no-repeat"
                                                   style="background-image: url(<?= $pay["IMG"] ?>)"></i>
                                                <div class="inline-flex flex-col md:gap-c_sm">
                                                    <span class="text-xs font-medium lg:text-lg group-has-[input:checked]:text-white dark:text-white dark:group-has-[input:checked]:text-primary md:text-base"><?= $pay["NAME"] ?></span>
                                                    <span class="text-mic md:text-xs lg:text-sm font-medium text-t-3"><?= $pay["DESCRIPTION"] ?></span>
                                                </div>
                                            </span>
                                        </label>
                                    <? endforeach; ?>
                                </div>
                            </div>
                        <? endif; ?>
                    </div>
                    <div data-sticky data-sticky-top="20" class="relative">
                        <div class="inline-flex h-fit flex-col gap-c_sm" data-sticky-item>
                            <? if ($arResult['IS_WITHIN_48_HOURS']): ?>
                                <div class="js-show-ur-type hidden-important">

                                    <div class="relative flex flex-col rounded-c_lg bg-t-1 dark:text-white p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">

                                        <div class="mb-2 inline-flex flex-col gap-2 md:mb-0 lg:flex-row lg:items-start lg:justify-between">
                                            <div class="inline-flex flex-col gap-2">
                                                <div class="inline-flex items-center gap-3">
                                                    <img src="<?= SITE_TEMPLATE_PATH ?>/assets/svgicons/warning.svg" alt=""
                                                         class="w-7 shrink-0">
                                                    <span>Оплата по счёту невозможна для части билетов. Один
						                						                или несколько билетов в вашем заказе начинаются
						                						                менее чем через 48 часов — согласно правилам, такие
						                						                билеты нельзя оплатить по счёту.</span>
                                                </div>
                                                <div>Чтобы воспользоваться этим способом оплаты, удалите билеты с ближайшими
                                                    датами из заказа.
                                                </div>
                                            </div>
                                            <a class="link__red shrink-0"
                                               href="<?= str_replace('order', 'basket', $APPLICATION->GetCurPage()) ?>"
                                               type="button">
                                                <i class="svg_icon-arrow rotate-[215deg]"></i> <span>Редактировать заказ</span>
                                            </a>
                                        </div>

                                    </div>

                                </div>
                            <? endif; ?>


                            <div id="total"
                                 class="relative inline-flex flex-col rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                                <div class="text-[10px] font-medium text-t-3 md:text-xs lg:text-sm"><?= $arResult["BASKET"]["QUANTITY"] ?> <?= $arResult["BASKET"]["QUANTITY_TEXT"] ?></div>
                                <div class="bg-icons-1 h-0.5 mx-[-1.0625rem] dark:bg-primary my-c_xs md:mx-[-1.25rem] lg:my-c_md laptop:mx-[-1.875rem] lg:mx-[-1.875rem]">
                                </div>
                                <? foreach ($arResult["BASKET"]["ITEMS"] as $item): ?>
                                    <div class="inline-flex w-full items-center justify-between gap-5">
                                        <div class="inline-flex flex-col flex-auto gap-[3px]">
                                            <div class="text-mic font-medium dark:text-white md:text-sm lg:text-base"><?= $item["NAME"] ?></div>
                                            <div class="text-mic font-medium text-t-3 md:text-xs lg:text-sm">
                                                <? if ($item["PROPS"] && is_array($item["PROPS"])): ?>
                                                    <?= implode(", ", $item["PROPS"]); ?>
                                                <? endif; ?>
                                            </div>
                                        </div>
                                        <div class="inline-flex flex-col gap-[3px]">
                                            <div class="inline-flex items-center justify-end gap-2.5">
                                                <? if ($item["DISCOUNT_PRICE"]): ?>
                                                    <div class="old-price text-xs font-semibold text-t-3 before:bg-warning md:text-sm lg:text-base whitespace-nowrap"><?= $item["BASE_PRICE_FORMAT"] ?>
                                                        ₽
                                                    </div>
                                                <? endif; ?>
                                                <div class="text-sm font-semibold dark:text-white flex-shrink-0 md:text-base lg:text-lg whitespace-nowrap"><?= $item["SUM_FORMAT"] ?>
                                                    ₽
                                                </div>
                                            </div>
                                            <? if ($item["RULE"]): ?>
                                                <div class="text-mic font-medium text-t-3 md:text-xs lg:text-sm">
                                                    Скидка «<?= $item["RULE"]["UF_NAME"] ?>»
                                                    <span class="md:text-sm">-<?= $item["DISCOUNT_PRICE_FORMAT"] ?> ₽</span>
                                                </div>
                                            <? endif; ?>
                                        </div>
                                    </div>

                                    <div class="bg-icons-1 h-0.5 mx-[-1.0625rem] dark:bg-primary my-c_xs md:mx-[-1.25rem] lg:my-c_md laptop:mx-[-1.875rem] lg:mx-[-1.875rem]">
                                    </div>
                                <? endforeach; ?>
                                <? if ($arResult["BASKET"]["SERVICES"]): ?>
                                    <div class="inline-flex w-full items-center justify-between gap-5">
                                        <div class="inline-flex flex-col gap-[3px]">
                                            <div class="text-mic font-medium dark:text-white md:text-sm lg:text-base"><?= $arResult["BASKET"]["SERVICES"]["NAME"] ?></div>
                                        </div>
                                        <div class="inline-flex flex-col gap-[3px]">
                                            <div class="inline-flex items-center justify-end gap-2.5">
                                                <div class="text-sm font-semibold dark:text-white flex-shrink-0 md:text-base lg:text-lg"><?= $arResult["BASKET"]["SERVICES"]["SUM_FORMAT"] ?>
                                                    ₽
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="bg-icons-1 h-0.5 mx-[-1.0625rem] dark:bg-primary my-c_xs md:mx-[-1.25rem] lg:my-c_md laptop:mx-[-1.875rem] lg:mx-[-1.875rem]">
                                    </div>
                                <? endif; ?>

                                <div class="inline-flex items-center justify-between pt-c_xs font-gothic">
                                    <div class="font-base tracking-[0.48px] dark:text-white md:text-lg lg:text-3xl">
                                        Итого:
                                    </div>
                                    <div class="inline-flex items-center gap-c_md">
                                        <? if ($arResult["BASKET"]["BASE_SUM"] > $arResult["BASKET"]["SUM"]): ?>
                                            <div class="old-price font-gothic text-base text-t-2 before:bg-warning dark:before:bg-white md:text-lg lg:text-3xl whitespace-nowrap">
                                                <?= $arResult["BASKET"]["BASE_SUM_FORMAT"] ?>
                                                <b class="font-[Montserrat]">₽</b>
                                            </div>
                                        <? endif; ?>
                                        <div class="font-gothic text-base text-warning md:text-lg lg:text-3xl whitespace-nowrap">
                                            <?= $arResult["BASKET"]["SUM_FORMAT"] ?>
                                            <b class="font-[Montserrat]">₽</b>
                                        </div>
                                    </div>
                                </div>


                            </div>


                            <div class="relative inline-flex flex-col gap-2.5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                                <div class="inline-flex gap-2.5 items-center">
                                    <label class="checkbox-round">
                                        <input type="checkbox" name='subscribe' value="Y"/>
                                        <span class="checkbox-round__icon svg_icon-check"></span>
                                    </label>
                                    <span class="text-mic font-medium leading-[130%]  dark:text-icons-1 md:text-xs">
                                            <a href="/documents/consent_receive_advertising.pdf" class="underline"
                                               target="_blank">Согласие на получение рекламных материалов</a>
                                        </span>
                                </div>

                                <div class="inline-flex gap-2.5">
                                        <span class="text-mic font-medium leading-[130%]  dark:text-icons-1 md:text-xs">
                                            Нажимая на кнопку
                                            <? if ($arResult["BASKET"]["SUM"] == 0): ?>
                                                «Регистрация»,
                                            <? else: ?>
                                                «Оплатить»,
                                            <? endif; ?>
                                           вы соглашаетесь с&nbsp;
								                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/user_agreement_and_terms_of_use.pdf" target="_blank">Пользовательским соглашением</a>,
								                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/org_buyer_contract_offer.pdf" target="_blank">Договором оказания услуг</a>,
								                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/policy_personal_data.pdf" target="_blank">Политикой в отношении защиты и обработки персональных данных</a>
							                                и даете
							                              <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/consent_processing_personal_data.pdf" target="_blank">Согласие на Обработку персональных данных</a>
                                        </span>
                                </div>
                            </div>
                            <? if ($arResult["ORGANIZER_INFO"]): ?>
                                <div class="relative inline-flex flex-col gap-2.5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                                    <div class="lg:flex flex-col:sm items-center gap-1 dark:text-white">
                                        <div class="text-sm font-medium">
                                            Организатор: <?= $arResult["ORGANIZER_INFO"]["UF_FULL_NAME"] ?><br/>
                                            ИНН: <?= $arResult["ORGANIZER_INFO"]["UF_INN"] ?>
                                        </div>

                                        <div class="flex-1 mb-2"></div>

                                        <? /*<div class="flex flex-col lg:items-end font-gothic font-bold">
                                                <?if($arResult["ORGANIZER_INFO"]["UF_EMAIL"]):?>
                                                    <a href="mailto:<?=$arResult["ORGANIZER_INFO"]["UF_EMAIL"]?>"><?=$arResult["ORGANIZER_INFO"]["UF_EMAIL"]?></a>
                                                <?endif;?>
                                                <?if($arResult["ORGANIZER_INFO"]["UF_PHONE"]):?>
                                                    <a href="tel:<?=$arResult["ORGANIZER_INFO"]["UF_PHONE_FORMAT"]?>"><?=$arResult["ORGANIZER_INFO"]["UF_PHONE"]?></a>
                                                <?endif;?>
                                            </div>*/ ?>

                                    </div>
                                </div>
                            <? endif; ?>

                            <div class="md:h-[60px] sm:h-[60px]">
                                <div class="laptop:static fixed bottom-5 inset-x-[22px] md:inset-x-[44px] flex h-fit flex-col gap-c_sm justify-end">

                                    <div class="relative hidden inline-flex flex-col gap-2.5 rounded-c_lg bg-primary text-white p-c_narrow dark:bg-icons-1 dark:text-primary py-[1rem] px-[2rem] pl-[1rem] font-[Montserrat] text-xs md:text-sm md-inset-x-[22px]"
                                         data-vpn-tooltip>
                                        <button class="absolute right-4 top-4 z-10 text-xl" data-close-vpn-tooltip="">
                                            <i class="svg_icon-cross-s"></i>
                                        </button>
                                        <b>Возможно, у вас включён VPN. Чтобы избежать сбоев при оплате, рекомендуем
                                            временно отключить его</b>
                                    </div>

                                    <div class="relative w-full laptop:p-0 laptop:w-full flex flex-col">
                                        <button id="submit_btn" type="button"
                                                class="btn__red items-baseline md:items-center w-full js-hide-ur-type js-form-submit-btn js-form-validate-btn">
                                            <i class="lock__icon svg_icon-lock"></i>
                                            <? if ($arResult["BASKET"]["SUM"] == 0): ?>
                                                <span class="font-gothic lg:text-xl">Регистрация</span>
                                            <? else: ?>
                                                <span id="submit-btn-text"
                                                      class="font-gothic lg:text-xl">Оплатить</span>
                                                <span id="submit-btn-price"
                                                      class="font-semibold lg:text-xl lg:leading-130"><?= $arResult["BASKET"]["SUM_FORMAT"] ?> ₽</span>
                                            <? endif; ?>
                                        </button>

                                        <a href="#" id="submit_btn_ur" class="btn__red items-baseline md:items-center w-full js-show-ur-type js-to-ur-payment hidden-important js-form-validate-btn">
                                            <i class="lock__icon svg_icon-lock"></i>
                                            <?if($arResult["BASKET"]["SUM"] == 0):?>
                                                <span class="font-gothic lg:text-xl">Регистрация</span>
                                            <?else:?>
                                                <span class="font-gothic lg:text-xl">Оплатить</span>
                                                <span class="font-semibold lg:text-xl lg:leading-130"><?=$arResult["BASKET"]["SUM_FORMAT"]?> ₽</span>
                                            <?endif;?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <? else: ?>
            <? include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/empty.php"); ?>
        <? endif; ?>
    </section>

    <section class="flex flex-auto flex-col js-step-ur-2 hidden">
        <div class="container__wide inline-flex h-full flex-auto flex-col gap-2.5 md:gap-5">
            <div class="mb-2 pt-2.5 inline-flex flex-col gap-2 px-c_narrow md:mb-0 lg:flex-row-reverse lg:items-start lg:justify-between">
                <a class="link__red js-back-ur-payment" href="#" type="button">
                    <i class="svg_icon-arrow rotate-[215deg]"></i> <span>Отмена</span>
                </a>
                <div class="inline-flex flex-col gap-c_sm">
                    <span class="text-sm font-medium dark:text-white md:text-sm lg:text-base">Оформление счета на оплату от компании</span>
                    <div class="inline-flex flex-col gap-c_sm lg:flex-row lg:gap-5"></div>
                </div>
            </div>

            <div class="relative inline-flex flex-col gap-c_sm laptop:grid laptop:grid-cols-2 laptop:gap-10 overflow-hidden md:overflow-visible">
                <div class="relative">
                    <div class="inline-flex flex-col gap-c_sm">
                        <div id="ur-payment" class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">

                            <div class="flex justify-between items-center gap-3 payment-head js-payment-head">
                                <h1 class="dark:text-white md:text-2xl text-base">Информация о заказе</h1>
                                <div class="payment-head-arrow js-payment-head-arrow laptop:hidden">
                                    <i class="svg_icon-arrow-r text-warning"></i>
                                </div>
                            </div>

                            <div class="ur-payment-hr dark:bg-primary h-0.5 -mx-c_lg laptop:hidden"></div>

                            <div class="ur-payment-list flex-1 lg:-mx-c_lg md:-mx-5 -mx-c_narrow">

                                <? foreach ($arResult['BASKET']['ITEMS'] as $item): ?>

                                    <div class="ur-payment-hr dark:bg-primary h-0.5"></div>

                                    <div class="ur-payment-list-itm relative flex flex-col gap-2.5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:flex-row md:gap-5 md:p-5 lg:gap-0 lg:px-c_lg">
                                        <div class="relative h-[70px] w-[127px] flex-shrink-0 rounded-c_sm bg-cover bg-center md:h-20 md:w-40 lg:h-[144px] lg:w-[258px]"
                                             style="background-image:url(<?= $arResult['EVENT_DATA']['DETAIL_PICTURE'] ?>)">

                                        </div>
                                        <div class="inline-flex flex-auto flex-col gap-2.5 md:gap-1 lg:p-5 laptop:py-2.5 laptop:pl-5 laptop:pr-c_md">
                                            <div class="inline-flex flex-col gap-0.5 laptop:gap-[3px]">
                                                <div class="text-c_xs font-medium dark:text-white md:text-sm lg:text-lg laptop:!leading-none">
                                                    <?= $arResult['EVENT_DATA']['NAME'] ?>
                                                </div>
                                                <div class="text-xs font-medium text-t-2 lg:text-base">
                                                    <?= $arResult['EVENT_DATA']['LOCATION_ADDRESS_FULL'] ?>
                                                </div>
                                            </div>
                                            <div class="inline-flex items-end justify-between">
                                                <div class="inline-flex flex-col">
                                                    <div class="inline-flex flex-wrap items-baseline gap-2.5 text-xs font-medium dark:text-white sm:text-c_xs md:text-sm lg:text-base">
                                                        <?= $item['DATE_PRESENTATION'] ?>
                                                    </div>
                                                </div>
                                                <div class="whitespace-nowrap text-sm font-semibold dark:text-white md:text-base lg:text-lg">
                                                    <?= $item['SUM_FORMAT'] ?> ₽
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <? endforeach; ?>

                                <div class="ur-payment-hr dark:bg-primary h-0.5"></div>

                            </div>

                            <? if ($arResult['BASKET']['SERVICES']['SUM'] > 0): ?>
                                <div class="ur-payment-service-line flex justify-between items-center dark:text-white">
                                    <div class="text-sm md:text-base">Сервисный сбор</div>
                                    <p class="font-semibold text-xs md:text-base"><?= $arResult['BASKET']['SERVICES']['SUM_FORMAT'] ?>
                                        ₽</p>
                                </div>

                                <div class="ur-payment-hr dark:bg-primary h-0.5 -mx-c_lg"></div>
                            <? endif; ?>

                            <div class="ur-payment-total ur-payment-service-foot-line flex justify-between items-center dark:text-white">
                                <div class="lg:text-3xl md:text-2xl text-base font-gothic">Сумма к оплате:</div>
                                <div class="lg:text-3xl md:text-2xl text-base font-gothic text-warning"><?= $arResult['BASKET']['SUM_FORMAT'] ?>
                                    ₽
                                </div>
                            </div>

                        </div>
                        <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                            <div class="flex items-center justify-between dark:text-white lg:gap-10 md:gap-5 gap-3 font-medium">
                                <img alt="" class="md:w-14 w-8" src="<?=SITE_TEMPLATE_PATH?>/assets/svgicons/warning.svg">
                                <div class="text-mic md:text-base">Обратите внимание: билеты будут отправлены только после
                                    поступления оплаты на наш расчетный счет.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <div class="inline-flex h-fit flex-col gap-c_sm js-form-validate"
                         style="position: relative; bottom: auto; top: 0px; left: 0px; width: 100%;">

                        <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                            <div class="flex items-center justify-between dark:text-white lg:gap-10 md:gap-5 gap-3 font-medium">
                                <span class="font-medium dark:text-white text-xs md:text-base">После заполнения формы ниже вы получите счет-договор здесь, а также на указанный вами e&#8209;mail. Его можно передать в&nbsp;бухгалтерию вашей компании.</span>
                            </div>
                        </div>

                        <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                            <div class="flex items-center justify-between dark:text-white lg:gap-10 md:gap-5 gap-3 font-medium">
                                <img alt="" class="md:w-14 w-8" src="<?=SITE_TEMPLATE_PATH?>/assets/svgicons/warning.svg">
                                <div class="text-mic md:text-base">
                                    Оплата по безналичному расчету может занимать до&nbsp;3 рабочих дней. Рекомендуем оформить и&nbsp;оплатить счет заранее и при планировании оплаты учесть выходные дни.
                                </div>
                            </div>
                        </div>

                        <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                            <div class="inline-flex flex-col gap-c_md md:gap-5 laptop:gap-c_af">
                                <div class="form__item required">
			                      <span class="form__item-label">
			                        ИНН
			                        <b class="text-warning">*</b>

				                      <span class="tooltip-parent" data-tooltip-parent="">
					                      <span class="tooltip-ico" data-tooltip-help-button=""></span>
					                      <span class="tooltip-text p-c_at bg-icons-1 dark:bg-primary dark:text-white" data-tooltip-help="">
					                      <span data-tooltip-help-arrow=""></span>
						                      Введите 10 или 12 цифр. В поле работает автозаполнение. Начните вводить ИНН и сайт сам отобразит и заполнит остальные ваши реквизиты</span>
				                      </span>
			                      </span>
                                    <select class="input input__bg js-dadata-inn" data-value="address" placeholder="Введите 10 или 12 цифр" name="legal_entity[inn]">
                                        <option value=""></option>
                                    </select>
                                    <span class="form__item-error">Поле обязательно для заполнения</span>
                                </div>

                                <div class="form__item required">
			                      <span class="form__item-label">
			                       Полное наименование компании
			                        <b class="text-warning">*</b>

				                      <span class="tooltip-parent" data-tooltip-parent="">
					                      <span class="tooltip-ico" data-tooltip-help-button=""></span>
					                      <span class="tooltip-text p-c_at bg-icons-1 dark:bg-primary dark:text-white" data-tooltip-help="">
					                        <span data-tooltip-help-arrow=""></span>
						                      Полное наименование организаци и, включая форму предприятия. В поле работает автозаполнение. Начните вводить наименование организаци и сайт сам отобразит и заполнит остальные ваши реквизиты
					                      </span>
				                      </span>
			                      </span>

                                    <select class="input input__bg js-dadata-name js-dadata-search-name" readonly="" data-no-disable="true" placeholder="Полное наименование юридического лица или ИП" type="text" name="legal_entity[company_name]">
                                        <option value=""></option>
                                    </select>
                                    <span class="form__item-error">Поле обязательно для заполнения</span>
                                </div>


                                <div class="form__item required">
			                      <span class="form__item-label">
			                       КПП
			                        <b class="text-warning">**</b>

				                      <span class="tooltip-parent" data-tooltip-parent="">
					                      <span class="tooltip-ico" data-tooltip-help-button=""></span>
					                      <span class="tooltip-text p-c_at bg-icons-1 dark:bg-primary dark:text-white" data-tooltip-help="">
					                        <span data-tooltip-help-arrow=""></span>
						                      Введите 9 цифр при наличии КПП
					                      </span>
				                      </span>
			                      </span>

                                    <input class="input input__bg js-validate-ip-kpp js-dadata-kpp js-format-only-number" placeholder="Введите 9 цифр при наличии КПП" type="text" maxlength="9" name="legal_entity[kpp]" data-no-disable="true">

                                    <span class="form__item-error">Поле обязательно для заполнения</span>
                                </div>

                                <div class="form__item required">
			                      <span class="form__item-label">
			                       Юридический адрес
			                        <b class="text-warning">*</b>

				                      <span class="tooltip-parent" data-tooltip-parent="">
					                      <span class="tooltip-ico" data-tooltip-help-button=""></span>
					                      <span class="tooltip-text p-c_at bg-icons-1 dark:bg-primary dark:text-white" data-tooltip-help="">
					                        <span data-tooltip-help-arrow=""></span>
						                      Укажите полный адрес регистрации, включая индекс
					                      </span>
				                      </span>
			                      </span>

                                    <input class="input input__bg js-dadata-address" placeholder="Адрес регистрации юридического лица или ИП" type="text" name="legal_entity[legal_address]" data-no-disable="true">
                                    <span class="form__item-error">Поле обязательно для заполнения</span>
                                </div>

                                <div class="form__item js-input">
			                      <span class="form__item-label">
			                       Почтовый адрес

				                      <span class="tooltip-parent" data-tooltip-parent="">
					                      <span class="tooltip-ico" data-tooltip-help-button=""></span>
					                      <span class="tooltip-text p-c_at bg-icons-1 dark:bg-primary dark:text-white" data-tooltip-help="">
					                        <span data-tooltip-help-arrow=""></span>
						                      Введите почтовый адрес если он отличается от юридического
					                      </span>
				                      </span>
			                      </span>

                                    <input class="input input__bg js-postal-address" placeholder="Если отличается от юридического" data-need-postal="true" type="text" name="legal_entity[postal_address]">
                                    <span class="form__item-error">Поле обязательно для заполнения</span>
                                </div>

                                <div class="inline-flex items-center gap-2">
                                    <label class="checkbox">
                                        <input name="" type="checkbox" class="js-postal-address-checkbox">
                                        <span class="checkbox__icon checkbox__icon--small svg_icon-check"></span>
                                    </label>
                                    <span class="font-medium dark:text-t-2 text-sm">Совпадает с юридическим адресом</span>
                                </div>


                                <div class="form__item required">
			                      <span class="form__item-label">
			                       ФИО контактного лица
			                        <b class="text-warning">*</b>

				                      <span class="tooltip-parent" data-tooltip-parent="">
					                      <span class="tooltip-ico" data-tooltip-help-button=""></span>
					                      <span class="tooltip-text p-c_at bg-icons-1 dark:bg-primary dark:text-white" data-tooltip-help="">
					                        <span data-tooltip-help-arrow=""></span>
						                      Человек, ответственный за оплату
					                      </span>
				                      </span>
			                      </span>
                                    <input class="input input__bg js-target-fio" placeholder="Укажите Имя и Фамилию контактного лица" type="text" minlength="3" maxlength="100" name="legal_entity[contact_person]">
                                    <span class="form__item-error"></span>
                                </div>

                                <div class="form__item required">
			                      <span class="form__item-label">
			                       Email контактного лица
			                        <b class="text-warning">*</b>

				                      <span class="tooltip-parent" data-tooltip-parent="">
					                      <span class="tooltip-ico" data-tooltip-help-button=""></span>
					                      <span class="tooltip-text p-c_at bg-icons-1 dark:bg-primary dark:text-white" data-tooltip-help="">
					                        <span data-tooltip-help-arrow=""></span>
						                      На этот адрес придет счет-договор и дальнейшие документы и билеты
					                      </span>
				                      </span>
			                      </span>
                                    <input class="input input__bg  js-target-email" name="legal_entity[contact_email]" placeholder="Укажите e-mail для связи" type="email">
                                    <span class="form__item-error"></span>
                                </div>


                                <div class="form__item required">
			                      <span class="form__item-label">
			                        Телефон контактного лица
			                        <b class="text-warning">*</b>

				                      <span class="tooltip-parent" data-tooltip-parent="">
					                      <span class="tooltip-ico" data-tooltip-help-button=""></span>
					                      <span class="tooltip-text p-c_at bg-icons-1 dark:bg-primary dark:text-white" data-tooltip-help="">
					                        <span data-tooltip-help-arrow=""></span>
						                      Укажите номер телефона, по которому мы можем связаться по вопросам заказа
					                      </span>
				                      </span>
			                      </span>
                                    <div class="form__item-wrapper">
                                        <input class="input input__bg js-target-tel" placeholder="Укажите номер телефона для связи" type="tel" name="legal_entity[contact_phone]">
                                    </div>
                                    <span class="form__item-error">Поле обязательно для заполнения</span>
                                </div>


                            </div>
                            <div class="flex flex-col md:gap-2">
                                <div class="inline-flex gap-2">
                                    <span class="block text-warning">*</span>
                                    <span class="form__item-label">— обязательный вопрос</span>
                                </div>
                                <div class="inline-flex gap-2">
                                    <span class="block text-warning">**</span>
                                    <span class="form__item-label"> — обязательный вопрос для всех форм предприятия, кроме ИП</span>
                                </div>
                            </div>
                        </div>

                        <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                            <div class="md:text-sm text-mic dark:text-white">Нажимая на кнопку «Оплатить», вы соглашаетесь с&nbsp;
	                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/user_agreement_and_terms_of_use.pdf" target="_blank">Пользовательским соглашением</a>,
	                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/org_buyer_contract_offer.pdf" target="_blank">Договором оказания услуг</a>,
	                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/policy_personal_data.pdf" target="_blank">Политикой в отношении защиты и обработки персональных данных</a>
                                и даете
                                <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/consent_processing_personal_data.pdf" target="_blank">Согласие на Обработку персональных данных</a>
                            </div>
                        </div>

                        <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 lg:p-c_lg laptop:p-c_lg">
                            <div class="flex items-center justify-between dark:text-white lg:gap-10 md:gap-5 gap-3 font-medium">
                                <img alt="" class="md:w-14 w-8" src="<?=SITE_TEMPLATE_PATH?>/assets/svgicons/warning.svg">
                                <div class="text-mic md:text-base">
                                    Формирование счета может занять некоторое время. Пожалуйста, дождитесь
                                    загрузки страницы с подтверждением.
                                </div>
                            </div>
                        </div>

                        <button class="btn__red items-baseline md:items-center w-full js-form-validate-btn disabled js-form-submit-btn">
                            <div class="font-gothic lg:text-xl">Получить счет на оплату</div>
                        </button>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <? if ($_REQUEST['ajax_basket_full'] == 'Y')
        die(); ?>
</form>

<? include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/success.php"); ?>

<div class="js-loader-block hidden md:pt-30 wrapper inline-flex h-full w-full flex-auto flex-col justify-between pt-20 has-[.detail]:pb-20 md:pt-[86px] lg:pt-[140px] lg:has-[.detail]:pb-0">
    <main class="flex flex-auto flex-col">
        <section class="flex flex-auto flex-col">
            <div class="container__wide flex flex-auto flex-col">
                <div class="ticket__bg">
                    <div class="inline-flex w-full flex-col items-center gap-5 dark:text-white lg:gap-c_af">
                        <h1>Данные обрабатываются</h1>
                        <div class="inline-flex flex-col gap-2.5">
                            <img src="<?=SITE_TEMPLATE_PATH?>/assets/svgicons/loader.svg" alt="" class="loading-rotater">
                        </div>
                        <div class="text-center text-xs font-medium md:text-base lg:text-lg text-balance" style="max-width: 40rem;">
                            Формирование счета может занять некоторое время. Пожалуйста, дождитесь загрузки страницы с подтверждением.
                        </div>
                    </div>

                    <div class="ticket__bg-lines"></div>
                </div>
            </div>
        </section>
    </main>
</div>


<?

if ($arResult["ORDER_ID"] && $arResult['PERSON_TYPE_ID'] !== 2): ?>
    <? $APPLICATION->RestartBuffer(); ?>
    <? if (!$arResult["ORDER_FREE"]): ?>
        <? $_REQUEST["ORDER_ID"] = $arResult["ORDER_ID"]; ?>
        <? $APPLICATION->IncludeComponent("custom:sale.order.payment", ""); ?>
    <? endif; ?>
    <? die(); ?>
<? endif; ?>

<? if ($arResult["ORDER_ID"] && $arResult['PERSON_TYPE_ID'] === 2): ?>
    <? $APPLICATION->RestartBuffer(); ?>
    <? include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/success.php"); ?>
<? endif; ?>

<?

function add_questionnare($key, $item, $basketItemId = false)
{
    ?>
    <?
    $fieldName = "anketa[{$key}]";
    if ($basketItemId)
        $fieldName = "anketa[{$basketItemId}][{$key}]";

    ?>
    <? if ($item["type"] == "string"): ?>
    <?
    $type = "text";
    if ($key == "email")
        $type = "email";
    if ($key == "phone")
        $class = "phone";
    ?>
    <div class="form__item <?=($item["required"])??"required" ?>">
            <span class="form__item-label">
                <?= $item["name"] ?>
                <? if ($item["required"]): ?><b class="text-warning">*</b><? endif; ?>
            </span>
        <? if ($key == "phone"): ?>
            <div class="form__item-wrapper">
                <i class="input__icon">+7</i>
                <input type="<?= $type ?>" class="input input__bg" data-key="anketa"
                       name="<?= $fieldName ?>" <?= $item["required"] ?>
                       placeholder="( ___ ) ___ - __ - __">
            </div>
        <? else: ?>
            <input type="<?= $type ?>" class="input input__bg" data-key="anketa"
                   name="<?= $fieldName ?>" <?= $item["required"] ?>>
        <? endif; ?>
        <span class="form__item-error"></span>
    </div>
<? endif; ?>

    <? if ($item["type"] == "phone"): ?>
    <div class="form__item <?=($item["required"])??'required' ?>">
            <span class="form__item-label">
                <?= $item["name"] ?>
                <? if ($item["required"]): ?><b class="text-warning">*</b><? endif; ?>
            </span>
        <div class="form__item-wrapper">
            <input type="tel" class="input input__bg" data-key="anketa"
                   name="<?= $fieldName ?>" <?= $item["required"] ?>
                   placeholder="+7 (___) ___ - __ - __">
            <span class="form__item-error"></span>
        </div>
    </div>
<? endif; ?>

    <? if ($item["type"] == "boolean"): ?>
    <div class="form__item <?= $item["required"] ?>">
            <span class="form__item-label !mb-2">
                <?= $item["name"] ?>
                <? if ($item["required"]): ?><b class="text-warning">*</b><? endif; ?>
            </span>
        <div class="inline-flex gap-c_lg">
            <div class="inline-flex items-center gap-2">
                <label class="radio">
                    <input type="radio" name="<?= $fieldName ?>" value="1">
                    <span class="radio__icon"></span>
                </label>
                <span class="text-xs font-medium dark:text-white md:text-base">Да</span>
            </div>
            <div class="inline-flex items-center gap-2">
                <label class="radio">
                    <input type="radio" name="<?= $fieldName ?>" value="0">
                    <span class="radio__icon"></span>
                </label>
                <span class="text-xs font-medium dark:text-white md:text-base">Нет</span>
            </div>
        </div>
        <span class="form__item-error"></span>
    </div>
<? endif; ?>

    <? if ($item["type"] == "list"): ?>
    <div class="form__item <?= $item["required"] ?>">
            <span class="form__item-label !mb-2">
                <?= $item["name"] ?>
                <? if ($item["required"]): ?><b class="text-warning">*</b><? endif; ?>
            </span>
        <div class="inline-flex flex-col gap-2.5">
            <? foreach ($item["options"] as $option): ?>
                <div class="inline-flex items-center gap-2">
                    <label class="radio">
                        <input type="radio" name="<?= $fieldName ?>" value="<?= $option ?>">
                        <span class="radio__icon"></span>
                    </label>
                    <span class="text-xs font-medium dark:text-white md:text-base"><?= $option ?></span>
                </div>
            <? endforeach; ?>

        </div>
        <span class="form__item-error"></span>
    </div>
<? endif; ?>

    <? if ($item["type"] == "m_list"): ?>
    <div class="form__item <?= $item["required"] ?>">
                <span class="form__item-label !mb-2">
                    <?= $item["name"] ?>
                    <? if ($item["required"]): ?><b class="text-warning">*</b><? endif; ?>
                </span>
        <div class="inline-flex flex-col gap-2.5">
            <? foreach ($item["options"] as $option): ?>
                <div class="inline-flex items-center gap-2">
                    <label class="checkbox">
                        <input type="checkbox" name="<?= $fieldName ?>[]" value="<?= $option ?>">
                        <span class="checkbox__icon svg_icon-check"></span>
                    </label>
                    <span class="text-xs font-medium dark:text-white md:text-base"><?= $option ?></span>
                </div>
            <? endforeach; ?>

        </div>
        <span class="form__item-error"></span>
    </div>
<? endif; ?>

    <? if ($item["type"] == "text"): ?>
    <div class="form__item">
            <span class="form__item-label">
                <?= $item["name"] ?>
                <? if ($item["required"]): ?><b class="text-warning">*</b><? endif; ?>
            </span>
        <textarea type="text" class="textarea" <?= $item["required"] ?> value="5" name="<?= $fieldName ?>"
                  data-textarea-auto-height="" style="height: 72px;"></textarea>
        <span class="form__item-error">Сообщение об ошибке</span>
    </div>
<? endif; ?>

    <? if ($item["type"] == "file"): ?>
    <div class="form__upload">
            <span class="form__item-label">
                <?= $item["name"] ?>
                <? if ($item["required"]): ?><b class="text-warning">*</b><? endif; ?>
            </span>
        <div class="form__item">
            <label class="upload-file svg_icon-clip" data-upload-file="">
                <input
                        type="file"
                        data-upload-file-weight='<?= $item["size"] ?>'
                        <? if ($item["extension"]): ?>accept="<?= $item["extension"] ?>"<?endif;
                ?>
                        data-name="<?= $fieldName ?>[]"
                        data-size="<?= $item["size"] ?>"
                    <?= $item["required"] ?> />
                <span class="upload-file__label"
                      data-def_text="До <?= $item["size"] ?> мб, форматы: <?= $item["extension"] ?>">
                        До <?= $item["size"] ?> мб, форматы: <?= $item["extension"] ?>
                    </span>
            </label>
            <span class="form__item-error">Ошибка загрузки: файл слишком большой</span>
        </div>
    </div>

<? endif; ?>
    <?
}

?>

<div id="basket-error-popup" aria-hidden="false" class="popup">
    <div class="popup__wrapper popup__wrapper--center">
        <div class="popup__content max-w-[500px] bg-t-1 p-7 dark:bg-primary lg:p-c_lg shadow-xl">
            <button class="absolute right-2.5 top-2.5 z-10 text-xl dark:text-white" onclick="location.reload()">
                <i class="svg_icon-cross-s"></i>
            </button>
            <div class="inline-flex flex-col items-center text-center">
                <h3 class="dark:text-white mb-[35px]">
                    Ваша корзина была изменена, для продолжения необходимо обновить страницу </h3>

                <button class="btn__red btn__buy" onclick="location.reload()">
                    <span class="font-gothic">Перезагрузить страницу</span>
                </button>
            </div>
        </div>
    </div>
</div>
