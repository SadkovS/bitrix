<?php
if($arResult['PERSON_TYPE_ID'] === 2):
		//результат оплаты по счету
		?>
<div>
	<div class="js-success-block md:pt-30 wrapper inline-flex h-full w-full flex-auto flex-col justify-between pt-20 has-[.detail]:pb-20 md:pt-[86px] lg:pt-[140px] lg:has-[.detail]:pb-0">
		<pre>
<?//print_r($arResult);?></pre>
        <main class="flex flex-auto flex-col">
			<section class="flex flex-auto flex-col">
				<div class="container__wide flex flex-auto flex-col">
					<div class="ticket__bg ticket__bg--small-padding">

						<div class="flex-1"></div>

						<div class="inline-flex w-full flex-col items-center gap-5 dark:text-white lg:gap-c_af">
							<h1>Спасибо!</h1>
							<div class="inline-flex flex-col gap-2.5">
								<div class="text-center text-xs font-medium md:text-sm lg:text-lg">Мы получили всю необходимую информацию и сформировали<br/> договор-счет на оплату билетов на мероприятие:
								</div>
								<div class="inline-flex flex-col items-center gap-c_sm rounded-c_sm border border-icons-2 bg-icons-1 p-c_md text-center dark:border-background-1 dark:bg-primary">
									<div class="text-center text-xs font-medium md:text-base lg:text-lg"><?=$arResult["EVENT_DATA"]["NAME"]?></div>
									<div class="inline-flex flex-col gap-1">
										<div class="text-mic font-medium text-t-2 md:text-sm lg:text-base"><?=$arResult["EVENT_DATA"]["LOCATION_ADDRESS"]?></div>
										<div class="text-mic font-medium text-t-2 md:text-sm lg:text-base"><?=$arResult["EVENT_DATA"]["DATES_GROUP_STR"]?></div>
									</div>
								</div>
							</div>
							<div class="text-center text-xs font-medium md:text-base lg:text-lg">
								Мы также отправили договор-счет на указанный вами e-mail.<br/> Скачать его можно, нажав на кнопку ниже.
							</div>

							<div class="flex gap-5">
								<a class="btn__red btn__buy js-autoclick" href="<?= $APPLICATION->GetCurPage().'?invoice='.$arResult["ORDER_ID"]?>">
									<span class="font-gothic">Скачать договор</span>
								</a>
								<a class="btn__blue btn__buy" href="/">
									<span class="font-gothic">На главную</span>
								</a>
							</div>
						</div>

						<div class="flex-1"></div>

						<div class="text-center dark:text-t-2 mt-5 text-sm sm:text-mic">По любым вопросам вы можете написать нам на
							<a href="mailto:support@voroh.ru">support@voroh.ru</a> или воспользоваться нашей
                        <a href="/?support_form=Y">формой поддержки</a><br class="hidden md:flex"/> Счет действителен до <?=$arResult['DATE_DEADLINE']?> включительно
						</div>

						<div class="ticket__bg-lines"></div>
					</div>
				</div>
			</section>
		</main>
	</div>
</div>
<?php else:
	//результат обычной оплаты
		?>
	<div id="success_form" class="container__wide flex flex-auto flex-col" style="display: none;">
		<div class="ticket__bg">
			<div class="inline-flex w-full flex-col items-center gap-5 dark:text-white lg:gap-c_af">
		  <?if($arResult["ONLY_FREE"]):?>
						<h1>Заявка принята</h1>
		  <?else:?>
						<h1>Заказ оплачен</h1>
		  <?endif;?>
				<div class="inline-flex flex-col gap-2.5">
					<div class="text-center text-xs font-medium md:text-sm lg:text-lg">
			  <?if($arResult["ONLY_FREE"]):?>
								Спасибо за регистрацию на мероприятие:
			  <?else:?>
								Спасибо за покупку билетов на мероприятие:
			  <?endif;?>
					</div>
					<div class="inline-flex flex-col items-center gap-c_sm rounded-c_sm border border-icons-2 bg-icons-1 p-c_md text-center dark:border-background-1 dark:bg-primary">
						<div class="text-center text-xs font-medium md:text-base lg:text-lg"><?=$arResult["EVENT_DATA"]["NAME"]?></h2></div>
						<div class="inline-flex flex-col gap-1">
							<div class="text-mic font-medium text-t-2 md:text-sm lg:text-base"><?=$arResult["EVENT_DATA"]["LOCATION_ADDRESS"]?></div>
							<div class="text-mic font-medium text-t-2 md:text-sm lg:text-base"><?=$arResult["EVENT_DATA"]["DATE_TIME"]["DATE_RU"]?> <?=$arResult["EVENT_DATA"]["DATE_TIME"]["TIME"]?></div>
						</div>
					</div>
				</div>
				<div class="text-center text-xs font-medium md:text-base lg:text-lg">
					Мы отправили письмо с деталями
					<br>
					о мероприятии вам на почту.
				</div>
				<a href="/" class="btn__red btn__buy">
					<span class="font-gothic">На главную</span>
				</a>
			</div>

			<div class="ticket__bg-lines"></div>
		</div>
	</div>
<?php endif; ?>
