$(function () {
    function add2log(log) {
        $.ajax(
            {
                type: 'POST',
                url: '/test/add2log.php',
                data: {"log": log},
            }
        );
    }

    const debounce = (fnc, ms) => {
        let timeout;

        function wrapper() {
            const fnCall = () => fnc.apply(this, arguments);
            clearTimeout(timeout);
            timeout = setTimeout(fnCall, ms);
        }

        return wrapper;
    }

    function setNumberTicketsAnketa() {
        var arrNumbers = [];
        $("#card form").find("[data-product-id]").each(function (e) {
            if (!arrNumbers[$(this).data("product-id")])
                arrNumbers[$(this).data("product-id")] = [];
            arrNumbers[$(this).data("product-id")].push($(this).data("anketa-ticket"));
        });

        let num = 1;
        $.each(arrNumbers, function (index, value) {
            if (value) {
                $.each(value, function (i, v) {
                    $("[data-anketa-ticket='" + v + "']").find(".ticket-number").html(num);
                    num = num + 1;
                });
            }
        });
    }

    setNumberTicketsAnketa();

    function refreshItems(error) {
        $.ajax({
            url: '',
            method: 'get',
            dataType: 'html',
            data: {'ajax_basket_full': 'Y', 'error': error},
            success: function (result) {
                $("#card").find("#promocodes").replaceWith($(result).find("#promocodes"));
                $("#card").find("#total").replaceWith($(result).find("#total"));
                $("#card").find("#submit_btn").html($(result).find("#submit_btn").html());
                $("#card").find("#submit_btn_ur").html($(result).find("#submit_btn_ur").html());
                $("#ur-payment").html($(result).find("#ur-payment").html());
            }
        });
    }

    function refreshFull() {
        $.ajax({
            url: '',
            method: 'get',
            dataType: 'html',
            data: {'ajax_basket_full': 'Y'},
            success: function (result) {
                $("#card").html(result);
                document.dispatchEvent(new CustomEvent("refresh-mask", {bubbles: true}));
            }
        });
    }

    function get_apply_promocodes() {
        var promocodes = [];

        $(".promo_item").each(function () {
            promocodes.push($(this).html());
        });

        return promocodes;
    }

    $(document).on("click", ".promo-apply-btn", function () {

        var promocodes = get_apply_promocodes();
        promocodes.push($(this).siblings("div").find("input").val());

        BX.ajax.runComponentAction("custom:basket", "promocode", {
            mode: "class",
            data: {promocode: promocodes}
        }).then(function (response) {
            refreshItems();
        }, function (response) {
            if (response["status"] == "error") {
                refreshItems(response["errors"][0]["message"]);
            }
        });
    });

    $(document).on("click", ".promo__item-delete", function () {

        $(this).parent(".promo__tag").remove();

        var promocodes = get_apply_promocodes();

        BX.ajax.runComponentAction("custom:basket", "promocode", {
            mode: "class",
            data: {promocode: promocodes}
        }).then(function (response) {
            refreshItems();
        }, function (response) {
            if (response["status"] == "error") {
                refreshItems(response["errors"][0]["message"]);
            }
        })
    });

    $(document).on("click", ".jq-del-basket-item", function () {
        var ticketId = $(this).data("id");

        BX.ajax.runComponentAction("custom:basket", "del", {
            mode: "class",
            data: {id: ticketId}
        }).then(function (response) {
            $("div[data-anketa-ticket='" + ticketId + "']").remove();
            setNumberTicketsAnketa();
            refreshItems();
        }, function (response) {
            if (response["status"] == "error") {
                refreshItems(response["errors"][0]["message"]);
            }
        })
    });

    function isEmail(email) {
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return regex.test(email);
    }

    $(document).on("click", ".js-form-submit-btn", function (e) {
        var flag = true;

        e.preventDefault()

        if ($(this).attr('onclick'))
            flag = false;
        //
        // $("#card form").find('input, textarea, select, div.required').each(function (e) {
        //     if ($(this).prop("tagName") == "DIV") {
        //         if (!$(this).find("input:checked").length) {
        //             flag = false;
        //
        //             $(this).find(".form__item-error").html("Заполните поле").show();
        //
        //         } else {
        //             $(this).find(".form__item-error").html("").hide();
        //         }
        //     } else {
        //         if ($(this).attr("required")) {
        //             if ($(this).attr("type") == "file") {
        //                 let parent = $(this).closest('.form__upload'),
        //                     files = parent.find('[type="file"].hidden')
        //
        //                 if (files.length > 0) {
        //                     return true;
        //                 }
        //                 flag = false;
        //                 $(this).closest(".form__item").find(".form__item-error").html("Заполните поле").show();
        //             }
        //             if (!$(this).val()) {
        //                 flag = false;
        //                 $(this).closest(".form__item").find(".form__item-error").html("Заполните поле").show();
        //
        //                 if ($(this).closest("[data-anketa-ticket]").length) {
        //                     $(this).closest("[data-anketa-ticket]").find(".showmore-input").prop('checked', true);
        //                 }
        //             } else if ($(this).attr("type") == "email" && !isEmail($(this).val())) {
        //                 flag = false;
        //                 $(this).closest(".form__item").find(".form__item-error").html("Не верный формат Email").show();
        //
        //                 if ($(this).closest("[data-anketa-ticket]").length) {
        //                     $(this).closest("[data-anketa-ticket]").find(".showmore-input").prop('checked', true);
        //                 }
        //             } else if ($(this).attr("type") == "phone" && $(this).val() == "+7 (___) ___-__-__") {
        //                 flag = false;
        //                 $(this).closest(".form__item").find(".form__item-error").html("Заполните поле").show();
        //
        //                 if ($(this).closest("[data-anketa-ticket]").length) {
        //                     $(this).closest("[data-anketa-ticket]").find(".showmore-input").prop('checked', true);
        //                 }
        //             } else {
        //                 $(this).closest(".form__item").find(".form__item-error").html("").hide();
        //             }
        //         }
        //     }
        // });
        //
        let buyer = $("#card form").find("input[name=buyer]:checked");

        // if (!buyer.length) {
        //     flag = false;
        //
        //     $("#card form").find('input[name=buyer]').each(function (e) {
        //         $(this).closest("[data-buyer-block]").find(".form__item-error").html("Должен быть выбран один покупатель").show();
        //
        //         if ($(this).closest("[data-anketa-ticket]").length) {
        //             $(this).closest("[data-anketa-ticket]").find(".showmore-input").prop('checked', true);
        //         }
        //     });
        // } else {
        //     alert('card');
        //     $("#card form").find('input[name=buyer]').each(function (e) {
        //         $(this).closest("[data-buyer-block]").find(".form__item-error").html("").hide();
        //     });
        // }

        if (flag) {
            $("#card form").find('input[type=phone],input[type=tel]').each(function (e) {
                let val = $(this).val();
                $(this).val(val.replace(/[^0-9\.]/g, ''));
            });

            if ($('.js-change-type-payment:checked').attr('data-code') === "invoice") {
                $('.js-loader-block').removeClass("hidden")
                $('#card_form').addClass("hidden")
            } else {
                addLoader();
            }

            try {

                (async () => {
                    const form = document.forms['card_form'];
                    const formData = new FormData(form);

                    var query = {};

                    if(localStorage.getItem('_ym_uid'))
                        formData.append('_ym_uid', localStorage.getItem('_ym_uid').replaceAll('"',''));

                    const response = await fetch(form.action, {
                        method: "POST",
                        body: formData
                    })

                    if (!response.ok) {
                        add2log(JSON.stringify(response));
                        debugger
                    }

                    const header = response.headers.get('content-type');

                    if (header.includes('application/json')) {
                        let result = await response.json();
                        add2log(JSON.stringify(result));
                        if (result.action == "error_compare_basket") {
                            document.dispatchEvent(new CustomEvent('openPopup', {detail: {popup: '#basket-error-popup'}}));
                        } else {
                            showToast(result);
                        }

                        $('.js-loader-block').addClass("hidden")
                        $('#card_form').removeClass("hidden")
                    } else {
                        let result = await response.text();
                        let resultTrim = result.trim();
                        add2log(resultTrim);

                        if (resultTrim && resultTrim.length) {
                            if ($(result).find('.js-success-block').length > 0) {
                                $('#card_form').html($(result).find('.js-success-block'))
                            } else {
                                $("body").append(result);
                                window.payHandler();
                                $('.js-form-submit-btn').attr('onclick', "window.payHandler()");
                            }
                        } else {
                            $("#card_form").remove();
                            $("#success_form").show();

                            localStorage.removeItem('seatMapCart');
                        }

                        const event_id = basketSettings.event_id;
                        const session_key = "tickets_" + event_id;

                        sessionStorage.removeItem('seatMapTickets');
                        sessionStorage.removeItem(session_key);

                        $('.js-loader-block').addClass("hidden")
                        $('#card_form').removeClass("hidden")
                    }

                    document.querySelector('.js-autoclick')?.click();


                })();

            } catch (err) {

                add2log(err.message);

            }

        }
    });

    //$('.footer').hide();
    $('.header').hide();

    function ajaxResult(result) {
        if (result) {
            $("body").append(result);
            $('.js-form-submit-btn').attr('onclick', "payHandler()");
        } else {
            $("#card_form").remove();
            $("#success_form").show();

            removeLoader();
        }

        const event_id = basketSettings.event_id;
        const session_key = "tickets_" + event_id;

        sessionStorage.removeItem('seatMapTickets');
        sessionStorage.removeItem(session_key);
    }

    $(document).on("click", "[data-back]", function () {
        window.history.back();
    });

    $(document).on("click", "[data-close-vpn-tooltip]", function (e) {
        e.preventDefault()

        $(this).closest('[data-vpn-tooltip]').slideUp(300)
    });


    function saveForm() {
        let content = [];

        $("#card div[data-anketa]").find('input, textarea, select').each(function (e) {
            if ((this.type == "radio" || this.type == "checkbox")) {
                if (this.checked) {
                    content.push(
                        {
                            name: $(this).attr("name"),
                            value: $(this).val(),
                            type: $(this).attr("type"),
                            checked: $(this).prop("checked")
                        }
                    );
                }
            } else if (this.value !== "") {
                content.push(
                    {
                        name: $(this).attr("name"),
                        value: $(this).val(),
                        type: $(this).attr("type"),
                    }
                );
            }

        });

        let event_id = $("input[name='EVENT_ID']").val();
        let anketa = JSON.parse(sessionStorage.getItem('anketa'));

        if (!anketa) {
            anketa = new Map();
        } else {
            anketa = new Map(anketa);
        }

        anketa.set(event_id, content);

        sessionStorage.setItem('anketa', JSON.stringify([...anketa]));
    }

    function showForm() {
        let event_id = $("input[name='EVENT_ID']").val();
        let anketa = JSON.parse(sessionStorage.getItem('anketa'));
        let content = [];
        console.log(anketa)
        if (anketa) {
            anketa = new Map(anketa);
            content = anketa.get(event_id);
        }

        if (content) {
            $.each(content, function (key, item) {
                if ((item.type == "radio" || item.type == "checkbox") && item.checked) {
                    let ob = $("#card div[data-anketa] [name='" + item.name + "'][value='" + item.value + "']");
                    $(ob).prop("checked", "checked");

                    $(ob).closest("[data-anketa-ticket]").find(".showmore-input").prop('checked', true);
                } else {
                    let ob = $("#card div[data-anketa] [name='" + item.name + "']");
                    $(ob).val(item.value);

                    $(ob).closest("[data-anketa-ticket]").find(".showmore-input").prop('checked', true);
                }
            });
        }

        $('#card>.js-form-validate').each(function () {
            if ($(this).hasClass('js-form-validate-no-disable') || $(this).hasClass('js-form-check-change')) {
                return;
            }

            setTimeout(()=>{
                formValidate(this,false)
            },100)

        });

    }

    showForm();

    $(document).on("input", "#card div[data-anketa] input", debounce(saveForm, 500));

    const checkVPN = () => {
        console.log('checkVPN')
        $.getJSON('/local/ajax/getCountry.php', function (data) {
            console.log(data)
            if (data.success == false || (data.success == true && data.country !== 'Russia')) {
                $('[data-vpn-tooltip]').removeClass("hidden")
            }
        });
    }

    checkVPN()

});

/*document.addEventListener("DOMContentLoaded", function() {
	document.querySelectorAll('textarea, input').forEach(function(e) {


		if(e.value === '')
		{
			if(e.type != "file")
				e.value = window.sessionStorage.getItem(e.name, e.value);
		}

		e.addEventListener('input', function() {
			window.sessionStorage.setItem(e.name, e.value);
		})
		e.addEventListener('change', function() {
			window.sessionStorage.setItem(e.name, e.value);
		})
	})
});*/
