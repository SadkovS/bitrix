
    <div class="container__wide flex flex-auto flex-col">
        <div class="ticket__bg">
            <div class="inline-flex w-full flex-col items-center gap-5 dark:text-white lg:gap-c_af">
                    <h1>Корзина пуста</h1>
                <div class="inline-flex flex-col gap-2.5">
                    <div class="text-center text-xs font-medium md:text-sm lg:text-lg">
                            Вернуться на главную и продолжить покупки:
                    </div>
                </div>
                <a href="/" class="btn__red btn__buy">
                    <span class="font-gothic">На главную</span>
                </a>
            </div>

            <div class="ticket__bg-lines"></div>
        </div>
    </div>


