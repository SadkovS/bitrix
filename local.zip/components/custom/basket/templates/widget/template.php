<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Catalog\ProductTable;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);
?>

<script>
    window.basketSettings = {
        key: '<?= $arResult["REQUEST_PARAMS"][0] ?>',
        val: '<?= $arResult["REQUEST_PARAMS"][1] ?>',
        event_id: '<?=$arResult["EVENT_DATA"]["EVENT_ID"]?>',
        within_48: '<?=$arResult['IS_WITHIN_48_HOURS']?>'
    };
</script>

<script src="https://widget.cloudpayments.ru/bundles/cloudpayments/?cms=1CBitrix" async></script>

<?if($_REQUEST['ajax_basket_full']=='Y')
    $APPLICATION->RestartBuffer();?>


    <div id="card" class="iframe-widget">

        <form action="" id="card_form" class="">
            <div class="js-step-ur-1">
                <div class="js-form-validate">
                    <div class="iframe-widget-header">
                        <div class="iframe-widget-header__left">
                            <div class="widget-event-info">
                                <?if($arResult["EVENT_DATA"]["DETAIL_PICTURE"]):?>
                                    <div class="widget-event-info__img">
                                        <img src="<?=$arResult["EVENT_DATA"]["DETAIL_PICTURE"]?>" alt="" class="fill-img">
                                    </div>
                                <?endif;?>
                                <div class="widget-event-info__body">
                                    <div class="widget-event-info__title"><?=$arResult["EVENT_DATA"]["NAME"]?></div>
                                    <div class="widget-event-info__desc">
                                        <p><?=$arResult["EVENT_DATA"]["LOCATION_ADDRESS_FULL"]?></p>
                                        <?if($arResult["EVENT_DATA"]['DATES_GROUP']):?>
                                            <?foreach($arResult["EVENT_DATA"]['DATES_GROUP'] as $dates):?>
                                                <p><?=$dates["date"]?> <?=$dates["time"]?></p>
                                            <?endforeach;?>
                                        <?else:?>
                                            <p><?=$arResult["EVENT_DATA"]["DATE_TIME"]["DATE_RU"]?> <?=$arResult["EVENT_DATA"]["DATE_TIME"]["TIME"]?></p>
                                        <?endif;?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="iframe-widget-header__right">
                            <a href="<?=str_replace("order", "event", $_SERVER['REQUEST_URI'])?>" class="iframe-widget-header__link">
                                <img src="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='15'%20height='14'%20viewBox='0%200%2015%2014'%20fill='none'%3e%3cpath%20d='M0%206.99982C0%206.52913%200.381576%206.14755%200.852273%206.14755H11.3905L6.88492%202.05154C6.48804%201.69075%206.49353%201.06488%206.89667%200.711102C7.24033%200.409521%207.75564%200.414039%208.09395%200.721599L14.9103%206.91831C14.9584%206.96202%2014.9584%207.03763%2014.9103%207.08133L8.09534%2013.2768C7.75777%2013.5837%207.24224%2013.5837%206.90468%2013.2768C6.51962%2012.9267%206.51827%2012.3216%206.90176%2011.9698L11.3905%207.8521H0.852272C0.381575%207.8521%200%207.47052%200%206.99982Z'%20fill='white'/%3e%3c/svg%3e" alt="" class="svg">
                                Назад
                            </a>
                            <div class="iframe-widget-header__logo">
                                <img class="svg" src="<?=SITE_TEMPLATE_PATH?>/assets/img/logo.svg" alt="">
                            </div>
                        </div>
                    </div>

                    <?if(!$arResult["ORDER_ID"] && $arResult["BASKET"]["ITEMS"]):?>

                    <div class="widget-form">
                        <input name="<?=$arResult["REQUEST_PARAMS"][0]?>" value="<?=$arResult["REQUEST_PARAMS"][1]?>" hidden>
                        <input name="sessid" value="<?=session_id()?>" hidden>
                        <input name="ORDER" value="Y" style="display: none;">
                        <input name="EVENT_ID" value="<?=$arResult["EVENT_DATA"]["EVENT_ID"]?>" style="display: none;">
                        <input name="COMPANY_ID" value="<?=$arResult["EVENT_DATA"]["COMPANY_ID"]?>" style="display: none;">
                        <input name="WIDGET_ID" class="js-widget-uuid" value="<?=$arResult["WIDGET"]["WIDGET_ID"]?>" style="display: none;">
                        <input name="event_item_id" value='<?=$arResult["BASKET_ITEM_IDS"]?>' style="display: none;">

                        <div class="widget-form-block" data-anketa>
                            <?if($arResult["EVENT_DATA"]["QUESTIONNAIRE_DESCRIPTION"]):?>
                                <div class="widget-form-block__desc">
                                    <?=$arResult["EVENT_DATA"]["QUESTIONNAIRE_DESCRIPTION"]?>
                                </div>
                            <?endif;?>

                            <?if(
                                $arResult["EVENT_DATA"]["QUESTIONNAIRE_FOREACH_TICKETS"]
                                && count($arResult["BASKET"]["ITEMS"]) > 1):?>
                                <div class="ticket-accordion-list">
                                    <input name="ANKETA_MULTIPLE" value="Y" style="display: none;">

                                    <?foreach($arResult["BASKET"]["ITEMS"] as $basketItem):?>
                                        <div data-anketa-ticket="<?=$basketItem["ID"]?>" data-product-id="<?=$basketItem["PRODUCT_ID"]?>" class="ticket-accordion">
                                            <div class="ticket-accordion-head">
                                                <div class="ticket-accordion-head__title">
                                                    <?if($basketItem["PROPS"] && is_array($basketItem["PROPS"])):?>
                                                        <?=$basketItem["NAME"]?><span>, <?=implode(", ", $basketItem["PROPS"]);?></span>
                                                    <?else:?>
                                                        <?=$basketItem["NAME"]?>
                                                    <?endif;?>
                                                </div>
                                                <div class="ticket-accordion-head__arrow"></div>
                                            </div>
                                            <div class="ticket-accordion-body">
                                                <div class="ticket-accordion-body-content">

                                                    <div class="input">
                                                        <input class="js-checkbox checkbox-switcher" name="buyer" placeholder="Покупатель" type="radio" value="<?=$basketItem["ID"]?>">
                                                    </div>

                                                    <?foreach($arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"] as $key => $item):?>
                                                        <?=add_questionnare($key, $item, $basketItem["ID"]);?>
                                                    <?endforeach;?>

                                                </div>
                                            </div>
                                        </div>
                                    <?endforeach;?>
                                </div>
                            <?else:?>
                                <input type="radio" name="buyer" value="1" checked style="display: none;"/>
                                <?foreach($arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"] as $key => $item):?>
                                    <?=add_questionnare($key, $item, $basketItem["ID"]);?>
                                <?endforeach;?>
                            <?endif;?>



                            <div class="required-line">
                                <span class="star-required">*</span> — обязательный вопрос
                            </div>

                        </div>

                        <div id="promocodes" class="widget-form-block">
                            <div class="h3 widget-form-block__title">Промокод</div>

                            <label class="input promocode-field">


                                <div class="input-field">

                                    <input type="text" name="code" placeholder="Введите промокод, если есть" value="">

                                    <a class="btn promocode-field__btn promo-apply-btn">Применить</a>

                                </div>

                                <span class="promocode-field-message"></span>
                                <span class="promocode-field-list">

		                    <?foreach($arResult["PROMOCODES"] as $promocode):?>
                                <div class="promocode-itm">
		                            <input name="promocode[]" type="hidden" value="<?=$promocode["PROMOCODE"]["UF_CODE"]?>">
		                            <div class="promocode-itm__name"><?=$promocode["PROMOCODE"]["UF_CODE"]?></div>
		                            <div class="promocode-itm__close"></div>
		                        </div>
                            <?endforeach;?>
		                </span>


                            </label>

                        </div>

                        <?if($arResult["BASKET"]["SUM"]):?>
                            <div class="widget-form-block">
                                <div class="h3 widget-form-block__title">Способ оплаты</div>

                                <div class="widget-payment-grid input required">
                                    <?foreach ($arResult["PAY_SYSTEMS"] as $pay):?>
                                        <label class="widget-payment-grid-itm-wrap">
                                            <input class="hide widget-payment-grid-itm-input js-change-type-payment" type="radio" name="PAY_SYSTEM_ID" data-code="<?= $pay["CODE"] ?>" value="<?=$pay["ID"]?>" <?=$pay["CHECKED"]?>>
                                            <span class="widget-payment-grid-itm">
		                            <span class="widget-payment-grid-itm__ico">
		                                <img alt="" class="fill-img svg" src="<?=$pay["IMG"]?>">
		                            </span>
		                            <span class="widget-payment-grid-itm__name"><?=$pay["NAME"]?></span>
		                            <span class="widget-payment-grid-itm__desc"><?=$pay["DESCRIPTION"]?></span>
		                          </span>
                                        </label>
                                    <?endforeach;?>
                                </div>

                            </div>
                        <?endif;?>

                        <div id="total" class="widget-form-ticket-info">

                            <div class="widget-ticket-line">
                                <div class="widget-ticket-line__count"><?=$arResult["BASKET"]["QUANTITY"]?> <?=$arResult["BASKET"]["QUANTITY_TEXT"]?></div>
                            </div>


                            <?foreach($arResult["BASKET"]["ITEMS"] as $item):?>
                                <div class="widget-ticket-line">
                                    <div class="widget-ticket-line__left">
                                        <div class="widget-ticket-line__title"><?=$item["NAME"]?></div>
                                        <div class="widget-ticket-line__desc">
                                            <?if($item["PROPS"] && is_array($item["PROPS"])):?>
                                                <?=implode(", ", $item["PROPS"]);?>
                                            <?endif;?>
                                        </div>
                                    </div>

                                    <?if($item["DISCOUNT_PRICE"]):?>
                                        <div class="widget-ticket-line__right">
                                            <div class="widget-ticket-line__price-line">
                                                <div class="widget-ticket-line__price old"><?=$item["BASE_PRICE_FORMAT"]?> ₽</div>
                                                <div class="widget-ticket-line__price"><?=$item["SUM_FORMAT"]?> ₽</div>
                                            </div>
                                            <?if($item["RULE"]):?>
                                                <div class="widget-ticket-line__desc">
                                                    <div class="widget-ticket-line__discount">Скидка «<?=$item["RULE"]["UF_NAME"]?>»</div>
                                                    <div class="widget-ticket-line__discount-price">- <?=$item["DISCOUNT_PRICE_FORMAT"]?> ₽</div>
                                                </div>
                                            <?endif;?>
                                        </div>
                                    <?else:?>
                                        <div class="widget-ticket-line__right">
                                            <div class="widget-ticket-line__price"><?=$item["SUM_FORMAT"]?> ₽</div>
                                        </div>
                                    <?endif;?>
                                </div>
                            <?endforeach;?>

                            <?if($arResult["BASKET"]["SERVICES"]):?>
                                <div class="widget-ticket-line">
                                    <div class="widget-ticket-line__left">
                                        <div class="widget-ticket-line__title"><?=$arResult["BASKET"]["SERVICES"]["NAME"]?></div>
                                        <div class="widget-ticket-line__desc">
                                        </div>
                                    </div>
                                    <div class="widget-ticket-line__right">
                                        <div class="widget-ticket-line__price"><?=$arResult["BASKET"]["SERVICES"]["SUM_FORMAT"]?> ₽</div>
                                    </div>
                                </div>

                            <?endif;?>

                            <div class="widget-ticket-line">
                                <div class="widget-ticket-line__total">Итого:</div>
                                <div class="widget-ticket-line__total">
                                    <?if($arResult["BASKET"]["BASE_SUM"] > $arResult["BASKET"]["SUM"]):?>
                                        <div class="widget-price-total old"><?=$arResult["BASKET"]["BASE_SUM_FORMAT"]?> ₽</div>
                                    <?endif;?>

                                    <div class="widget-price-total"><?=$arResult["BASKET"]["SUM_FORMAT"]?> ₽</div>
                                </div>
                            </div>

                        </div>

                        <div class="widget-form-block">

                            <div class="widget-form-police">

                                <input name='subscribe' value="Y" class="js-checkbox" placeholder="<a href='/documents/consent_receive_advertising.pdf' target='_blank'>Согласие на получение рекламных материалов</a>" type="checkbox">

	                            <label class="check_box disabled checked">
										            <span class="check_box__text">
											            Нажимая на кнопку
												            <? if ($arResult["BASKET"]["SUM"] == 0): ?>
													            «Регистрация»,
												            <? else: ?>
																      «Оплатить»,
												            <? endif; ?>
											            вы соглашаетесь с&nbsp;
			                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/user_agreement_and_terms_of_use.pdf" target="_blank">Пользовательским соглашением</a>,
			                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/org_buyer_contract_offer.pdf" target="_blank">Договором оказания услуг</a>,
			                            <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/policy_personal_data.pdf" target="_blank">Политикой в отношении защиты и обработки персональных данных</a>
		                                и даете
		                              <a class="underline" href="https://<?=$_SERVER["SERVER_NAME"]?>/documents/consent_processing_personal_data.pdf" target="_blank">Согласие на Обработку персональных данных</a>
											          </span>
	                            </label>

                            </div>

                        </div>
                        <?php if($arResult["ORGANIZER_INFO"]):?>
                            <div class="widget-form-block">
                                <div class="widget-copyright">
                                    <div class="widget-copyright__left">
                                        Организатор: <?=$arResult["ORGANIZER_INFO"]["UF_FULL_NAME"]?><br/> ИНН: <?=$arResult["ORGANIZER_INFO"]["UF_INN"]?>
                                    </div>


                                    <?/*<div class="widget-copyright__right">
		                            <a href="mailto:<?=$arResult["ORGANIZER_INFO"]["UF_EMAIL"]?>"><?=$arResult["ORGANIZER_INFO"]["UF_EMAIL"]?></a>
		                            <a href="tel:<?=$arResult["ORGANIZER_INFO"]["UF_PHONE_FORMAT"]?>"><?=$arResult["ORGANIZER_INFO"]["UF_PHONE"]?></a>
		                        </div>*/?>
                                </div>
                            </div>
                        <?endif; ?>
                        <div class="widget-form-foot">
                            <button
                                <?if(!$_REQUEST["preview"]):?>id="submit_btn"<?endif;?> type="button" class="btn js-form-validate-btn js-hide-ur-type no-check <?if(!$_REQUEST["preview"]):?> js-form-submit-btn<?endif;?>">
                                <? if ($arResult["BASKET"]["SUM"] == 0): ?>
                                    <span class="btn__text">Регистрация</span>
                                <? else: ?>
                                    <span class="btn__text">Оплатить <span class="widget-form-foot__price"><?= $arResult["BASKET"]["SUM_FORMAT"] ?> ₽</span></span>
                                <? endif; ?>
                            </button>

                            <a href="#" class="btn js-form-validate-btn js-show-ur-type no-check hidden-important js-to-ur-payment">
                                <? if ($arResult["BASKET"]["SUM"] == 0): ?>
                                    <span class="btn__text">Регистрация</span>
                                <? else: ?>
                                    <span class="btn__text">Оплатить <span class="widget-form-foot__price"><?= $arResult["BASKET"]["SUM_FORMAT"] ?> ₽</span></span>
                                <? endif; ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="js-step-ur-2 hidden">
                <div class="js-form-validate">

                    <div class="ur-payment-head">
                        <div class="ur-payment-head__left">
                            <div class="ur-payment-head__name">Оформление счета на оплату от компании</div>
                        </div>
                        <div class="ur-payment-head__right">
                            <a class="link-ico js-back-ur-payment" href="#">
                                <img alt="" class="svg link-ico__arrow" src="<?=SITE_TEMPLATE_PATH?>/assets/img/ico/arrow.svg">
                                Отмена
                            </a>
                        </div>
                    </div>

                    <div id="ur-payment" class="widget-form-block">
                        <div class="widget-form-orders">
                            <div class="widget-form-orders-head">
                                <div class="h3">Информация о заказе</div>
                                <div class="widget-form-orders-head__arrow"></div>
                            </div>

                            <div class="widget-form-orders-body">

                                <? foreach ($arResult['BASKET']['ITEMS'] as $item): ?>
                                    <div class="widget-form-order">
                                        <div class="widget-form-order__image">
                                            <picture class="fill-img">
                                                <img alt="" class="fill-img" src="<?= $arResult['EVENT_DATA']['DETAIL_PICTURE'] ?>">
                                            </picture>
                                        </div>
                                        <div class="widget-form-order__body">
                                            <div class="widget-form-order__info">
                                                <div class="widget-form-order__title"><?= $arResult['EVENT_DATA']['NAME'] ?></div>
                                                <div class="widget-form-order__desc"><?= $arResult['EVENT_DATA']['LOCATION_ADDRESS_FULL'] ?></div>
                                                <div class="widget-form-order__date"><?= $item['DATE_PRESENTATION'] ?></div>
                                            </div>

                                            <div class="widget-form-order__price">
                                                <?= $item['SUM_FORMAT'] ?> ₽
                                            </div>
                                        </div>

                                    </div>
                                <? endforeach; ?>



                            </div>
                        </div>

                        <? if ($arResult['BASKET']['SERVICES']['SUM'] > 0): ?>
                            <div class="widget-service-line">
                                <div class="widget-service-line__text">Сервисный сбор</div>
                                <div class="widget-service-line__val"><?= $arResult['BASKET']['SERVICES']['SUM_FORMAT'] ?> ₽</div>
                            </div>
                        <? endif; ?>

                        <div class="widget-total-line">
                            <div class="widget-total-line__text h3">Сумма к оплате:</div>
                            <div class="widget-total-line__val h3"><?= $arResult['BASKET']['SUM_FORMAT'] ?> ₽</div>
                        </div>
                    </div>

                    <div class="widget-form-block widget-warning-line">
                        <div class="widget-warning-line__ico">
                            <img alt="" src="<?=SITE_TEMPLATE_PATH?>/assets/img/ico/warning.svg">
                        </div>
                        <div class="widget-warning-line__text">
                            Обратите внимание: билеты будут отправлены только после поступления оплаты на наш расчетный счет. Подробнее об оплате по счету читайте в нашем
                            <a href="">FAQ</a>
                        </div>
                    </div>


                    <div class="widget-form">
                        <div class="widget-form-block">
                            <div class="widget-form-block__desc-small">
                                После заполнения формы ниже вы получите счет-договор здесь, а также на указанный вами e-mail. Его можно передать в бухгалтерию вашей компании.
                            </div>

                            <label class="input required">

                                <div class="input-label">
                                    ИНН
                                    <span class="star-required">*</span>

                                    <div class="tooltip">
                                        <div class="tooltip-ico"></div>
                                        <div class="tooltip-text">Введите 10 или 12 цифр. В поле работает автозаполнение. Начните вводить ИНН и сайт сам отобразит и заполнит остальные ваши реквизиты</div>
                                    </div>
                                </div>

                                <div class="input-field">

                                    <select class="js-dadata-inn" placeholder="10 или 12 цифр, без пробелов" data-value="address"  value="" name="legal_entity[inn]">
                                        <option value=""></option>
                                    </select>

                                </div>
                                <div class="input-hint" ></div>

                            </label>
                            <label class="input required">

                                <div class="input-label">
                                    Полное наименование компании
                                    <span class="star-required">*</span>

                                    <div class="tooltip">
                                        <div class="tooltip-ico"></div>
                                        <div class="tooltip-text">Полное наименование организаци и, включая форму предприятия. В поле работает автозаполнение. Начните вводить наименование организаци и сайт сам отобразит и заполнит остальные ваши реквизиты </div>
                                    </div>
                                </div>

                                <div class="input-field">

                                    <select class="js-dadata-name js-dadata-search-name" placeholder="Полное наименование юридического лица или ИП" readonly="" data-no-disable="true" value="" name="legal_entity[company_name]">
                                        <option value=""></option>
                                    </select>

                                </div>
                                <div class="input-hint" ></div>

                            </label>

                            <label class="input  required">

                                <div class="input-label">
                                    КПП
                                    <span class="star-required">**</span>

                                    <div class="tooltip">
                                        <div class="tooltip-ico"></div>
                                        <div class="tooltip-text">Введите 9 цифр при наличии КПП</div>
                                    </div>
                                </div>

                                <div class="input-field">

                                    <input class=" js-dadata-kpp js-validate-ip-kpp js-format-only-number" type="text" placeholder="Введите 9 цифр при наличии КПП" maxlength="9" name="legal_entity[kpp]" data-no-disable="true" value="">




                                </div>
                                <div class="input-hint" ></div>

                            </label>

                            <label class="input required">

                                <div class="input-label">
                                    Юридический адрес
                                    <span class="star-required">*</span>

                                    <div class="tooltip">
                                        <div class="tooltip-ico"></div>
                                        <div class="tooltip-text">Укажите полный адрес регистраци и, включая индекс</div>
                                    </div>
                                </div>

                                <div class="input-field">

                                    <input class="js-format-no-special js-dadata-address" type="text" placeholder="Адрес регистрации юридического лица или ИП" maxlength="256" name="legal_entity[legal_address]" value="">




                                </div>
                                <div class="input-hint" ></div>

                            </label>

                            <label class="input js-input">

                                <div class="input-label">
                                    Почтовый адрес

                                    <div class="tooltip">
                                        <div class="tooltip-ico"></div>
                                        <div class="tooltip-text">Введите почтовый адрес если он отличается от юридического</div>
                                    </div>
                                </div>

                                <div class="input-field">

                                    <input class="js-postal-address" type="text" placeholder="Если отличается от юридического" data-need-postal="true" value="" name="legal_entity[postal_address]">




                                </div>
                                <div class="input-hint" ></div>

                            </label>

                            <div class="input">
                                <input class="js-checkbox js-postal-address-checkbox" name="question" placeholder="Совпадает с юридическим адресом" type="checkbox"/>
                            </div>



                            <label class="input required">

                                <div class="input-label">
                                    ФИО контактного лица
                                    <span class="star-required">*</span>

                                    <div class="tooltip">
                                        <div class="tooltip-ico"></div>
                                        <div class="tooltip-text">Человек, ответственный за оплату</div>
                                    </div>
                                </div>

                                <div class="input-field">

                                    <input class="js-target-fio" type="text" placeholder="Укажите Имя и Фамилию контактного лица" minlength="3" maxlength="100" value="" name="legal_entity[contact_person]">




                                </div>
                                <div class="input-hint" ></div>

                            </label>

                            <label class="input required">

                                <div class="input-label">
                                    Email контактного лица
                                    <span class="star-required">*</span>

                                    <div class="tooltip">
                                        <div class="tooltip-ico"></div>
                                        <div class="tooltip-text">На этот адрес придет счет-договор и дальнейшие документы и билеты</div>
                                    </div>
                                </div>

                                <div class="input-field">

                                    <input class="js-target-email" type="email" placeholder="Укажите e-mail для связи"  value="" name="legal_entity[contact_email]">




                                </div>
                                <div class="input-hint" ></div>

                            </label>

                            <label class="input required">

                                <div class="input-label">
                                    Телефон контактного лица
                                    <span class="star-required">*</span>

                                    <div class="tooltip">
                                        <div class="tooltip-ico"></div>
                                        <div class="tooltip-text">Укажите номер телефона для связи</div>
                                    </div>
                                </div>

                                <div class="input-field">

                                    <input class="js-target-tel" type="tel" placeholder=""  value="" name="legal_entity[contact_phone]">




                                </div>
                                <div class="input-hint" ></div>

                            </label>


                            <div class="required-line">
                                <span class="star-required">*</span> — обязательный вопрос
                            </div>
                            <div class="required-line">
                                <span class="star-required">**</span> — обязательный вопрос для всех форм предприятия, кроме ИП
                            </div>
                        </div>


                        <div class="widget-form-block widget-warning-line">
                            <div class="widget-warning-line__ico">
                                <img alt="" src="<?=SITE_TEMPLATE_PATH?>/assets/img/ico/warning.svg">
                            </div>
                            <div class="widget-warning-line__text">
                                Оплата по безналичному расчету может занимать до 3 рабочих дней. Рекомендуем оформить и оплатить счет заранее и при планировании оплаты учесть выходные дни.
                            </div>
                        </div>


                        <div class="widget-form-foot">
                            <button
                                <?if(!$_REQUEST["preview"]):?>id="submit_btn"<?endif;?> class="btn js-form-validate-btn<?if(!$_REQUEST["preview"]):?> js-form-submit-btn<?endif;?>" type="button">
                                <span class="btn__text">Получить счет на оплату</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </form>

        <?include ($_SERVER["DOCUMENT_ROOT"].$templateFolder."/success.php");?>

        <div id="basket-error-popup" aria-hidden="false" class="popup">
            <div class="popup__wrapper">
                <div class="popup__content">
                    <button class="popup__close" onclick="location.reload()"></button>
                    <div class="inline-flex flex-col items-center text-center">
                        <h3 class="popup__title">
                            Ваша корзина была изменена, для продолжения необходимо обновить страницу </h3>

                        <button class="btn" onclick="location.reload()">
                            <span class="font-gothic">Перезагрузить страницу</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <?else:?>
            <?include ($_SERVER["DOCUMENT_ROOT"].$templateFolder."/empty.php");?>
        <? endif;?>

    </div>



<?if($_REQUEST['ajax_basket_full']=='Y')
    die();?>

<?if ($arResult["ORDER_ID"] && $arResult['PERSON_TYPE_ID'] !== 2): ?>
    <? $APPLICATION->RestartBuffer(); ?>
    <? if (!$arResult["ORDER_FREE"]): ?>
        <? $_REQUEST["ORDER_ID"] = $arResult["ORDER_ID"]; ?>
        <? $APPLICATION->IncludeComponent("custom:sale.order.payment", ""); ?>
    <? endif; ?>
    <? die(); ?>
<? endif; ?>

<? if ($arResult["ORDER_ID"] && $arResult['PERSON_TYPE_ID'] === 2): ?>
    <? $APPLICATION->RestartBuffer(); ?>
    <? include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/success.php"); ?>
<? endif; ?>

<? function add_questionnare($key, $item, $basketItemId = false)
{?>
    <?
    $fieldName = "anketa[{$key}]";
    if($basketItemId)
        $fieldName = "anketa[{$basketItemId}][{$key}]";

    ?>
    <?if($item["type"] == "string"):?>
    <?
    $type = "text";
    if($key == "email")
        $type = "email";
    if($key == "phone")
        $type = "tel";
    ?>

    <label class="input <?if($item["required"]):?>required<?endif;?>">
        <div class="input-label"><?=$item["name"]?>
            <?if($item["required"]):?><span class="star-required">*</span><?endif;?>
        </div>
        <div class="input-field">
            <input type="<?=$type?>" placeholder=" "  value="" data-key="anketa" name="<?=$fieldName?>" <?=$item["required"]?>>
        </div>
        <div class="input-hint" ></div>
    </label>
<?endif;?>

    <?if($item["type"] == "phone"):?>
    <label class="input <?if($item["required"]):?>required<?endif;?>">
        <div class="input-label"><?=$item["name"]?>
            <?if($item["required"]):?><span class="star-required">*</span><?endif;?>
        </div>
        <div class="input-field">
            <input type="tel" placeholder=" "  value="" data-key="anketa" name="<?=$fieldName?>" <?=$item["required"]?>>
        </div>
        <div class="input-hint" ></div>
    </label>
<?endif;?>

    <?if($item["type"] == "boolean"):?>

    <div class="input <?=$item["required"]?>">
        <div class="input-label">
            <?=$item["name"]?>
            <?if($item["required"]):?><span class="star-required">*</span><?endif;?>
        </div>
        <div class="input-radio-line">
            <input class="js-checkbox" placeholder="Да" type="radio" name="<?=$fieldName?>" value="1">
            <input class="js-checkbox" placeholder="Нет" type="radio" name="<?=$fieldName?>" value="0">
        </div>
    </div>

<?endif;?>

    <?if($item["type"] == "list"):?>
    <div class="input <?=$item["required"]?>">
        <div class="input-label">
            <?=$item["name"]?>
            <?if($item["required"]):?><span class="star-required">*</span><?endif;?>
        </div>
        <div class="input-radio-row">
            <?foreach($item["options"] as $option):?>
                <input class="js-checkbox"  name="<?=$fieldName?>" value="<?=$option?>" placeholder="<?=$option?>" type="radio">
            <?endforeach;?>
        </div>
    </div>

<?endif;?>

    <?if($item["type"] == "m_list"):?>
    <div class="input <?=$item["required"]?>">
        <div class="input-label">
            <?=$item["name"]?>
            <?if($item["required"]):?><span class="star-required">*</span><?endif;?>
        </div>
        <div class="input-radio-row">
            <?foreach($item["options"] as $option):?>
                <input class="js-checkbox" name="<?=$fieldName?>[]" value="<?=$option?>" placeholder="<?=$option?>" type="checkbox">
            <?endforeach;?>
        </div>
    </div>
<?endif;?>

    <?if($item["type"] == "text"):?>
    <label class="input input--textarea <?if($item["required"]):?>required<?endif;?>">
        <div class="input-label">
            <?=$item["name"]?>
            <?if($item["required"]):?><span class="star-required">*</span><?endif;?>
        </div>

        <div class="input-field">
            <textarea  placeholder=" " <?=$item["required"]?> name="<?=$fieldName?>"></textarea>
        </div>
        <div class="input-hint" ></div>
    </label>
<?endif;?>

    <?if($item["type"] == "file"):?>

    <div class="input form__upload <?= ($item["required"]) ? "required" : "" ?>">
            <span class="form__item-label input-label">
                <?=$item["name"]?>
                <?if($item["required"]):?><b class="star-required">*</b><?endif;?>
            </span>
        <div class="form__item">
            <label class="upload-file svg_icon-clip" data-upload-file="">
                <input
                        type="file"
                        data-upload-file-weight='<?=$item["size"]?>'
                        <?if($item["extension"]):?>accept="<?=$item["extension"]?>"<?endif;?>
                        data-name="<?=$fieldName?>[]"
                        data-size="<?=$item["size"]?>" />
                <span class="upload-file__label" data-def_text="До <?=$item["size"]?> мб, форматы: <?=$item["extension"]?>">
                        До <?=$item["size"]?> мб, форматы: <?=$item["extension"]?>
                    </span>
            </label>
            <span class="form__item-error"></span>
        </div>
    </div>

<?endif;?>
<?}

?>