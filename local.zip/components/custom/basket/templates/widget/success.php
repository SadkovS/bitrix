<?php if($arResult['PERSON_TYPE_ID'] === 2):
//результат оплаты по счету
?>
	<div>
		<div id="success_form" class="js-success-block card-buy-wrap">
			<div class="card-buy card-buy--ur">
				<div class="card-buy__line"></div>
				<div class="h3 card-buy__title">Спасибо!</div>
				<p>Мы получили всю необходимую информацию и сформировали договор-счет на оплату билетов на мероприятие</p>

				<div class="card-buy-event">
					<div class="card-buy-event__title"><?= $arResult["EVENT_DATA"]["NAME"] ?></div>
					<div class="card-buy-event__place"><?= $arResult["EVENT_DATA"]["LOCATION_ADDRESS"] ?></div>
					<div class="card-buy-event__date"><?= $arResult["EVENT_DATA"]["DATES_GROUP_STR"] ?></div>
				</div>

				<p>Мы также отправили договор-счет на указанный вами e-mail. Скачать его можно, нажав на кнопку ниже.</p>

				<div class="card-buy__btns">
					<a class="btn js-autoclick" target="_blank"
					   href="https://<?= SITE_SERVER_NAME . $APPLICATION->GetCurPage() . '?invoice=' . $arResult["ORDER_ID"] ?>">
						Скачать договор
					</a>
					<a class="btn btn--second" href="<?=str_replace("order", "event", $APPLICATION->GetCurPage(false))?>">Оформить еще билет</a>
				</div>
				<p class="card-buy__desc">По любым вопросам вы можете написать нам на
					<a href="mailto:support@voroh.ru">support@voroh.ru</a>
					или воспользоваться нашей
					<a href="/?support_form=Y">формой поддержки</a>
					. Счет действителен до <?= $arResult['DATE_DEADLINE'] ?> включительно
				</p>

			</div>
		</div>
	</div>
<?php else:
//результат обычной оплаты
?>
<div id="success_form" class="card-buy-wrap" style="display: none;">
    <div class="card-buy">
        <div class="card-buy__line"></div>
        <div class="h3 card-buy__title">
            <?if($arResult["ONLY_FREE"]):?>
                Заявка принята
            <?else:?>
                Заказ оплачен
            <?endif;?>
        </div>
        <p>
            <?if($arResult["ONLY_FREE"]):?>
                Спасибо за регистрацию на мероприятие.
            <?else:?>
                Спасибо за покупку билетов на мероприятие.
            <?endif;?>
        </p>
        <p>Мы отправили письмо с деталями <br>о мероприятии вам на почту.</p>
        <a class="btn" href="<?=str_replace("order", "event", $APPLICATION->GetCurPage(false))?>">Оформить ещё билет</a>
    </div>
</div>
<?php endif; ?>