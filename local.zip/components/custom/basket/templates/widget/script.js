function refreshItems(error)
{
	const data = {'ajax_basket_full':'Y', 'error': error};
	data[window.basketSettings.key] = window.basketSettings.val;

	$.ajax({
		url: '',
		method: 'get',
		dataType: 'html',
		data: data,
		success: function(result){
			$("#card_form").find("#promocodes").replaceWith($(result).find("#promocodes"));
			$("#card_form").find("#total").replaceWith($(result).find("#total"));
			$("#card_form").find("#ur-payment").replaceWith($(result).find("#ur-payment"));
			$("#card_form").find(".js-show-ur-type .btn__text").replaceWith($(result).find(".js-show-ur-type .btn__text"));
			$("#card_form").find(".js-hide-ur-type .btn__text").replaceWith($(result).find(".js-hide-ur-type .btn__text"));

			removeLoader();

			sendHeight()
		}
	});
}

function get_apply_promocodes()
{
	var promocodes = [];

	$("[name='promocode[]']").each(function() {
		promocodes.push($(this).val());
	});

	return promocodes;
}

function send_promocodes_action(promocodes)
{
	var query = {
		c: 'custom:basket',
		action: 'promocode',
		mode: 'class',
	};

	query[window.basketSettings.key] = window.basketSettings.val;

	var data = {
		promocode: promocodes
	};
	var request = $.ajax({
		url: '/bitrix/services/main/ajax.php?' + $.param(query, true),
		method: 'POST',
		data: data,
		dataType: 'json',
	});
	request.done(function (response) {
		if(response.status == "error")
		{
			$(".promocode-field-message").html(response.errors[0].message);
			sendHeight()

			removeLoader();
		}
		else
		{
			refreshItems();
		}
	});
}

function saveForm()
{
	let content = [];

	$("#card form div[data-anketa]").find('input, textarea, select').each(function (e) {
		if((this.type == "radio" || this.type == "checkbox"))
		{
			if(this.checked)
			{
				content.push(
					{
						name: $(this).attr("name"),
						value: $(this).val(),
						type: $(this).attr("type"),
						checked: $(this).prop("checked")
					}
				);
			}
		}
		else if(this.value !== "")
		{
			content.push(
				{
					name: $(this).attr("name"),
					value: $(this).val(),
					type: $(this).attr("type"),
				}
			);
		}

	});

	let event_id = $("input[name='EVENT_ID']").val();
	let anketa = JSON.parse(sessionStorage.getItem('anketa'));

	if(!anketa)
	{
		anketa = new Map();
	}
	else
	{
		anketa = new Map(anketa);
	}

	anketa.set(event_id, content);

	sessionStorage.setItem('anketa', JSON.stringify([...anketa]));
}

function showForm()
{
	let event_id = $("input[name='EVENT_ID']").val();
	let anketa = JSON.parse(sessionStorage.getItem('anketa'));
	let content = [];

	if(anketa)
	{
		anketa = new Map(anketa);
		content = anketa.get(event_id);
	}

	if(content)
	{
		$.each(content, function(key, item)
		{
			if((item.type == "radio" || item.type == "checkbox") && item.checked)
			{
				let ob = $("#card form div[data-anketa] [name='"+item.name+"'][value='"+item.value+"']");
				$(ob).prop("checked", "checked");

				$(ob).closest("[data-anketa-ticket]").find(".showmore-input").prop('checked', true);
			}
			else
			{
				let ob = $("#card form div[data-anketa] [name='"+item.name+"']");
				$(ob).val(item.value);

				$(ob).closest("[data-anketa-ticket]").find(".showmore-input").prop('checked', true);
			}
		});
	}
}

const debounce = (fnc, ms) => {
	let timeout;
	function wrapper(){
		const fnCall = () => fnc.apply(this, arguments);
		clearTimeout(timeout);
		timeout = setTimeout(fnCall, ms);
	}

	return wrapper;
}

function isEmail(email) {
	var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	return regex.test(email);
}

$(function() {
	$(document).on("click", ".promo-apply-btn",  function () {
		addLoader();

		var promocodes = get_apply_promocodes();
		promocodes.push($(this).siblings("input").val());

		send_promocodes_action(promocodes);
	});

	$(document).on("click", ".promocode-itm__close",  function () {
		addLoader();

		var promo_block = $(this).parent(".promocode-itm").remove();
		var promocodes = get_apply_promocodes();

		send_promocodes_action(promocodes);
	});

	$(document).on("click", ".js-form-submit-btn",  function (e) {
		var flag = true;

		if($(this).attr('onclick'))
			flag = false;

		let form = $(this).closest('#card_form')
		if (formValidate(form, false) === false) {
			e.preventDefault();
			return false;
		}


		if(flag)
		{
			$("#card form").find ('input[type=phone]').each(function (e) {
				let val = $(this).val();
				$(this).val(val.replace(/[^0-9\.]/g, ''));
			});

			addLoader();

			(async () => {
				const form  = document.forms['card_form'];
				const formData = new FormData(form);

				var query = {};

				if(localStorage.getItem('_ym_uid'))
					formData.append('_ym_uid', localStorage.getItem('_ym_uid').replaceAll('"',''));

				const response = await fetch(form.action, {
					method: "POST",
					body: formData
				})

				if (!response.ok) {
					debugger
				}

				const header = response.headers.get('content-type');

				if(header.includes('application/json'))
				{
					let result = await response.json();

					if(result.action == "error_compare_basket")
					{
						openModal("#basket-error-popup");
					}
					else
					{
						showToast(result);
					}

					removeLoader();
				}
				else
				{
					let result = await response.text();
					let resultTrim  = result.trim();

					if(resultTrim && resultTrim.length)
					{
						if ($(result).find('.js-success-block').length > 0) {
							$('#card_form').html($(result).find('.js-success-block'))
						} else {
							$("body").append(result);
							window.payHandler();
							$('.js-form-submit-btn').attr('onclick', "window.payHandler()");
						}
					}
					else
					{
						$("#card_form").remove();
						$("#success_form").show();

						removeLoader();
					}

					const event_id = window.basketSettings.event_id;
					const session_key = "tickets_"+event_id;

					sessionStorage.removeItem('seatMapTickets');
					sessionStorage.removeItem(session_key);

					document.querySelector('.js-autoclick')?.click();
					removeLoader();
					window.dispatchEvent(new Event("resize"));
				}
			})();
		}
	});

	$('.footer').hide();
	$('.header').hide();

	$(document).on("click", "[data-back]",  function () {
		window.history.back();
	});

	function setupIframeObserver() {
		const observer = new MutationObserver((mutations, obs) => {
			const iframe = document.querySelector('iframe[allowpaymentrequest]');
			if (iframe) {
				iframe.style.maxHeight = '38rem';
				iframe.style.top = 'auto';
				obs.disconnect();

				iframe.addEventListener('load',()=>{
					console.log('iframe load')

					// Добавляем затемняющий фон
					if(!document.querySelector('.payment-widget-fade')) {
						const fade = document.createElement('div');
						fade.className = 'payment-widget-fade';
						document.body.appendChild(fade);
					}
				})



				// Следим за удалением iframe
				const removeObserver = new MutationObserver(() => {
					if (!document.querySelector('iframe[allowpaymentrequest]')) {
						// Удаляем затемняющий фон
						document.querySelector('.payment-widget-fade')?.remove();
						$('body').removeClass("loading")
						removeObserver.disconnect();
						setupIframeObserver();
					}
				});

				removeObserver.observe(document.body, {
					childList: true,
					subtree: true
				});
			}
		});

		observer.observe(document.body, {
			childList: true,
			subtree: true
		});
	}

	$(document).on("input", "#card div[data-anketa] input",  debounce(saveForm, 500));

	$(document).on("click", "[data-back]",  function () {
		window.history.back();
	})

	showForm();
});
