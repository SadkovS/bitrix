<div id="success_form" class="card-buy-wrap" style="display: none;">
    <div class="card-buy">
        <div class="card-buy__line"></div>
        <div class="h3 card-buy__title">
            <?if($arResult["ONLY_FREE"]):?>
                Заявка принята
            <?else:?>
                Заказ оплачен
            <?endif;?>
        </div>
        <p>
            <?if($arResult["ONLY_FREE"]):?>
                Спасибо за регистрацию на мероприятие.
            <?else:?>
                Спасибо за покупку билетов на мероприятие.
            <?endif;?>
        </p>
        <p>Мы отправили письмо с деталями <br>о мероприятии вам на почту.</p>
        <a class="btn" href="<?=$_SERVER['HTTP_REFERER']?>">Оформить ещё билет</a>
    </div>
</div>


