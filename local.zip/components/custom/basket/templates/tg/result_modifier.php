<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

$arResult["REQUEST_PARAMS"] = (new \Custom\Core\Session())->makeRequest(session_id());