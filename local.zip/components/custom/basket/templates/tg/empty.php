<div id="success_form" class="card-buy-wrap">
    <div class="card-buy">
        <div class="card-buy__line"></div>
        <div class="h3 card-buy__title">Корзина пуста</div>
        <p>Ваша корзина пуста</p>
    </div>
</div>


