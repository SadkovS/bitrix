<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
    die();

require_once($_SERVER["DOCUMENT_ROOT"] . '/local/crest/crest.php');

global $APPLICATION;

use Bitrix\Catalog;
use Bitrix\Iblock;
use Bitrix\Main;
use Bitrix\Main\Error;
use Bitrix\Main\ErrorCollection;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Sale;
use Bitrix\Sale\Basket;
use Bitrix\Sale\DiscountCouponsManager;
use Bitrix\Sale\Fuser;
use Bitrix\Sale\PriceMaths;
use Custom\Core\Events\EventsQuestionnaireTable;
use \Bitrix\Main\Application;
use \Bitrix\Main\Context;
use \Bitrix\Main\Request;
use \Custom\Core\UUID;
use \Custom\Core\Events;
use \Bitrix\Main\ORM;
use \Custom\Core\Questionnaires;
use Bitrix\Highloadblock as HL;
use Custom\Core\Helper as Helper;

class BasketCustom extends CBitrixComponent implements \Bitrix\Main\Engine\Contract\Controllerable {


    const excludeProps = [
        "PRODUCT.XML_ID",
        "UUID",
        "BARCODE",
        "SECTOR",
    ];

    const requiredProps = [
        "full_name" => "FIO",
        "email"     => "EMAIL",
        "phone"     => "PHONE",
    ];

    const basketPropsShow = [
        "row"    => "Ряд",
        "place"  => "Место",
        "sector" => "Сектор",
    ];

    const orderSubmitName = [
        "FREE" => "Зарегистрироваться",
        "PAY"  => "Перейти к оплате",
    ];

    const PERSON_TYPE_ID       = 1;
    const PERSON_TYPE_ID_LEGAL = 2;

    const PAY_SISTEM_DEF = 2;

    const DELIVERY_DEF                = 3;
    const COUNT_ZERO_IN_TICKET_NUMBER = 7;

    const servicesPriceName = "Сервисный сбор";

    private $userId;

    public function configureActions()
    {
        return [
            'add'       => [
                'prefilters'  => [],
                'postfilters' => []
            ],
            'del'       => [
                'prefilters'  => [],
                'postfilters' => []
            ],
            'change'    => [
                'prefilters'  => [],
                'postfilters' => []
            ],
            'refresh'   => [
                'prefilters'  => [],
                'postfilters' => []
            ],
            'promocode' => [
                'prefilters'  => [],
                'postfilters' => []
            ]
        ];
    }

    public static function getBasketItems()
    {
        \Bitrix\Main\Loader::includeModule("sale");

        $eventData = [];

        $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());

        $basketItems = $basket->getBasketItems();

        return $basketItems;
    }

    public static function getBasketApplyPromocodes($basketItemsIds, $full = false)
    {
        $arPromocodes = [];

        $applyRulesEntity = new ORM\Query\Query('Custom\Core\Events\DiscountApplyTable');
        $query            = $applyRulesEntity
            ->setSelect(
                [
                    '*',
                ]
            )
            ->setFilter(
                [
                    'UF_BASKET_ITEM_ID' => $basketItemsIds,
                    'UF_RULE_TYPE'      => "PROMOCODE"
                ]
            )
            ->exec();

        while ($rule = $query->fetch()) {
            if ($full)
                $arPromocodes[$rule["UF_PROMOCODE_ID"]] = \Custom\Core\Discount::getPromocodeInfo($rule["UF_PROMOCODE_ID"]);
            else
                $arPromocodes[$rule["UF_PROMOCODE_ID"]] = \Custom\Core\Discount::getPromocodeInfo($rule["UF_PROMOCODE_ID"])["UF_CODE"];
        }

        return $arPromocodes;
    }

    public static function recalculate($basket = null)
    {
        if ($basket)
            $basketItems = $basket->getBasketItems();
        else
            $basketItems = self::getBasketItems();

        $promocodes = [];

        $basketItemsIds = array_map(
            function ($item) {
                return $item->getField("ID");
            }, $basketItems
        );

        if ($basketItemsIds) {
            $promocodes = self::getBasketApplyPromocodes($basketItemsIds);
        }

        self::discountAction($basket);

        if ($promocodes)
            self::promocodeAction($promocodes);
    }

    public function refreshAction()
    {
        $_REQUEST["ajax_basket"] = "Y";
        $this->getBasketArray();
        $this->includeComponentTemplate();
    }

    public function changeAction($items)
    {
        $this->clearBasket();
        $this->addAction($items);
    }

    public function delAction($id)
    {
        \Bitrix\Main\Loader::includeModule("sale");

        $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());
        $basket->getItemById($id)->delete();
        $basket->save();

        self::recalculate();
    }

    public function getProductInfo($items = [])
    {
        $products = [];

        if ($items) {
            $res = \CIBlockElement::GetList(
                [],
                ["ID" => $items],
                false,
                false,
                ["ID", "XML_ID", "PROPERTY_MAX_QUANTITY", "PROPERTY_TYPE", "CATALOG_QUANTITY"],
            );

            while ($ob = $res->Fetch()) {
                $products[$ob["ID"]]["MAX_QUANTITY"]     = $ob["PROPERTY_MAX_QUANTITY_VALUE"];
                $products[$ob["ID"]]["CATALOG_QUANTITY"] = $ob["CATALOG_QUANTITY"];
                $products[$ob["ID"]]["NAME"]             = $ob["PROPERTY_TYPE_VALUE"];
            }
        }

        return $products;
    }

    public function getEventInOrderData($offerId = null)
    {
        $productId = \CCatalogSku::GetProductInfo($offerId)["ID"];

        $eventId = \Custom\Core\Events::getEventIdByProduct($productId);

        Custom\Core\Events::getEventData($eventId, $event, true);

        return $event;
    }

    public function setNumberTicketForBarcodes($barcodes)
    {
        $enumIdBooked = \Custom\Core\Contract::getHLfileldEnumId(
            "Barcodes",
            "UF_STATUS",
            "booked"
        );

        $series = $barcodes[0]["UF_SERIES"];

        $result = \Custom\Core\Tickets\BarcodesTable::getList(
            [
                "filter"  => [
                    "UF_SERIES" => $series,
                ],
                "order"   => ["UF_TICKET_NUM" => "DESC"],
                "select"  => ["UF_TICKET_NUM"],
                "limit"   => 1,
                "runtime" => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'STATUS',
                        '\Custom\Core\FieldEnumTable',
                        ['this.UF_STATUS' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ]
            ]
        )->fetchAll();

        if (!$result || !$result[0]["UF_TICKET_NUM"]) {
            $number = 1;
        } else {
            $number = (int)$result[0]["UF_TICKET_NUM"] + 1;
        }

        foreach ($barcodes as $item) {
            $resUp = \Custom\Core\Tickets\BarcodesTable::update(
                $item["ID"],
                [
                    "UF_TICKET_NUM" => str_pad($number, self::COUNT_ZERO_IN_TICKET_NUMBER, "0", STR_PAD_LEFT),
                    "UF_STATUS"     => $enumIdBooked
                ]
            );

            $number++;
        }
    }

    public function setSeatMapIdForBarcodes($id, $seat_map_id)
    {
        $resUp = \Custom\Core\Tickets\BarcodesTable::update(
            $id,
            [
                "UF_SEATMAP_ID" => $seat_map_id
            ]
        );
    }

    public function getBarcodesForTicket(&$ticket)
    {
        $barcodes = \Custom\Core\Tickets\BarcodesTable::getList(
            [
                "filter"  => [
                    "UF_OFFER_ID" => $ticket["id"],
                    [
                        "LOGIC" => "OR",
                        ["STATUS.XML_ID" => false],
                        ["STATUS.XML_ID" => "new"],
                    ]
                ],
                "select"  => ["ID", "UF_SERIES"],
                "limit"   => $ticket["quantity"],
                "runtime" => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'STATUS',
                        '\Custom\Core\FieldEnumTable',
                        ['this.UF_STATUS' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ]
            ]
        )->fetchAll();

        if (empty($barcodes) || count($barcodes) < $ticket["quantity"]) {
            echo json_encode(['status' => 'error', 'message' => 'Внутренняя ошибка'], JSON_UNESCAPED_UNICODE);
            die();
        }

        self::setNumberTicketForBarcodes($barcodes);

        $ticket["barcodes"] = $barcodes;
    }

    public function checkSeatMapIds($seatMapIds, $items)
    {
        $barcodes = \Custom\Core\Tickets\BarcodesTable::getList(
            [
                "filter"  => [
                    "UF_SEATMAP_ID" => $seatMapIds,
                    [
                        "LOGIC" => "OR",
                        ["STATUS.XML_ID" => "sold"],
                        ["STATUS.XML_ID" => "used"],
                        ["STATUS.XML_ID" => "booked"],
                    ]
                ],
                "select"  => ["ID", "UF_SEATMAP_ID"],
                "runtime" => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'STATUS',
                        '\Custom\Core\FieldEnumTable',
                        ['this.UF_STATUS' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ]
            ]
        )->fetchAll();

        if ($barcodes) {
            echo json_encode(['status' => 'error', 'message' => 'Билет в вашей корзине уже забронирован'], JSON_UNESCAPED_UNICODE);
            die();
        }
    }

    public function addAction($items)
    {
        if ($items) {
            \Bitrix\Main\Loader::includeModule("sale");

            $this->clearBasket();

            $seatMapIds = array_column($items, 'seat_map_id');
            $this->checkSeatMapIds($seatMapIds, $items);

            $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());

            $productIds = array_column($items, 'id');
            $products   = $this->getProductInfo($productIds);

            foreach ($items as $key => &$item) {
                if ($products[$item["id"]]) {
                    if ($products[$item["id"]]["MAX_QUANTITY"] < $item["quantity"])
                        $item["quantity"] = $products[$item["id"]]["MAX_QUANTITY"];
                    if ($products[$item["id"]]["CATALOG_QUANTITY"] < $item["quantity"])
                        $item["quantity"] = $products[$item["id"]]["CATALOG_QUANTITY"];
                }

                $this->getBarcodesForTicket($item);
            }
            unset($item);

            foreach ($items as $key => $item) {

                for ($i = 1; $i <= $item["quantity"]; $i++) {
                    $nameTickets = $products[$item["id"]]["NAME"];
                    /*if($item["quantity"] > 1)
                        $nameTickets = $products[$item["id"]]["NAME"]." №".$i;*/

                    $fields = [
                        "PRODUCT_ID"             => $item["id"],
                        "NAME"                   => $nameTickets,
                        'QUANTITY'               => 1,
                        'CURRENCY'               => \Bitrix\Currency\CurrencyManager::getBaseCurrency(),
                        "PRODUCT_PROVIDER_CLASS" => "\Bitrix\Catalog\Product\CatalogProvider",
                    ];

                    $props = self::basketPropsShow;
                    if (!empty($item["props"])) {
                        $props = array_merge(self::basketPropsShow, $item["props"]);
                    }

                    foreach ($props as $key => $val) {
                        $name = $key;
                        if (self::basketPropsShow[$key])
                            $name = self::basketPropsShow[$key];

                        if (self::basketPropsShow[$key] == $val)
                            $val = "";

                        $fields['PROPS'][] = [
                            "NAME"  => $name,
                            "CODE"  => strtoupper($key),
                            "VALUE" => $val,
                            "SORT"  => "100",
                        ];
                    }


                    $uuid              = UUID::uuid3(UUID::NAMESPACE_ORDER, $item["id"] . microtime());
                    $fields["PROPS"][] =
                        [
                            "NAME"  => "UUID",
                            "CODE"  => "UUID",
                            "VALUE" => $uuid,
                            "SORT"  => "100",
                        ];

                    if ($item["barcodes"][$i - 1]) {
                        $barcodeId = $item["barcodes"][$i - 1]["ID"];

                        $fields["PROPS"][] = [
                            "NAME"  => "BARCODE",
                            "CODE"  => "BARCODE",
                            "VALUE" => $barcodeId,
                            "SORT"  => "100",
                        ];

                        if ($item["seat_map_id"]) {
                            self::setSeatMapIdForBarcodes($barcodeId, $item["seat_map_id"]);
                        }
                    }

                    if (!empty($item["properties"])) {
                        $fields = array_merge($item["properties"], $fields);
                    }

                    $result = \Bitrix\Catalog\Product\Basket::addProductToBasket(
                        $basket,
                        $fields,
                        [
                            'CURRENCY' => \Bitrix\Currency\CurrencyManager::getBaseCurrency(),
                        ],
                        [
                            'USE_MERGE' => 'N',
                        ]
                    );

                    if (!$result->isSuccess()) {
                        echo json_encode(['status' => 'error', 'message' => str_replace("<br>", "\n", implode(', ', $result->getErrorMessages()))], JSON_UNESCAPED_UNICODE);
                        die();
                    }
                }

            }

            $basket->save();
            self::recalculate();
        }
    }

    public function getMinReserveTime($basketItems)
    {
        return TICKET_RESERVE_MIN_DEF * 60 + time();

        /*$productIds = [];
        $reserveTime = [];

        foreach ($basketItems as $key => $item)
        {
            $productIds[] = $item->getField("PRODUCT_ID");
        }

        if($productIds)
        {
            $res = \CIBlockElement::GetList(
                [],
                ["ID" => $productIds],
                false,
                false,
                ["ID", "PROPERTY_RESERVE_TIME"],
            );

            while($ob = $res->Fetch())
            {
                $reserveTime[$ob["ID"]] = $ob["PROPERTY_RESERVE_TIME_VALUE"];
            }

            if($reserveTime)
            {
                return min($reserveTime)*60 + time();
            }
        }

        return false;*/
    }

    public static function setCountApplyPromocodes($basketItems)
    {
        $promocodes = [];

        $basketItemsIds = array_map(
            function ($item) {
                return $item->getField("ID");
            }, $basketItems
        );

        if ($basketItemsIds) {
            $promocodeIds = [];
            $ruleIds      = [];

            $applyRulesEntity = new ORM\Query\Query('Custom\Core\Events\DiscountApplyTable');
            $query            = $applyRulesEntity
                ->setSelect(
                    [
                        '*',
                    ]
                )
                ->setFilter(
                    [
                        'UF_BASKET_ITEM_ID' => $basketItemsIds
                    ]
                )
                ->exec();

            while ($rule = $query->fetch()) {
                $ruleIds[] = $rule["UF_RULE_ID"];

                if ($rule["UF_RULE_TYPE"] == "PROMOCODE") {
                    $promocodeIds[] = $rule["UF_PROMOCODE_ID"];
                }
            }

            $promocodeIds = array_unique($promocodeIds);
            $ruleIds      = array_unique($ruleIds);

            if ($promocodeIds) {
                $priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PromoCodesTable');
                $query            = $priceRulesEntity
                    ->setSelect(
                        [
                            '*',
                        ]
                    )
                    ->setFilter(
                        [
                            'ID' => $promocodeIds,
                        ]
                    )
                    ->exec();

                while ($priceRule = $query->fetchObject()) {
                    $priceRule->set("UF_IS_USE", 1);
                    $priceRule->save();
                }
            }

            if ($ruleIds) {
                $priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');
                $query            = $priceRulesEntity
                    ->setSelect(
                        [
                            '*',
                        ]
                    )
                    ->setFilter(
                        [
                            'ID' => $ruleIds,
                        ]
                    )
                    ->exec();

                while ($priceRule = $query->fetchObject()) {
                    $cnt = $priceRule->get("UF_NUMBER_OF_USES");
                    $cnt++;

                    $priceRule->set("UF_NUMBER_OF_USES", $cnt);
                    $priceRule->save();
                }
            }
        }
    }

    public function getCooperationPercent($companyID)
    {
        $query      = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany = $query
            ->setFilter(['ID' => $companyID, '!UF_COOPERATION_PERCENT' => false])
            ->setSelect(
                [
                    'UF_COOPERATION_PERCENT',
                ]
            )
            ->setLimit(1)
            ->exec();
        if ($company = $resCompany->fetch()) {
            return $company["UF_COOPERATION_PERCENT"];
        }

        return 0;
    }

    public function getWidgetId($uuid)
    {
        $widgetEntity = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
        $widgetClass  = $widgetEntity->getEntity()->getDataClass();
        $query        = $widgetEntity
            ->setSelect(
                [
                    'ID',
                ]
            )
            ->setFilter(
                [
                    'UF_UUID' => $uuid
                ]
            )
            ->exec();
        if ($widget = $query->fetch()) {
            return $widget["ID"];
        }

        return "";
    }

    public static function changeOfferQuantity($basketItems, $refund = false)
    {
        $offers = [];

        foreach ($basketItems as $item) {
            $offers[$item->getProductId()] += $item->getQuantity();
        }

        foreach ($offers as $offer => $qnt) {
            $obProduct = \Bitrix\Catalog\ProductTable::getList(
                [
                    'filter' => [
                        "ID" => $offer,
                    ],
                    'select' => [
                        "ID", "QUANTITY"
                    ]
                ]
            );

            if ($product = $obProduct->Fetch()) {

                if ($refund) {
                    $newQnt = $product["QUANTITY"] + $qnt;
                } else {
                    $newQnt = $product["QUANTITY"] - $qnt;
                }

                \Bitrix\Catalog\ProductTable::update(
                    $product["ID"],
                    [
                        "QUANTITY" => $newQnt,
                    ]
                );
            }
        }
    }

    public function order($data)
    {
        \Bitrix\Main\Loader::includeModule("sale");
        global $USER;

        $siteId       = \Bitrix\Main\Context::getCurrent()->getSite();
        $currencyCode = \Bitrix\Currency\CurrencyManager::getBaseCurrency();
        $userId       = $this->userId;

        $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), $siteId);

        $basketItems = $basket->getBasketItems();

        if (!$basketItems)
            return false;

        // Определяем тип плательщика на основе способа оплаты
        $personTypeId = self::PERSON_TYPE_ID; // по умолчанию физлицо

        if (!$data["PAY_SYSTEM_ID"])
            $PAY_SYSTEM_ID = self::PAY_SISTEM_DEF;
        else
            $PAY_SYSTEM_ID = $data["PAY_SYSTEM_ID"];

        // Получаем код платежной системы для определения типа плательщика
        if ($PAY_SYSTEM_ID) {
            $paySystemService = \Bitrix\Sale\PaySystem\Manager::getObjectById($PAY_SYSTEM_ID);
            if ($paySystemService) {
                $paySystemCode = $paySystemService->getField("CODE");

                // Проверяем различные варианты кодов для счета
                if ($paySystemCode == "invoice" ||
                    strpos(strtolower($paySystemCode), 'invoice') !== false ||
                    strpos(strtolower($paySystemCode), 'bill') !== false ||
                    strpos(strtolower($paySystemCode), 'legal') !== false) {
                    $personTypeId = self::PERSON_TYPE_ID_LEGAL; // юрлицо для счета
                }
            }
        }

        $order = \Bitrix\Sale\Order::create($siteId, $userId, $currencyCode);
        $order->setPersonTypeId($personTypeId);

        $order->setBasket($basket);

        if ($basket->getPrice() && $data["COMPANY_ID"]) {
            $orderServicesPrice = self::getOrderServicesPrice($data["COMPANY_ID"], $basket->getPrice());

            if ($orderServicesPrice) {
                $shipmentCollection = $order->getShipmentCollection();
                $shipment           = $shipmentCollection->createItem();
                $service            = \Bitrix\Sale\Delivery\Services\Manager::getById(self::DELIVERY_DEF);
                $shipment->setFields(
                    [
                        'DELIVERY_ID'           => $service['ID'],
                        'DELIVERY_NAME'         => $service['NAME'],
                        'ALLOW_DELIVERY'        => 'Y',
                        'PRICE_DELIVERY'        => $orderServicesPrice,
                        'CUSTOM_PRICE_DELIVERY' => 'Y'
                    ]
                );

                $shipmentItemCollection = $shipment->getShipmentItemCollection();
                foreach ($basket as $basketItem) {
                    $item = $shipmentItemCollection->createItem($basketItem);
                    $item->setQuantity($basketItem->getQuantity());
                }
            }
        }

        if ($PAY_SYSTEM_ID) {
            $paymentCollection = $order->getPaymentCollection();
            $payment           = $paymentCollection->createItem();
            $payment->setFields(
                [
                    'PAY_SYSTEM_ID'   => $paySystemService->getField("PAY_SYSTEM_ID"),
                    'PAY_SYSTEM_NAME' => $paySystemService->getField("NAME"),
                    'SUM'             => $order->getPrice()
                ]
            );
        }


        $propertyCollection = $order->getPropertyCollection();

        $anketa = $data["anketa"];
        if ($data["ANKETA_MULTIPLE"] && $data["ANKETA_MULTIPLE"] == "Y") {
            if ($data["buyer"] && $data["anketa"][$data["buyer"]]) {
                $anketa = $data["anketa"][$data["buyer"]];
            } else {
                $bufAnkets = $data["anketa"];
                $anketa    = array_shift($bufAnkets);
            }
        }

        if ($personTypeId == self::PERSON_TYPE_ID_LEGAL && isset($data["legal_entity"])) {
            // Для юрлица используем данные из формы юрлица
            $property = $propertyCollection->getPayerName();
            if ($property) $property->setValue($data["legal_entity"]["company_name"]);

            $property = $propertyCollection->getUserEmail();
            if ($property) $property->setValue($data["legal_entity"]["contact_email"]);

            $property = $propertyCollection->getPhone();
            if ($property) $property->setValue($data["legal_entity"]["contact_phone"]);

            // Дополнительные свойства для юрлица
            $property = $propertyCollection->getItemByOrderPropertyCode("COMPANY");
            if ($property) $property->setValue($data["legal_entity"]["company_name"]);

            $property = $propertyCollection->getItemByOrderPropertyCode("INN");
            if ($property) $property->setValue($data["legal_entity"]["inn"]);

            $property = $propertyCollection->getItemByOrderPropertyCode("KPP");
            if ($property) $property->setValue($data["legal_entity"]["kpp"]);

            $property = $propertyCollection->getItemByOrderPropertyCode("COMPANY_ADR");
            if ($property) $property->setValue($data["legal_entity"]["legal_address"]);

            $property = $propertyCollection->getItemByOrderPropertyCode("ADDRESS");
            if ($property) $property->setValue($data["legal_entity"]["postal_address"]);

            $property = $propertyCollection->getItemByOrderPropertyCode("FIO");
            if ($property) $property->setValue($data["legal_entity"]["contact_person"]);
        } else {
            // Для физлица используем данные из анкеты
            $property = $propertyCollection->getPayerName();
            if ($property) $property->setValue($anketa["full_name"]);

            $property = $propertyCollection->getUserEmail();
            if ($property) $property->setValue($anketa["email"]);

            $property = $propertyCollection->getPhone();
            if ($property) $property->setValue($anketa["phone"]);
        }

        $property = $propertyCollection->getItemByOrderPropertyCode("EVENT_ID");
        if ($property) $property->setValue($data["EVENT_ID"]);

        $property = $propertyCollection->getItemByOrderPropertyCode("ORGANIZER_ID");
        if ($property) $property->setValue($data["COMPANY_ID"]);

        if ($data["COMPANY_ID"]) {
            $cooperationPercent = $this->getCooperationPercent($data["COMPANY_ID"]);
            $property           = $propertyCollection->getItemByOrderPropertyCode("COOPERATION_PERCENT");
            if ($property) $property->setValue($cooperationPercent);
        }

        if ($data["WIDGET_ID"]) {
            $widgetId = $this->getWidgetId($data["WIDGET_ID"]);
            $property = $propertyCollection->getItemByOrderPropertyCode("WIDGET_ID");
            if ($property) $property->setValue($widgetId);
        }

        if ($data["_ym_uid"]) {
            $property = $propertyCollection->getItemByOrderPropertyCode("_ym_uid");
            if ($property) $property->setValue($data["_ym_uid"]);
        }

        //$property = $propertyCollection->getItemByOrderPropertyCode("ANKETA_ID");
        //$property->setValue($anketaId);
        $event = null;
        if ($data["EVENT_ID"]) {
            Custom\Core\Events::getEventData($data["EVENT_ID"], $event, true);
            
            // Формируем даты для basketItems аналогично getBasketArray
            $this->populateBasketItemsDates($basketItems, $event);
        }


        if ($personTypeId == self::PERSON_TYPE_ID_LEGAL) {
            $reserveTime                     = $this->calculateLegalReserveTime($event, $basketItems);
            $this->arResult['DATE_DEADLINE'] = $this->formatDateForPDF($reserveTime);
        } else {
            $reserveTime = $this->getMinReserveTime($basketItems);
        }

        if ($reserveTime) {
            $property = $propertyCollection->getItemByOrderPropertyCode("RESERVE_TIME");
            if ($property) $property->setValue($reserveTime);
        }

        $order->doFinalAction(true);

        $result = $order->save();
        if ($result->isSuccess()) {
            $organizer = $this->getOrganizerInfo($data["COMPANY_ID"]);
            $orderData = $order->getFields()->getValues();
            if ($personTypeId == self::PERSON_TYPE_ID_LEGAL) {
                $this->arResult['EVENT_DATA']['EVENT_ID'] = $event['ID'];
                $invoice                                  = new \Custom\Core\Orders\InvoiceGenerator();
                $serverName                               = 'https://' . Bitrix\Main\Config\Option::get('main', 'server_name', '');
                // Генерируем и отправляем PDF
                $relativePath = "/upload/invoice/order/счет-оферта-{$orderData["ACCOUNT_NUMBER"]}.pdf";
                $filePath     = $_SERVER["DOCUMENT_ROOT"] . $relativePath;
                $invoice->saveInvoice($result->getId(), $filePath);

                // Получаем минимальную дату из билетов в корзине
                $minBasketDate = $this->getMinDateFromBasketItems($basketItems);
                $targetDate = $minBasketDate;

                $reservationDate = $this->calculateLegalReserveTime($event, $basketItems);

                $resCompany      = CRest::call(
                    'crm.company.add',
                    ['FIELDS' => [
                        'TITLE' => $data["legal_entity"]["company_name"],
                        'UF_CRM_1733239527983' => '',
                    ]]
                );
                $clientCompanyID = $resCompany['result'];
                if ((int)$clientCompanyID < 1)
                    Bitrix\Main\Diag\Debug::writeToFile($resCompany['error'] . ': ' . $resCompany['error_information'], '', '/log/b24_order_legal_pay_error.txt');

                if (!empty($data["legal_entity"]["kpp"])) $presetID = 1;
                else $presetID = 2;

                $requsiteFields = [
                    'ACTIVE'         => 'Y',
                    "ENTITY_TYPE_ID" => 4,
                    "ENTITY_ID"      => $clientCompanyID,
                    "PRESET_ID" => $presetID,
                    "NAME"           => $data["legal_entity"]["company_name"],
                    "RQ_INN"         => $data["legal_entity"]["inn"],
                    "RQ_KPP"         => $data["legal_entity"]["kpp"]
                ];

                $resultRequisite = \CRest::call(
                    'crm.requisite.add',
                    [
                        'FIELDS' => $requsiteFields
                    ]
                );
                if ((int)$resultRequisite["result"] < 1)
                    Bitrix\Main\Diag\Debug::writeToFile($resCompany['error'] . ': ' . $resCompany['error_information'], '', '/log/b24_order_legal_pay_error.txt');
                $requsiteId = $resultRequisite["result"];

                $addressFields = [
                    "TYPE_ID"        => 4,
                    "ENTITY_TYPE_ID" => 8,
                    "ENTITY_ID"      => $requsiteId,
                    "ADDRESS_1"      => $data["legal_entity"]["legal_address"],
                ];

                $resultAddress = \CRest::call(
                    'crm.address.add',
                    [
                        'FIELDS' => $addressFields
                    ]
                );

                $resContact = CRest::call(
                    'crm.legal.payments.add',
                    [
                        "company_id" => $clientCompanyID,
                        "inn"              => $data["legal_entity"]["inn"],
                        "org_name"         => $data["legal_entity"]["company_name"],
                        "org_id"           => $clientCompanyID,
                        "order_number"     => $orderData["ACCOUNT_NUMBER"],
                        "paid_amount"      => $orderData["PRICE"],
                        "tickets_number"   => $order->getBasket()->count(),
                        "event_name"       => $event['NAME'],
                        "event_date"       => $targetDate->format('d.m.Y'),
                        "order_date"       => $orderData['DATE_INSERT']->format('d.m.Y'),
                        "reservation_date" => date('d.m.Y', $reservationDate),
                        "order_invoice"    => $serverName . $relativePath
                    ]
                );
                if((int)$resContact['result']['item']['id'] < 1)
                    Bitrix\Main\Diag\Debug::writeToFile($resContact['error'].': '.$resContact['error_information'],'','/log/b24_order_legal_pay_error.txt');
                else{
                    $propertyCollection = $order->getPropertyCollection();
                    $property = $propertyCollection->getItemByOrderPropertyCode("B24_DEAL_ID");
                    if ($property) {
                        $property->setValue((int)$resContact['result']['item']['id']);
                        $order->save();
                    }
                }
            }


            foreach ($basketItems as $item) {
                $basketIds[] = $item->getField("ID");
            }

            $this->addGuid($order->getId());

            self::setCountApplyPromocodes($basketItems);

            $this->arResult["ORDER_ID"]       = $order->getId();
            $this->arResult["PERSON_TYPE_ID"] = $personTypeId;

            $hlblock  = HL\HighloadBlockTable::getById(HL_QUESTIONNARES)->fetch();
            $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
            $hlbClass = $entity->getDataClass();

            $subscribes = [];

            if ($data["ANKETA_MULTIPLE"] && $data["ANKETA_MULTIPLE"] == "Y") {
                foreach ($data["anketa"] as $key => $anketa) {
                    if ($event) {
                        foreach ($anketa as $qId => &$value) {
                            if ($event["UF_QUESTIONNAIRE_FIELDS"][$qId]
                                && $value
                                && $event["UF_QUESTIONNAIRE_FIELDS"][$qId]["type"] == "text"
                                && is_array($value)
                            ) {
                                $value = implode("\n", $value);
                            }
                        }
                    }

                    $resAdd = $hlbClass::add(
                        [
                            "UF_EVENT_ID"  => $data["EVENT_ID"],
                            "UF_USER_ID"   => $userId,
                            "UF_DATE"      => new \Bitrix\Main\Type\DateTime(),
                            "UF_USER_DATA" => json_encode($anketa, JSON_UNESCAPED_UNICODE),
                            "UF_ORDER_ID"  => $this->arResult["ORDER_ID"],
                            "UF_TICKET"    => [$key],
                            "UF_FULL_NAME" => $anketa["full_name"],
                            "UF_EMAIL"     => $anketa["email"],
                            "UF_PHONE"     => $anketa["phone"],
                            "UF_BUYER"     => ($data["buyer"] == $key) ? 1 : 0,
                        ]
                    );

                    if (!$subscribes[$anketa["email"]] && $data["buyer"] == $key) {
                        $subscribes[$anketa["email"]] = [
                            "UF_NAME"      => $anketa["full_name"],
                            "UF_EMAIL"     => $anketa["email"],
                            "UF_PHONE"     => $anketa["phone"],
                            "UF_SUBSCRIBE" => $data["subscribe"] ?? ""
                        ];
                    }
                }
            } else {
                if ($event) {
                    foreach ($data["anketa"] as $qId => &$value) {
                        if ($event["UF_QUESTIONNAIRE_FIELDS"][$qId]
                            && $value
                            && $event["UF_QUESTIONNAIRE_FIELDS"][$qId]["type"] == "text"
                            && is_array($value)
                        ) {
                            $value = implode("\n", $value);
                        }
                    }
                }

                $basketIds = [];
                foreach ($basketItems as $item) {
                    $basketIds[] = $item->getField("ID");
                }

                $resAdd = $hlbClass::add(
                    [
                        "UF_EVENT_ID"  => $data["EVENT_ID"],
                        "UF_USER_ID"   => $userId,
                        "UF_DATE"      => new \Bitrix\Main\Type\DateTime(),
                        "UF_USER_DATA" => json_encode($data["anketa"], JSON_UNESCAPED_UNICODE),
                        "UF_ORDER_ID"  => $this->arResult["ORDER_ID"],
                        "UF_TICKET"    => $basketIds,
                        "UF_FULL_NAME" => $data["anketa"]["full_name"],
                        "UF_EMAIL"     => $data["anketa"]["email"],
                        "UF_PHONE"     => $data["anketa"]["phone"],
                        "UF_BUYER"     => 1,
                    ]
                );

                $subscribes[$data["anketa"]["email"]] = [
                    "UF_NAME"      => $data["anketa"]["full_name"],
                    "UF_EMAIL"     => $data["anketa"]["email"],
                    "UF_PHONE"     => $data["anketa"]["phone"],
                    "UF_SUBSCRIBE" => $data["subscribe"] ?? ""
                ];
            }

            if ($subscribes) {
                $this->subscribeProcess($subscribes);
            }

            if ($order->getPrice() > 0) {
                $this->arResult["PAY_SYSTEM_ID"] = $data["PAY_SYSTEM_ID"];
            } else {
                $this->arResult["ORDER_FREE"] = true;

                $paymentCollection = $order->getPaymentCollection();
                $onePayment        = $paymentCollection[0];
                $onePayment->setPaid("Y");
                $order->save();
            }
            $this->arResult["EVENT_DATA"] = $event;
        } else {
            $this->arResult["ERROR"][] = $result->getErrorMessages();
        }
    }

    public function subscribeProcess($subscribes)
    {
        $emails = array_column($subscribes, 'UF_EMAIL');

        $enumId = \Custom\Core\Contract::getHLfileldEnumId(
            "Subscriptions",
            "UF_SUBSCRIBE",
            "Y"
        );

        $Entity = new ORM\Query\Query('Custom\Core\Users\SubscriptionsTable');
        $query  = $Entity
            ->setSelect(
                [
                    'ID',
                    'UF_EMAIL',
                    'UF_SUBSCRIBE',
                ]
            )
            ->setFilter(
                [
                    'UF_EMAIL' => $emails,
                ]
            )
            ->exec();

        $queryResult = [];

        while ($ob = $query->fetch()) {
            foreach ($subscribes as $k => $item) {
                if ($item["UF_EMAIL"] == $ob["UF_EMAIL"]) {
                    $subscribes[$k]["HL_ID"] = $ob["ID"];

                    if ((!$ob["UF_SUBSCRIBE"] && $item["UF_SUBSCRIBE"]) || ($ob["UF_SUBSCRIBE"] && !$item["UF_SUBSCRIBE"])) {
                        $subscribes[$k]["NEED_UPDATE"] = true;

                        if ($item["UF_SUBSCRIBE"])
                            $subscribes[$k]["UF_SUBSCRIBE"] = $enumId;
                        else
                            $subscribes[$k]["UF_SUBSCRIBE"] = null;
                    }
                }
            }
        }

        foreach ($subscribes as $k => $item) {
            if ($item["NEED_UPDATE"] && $item["HL_ID"]) {
                \Custom\Core\Users\SubscriptionsTable::update(
                    $item["HL_ID"],
                    [
                        "UF_NAME"      => $item["UF_NAME"],
                        "UF_EMAIL"     => $item["UF_EMAIL"],
                        "UF_PHONE"     => $item["UF_PHONE"],
                        "UF_SUBSCRIBE" => $item["UF_SUBSCRIBE"]
                    ]
                );
            }

            if (!$item["HL_ID"]) {
                \Custom\Core\Users\SubscriptionsTable::add(
                    [
                        "UF_NAME"      => $item["UF_NAME"],
                        "UF_EMAIL"     => $item["UF_EMAIL"],
                        "UF_PHONE"     => $item["UF_PHONE"],
                        "UF_SUBSCRIBE" => ($item["UF_SUBSCRIBE"]) ? $enumId : null
                    ]
                );
            }
        }
    }

    public function addGuid($orderId)
    {
        \Bitrix\Main\Loader::includeModule("sale");

        $order = \Bitrix\Sale\Order::load($orderId);

        if (!$order) {
            return false;
        }

        $uuid = UUID::uuid3(UUID::NAMESPACE_ORDER, $orderId);

        $propertyCollection = $order->getPropertyCollection();
        $property           = $propertyCollection->getItemByOrderPropertyCode("UUID");
        if ($property) $property->setValue($uuid);

        $result = $order->save();
        return $result;
    }

    public function clearBasket()
    {
        if (!\Bitrix\Sale\Fuser::getId())
            return;

        $enumIdNew = \Custom\Core\Contract::getHLfileldEnumId(
            "Barcodes",
            "UF_STATUS",
            "new"
        );

        $barcodeIds = \Bitrix\Sale\BasketPropertiesCollection::getList(
            [
                'select'  => ['VALUE'],
                'filter'  => [
                    '=BASKET.FUSER_ID' => \Bitrix\Sale\Fuser::getId(),
                    '=BASKET.ORDER_ID' => null,
                    '=CODE'            => "BARCODE",
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET',
                        '\Bitrix\Sale\Internals\BasketTable',
                        ['this.BASKET_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ]
            ]
        )->fetchAll();;

        foreach ($barcodeIds as $id) {
            \Custom\Core\Tickets\BarcodesTable::update(
                $id["VALUE"],
                [
                    "UF_STATUS"     => $enumIdNew,
                    "UF_TICKET_NUM" => null,
                    "UF_SEATMAP_ID" => null,
                ]
            );
        }

        CSaleBasket::DeleteAll(\Bitrix\Sale\Fuser::getId());
    }

    public static function discountAction($basket)
    {
        \Bitrix\Main\Loader::includeModule("sale");

        if (!$basket)
            $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());

        \Custom\Core\Discount::getOptimalPriceInBasket($basket);

        $basket->save();
    }

    public static function promocodeAction($promocode = null)
    {
        if (!$promocode) {
            \Bitrix\Main\Loader::includeModule("sale");

            $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());

            $basketItems = $basket->getBasketItems();

            \Custom\Core\Discount::deleteAllPromocodeDiscount($basket);

            $basket->save();

            self::recalculate();
        } else {
            \Bitrix\Main\Loader::includeModule("sale");

            $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());

            $result = \Custom\Core\Discount::validatePromocodeDiscount($promocode, $basket);

            //\Custom\Core\Discount::setPromocodeDiscount($promocode, $basket);

            $basket->save();

            if ($result["error"]) {
                throw new \Exception(implode("\n", $result["error"]));
            }
        }
    }

    public function getBasketRule($basketItemsIds, &$arItems)
    {
        $arRulesInfo      = [];
        $arRulesInfoTotal = [];
        $arPromocodesInfo = [];

        $applyRulesEntity = new ORM\Query\Query('Custom\Core\Events\DiscountApplyTable');
        $query            = $applyRulesEntity
            ->setSelect(
                [
                    '*',
                ]
            )
            ->setFilter(
                [
                    'UF_BASKET_ITEM_ID' => $basketItemsIds
                ]
            )
            ->exec();

        while ($rule = $query->fetch()) {
            if ($rule["UF_RULE_TYPE"] == "RULE") {
                if (!$arRulesInfo[$rule["UF_RULE_ID"]]) {
                    $arRulesInfo[$rule["UF_RULE_ID"]] = \Custom\Core\Discount::getRuleInfo($rule["UF_RULE_ID"]);
                }

                $arItems[$rule["UF_BASKET_ITEM_ID"]]["RULE"] = $arRulesInfo[$rule["UF_RULE_ID"]];

                if (!$arRulesInfoTotal[$rule["UF_RULE_ID"]]) {
                    $arRulesInfoTotal[$rule["UF_RULE_ID"]]             = \Custom\Core\Discount::getRuleInfo($rule["UF_RULE_ID"]);
                    $arRulesInfoTotal[$rule["UF_RULE_ID"]]["DISCOUNT"] = $rule["UF_DISCOUNT_VALUE"];
                } else
                    $arRulesInfoTotal[$rule["UF_RULE_ID"]]["DISCOUNT"] += $rule["UF_DISCOUNT_VALUE"];
            }
            if ($rule["UF_RULE_TYPE"] == "PROMOCODE") {
                if (!$arPromocodesInfo[$rule["UF_PROMOCODE_ID"]]) {
                    $arPromocodesInfo[$rule["UF_PROMOCODE_ID"]]["PROMOCODE"] = \Custom\Core\Discount::getPromocodeInfo($rule["UF_PROMOCODE_ID"]);
                    $arPromocodesInfo[$rule["UF_PROMOCODE_ID"]]["RULE"]      = \Custom\Core\Discount::getRuleInfo($rule["UF_RULE_ID"]);
                    $arPromocodesInfo[$rule["UF_PROMOCODE_ID"]]["DISCOUNT"]  = $rule["UF_DISCOUNT_VALUE"];
                } else
                    $arPromocodesInfo[$rule["UF_PROMOCODE_ID"]]["DISCOUNT"] += $rule["UF_DISCOUNT_VALUE"];
            }
        }

        foreach ($arRulesInfoTotal as $key => &$item) {
            $item["DISCOUNT"] = round($item["DISCOUNT"], 2);
        }

        foreach ($arPromocodesInfo as $key => &$item) {
            $item["DISCOUNT"] = round($item["DISCOUNT"], 2);
        }

        $this->arResult["PROMOCODES"] = $arPromocodesInfo;
        $this->arResult["RULES"]      = $arRulesInfoTotal;
    }

    public function getOrderServicesPrice($companyID, $orderSum)
    {
        $query      = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany = $query
            ->setFilter(['ID' => $companyID, '!UF_COOPERATION_SERVICE_FEE' => false])
            ->setSelect(
                [
                    'UF_COOPERATION_SERVICE_FEE',
                ]
            )
            ->setLimit(1)
            ->exec();
        if ($company = $resCompany->fetch()) {
            return round(($orderSum / 100) * $company["UF_COOPERATION_SERVICE_FEE"], 2);
        }

        return 0;
    }

    public function getQntText($qnt)
    {
        switch (true) {
            case $qnt == 1:
                return "билет";
            case $qnt >= 2 && $qnt <= 4:
                return "билета";
            case $qnt >= 5:
                return "билетов";
        }

        return "";
    }

    public function getBasketIds($basket)
    {
        $basketItems = $basket->getBasketItems();

        $result = [];

        foreach ($basketItems as $item) {
            $result[] = $item->getId();
        }

        return $result;
    }

    public function getArrayToStr($array)
    {
        return base64_encode(json_encode($array));
    }

    public function getStrToArray($str)
    {
        return base64_decode(json_decode($str, true));
    }

    public function getOrganizerInfo($orgId = null)
    {
        if (!$orgId)
            return [];

        $result = [];

        $query      = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany = $query
            ->setFilter(
                [
                    'ID'              => $orgId,
                    'CONTRACT.XML_ID' => "signed"
                ]
            )
            ->setSelect(
                [
                    'COMPANY_TYPE_XML_ID' => 'COMPANY_TYPE.XML_ID',
                    'UF_FULL_NAME',
                    'UF_XML_ID',
                    'UF_INN',
                    'UF_EMAIL',
                    'UF_PHONE',
                    'UF_FIO',
                ]
            )
            ->registerRuntimeField(
                'COMPANY_TYPE',
                [
                    'data_type' => '\Custom\Core\FieldEnumTable',
                    'reference' => ['=this.UF_TYPE' => 'ref.ID'],
                    'join_type' => 'LEFT'
                ]
            )
            ->registerRuntimeField(
                'CONTRACT',
                [
                    'data_type' => '\Custom\Core\FieldEnumTable',
                    'reference' => ['=this.UF_CONTRACT' => 'ref.ID'],
                    'join_type' => 'LEFT'
                ]
            )
            ->setLimit(1)
            ->exec();
        if ($company = $resCompany->fetch()) {
            $company["UF_PHONE_FORMAT"] = str_replace(["(", ")", "-", " "], "", $company["UF_PHONE"]);

            if ($company["COMPANY_TYPE_XML_ID"] == "person") {
                $company["UF_FULL_NAME"] = $company["UF_FIO"];
            }
            $result = $company;
        }

        return $result;
    }

    public function getBasketArray()
    {
        \Bitrix\Main\Loader::includeModule("sale");

        $eventData = [];

        $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());

        $basketItems = $basket->getBasketItems();

        $promocodes = [];

        $arNumderTicketsForMane = [];

        foreach ($basketItems as $item) {
            $props                    = [];
            $basketPropertyCollection = $item->getPropertyCollection();
            foreach ($basketPropertyCollection as $basketProperty) {
                if (!in_array($basketProperty->getField('CODE'), self::excludeProps)
                    //&& self::basketPropsShow[$basketProperty->getField('CODE')]
                    && $basketProperty->getField('VALUE') != null) {
                    //$props[] = ["NAME" => $basketProperty->getField('NAME'), "VALUE" => $basketProperty->getField('VALUE')];
                    $props[] = $basketProperty->getField('NAME') . " " . $basketProperty->getField('VALUE');
                }
            }

            /*if(!$arNumderTicketsForMane[$item->getProductId()])
                $arNumderTicketsForMane[$item->getProductId()] = 0;

            $arNumderTicketsForMane[$item->getProductId()] ++;*/

            $arItems[$item->getId()] = [
                "ID"                    => $item->getId(),
                "NAME"                  => $item->getField('NAME'),
                "PRODUCT_ID"            => $item->getProductId(),
                "QUANTITY"              => $item->getQuantity(),
                "SUM"                   => CurrencyFormat($item->getFinalPrice(), "RUB"),
                "BASE_PRICE"            => $item->getField('BASE_PRICE'),
                "DISCOUNT_PRICE"        => $item->getField('DISCOUNT_PRICE'),
                "PRICE"                 => $item->getPrice(),
                "PROPS"                 => $props,
                "SUM_FORMAT"            => Helper::priceFormat($item->getFinalPrice()),
                "BASE_PRICE_FORMAT"     => Helper::priceFormat($item->getField('BASE_PRICE')),
                "DISCOUNT_PRICE_FORMAT" => Helper::priceFormat($item->getField('DISCOUNT_PRICE')),
            ];

            if (!$eventData)
                $eventData = self::getEventInOrderData($item->getProductId());
        }

        $basketItemsIds = array_map(
            function ($item) {
                return $item->getField("ID");
            }, $basketItems
        );

        if ($basketItemsIds) {
            self::getBasketRule($basketItemsIds, $arItems);
        }

        $this->arResult["BASKET_ITEM_IDS"] = $this->getArrayToStr($this->getBasketIds($basket));

        $this->arResult["BASKET"]["BASE_SUM"] = CurrencyFormat($basket->getBasePrice(), "RUB");
        $this->arResult["BASKET"]["SUM"]      = CurrencyFormat($basket->getPrice(), "RUB");

        $arProducts = \Custom\Core\Helper::getTicketsOffers($eventData["EVENT_ID"] ?? 0);
        
        foreach ($arItems as $key => &$item) {
            // Сначала устанавливаем все даты события
            $item['DATES'] = $eventData['UF_DATE_TIME'] ?? [];
            
            // Фильтруем по SKU_DATES если они есть
            foreach ($arProducts as $product) {
                if ($product['SKU_ID'] == $item['PRODUCT_ID'] && !empty($product['SKU_DATES'])) {
                    // Фильтруем уже установленные даты по SKU_DATES
                    $filteredDates = [];
                    foreach ($item['DATES'] as $eventDate) {
                        $eventDateTime = \DateTime::createFromFormat('Y-m-d H:i:s', $eventDate);
                        if (!$eventDateTime) continue;
                        
                        foreach ($product['SKU_DATES'] as $skuDate) {
                            $skuDateTime = \DateTime::createFromFormat('d.m.y', $skuDate);
                            if (!$skuDateTime) continue;
                            
                            // Сравниваем только даты (без времени)
                            if ($eventDateTime->format('Y-m-d') === $skuDateTime->format('Y-m-d')) {
                                $filteredDates[] = $eventDate;
                                break;
                            }
                        }
                    }
                    $item['DATES'] = $filteredDates;
                    break;
                }
            }
        }

        $this->arResult["BASKET"]["ITEMS"] = $arItems;

        if ($arItems)
            $this->arResult["BASKET"]["QUANTITY"] = array_sum(array_column($arItems, 'QUANTITY'));

        $this->arResult["BASKET"]["QUANTITY_TEXT"] = self::getQntText($this->arResult["BASKET"]["QUANTITY"]);

        if ($this->arResult["BASKET"]["SUM"] && $eventData["COMPANY_ID"]) {
            $orderServicesPrice = self::getOrderServicesPrice($eventData["COMPANY_ID"], $this->arResult["BASKET"]["SUM"]);

            if ($orderServicesPrice) {
                $this->arResult["BASKET"]["SUM"]      += $orderServicesPrice;
                $this->arResult["BASKET"]["BASE_SUM"] += $orderServicesPrice;

                $this->arResult["BASKET"]["SERVICES"] = [
                    "SUM"        => $orderServicesPrice,
                    "SUM_FORMAT" => Helper::priceFormat($orderServicesPrice),
                    "NAME"       => self::servicesPriceName,
                ];
            }
        }

        $this->arResult["BASKET"]["BASE_SUM_FORMAT"] = Helper::priceFormat($this->arResult["BASKET"]["BASE_SUM"]);
        $this->arResult["BASKET"]["SUM_FORMAT"]      = Helper::priceFormat($this->arResult["BASKET"]["SUM"]);

        $eventTypeText = [];
        if ($eventData["LOCATION_ROOM"])
            $eventTypeText[] = $eventData["LOCATION_ROOM"];
        if ($eventData["LOCATION_ADDRESS"])
            $eventTypeText[] = $eventData["LOCATION_ADDRESS"];

        if ($eventTypeText)
            $eventData["EVENT_TYPE_TEXT"] = implode(". ", $eventTypeText);

        $this->arResult["ORGANIZER_INFO"] = $this->getOrganizerInfo($eventData["COMPANY_ID"]);

        $this->arResult["EVENT_DATA"] = $eventData;

        $this->prepareQuestionnaireFields();

        if ($this->arResult["BASKET"]["BASE_SUM"] == 0) {
            $this->arResult["SUBMIT_BTN"] = self::orderSubmitName["FREE"];
            $this->arResult["ONLY_FREE"]  = true;
        } else {
            $this->arResult["SUBMIT_BTN"] = self::orderSubmitName["PAY"];
            $this->arResult["ONLY_FREE"]  = false;
        }
    }

    public function loginOrRegister($data)
    {
        $anketa = $data["anketa"];
        if ($data["ANKETA_MULTIPLE"] && $data["ANKETA_MULTIPLE"] == "Y") {
            if ($data["buyer"] && $data["anketa"][$data["buyer"]]) {
                $anketa = $data["anketa"][$data["buyer"]];
            } else {
                $bufAnkets = $data["anketa"];
                $anketa    = array_shift($bufAnkets);
            }
        }

        if ($anketa["email"]) {
            global $USER;

            $user = \Bitrix\Main\UserTable::getList(
                [
                    'select' => [
                        'ID'
                    ],
                    'filter' => [
                        'EMAIL' => $anketa["email"]
                    ]
                ]
            )->fetch();

            if ($user["ID"]) {
                $this->userId = $user["ID"];
            } else {
                $pwd = randString(10);

                $userAdd  = new \CUser;
                $arFields = [
                    "EMAIL"            => $anketa["email"],
                    "LOGIN"            => $anketa["email"],
                    "ACTIVE"           => "Y",
                    "GROUP_ID"         => [10, 11],
                    "PASSWORD"         => $pwd,
                    "CONFIRM_PASSWORD" => $pwd,
                ];

                $ID = $userAdd->Add($arFields);

                $this->userId = $ID;
            }
        } else {
            throw new \Exception("Ошибка! Не передан email");
        }
    }

    public function saveAnketaFiles(&$request = null, $files = null)
    {
        $extSystem = ['bin', 'apk', 'bat', 'cmd', 'js', 'php', 'cgi', 'com', 'cpp', 'jse', 'exe', 'gadget', 'gtp', 'hta', 'jar', 'msi', 'msu', 'pif', 'psl', 'pwz', 'scr', 'thm', 'vb', 'vbe', 'vbs', 'wsf', 'dmg'];

        $Questionnaires = new \Custom\Core\Questionnaires();
        $includeSystem  = $Questionnaires->extensions;
        $maxSize        = $Questionnaires->fileSize;

        $arSaveFilesId = [];
        if ($request["ANKETA_MULTIPLE"] && $request["ANKETA_MULTIPLE"] == "Y") {
            foreach ($files["anketa"]["name"] as $basketItemId => $questionnaire) {
                if (empty($questionnaire))
                    continue;

                foreach ($questionnaire as $questionnaireId => $questionnaireArray) {
                    if (is_array($files["anketa"]["name"][$basketItemId][$questionnaireId])) {
                        foreach ($files["anketa"]["name"][$basketItemId][$questionnaireId] as $file) {
                            if (!in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), $includeSystem)) {
                                throw new \Exception("Загрузка файла {$file} запрещена.");
                            }
                        }
                    } elseif (!in_array(strtolower(pathinfo($files["anketa"]["name"][$basketItemId][$questionnaireId], PATHINFO_EXTENSION)), $includeSystem)) {
                        throw new \Exception("Загрузка файла {$files["anketa"]["name"][$basketItemId][$questionnaireId]} запрещена.");
                    }

                    if (is_array($files["anketa"]["size"][$basketItemId][$questionnaireId])) {
                        foreach ($files["anketa"]["size"][$basketItemId][$questionnaireId] as $file) {
                            if ($file > $maxSize) {
                                throw new \Exception("Загрузка файла запрещена.");
                            }
                        }
                    } elseif ($files["anketa"]["size"][$basketItemId][$questionnaireId] > $maxSize) {
                        throw new \Exception("Загрузка файла {$files["anketa"]["name"][$basketItemId][$questionnaireId]} запрещена.");
                    }

                    foreach ($questionnaireArray as $keyVal => $val) {
                        $arFileArray = [
                            "name"      => $files["anketa"]["name"][$basketItemId][$questionnaireId][$keyVal],
                            "size"      => $files["anketa"]["size"][$basketItemId][$questionnaireId][$keyVal],
                            "tmp_name"  => $files["anketa"]["tmp_name"][$basketItemId][$questionnaireId][$keyVal],
                            "type"      => $files["anketa"]["type"][$basketItemId][$questionnaireId][$keyVal],
                            "MODULE_ID" => "highloadblock"
                        ];

                        $FileID = \CFile::SaveFile($arFileArray, "highloadblock");

                        if ($FileID) {
                            $arFile = \CFile::GetFileArray($FileID);

                            $request["anketa"][$basketItemId][$questionnaireId][$keyVal] = $arFile["EXTERNAL_ID"];
                        }
                    }

                }
            }

        } else {
            foreach ($files["anketa"]["name"] as $qKey => $arFiles) {
                foreach ($arFiles as $fKey => $file) {
                    if (!in_array(strtolower(pathinfo($files["anketa"]["name"][$qKey][$fKey], PATHINFO_EXTENSION)), $includeSystem)) {
                        throw new \Exception("Загрузка файла {$file} запрещена.");
                    }

                    if ($files["anketa"]["size"][$qKey][$fKey] > $maxSize) {
                        throw new \Exception("Загрузка файла {$files["anketa"]["name"][$qKey][$fKey]} запрещена.");
                    }
                }

                foreach ($arFiles as $fKey => $file) {
                    $arFileArray = [
                        "name"      => $files["anketa"]["name"][$qKey][$fKey],
                        "size"      => $files["anketa"]["size"][$qKey][$fKey],
                        "tmp_name"  => $files["anketa"]["tmp_name"][$qKey][$fKey],
                        "type"      => $files["anketa"]["type"][$qKey][$fKey],
                        "MODULE_ID" => "highloadblock"
                    ];

                    $FileID = \CFile::SaveFile($arFileArray, "highloadblock");

                    if ($FileID) {
                        $arFile = \CFile::GetFileArray($FileID);

                        $request["anketa"][$qKey][$fKey] = $arFile["EXTERNAL_ID"];
                    }
                }


            }

        }
    }

    public function prepareQuestionnaireFields()
    {
        $Questionnaires = new \Custom\Core\Questionnaires();

        if ($this->arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"])
            $this->arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"] = array_merge(
                $Questionnaires->defaultFields,
                $this->arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"]
            );
        else
            $this->arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"] = $Questionnaires->defaultFields;

        foreach ($this->arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"] as $key => &$item) {
            if ($this->arResult["EVENT_DATA"]["QUESTIONNAIRE_ACTIVE"] || self::requiredProps[$key]) {
                if (self::requiredProps[$key] || $item["required"])
                    $item["required"] = "required";

                if ($item["type"] == "file") {
                    $item["extension"] = $Questionnaires->extensions;
                    foreach ($item["extension"] as &$extension) {
                        $extension = "." . $extension;
                    }

                    $item["extension"] = implode(", ", $item["extension"]);

                    $item["size"] = $Questionnaires->fileSize / 1024 / 1024;
                }
                /*if($item["type"] == "file" && $item["extension"])
                {
                    foreach ($item["extension"] as &$extension) {
                        $extension = ".".$extension;
                    }

                    $item["extension"] = implode(", ", $item["extension"]);
                }*/
            } else {
                unset($this->arResult["EVENT_DATA"]["UF_QUESTIONNAIRE_FIELDS"][$key]);
            }
        }
    }

    public function getPaySystems(array $additionalPaySystems = [])
    {
        $defaultPaySystems = [5, 10];
        if (!empty($additionalPaySystems)) $defaultPaySystems = array_merge($defaultPaySystems, $additionalPaySystems);
        $paySystemResult = \Bitrix\Sale\PaySystem\Manager::getList(
            [
                'select'  => ['ID', 'PAY_SYSTEM_ID', 'NAME', 'LOGO_SRC', 'DESCRIPTION', 'CODE'],
                'filter'  => ['ACTIVE' => 'Y', 'ID' => $defaultPaySystems],
                'order'   => ['SORT' => 'ASC'],
                'cache'   => ['ttl' => 3600],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PICTURE',
                        '\Bitrix\Main\FileTable',
                        ['this.LOGOTIP' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'LOGO_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['PICTURE.SUBDIR', 'PICTURE.FILE_NAME']
                    ),
                ]
            ]
        );
        while ($resPaySys = $paySystemResult->fetch()) {
            if ($resPaySys["CODE"] == "b_cards") $resPaySys["CHECKED"] = "checked";
            $resPaySys['IMG'] = $resPaySys['LOGO_SRC'];
            unset($resPaySys['LOGO_SRC']);
            $result[] = $resPaySys;
        }

        $this->arResult["PAY_SYSTEMS"] = $result;
    }

    public function getWedgetData($request)
    {
        if ($request["WIDGET_ID"]) {
            $this->arResult["WIDGET"]["WIDGET_ID"] = $request["WIDGET_ID"];
        }
    }


    public function checkBasketEvent($request)
    {
        if ($request["event_item_id"]) {
            $basketRequest = $request["event_item_id"];

            $basket       = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());
            $basketBitrix = $this->getArrayToStr($this->getBasketIds($basket));

            if (strcmp($basketRequest, $basketBitrix)) {
                self::errorFormatJson(['status' => 'error', 'action' => 'error_compare_basket']);
            }

        }
    }

    public function checkBasketDiscount()
    {
        $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());
        $oldPrice = $basket->getPrice();

        self::recalculate($basket);

        $basket = \Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());

        $price = $basket->getPrice();

        if($price != $oldPrice)
        {
            self::errorFormatJson(['status' => 'error', 'action' => 'error_compare_basket']);
        }
    }

    public function onPrepareComponentParams($arParams)
    {
        return $arParams;
    }

    public function executeComponent()
    {
        $objRequest = \Bitrix\Main\Context::getCurrent()->getRequest();
        $files      = $objRequest->getFileList()->toArray();

        $request = $objRequest->toArray();

        $this->arResult = $this->arParams;

        $this->arResult["ERROR"] = [];

        if (isset($request['invoice']) && $request['invoice'] > 0) {
            global $APPLICATION;
            $APPLICATION->RestartBuffer();
            $invoice = new \Custom\Core\Orders\InvoiceGenerator();

            if (!$invoice->orderExists((int)$request['invoice'])) {
                throw new Exception("Заказ #{$request['invoice']} не найден в базе данных");
            }

            // Генерируем и отправляем PDF
            $invoice->outputInvoice((int)$request['invoice']);
            //saveInvoice
            //$filename = "счет-оферта-{$this->orderData["ACCOUNT_NUMBER"]}.pdf";
            die();
        }

        if ($request["ORDER"] == "Y") {
            $GLOBALS["APPLICATION"]->RestartBuffer();

            $this->checkBasketEvent($request);
            $this->checkBasketDiscount();
            /*if(!check_bitrix_sessid())
            {
                $this->showError("Ошибка сессии");
            }*/

            global $USER;
            if (!$USER->IsAuthorized()) {
                $this->loginOrRegister($request);
            } else {
                $this->userId = $USER->GetID();
            }

            if ($files) {
                $this->saveAnketaFiles($request, $files);
            }
 
            if(!$request["_ym_uid"])
            {
                $request["_ym_uid"] = $objRequest->getQuery("_ym_uid");
            }

            $this->order($request);

            if ($this->arResult["ORDER_ID"]) {
                $this->includeComponentTemplate();
            } elseif ($this->arResult["ERROR"]) {
                global $APPLICATION;
                $APPLICATION->RestartBuffer();

                echo json_encode($this->arResult["ERROR"]);

                die();
            }
        } else {
            $this->getBasketArray();

            global $APPLICATION;
            if(strpos($APPLICATION->GetCurPage(), "/tg/") === false)
            {
                $additionalPaySystems = $this->getAdditionalPaySystems($this->arResult['EVENT_DATA']['EVENT_ID'] ?? 0);
            }
            else
            {
                $additionalPaySystems = [];
            }

            $this->getPaySystems($additionalPaySystems);
            $this->getWedgetData($request);

            if ($request["error"])
                $this->arResult["ERROR"] = $request["error"];

            // Проверяем время до начала мероприятия
            $this->checkEventStartTime();

            // Обработка дат для корзины
            if (!empty($this->arResult["BASKET"]["ITEMS"])) {
                foreach ($this->arResult["BASKET"]["ITEMS"] as &$item) {
                    $item["DATE_PRESENTATION"] = $this->formatDatePresentation($item["DATES"] ?? [], $this->arResult["EVENT_DATA"]["UF_DATE_TIME"] ?? []);
                }
                unset($item);
            }


            $this->includeComponentTemplate();
        }
    }

    /**
     * Проверяет время до начала мероприятия и устанавливает булевый параметр
     * если до начала осталось 48 часов или менее
     */
    private function checkEventStartTime(): void
    {
        // Получаем минимальную дату из билетов в корзине
        $minEventDate = $this->getMinimumEventDateFromBasket();

        // Получаем время начала события
        $eventStartTime = $this->getEventStartTime($minEventDate);

        if ($eventStartTime) {
            $currentTime     = time();
            $hoursUntilEvent = (float)(($eventStartTime - $currentTime) / 3600);

            // Если до начала мероприятия осталось 48 часов или менее
            $this->arResult['IS_WITHIN_48_HOURS'] = ($hoursUntilEvent <= 48);
        } else {
            $this->arResult['IS_WITHIN_48_HOURS'] = false;
        }
    }

    /**
     * Получает минимальную дату из билетов в корзине
     */
    private function getMinimumEventDateFromBasket(): ?string
    {
        $basketItems = $this->arResult['BASKET']['ITEMS'] ?? [];

        if (empty($basketItems)) {
            return null;
        }

        $allDates = [];

        foreach ($basketItems as $item) {
            if (!empty($item['DATES']) && is_array($item['DATES'])) {
                $allDates = array_merge($allDates, $item['DATES']);
            }
        }

        if (empty($allDates)) {
            return null;
        }

        // Сортируем даты и берем минимальную (теперь формат Y-m-d H:i:s)
        usort(
            $allDates, function ($a, $b) {
            $dateA = \DateTime::createFromFormat('Y-m-d H:i:s', $a);
            $dateB = \DateTime::createFromFormat('Y-m-d H:i:s', $b);
            return $dateA <=> $dateB;
        }
        );

        return $allDates[0];
    }

    /**
     * Получает timestamp начала события
     */
    private function getEventStartTime(?string $eventDate): ?int
    {
        // Если есть дата из билетов, используем её (теперь формат Y-m-d H:i:s)
        if ($eventDate) {
            $eventDateTime = \DateTime::createFromFormat('Y-m-d H:i:s', $eventDate);
            if ($eventDateTime) {
                return $eventDateTime->getTimestamp();
            }
        }

        // Иначе используем дату из EVENT_DATA
        $datesGroup = $this->arResult['EVENT_DATA']['DATES_GROUP'][0] ?? null;
        if ($datesGroup && isset($datesGroup['timestamp_start'])) {
            return (int)$datesGroup['timestamp_start'];
        }

        return null;
    }

    /**
     * Извлекает время начала из EVENT_DATA
     */
    private function getEventTime(): ?string
    {
        $datesGroup = $this->arResult['EVENT_DATA']['DATES_GROUP'][0] ?? null;
        if (!$datesGroup || empty($datesGroup['time'])) {
            return null;
        }

        $timeRange = $datesGroup['time'];
        // Извлекаем время начала
        $timeParts = explode(' - ', $timeRange);
        return $timeParts[0] ?? null;
    }

    /**
     * Рассчитывает время резерва для юридических лиц
     *
     * @param array|null $event       Данные события
     * @param array      $basketItems Элементы корзины
     *
     * @return int|null Время резерва в формате timestamp
     */
    private function calculateLegalReserveTime(?array $event, array $basketItems): ?int
    {
        if (!$event || !isset($event['UF_RESERVATION_VALIDITY_PERIOD'])) {
            return null;
        }

        $reservePeriodDays = (int)$event['UF_RESERVATION_VALIDITY_PERIOD'];
        if ($reservePeriodDays <= 0) {
            return null;
        }

        // Получаем минимальную дату из билетов в корзине 
        $minBasketDate = $this->getMinDateFromBasketItems($basketItems);

        if (!$minBasketDate) {
            return null;
        }

        // Рассчитываем дату резерва (текущая дата + период резерва в днях)
        $reserveEndDate = new \DateTime();
        $reserveEndDate->add(new \DateInterval('P' . $reservePeriodDays . 'D'));
        $reserveEndDate->setTime(23, 59, 59);

        // Если дата резерва больше даты билетов, то устанавливаем резерв до даты билетов в 23:59:59
        if ($reserveEndDate >= $minBasketDate) {
            $minBasketDate->setTime(23, 59, 59);
            return $minBasketDate->getTimestamp();
        }

        return $reserveEndDate->getTimestamp();
    }

    /**
     * Получает минимальную дату из билетов в корзине
     */
    private function getMinDateFromBasketItems(array $basketItems): ?\DateTime
    {
        $minDate = null;

        foreach ($basketItems as $item) {
            $productId   = $item->getProductId();
            // Используем даты из объекта basketItem если они есть
            $ticketDates = $this->getTicketDatesFromBasketItem($basketItems, $productId);
            
            // Если нет дат в basketItem, получаем из arResult
            if (empty($ticketDates)) {
                $ticketDates = $this->getTicketDates($productId);
            }

            if (empty($ticketDates)) {
                continue;
            }

            foreach ($ticketDates as $dateStr) {
                $date = \DateTime::createFromFormat('Y-m-d H:i:s', $dateStr);
                if ($date && (!$minDate || $date < $minDate)) {
                    $minDate = $date;
                }
            }
        }

        return $minDate;
    }

    /**
     * Получает даты билета по ID продукта
     */
    private function getTicketDates(int $productId): array
    {
        // Используем данные из arResult если они уже загружены (теперь в формате Y-m-d H:i:s)
        if (isset($this->arResult['BASKET']['ITEMS'])) {
            foreach ($this->arResult['BASKET']['ITEMS'] as $item) {
                if ($item['PRODUCT_ID'] == $productId && !empty($item['DATES'])) {
                    return $item['DATES'];
                }
            }
        }

        // Если данных нет в arResult, возвращаем все даты события
        return $this->arResult['EVENT_DATA']['UF_DATE_TIME'] ?? [];
    }
    
    /**
     * Получает даты билета из объекта Bitrix\Sale по ID продукта
     */
    private function getTicketDatesFromBasketItem($basketItems, int $productId): array
    {
        foreach ($basketItems as $item) {
            if ($item->getProductId() == $productId && !empty($item->dates)) {
                return $item->dates;
            }
        }
        
        return [];
    }



    /**
     * Форматирует дату в формате "2 июля 2025"
     */
    private function formatDateForPDF(?int $timestamp): string
    {
        $months = [
            1 => 'января', 2 => 'февраля', 3 => 'марта', 4 => 'апреля',
            5 => 'мая', 6 => 'июня', 7 => 'июля', 8 => 'августа',
            9 => 'сентября', 10 => 'октября', 11 => 'ноября', 12 => 'декабря'
        ];

        // Если timestamp не передан, используем текущую дату
        $targetTimestamp = $timestamp ?: time();

        $day   = date('j', $targetTimestamp);
        $month = (int)date('n', $targetTimestamp);
        $year  = date('Y', $targetTimestamp);

        return $day . ' ' . ($months[$month] ?? 'месяца') . ' ' . $year;
    }

    public function getAdditionalPaySystems(int $eventId): array
    {
        $hlblock  = HL\HighloadBlockTable::getById(HL_EVENTS_ID)->fetch();
        $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
        $hlbClass = $entity->getDataClass();
        $query    = $hlbClass::getList(
            [
                'filter' => ['ID' => $eventId],
                'select' => ['UF_PAY_SYSTEM'],
            ]
        );
        return $query->fetch()['UF_PAY_SYSTEM'] ?? [];
    }

    public static function errorFormatJson($error)
    {
        header('Content-Type: application/json');
        $GLOBALS["APPLICATION"]->RestartBuffer();
        echo json_encode($error, JSON_UNESCAPED_UNICODE);
        die;
    }

    protected static function getSession(): ?Session
    {
        /** @var Session $session */
        $session = Application::getInstance()->getSession();
        if (!$session->isAccessible()) {
            return null;
        }

        return $session;
    }

    /**
     * Заполняет даты для элементов корзины
     *
     * @param array $basketItems Элементы корзины Bitrix\Sale
     * @param array $eventData   Данные события
     */
    private function populateBasketItemsDates($basketItems, $eventData): void
    {
        $arProducts = \Custom\Core\Helper::getTicketsOffers($eventData["EVENT_ID"] ?? 0);
        
        foreach ($basketItems as $item) {
            // Сначала устанавливаем все даты события
            $item->dates = $eventData['UF_DATE_TIME'] ?? [];
            
            // Фильтруем по SKU_DATES если они есть
            foreach ($arProducts as $product) {
                if ($product['SKU_ID'] == $item->getProductId() && !empty($product['SKU_DATES'])) {
                    // Фильтруем уже установленные даты по SKU_DATES
                    $filteredDates = [];
                    foreach ($item->dates as $eventDate) {
                        $eventDateTime = \DateTime::createFromFormat('Y-m-d H:i:s', $eventDate);
                        if (!$eventDateTime) continue;
                        
                        foreach ($product['SKU_DATES'] as $skuDate) {
                            $skuDateTime = \DateTime::createFromFormat('d.m.y', $skuDate);
                            if (!$skuDateTime) continue;
                            
                            // Сравниваем только даты (без времени)
                            if ($eventDateTime->format('Y-m-d') === $skuDateTime->format('Y-m-d')) {
                                $filteredDates[] = $eventDate;
                                break;
                            }
                        }
                    }
                    $item->dates = $filteredDates;
                    break;
                }
            }
        }
    }

    /**
     * Форматирует даты для презентации в корзине
     *
     * @param array $basketDates Даты из корзины в формате d.m.y
     * @param array $eventDates  Даты события в формате Y-m-d H:i:s
     *
     * @return string Отформатированная строка дат
     */
    private function formatDatePresentation(array $basketDates, array $eventDates): string
    {
        $months = [
            1 => 'Января', 2 => 'Февраля', 3 => 'Марта', 4 => 'Апреля',
            5 => 'Мая', 6 => 'Июня', 7 => 'Июля', 8 => 'Августа',
            9 => 'Сентября', 10 => 'Октября', 11 => 'Ноября', 12 => 'Декабря'
        ];

        $targetDates = [];

        // Если есть даты в корзине, используем их
        if (!empty($basketDates)) {
            // Конвертируем даты корзины в формат DateTime и найдем соответствующие даты в UF_DATE_TIME
            foreach ($basketDates as $basketDate) {
                $basketDateTime = \DateTime::createFromFormat('Y-m-d H:i:s', $basketDate);
                if (!$basketDateTime) continue;

                // Ищем соответствующую дату в UF_DATE_TIME
                foreach ($eventDates as $eventDate) {
                    $eventDateTime = \DateTime::createFromFormat('Y-m-d H:i:s', $eventDate);
                    if (!$eventDateTime) continue;

                    // Сравниваем только даты (без времени)
                    if ($basketDateTime->format('Y-m-d') === $eventDateTime->format('Y-m-d')) {
                        $targetDates[] = $eventDateTime;
                        break;
                    }
                }
            }
        } else {
            // Если дат в корзине нет, используем все даты из UF_DATE_TIME
            foreach ($eventDates as $eventDate) {
                $eventDateTime = \DateTime::createFromFormat('Y-m-d H:i:s', $eventDate);
                if ($eventDateTime) {
                    $targetDates[] = $eventDateTime;
                }
            }
        }

        if (empty($targetDates)) {
            return '';
        }

        // Сортируем даты по возрастанию
        usort(
            $targetDates, function ($a, $b) {
            return $a <=> $b;
        }
        );

        // Проверяем, последовательны ли даты и одинаково ли время
        if (count($targetDates) > 1) {
            $firstTime    = $targetDates[0]->format('H:i');
            $allSameTime  = true;
            $isSequential = true;

            // Проверяем одинаковое время
            foreach ($targetDates as $date) {
                if ($date->format('H:i') !== $firstTime) {
                    $allSameTime = false;
                    break;
                }
            }

            // Проверяем последовательность дат
            if ($allSameTime && count($targetDates) > 1) {
                for ($i = 1; $i < count($targetDates); $i++) {
                    $prevDate = clone $targetDates[$i - 1];
                    $prevDate->modify('+1 day');
                    if ($prevDate->format('Y-m-d') !== $targetDates[$i]->format('Y-m-d')) {
                        $isSequential = false;
                        break;
                    }
                }
            } else {
                $isSequential = false;
            }

            // Если даты последовательны и время одинаково
            if ($isSequential && $allSameTime) {
                $firstDate = $targetDates[0];
                $lastDate  = end($targetDates);

                $firstDay   = $firstDate->format('j');
                $lastDay    = $lastDate->format('j');
                $firstMonth = $months[(int)$firstDate->format('n')];
                $lastMonth  = $months[(int)$lastDate->format('n')];
                $firstYear  = $firstDate->format('Y');
                $lastYear   = $lastDate->format('Y');
                $time       = $firstDate->format('H:i');

                // Если разные годы
                if ($firstYear !== $lastYear) {
                    return "{$firstDay} {$firstMonth} {$firstYear} - {$lastDay} {$lastMonth} {$lastYear} {$time}";
                } // Если разные месяцы, но одинаковый год
                elseif ($firstMonth !== $lastMonth) {
                    return "{$firstDay} {$firstMonth} - {$lastDay} {$lastMonth} {$lastYear} {$time}";
                } // Если одинаковый месяц и год
                else {
                    return "{$firstDay} - {$lastDay} {$lastMonth} {$lastYear} {$time}";
                }
            }
        }

        // Если даты не последовательны или время разное, выводим отдельными строками
        $result = [];
        foreach ($targetDates as $date) {
            $day   = $date->format('j');
            $month = $months[(int)$date->format('n')];
            $year  = $date->format('Y');
            $time  = $date->format('H:i');

            $result[] = "{$day} {$month} {$year} {$time}";
        }

        return implode('<br>', $result);
    }

}
