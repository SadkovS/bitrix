<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include.php");

$APPLICATION->IncludeComponent(
	"custom:basket",
	"basket",
	Array()
);
?>