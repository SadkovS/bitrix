<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();

use Bitrix\Main;
use Bitrix\Iblock;
use Bitrix\Main\ORM;
use	Custom\Core\Events\EventsCategoryTable;
use	Custom\Core\Events\EventsTable;

class Compilation extends CBitrixComponent
{
	public function onPrepareComponentParams($arParams)
	{
		$arParams["CATEGORY_IBLOCK_ID"] = 7;
		return $arParams;
	}
	
	public function get404()
	{
		Bitrix\Iblock\Component\Tools::process404(
	       'Страница не найдена',
	       true,
	       true,
	       true,
	       false
		);
	}
	
	public function setCategotyFilter($filter = null)
	{
        if($GLOBALS[$this->arParams["FILTER_NAME"]] && array_key_exists("PROPERTY_EVENT_ID", $GLOBALS[$this->arParams["FILTER_NAME"]]))
        {
            $filter["=ID"] = $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"];
        }

		$eventIds = [];

        $productEntity     = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $productPropField  = $productEntity->getField('EVENT_ID');
        $productPropEntity = $productPropField->getRefEntity();

        $propFieldClosed       = $productEntity->getField('IS_CLOSED_EVENT');
        $propFieldClosedEntity = $propFieldClosed->getRefEntity();

        $propFieldModeration       = $productEntity->getField('MODERATION');
        $propFieldModerationEntity = $propFieldModeration->getRefEntity();

        $filter = array_merge(
            $filter,
            [
                "=STATUS_REF.UF_XML_ID" => ["published"],
                "=ELEMENT.ACTIVE" => "Y",
                "=PROP_CLOSED_REF.VALUE" => null,
                "=PROP_MODERATION_REF.VALUE" => null,
                [
                    'LOGIC' => 'OR',
                    ['ELEMENT.ACTIVE_FROM' => false],
                    ['<=ELEMENT.ACTIVE_FROM' => date('d.m.Y H:i:s')]
                ],
                [
                    'LOGIC' => 'OR',
                    ['ELEMENT.ACTIVE_TO' => false],
                    ['>=ELEMENT.ACTIVE_TO' => date('d.m.Y H:i:s')]
                ],
            ]
        );

		$eventEntity = new \Bitrix\Main\ORM\Query\Query('Custom\Core\Events\EventsTable');
	    $query = $eventEntity
	        ->setSelect(
	            [
	                'ID',
	            ]
	        )
	        ->setFilter($filter)
            ->registerRuntimeField(
                'EVENT_REF',
                array(
                    'data_type' => $productPropEntity,
                    'reference' => array('=this.ID' => 'ref.VALUE'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'ELEMENT',
                array(
                    'data_type' => $productEntity,
                    'reference' => array('=this.EVENT_REF.IBLOCK_ELEMENT_ID' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'STATUS_REF',
                array(
                    'data_type' => '\Custom\Core\Events\EventsStatusTable',
                    'reference' => array('=this.UF_STATUS' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'PROP_CLOSED_REF',
                array(
                    'data_type' => $propFieldClosedEntity,
                    'reference' => array('=this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'PROP_MODERATION_REF',
                array(
                    'data_type' => $propFieldModerationEntity,
                    'reference' => array('=this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'),
                    'join_type' => 'LEFT'
                )
            )
	        ->exec();
	    
		while($obEvents = $query->fetch())
		{
			$eventIds[] = $obEvents["ID"];
		}

        if($eventIds)
        {
            global ${$this->arParams["FILTER_NAME"]};
            ${$this->arParams["FILTER_NAME"]}["PROPERTY_EVENT_ID"] = $eventIds;
        }
		else
        {
            if($_REQUEST["SMART_FILTER_PATH"])
            {
                global ${$this->arParams["FILTER_NAME"]};
                ${$this->arParams["FILTER_NAME"]}["PROPERTY_EVENT_ID"] = false;
            }
            else
            {
                $this->get404();
            }
        }
	}
	
	public function getCategotyFromIB($code)
	{
		$result = [];
		$filter = [];
		
		$res = \Bitrix\Iblock\Elements\ElementCompilationTable::getList(array(
		    'order' => array('SORT' => 'ASC'), 
		    'select' => array('NAME', 'CODE', 'DETAIL_PICTURE', 'EVENTS_' => 'EVENTS'), 
		    'filter' => array("CODE" => $code), 
		))->fetchAll();
		
		foreach ($res as $item) {
			if(!$result["NAME"])
			{
				$result = [
					"NAME" => $item["NAME"], 
					"CODE" => $item["CODE"], 
					"IMG" => \CFile::GetPath($item["DETAIL_PICTURE"])
				];
			}
			
			$filter["UF_XML_ID"][] = $item["EVENTS_VALUE"];
		}
		
		$this->setCategotyFilter($filter);
		
		return $result;
	}
	
	public function getCategoty()
	{
		$request = \Bitrix\Main\Context::getCurrent()->getRequest();
		$code = $request["compilation"];

		if($code)
		{
            global $APPLICATION;
            if(strpos($APPLICATION->GetCurPage(), COMPILATION_SPECIAL) !== false)
            {
                $category["NAME"] = COMPILATION_SPECIAL_NAME;

                global ${$this->arParams["FILTER_NAME"]};
                ${$this->arParams["FILTER_NAME"]}["!PROPERTY_EVENT_ID"] = false;

                return $category;
            }

			$eventEntity = new \Bitrix\Main\ORM\Query\Query('Custom\Core\Events\EventsCategoryTable');
		    $query = $eventEntity
		        ->setSelect(
		            [
		                '*',
		            ]
		        )
		        ->setFilter(['UF_CODE' => $code])
		        ->exec();
		    $category = $query->fetch();

			if($category)
			{
				$this->setCategotyFilter(['UF_CATEGORY' => $category["ID"]]);
				
				$category["IMG"] = \CFile::GetPath($category["UF_IMG"]);
				$category["NAME"] = $category["UF_NAME"];

				return $category;
			}
			else
			{
				$category = $this->getCategotyFromIB($code);
				
				if($category)
				{
					return $category;
				}
				else
				{
					$this->get404();
				}
			}
		}
		else
		{
			$this->get404();
		}
	}
	
	public function executeComponent()
	{
		$componentPage = "section";
		
		$this->arResult["CATEGORY"] = $this->getCategoty();
		
		$this->IncludeComponentTemplate($componentPage);
	}
	
	protected static function getSession(): ?Session
	{
		/** @var Session $session */
		$session = Application::getInstance()->getSession();
		if (!$session->isAccessible())
		{
			return null;
		}

		return $session;
	}

}
