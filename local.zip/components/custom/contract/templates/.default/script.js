$(document).ready(function () {
    let CHANGE_COUNTER = 0;

    function addLoader() {
        document.body.classList.add('loading')
    }

    function removeLoader() {
        document.body.classList.remove('loading')
    }
    function saveEventBody(resolve) {
        const that = this;
        const outsideBtn = this.closest('[data-tabs-titles="async"]') || this.hasAttribute('data-event-save-close');
        let container = outsideBtn ? $('#create-event .create-event__body:visible') : $(this).parents('.popup__content').find('.create-event__body:visible');
        let form = container.find('form');

        let url = form.attr('action');
        let formData = new FormData(form.get(0));

        //Если функция была инициирована с помощью табов
        if (that.classList.contains('create-event__title')) {
            formData.append('only-save', 'true');
        }

        addLoader();

        $.ajax({
            method: 'post',
            url: url,
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
        }).done(function (data) {
            CHANGE_COUNTER = 0;
            removeLoader();
            const formattedData = JSON.parse(data);

            //Показывает всплывашку, только если нажали на кнопку "Далее"
            if (that.classList.contains('btn-contract-next-step')) {
                showToast(formattedData);
            }

            if (formattedData.status == "success") {
                refreshOrg(that, "/admin_panel/organization/contract/add_contract.php");
                if (parseInt(getFormStep(url)) === 4) {
                    const parent = that.closest('.popup');
                    const selectType = parent.querySelector('[name="data[UF_CONTRACT_TYPE_CONFIRM]"]');
                    document.dispatchEvent(new CustomEvent('closePopup', {
                        bubbles: true, detail: {
                            popup: '#' + parent.id
                        }
                    }));
	                if (selectType && parseInt(selectType.value) === 68) {
		                $('.js-document-block').html(`
						<p class="text__large color__blue-three mb-3">Пожалуйста, подождите — ваш счет формируется</p>
						<div class="progress-bar js-progress-bar">
							<div class="progress-bar__num">0%</div>
							<div class="progress-bar__progress">
								<div class="progress-bar__progress-val"></div>
							</div>
						</div>
						`)
		                progressBarStart('.js-progress-bar', 10000, () => {
			                renewElement('.admin-body');
		                });
                    } else {
                        renewElement('.admin-body');
                    }

					$('.adminpanel-notification-line').remove()
                }
            }
        });
    }

    async function refreshOrg(that, url) {
        const response = await fetch(url)
        if (!response.ok) {
            console.error(response.statusText);
            return
            // throw new Error(response.statusText);
        }
        const data = await response.text();
        const html = new DOMParser().parseFromString(data, 'text/html');
        const dataPriceTable = html.querySelector('.create-event__content');
        const priceTable = $(that).parents('.create-event__content');
        if (dataPriceTable) {
            let active_index = $('[data-tabs-title].tab-active').index()
            if (that.classList.contains('btn-contract-next-step')) {
                active_index++;
                $('[data-tabs-title]').removeClass("tab-active")
                $('[data-tabs-title]').eq(active_index).addClass("tab-active")
            }

            priceTable.replaceWith(dataPriceTable);

            $('[data-tabs-item]').attr("hidden", "");
            $('[data-tabs-item]').eq(active_index).removeAttr("hidden");

        }

        formInit()
        rangeDatepickerInit()
        tabAllValidate(that.closest('.js-form-validate'))
    }

    //Добавил таймаут чтобы по приоритету сначала выполнялась валидация
    setTimeout(() => {
        $(document).on('click', '.btn-contract-next-step', function () {
            saveEventBody.call(this, null)
        });

        $(document).on('change', '[name="data[UF_TYPE]"]', function () {
            saveEventBody.call(this, null)
        });


    }, 0)

    function delFile() {
        let form = $(this).parents('form');
        let action = form.attr('action');
        let img = $(this).closest(".upload-ibg_contain").find("img");
        let input = $(this).closest(".upload").find("input[type='file']");

        action = action.split('?');
        action[1] = 'action=delFile&xml_id=' + $(input).attr("name");
        action = action.join('?');
        addLoader();

        $.ajax({
            method: 'post',
            url: action,
            processData: false,
            contentType: false,
            cache: false,
        }).done(function (data) {
            removeLoader();
            const formattedData = JSON.parse(data);
            showToast(formattedData);

            if (formattedData.status === 'success') {
                $(input).val("");
                $(img).remove();
            }
        });
    }

    $(document).on('mouseup', '[data-tabs-title]', function () {
        console.log($(".create-event__title.complete.tab-active").index())
        if (CHANGE_COUNTER === 1) {
            saveEventBody.call(this, null)
        }
    });

    $(document).on('.create-event__body input').on('input', function () {
        CHANGE_COUNTER = 1;
    })

    $(document).on('click', '._icon-trash2', function () {
        delFile.call(this, null);
    });

    function getFormStep(str) {
        const regex = /step=(\d+)/;
        const match = str.match(regex);
        return match ? match[1] : null;
    }
});


