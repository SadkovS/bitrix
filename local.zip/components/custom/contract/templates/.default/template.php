<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;

use Bitrix\Main\Application;
use Bitrix\Main\Page\Asset;
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");

?>
<?php
    $arSteps = [
        [
        'name'        => 'Форма ведения бизнеса',
        'description' => ''
        ],
        [
        'name'        => 'Данные организации',
        'description' => ''
        ],
        [
        'name'        => 'Банковские реквизиты',
        'description' => ''
        ],
        [
        'name'        => 'Способ подтверждения',
        'description' => ''
        ],
    ];

    $curStep = (int)$arResult['COMPANY']['UF_STEP'];
    ?>

<?if(empty($arParams["HIDE_MODAL"]) || $arParams["HIDE_MODAL"] != "Y"):?>
<div class="popup__content js-form-validate">
    <button type="button" class="popup__close profile__popup-close" data-close=""><i class="_icon-plus"></i></button>
    <div class="popup__name h1">Заключение договора</div>

    <div data-tabs="" class="create-event create-buisnes _tab-init" data-tabs-index="4">
        <nav data-tabs-titles="" class="create-event__navigation">
            <? foreach ($arSteps as $key => $step): ?>
            <? if (($curStep < 1 && $key == 0) || ($curStep == $key + 1)): ?>
            <button type="button" class="create-event__title  tab-active complete" data-tabs-title>
                <? elseif ($curStep > $key + 1): ?>
                <button type="button" class="create-event__title complete" data-tabs-title>
                    <? else: ?>
                    <button type="button" class="create-event__title" data-tabs-title>
                        <? endif; ?>
                        <span class="tab-body">
								<i class="tab-number"><?= ($key + 1) ?></i>
								<span class="tab-info">
									<p><?= $step['name'] ?></p>
									<?php if($step['description']):?>
										<small><?= $step['description'] ?></small>
									<?php endif;?>
								</span>
							</span>
                    </button>
                    <? endforeach; ?>
        </nav>

        <div data-tabs-body="" class="create-event__content">

            <div class="create-event__body" data-tabs-item="" <?if($curStep != 1) echo 'hidden=""';?>>
							<div class="grey__body grey__body--p1">
                <h2 class="h2 mb-3">Форма ведения бизнеса</h2>
                <form action="<?=$arParams["SEF_FOLDER"]?>?action=setContract&step=1" class="row gy-3 gx-3">
                    <div class="col-4">
                        <div class="form-item">
                            <label class="form-item__label">Выбор типа организации</label>
                            <div class="form-select js-form-select borderless">
                                <div class="form-select__selected-option js-form-select-option js-option-change" data-placeholder="Выберите из списка">
                                    <?if($arResult["COMPANY"]["UF_TYPE"]):?>
                                        <?=$arResult["HL_FIELDS_ENUM"]["UF_TYPE"][$arResult["COMPANY"]["UF_TYPE"]]["ENUM_VALUE"]?>
                                    <?else:?>
                                        <?=reset($arResult["HL_FIELDS_ENUM"]["UF_TYPE"])["ENUM_VALUE"]?>
                                    <?endif;?>
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <?foreach ($arResult["HL_FIELDS_ENUM"]["UF_TYPE"] as $item):?>
                                            <li class="form-select-options__item js-form-select-options-item" data-option="<?=$item["ENUM_ID"]?>">
                                                <?=$item["ENUM_VALUE"]?>
                                            </li>
                                        <?endforeach;?>
                                    </ul>
                                </div>
                                <?if($arResult["COMPANY"]["UF_TYPE"]):?>
                                    <input name="data[UF_TYPE]" type="hidden" value="<?=$arResult["COMPANY"]["UF_TYPE"]?>">
                                <?else:?>
                                    <input name="data[UF_TYPE]" type="hidden" value="<?=reset($arResult["HL_FIELDS_ENUM"]["UF_TYPE"])["ENUM_ID"]?>">
                                <?endif;?>
                            </div>
                        </div>
                    </div>
                </form>
							</div>
            </div>

            <div class="create-event__body" data-tabs-item="" <?if($curStep != 2) echo 'hidden=""';?>>
                <?if($arResult["COMPANY"]["UF_TYPE"] && $arResult["HL_FIELDS_ENUM"]["UF_TYPE"][$arResult["COMPANY"]["UF_TYPE"]]["ENUM_XML_ID"] == "legal"):?>
									<div class="grey__body grey__body--p1">
                    <h2 class="h2 mb-3">Данные организации</h2>
                    <form action="<?=$arParams["SEF_FOLDER"]?>?action=setContract&step=2" class="row gy-3 gx-3">

	                    <div class="col-3">
		                    <div class="form-item required">
			                    <label class="form-item__label">ИНН</label>
			                    <span class="form__error"></span>
			                    <select name="data[UF_INN]" type="text" class="form__underline-input js-dadata-inn" data-type="ur">
				                    <option value="<?=$arResult["COMPANY"]["UF_INN"]?>"><?=$arResult["COMPANY"]["UF_INN"]?></option>
			                    </select>
		                    </div>
	                    </div>

                        <div class="col-6">
                            <div class="form-item required">
                                <label class="form-item__label">ФИО</label>
                                <span class="form__error"></span>
                                <input name="data[UF_FIO]" type="text" maxlength="255" class="form__underline-input js-format-no-special" value="<?=$arResult["COMPANY"]["UF_FIO"]?>" placeholder="Фамилия Имя Отчество">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-item required">
                                <label class="form-item__label">E-mail</label>
                                <span class="form__error"></span>
                                <input name="data[UF_EMAIL]" type="email" class="form__underline-input" value="<?=$arResult["COMPANY"]["UF_EMAIL"]?>" placeholder="E-mail">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-item required">
                                <label class="form-item__label">Контактный номер телефона</label>
                                <span class="form__error"></span>
                                <input name="data[UF_PHONE]" type="tel" class="form__underline-input" value="<?=$arResult["COMPANY"]["UF_PHONE"]?>">
                            </div>
                        </div>



                        <div class="col-9">
                            <div class="form-item required disabled">
                                <label class="form-item__label">Полное название компании</label>
                                <span class="form__error"></span>
                                <input name="data[UF_FULL_NAME]" type="text" class="form__underline-input js-dadata-name" readonly value="<?=htmlspecialchars($arResult["COMPANY"]["UF_FULL_NAME"])?>">
                            </div>
                        </div>

                        <div class="col-3">
                            <div class="form-item required disabled">
                                <label class="form-item__label">КПП</label>
                                <span class="form__error"></span>
                                <input name="data[UF_KPP]" type="text" class="form__underline-input js-dadata-kpp" readonly value="<?=$arResult["COMPANY"]["UF_KPP"]?>">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-item required disabled">
                                <label class="form-item__label">ОГРН</label>
                                <span class="form__error"></span>
                                <input name="data[UF_OGRN]" type="text" class="form__underline-input js-dadata-orgn" readonly value="<?=$arResult["COMPANY"]["UF_OGRN"]?>">
                            </div>
                        </div>

												<div class="col-6">
													<div class="form-item required">
														<label class="form-item__label">Система налогообложения</label>
														<div class="form-select js-form-select borderless">
															<div class="form-select__selected-option js-form-select-option js-option-change" data-placeholder="Выберите из списка">
									<?if($arResult["COMPANY"]["UF_TAX_SYSTEM"]):?>
										<?=$arResult["HL_FIELDS_ENUM"]["UF_TAX_SYSTEM"][$arResult["COMPANY"]["UF_TAX_SYSTEM"]]["ENUM_VALUE"]?>
									<?else:?>
										<?=reset($arResult["HL_FIELDS_ENUM"]["UF_TAX_SYSTEM"])["ENUM_VALUE"]?>
									<?endif;?>
															</div>
															<i class="form-select__icon js-form-select-icon _icon-chev"></i>
															<div class="form-select-options-wrap js-form-select-options-wrap">
																<ul class="form-select-options form-select__options">
										<?foreach ($arResult["HL_FIELDS_ENUM"]["UF_TAX_SYSTEM"] as $item):?>
																			<li class="form-select-options__item js-form-select-options-item" data-option="<?=$item["ENUM_ID"]?>">
											<?=$item["ENUM_VALUE"]?>
																			</li>
										<?endforeach;?>
																</ul>
															</div>
									<?if($arResult["COMPANY"]["UF_TAX_SYSTEM"]):?>
																	<input name="data[UF_TAX_SYSTEM]" type="hidden" value="<?=$arResult["COMPANY"]["UF_TAX_SYSTEM"]?>">
									<?else:?>
																	<input name="data[UF_TAX_SYSTEM]" type="hidden" value="<?=reset($arResult["HL_FIELDS_ENUM"]["UF_TAX_SYSTEM"])["ENUM_ID"]?>">
									<?endif;?>
														</div>
													</div>
												</div>

                        <div class="col-6">
                            <div class="form-item required">
                                <label class="form-item__label">ФИО подписывающего лица</label>
                                <span class="form__error"></span>
                                <input name="data[UF_SIGNATORE_FIO]" type="text" class="form__underline-input js-format-no-special" value="<?=$arResult["COMPANY"]["UF_SIGNATORE_FIO"]?>" maxlength="256" placeholder="Фамилия Имя Отчество">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-item required">
                                <label class="form-item__label">Должность подписанта</label>
                                <span class="form__error"></span>
                                <input name="data[UF_SIGNATORE_POSITION]" type="text" class="form__underline-input js-format-no-special" value="<?=$arResult["COMPANY"]["UF_SIGNATORE_POSITION"]?>" maxlength="256">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-item required disabled">
                                <label class="form-item__label">Юридический адрес</label>
                                <span class="form__error"></span>
                                <input name="data[UF_REGISTRATION_ADDRESS]" type="text" readonly class="form__underline-input js-format-no-special js-dadata-address" value="<?=$arResult["COMPANY"]["UF_REGISTRATION_ADDRESS"]?>" maxlength="256">
                            </div>
                        </div>
                    </form>
									</div>
            <?endif;?>
            <?if($arResult["COMPANY"]["UF_TYPE"] && $arResult["HL_FIELDS_ENUM"]["UF_TYPE"][$arResult["COMPANY"]["UF_TYPE"]]["ENUM_XML_ID"] == "ip"):?>
									<div class="grey__body grey__body--p1">
                    <h2 class="h2 mb-3">Данные организации</h2>
                    <form action="<?=$arParams["SEF_FOLDER"]?>?action=setContract&step=2" class="row gy-3 gx-3">

	                    <div class="col-3">
		                    <div class="form-item required">
			                    <label class="form-item__label">ИНН</label>
			                    <span class="form__error"></span>
			                    <select name="data[UF_INN]" type="text" class="form__underline-input js-dadata-inn" data-type="ip">
				                    <option value="<?=$arResult["COMPANY"]["UF_INN"]?>"><?=$arResult["COMPANY"]["UF_INN"]?></option>
			                    </select>
		                    </div>
	                    </div>

                        <div class="col-6">
                            <div class="form-item required disabled">
                                <label class="form-item__label">ФИО</label>
                                <span class="form__error"></span>
                                <input name="data[UF_FIO]" readonly type="text" maxlength="255" class="form__underline-input js-format-no-special js-dadata-fio" value="<?=$arResult["COMPANY"]["UF_FIO"]?>" placeholder="Фамилия Имя Отчество" />
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-item required">
                                <label class="form-item__label">E-mail</label>
                                <span class="form__error"></span>
                                <input name="data[UF_EMAIL]" type="email" class="form__underline-input" value="<?=$arResult["COMPANY"]["UF_EMAIL"]?>" placeholder="E-mail" />
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-item required">
                                <label class="form-item__label">Контактный номер телефона</label>
                                <span class="form__error"></span>
                                <input name="data[UF_PHONE]" type="tel" class="form__underline-input" value="<?=$arResult["COMPANY"]["UF_PHONE"]?>" />
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="form-item required">
                                <label class="form-item__label">Серия и номер паспорта</label>
                                <span class="form__error"></span>
                                <input name="data[UF_PASSPORT_SERIES]" type="text" class="form__underline-input js-masked" data-mask="0000 000000" value="<?=$arResult["COMPANY"]["UF_PASSPORT_SERIES"]?>" />
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-item required">
                                <label class="form-item__label">Дата выдачи</label>
                                <span class="form__error"></span>
                                <input name="data[UF_PASSPORT_DATE]" type="text" placeholder="дд.мм.гггг" class="promo-date form__underline-input" data-date data-date-no-future data-formatted-date data-formatted-year="full" value="<?=$arResult["COMPANY"]["UF_PASSPORT_DATE"]?>" />
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-item required">
                                <label class="form-item__label">Кем выдан паспорт</label>
                                <span class="form__error"></span>
                                <input name="data[UF_PASSPORT_ISSUED]" type="text" class="form__underline-input js-format-passport-issued" value="<?=$arResult["COMPANY"]["UF_PASSPORT_ISSUED"]?>" />
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="form-item required">
                                <label class="form-item__label">Скан-копия разворота паспорта с фотографией </label>
                                <div class="upload upload-border upload__clean" data-img-upload>
                                    <input name="UF_FILE_PASPORT_1" type="file" class="upload__input" accept=".pdf, .jpg, .jpeg, .heic, .png" data-file-size="5">
                                    <div class="upload__icon upload-ibg_contain">
                                        <?if($arResult["COMPANY"]["UF_FILE_PASPORT_1"]):?>
                                            <img src="<?=$arResult["COMPANY"]["UF_FILE_PASPORT_1"]?>">
                                        <?endif;?>
                                        <button class="upload__delete" type="button">
                                            <i class="_icon-trash2"></i>
                                        </button>
                                        <i class="_icon-upload"></i>
                                    </div>
                                    <div class="upload__info">
																			<small>Максимальный размер файла - 5 МБ<br>
																				Поддерживаются форматы PDF, JPEG, JPG, HEIC и PNG<br>
																				Перетащите файл на рамку или нажмите для обзора
																			</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-item required">
                                <label class="form-item__label">Скан-копия разворота паспорта с регистрацией</label>
                                <div class="upload upload-border upload__clean" data-img-upload>
                                    <input name="UF_FILE_PASPORT_2" type="file" class="upload__input" accept=".pdf, .jpg, .jpeg, .heic, .png" data-file-size="5">
                                    <div class="upload__icon upload-ibg_contain">
                                        <?if($arResult["COMPANY"]["UF_FILE_PASPORT_2"]):?>
                                            <img src="<?=$arResult["COMPANY"]["UF_FILE_PASPORT_2"]?>">
                                        <?endif;?>
                                        <button class="upload__delete" type="button">
                                            <i class="_icon-trash2"></i>
                                        </button>
                                        <i class="_icon-upload"></i>
                                    </div>
                                    <div class="upload__info">
																			<small>Максимальный размер файла - 5 МБ<br>
																				Поддерживаются форматы PDF, JPEG, JPG, HEIC и PNG<br>
																				Перетащите файл на рамку или нажмите для обзора
																			</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-item required disabled">
                                <label class="form-item__label">Номер ОГРНИП</label>
                                <span class="form__error"></span>
                                <input name="data[UF_OGRNIP]" type="text" readonly="readonly" class="form__underline-input js-dadata-orgn" value="<?=$arResult["COMPANY"]["UF_OGRNIP"]?>" />
                            </div>
                        </div>
                        <div class="col-9">
                            <div class="form-item required">
                                <label class="form-item__label">Адрес регистрации</label>
                                <span class="form__error"></span>
                                <input name="data[UF_REGISTRATION_ADDRESS]" type="text" class="form__underline-input" value="<?=$arResult["COMPANY"]["UF_REGISTRATION_ADDRESS"]?>" />
                            </div>
                        </div>

                        <?/*
                        Этот блок убрали из дизайна
                        <div class="col-6">
                            <div class="form-item">
                                <label class="form-item__label">Скан-копия СНИЛС</label>
                                <div class="upload upload-border upload__clean" data-img-upload>
                                    <input name="UF_FILE_SNILS" type="file" class="upload__input" accept=".pdf, .xls, .xlsx, .xlsm, .csv, .jpg, .jpeg, .heic, .png" data-file-size="2">
                                    <div class="upload__icon upload-ibg_contain">
                                        <button class="upload__delete" type="button">
                                            <i class="_icon-trash2"></i>
                                        </button>
                                        <i class="_icon-upload"></i>
                                    </div>
                                    <div class="upload__info">
                                        <small>Рекомендуемый размер изображения — 512 х 512 пикселей <br>
                                            Поддерживаются форматы JPG и PNG <br>
                                            Перетащите файл на рамку или нажмите для обзора
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>*/?>
                    </form>
									</div>
            <?endif;?>
            <?if($arResult["COMPANY"]["UF_TYPE"] && $arResult["HL_FIELDS_ENUM"]["UF_TYPE"][$arResult["COMPANY"]["UF_TYPE"]]["ENUM_XML_ID"] == "person"):?>
							<div class="grey__body grey__body--p1">
                    <h2 class="h2 mb-3">Данные организации</h2>
                    <form action="<?=$arParams["SEF_FOLDER"]?>?action=setContract&step=2" class="row gy-3 gx-3">
                    <div class="col-6">
                    <div class="form-item required">
                    <label class="form-item__label">ФИО</label>
                    <span class="form__error"></span>
                    <input name="data[UF_FIO]" type="text" maxlength="255" class="form__underline-input js-format-no-special" value="<?=$arResult["COMPANY"]["UF_FIO"]?>" placeholder="Фамилия Имя Отчество" />
                    </div>
                    </div>
                    <div class="col-3">
                        <div class="form-item required">
                            <label class="form-item__label">E-mail</label>
                            <span class="form__error"></span>
                            <input name="data[UF_EMAIL]" type="email" class="form__underline-input" value="<?=$arResult["COMPANY"]["UF_EMAIL"]?>" placeholder="E-mail" />
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-item required">
                            <label class="form-item__label">Контактный номер телефона</label>
                            <span class="form__error"></span>
                            <input name="data[UF_PHONE]" type="tel" class="form__underline-input" value="<?=$arResult["COMPANY"]["UF_PHONE"]?>" />
                        </div>
                    </div>


										<div class="col-3">
											<div class="form-item required">
												<label class="form-item__label">Серия и номер паспорта</label>
												<span class="form__error"></span>
												<input name="data[UF_PASSPORT_SERIES]" type="text" class="form__underline-input js-masked" data-mask="0000 000000" value="<?=$arResult["COMPANY"]["UF_PASSPORT_SERIES"]?>" />
											</div>
										</div>

										<div class="col-3">
											<div class="form-item required">
												<label class="form-item__label">Дата выдачи</label>
												<span class="form__error"></span>
												<input name="data[UF_PASSPORT_DATE]" type="text" placeholder="дд.мм.гггг" class="promo-date form__underline-input" data-date data-date-no-future data-formatted-date data-formatted-year="full" value="<?=$arResult["COMPANY"]["UF_PASSPORT_DATE"]?>" />
											</div>
										</div>

                    <div class="col-6">
                        <div class="form-item required">
                            <label class="form-item__label">ИНН</label>
                            <span class="form__error"></span>
														<input name="data[UF_INN]" type="text" class="form__underline-input js-format-inn" value="<?=$arResult["COMPANY"]["UF_INN"]?>">
                        </div>
                    </div>


                    <div class="col-12">
                        <div class="form-item required">
                            <label class="form-item__label">Кем выдан паспорт</label>
                            <span class="form__error"></span>
                            <input name="data[UF_PASSPORT_ISSUED]" type="text" class="form__underline-input js-format-passport-issued" value="<?=$arResult["COMPANY"]["UF_PASSPORT_ISSUED"]?>" />
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-item required">
                            <label class="form-item__label">Скан-копия разворота паспорта с фотографией </label>
                            <div class="upload upload-border upload__clean" data-img-upload>
                                <input name="UF_FILE_PASPORT_1" type="file" class="upload__input" accept=".pdf, .jpg, .jpeg, .heic, .png" data-file-size="5">
                                <div class="upload__icon upload-ibg_contain">
                                    <?if($arResult["COMPANY"]["UF_FILE_PASPORT_1"]):?>
                                        <img src="<?=$arResult["COMPANY"]["UF_FILE_PASPORT_1"]?>">
                                    <?endif;?>
                                    <button class="upload__delete" type="button">
                                        <i class="_icon-trash2"></i>
                                    </button>
                                    <i class="_icon-upload"></i>
                                </div>
                                <div class="upload__info">
																	<small>Максимальный размер файла - 5 МБ<br>
																		Поддерживаются форматы PDF, JPEG, JPG, HEIC и PNG<br>
																		Перетащите файл на рамку или нажмите для обзора
																	</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-item required">
                            <label class="form-item__label">Скан-копия разворота паспорта с регистрацией</label>
                            <div class="upload upload-border upload__clean" data-img-upload>
                                <input name="UF_FILE_PASPORT_2" type="file" class="upload__input" accept=".pdf, .jpg, .jpeg, .heic, .png" data-file-size="5">
                                <div class="upload__icon upload-ibg_contain">
                                    <?if($arResult["COMPANY"]["UF_FILE_PASPORT_2"]):?>
                                        <img src="<?=$arResult["COMPANY"]["UF_FILE_PASPORT_2"]?>">
                                    <?endif;?>
                                    <button class="upload__delete" type="button">
                                        <i class="_icon-trash2"></i>
                                    </button>
                                    <i class="_icon-upload"></i>
                                </div>
                                <div class="upload__info">
																	<small>Максимальный размер файла - 5 МБ<br>
																		Поддерживаются форматы PDF, JPEG, JPG, HEIC и PNG<br>
																		Перетащите файл на рамку или нажмите для обзора
																	</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-item required">
                            <label class="form-item__label">Номер СНИЛС</label>
                            <span class="form__error"></span>
                            <input name="data[UF_SNILS]" type="text" class="form__underline-input js-masked" data-mask="000-000-000 00" value="<?=$arResult["COMPANY"]["UF_SNILS"]?>" />
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="form-item required">
                            <label class="form-item__label">Адрес регистрации</label>
                            <span class="form__error"></span>
                            <input name="data[UF_REGISTRATION_ADDRESS]" type="text" class="form__underline-input js-dadata-address" value="<?=$arResult["COMPANY"]["UF_REGISTRATION_ADDRESS"]?>" />
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-item required">
                            <label class="form-item__label">Скан-копия СНИЛС</label>
                            <div class="upload upload-border upload__clean" data-img-upload>
                                <input name="UF_FILE_SNILS" type="file" class="upload__input" accept=".pdf, .jpg, .jpeg, .heic, .png" data-file-size="5">
                                <div class="upload__icon upload-ibg_contain">
                                    <?if($arResult["COMPANY"]["UF_FILE_SNILS"]):?>
                                        <img src="<?=$arResult["COMPANY"]["UF_FILE_SNILS"]?>">
                                    <?endif;?>
                                    <button class="upload__delete" type="button">
                                        <i class="_icon-trash2"></i>
                                    </button>
                                    <i class="_icon-upload"></i>
                                </div>
                                <div class="upload__info">
																	<small>Максимальный размер файла - 5 МБ<br>
																		Поддерживаются форматы PDF, JPEG, JPG, HEIC и PNG<br>
																		Перетащите файл на рамку или нажмите для обзора
																	</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-item required">
                            <label class="form-item__label">Скан-копия заявления о регистрации Самозанятого</label>
                            <div class="upload upload-border upload__clean" data-img-upload>
                                <input name="UF_FILE_SELF_EMPLOYED" type="file" class="upload__input" accept=".pdf, .jpg, .jpeg, .heic, .png" data-file-size="5">
                                <div class="upload__icon upload-ibg_contain">
                                    <?if($arResult["COMPANY"]["UF_FILE_SELF_EMPLOYED"]):?>
                                        <img src="<?=$arResult["COMPANY"]["UF_FILE_SELF_EMPLOYED"]?>">
                                    <?endif;?>
                                    <button class="upload__delete" type="button">
                                        <i class="_icon-trash2"></i>
                                    </button>
                                    <i class="_icon-upload"></i>
                                </div>
                                <div class="upload__info">
																	<small>Максимальный размер файла - 5 МБ<br>
																		Поддерживаются форматы PDF, JPEG, JPG, HEIC и PNG<br>
																		Перетащите файл на рамку или нажмите для обзора
																	</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
							</div>
            <?endif;?>
            </div>
            <div class="create-event__body" data-tabs-item="" <?if($curStep != 3) echo 'hidden=""';?>>
							<div class="grey__body grey__body--p1">
                <h2 class="h2 mb-3">Банковские реквизиты</h2>
                <form action="<?=$arParams["SEF_FOLDER"]?>?action=setContract&step=3" class="row gy-3 gx-3">

										<div class="col-3">
											<div class="form-item required">
												<label class="form-item__label">БИК</label>
												<span class="form__error"></span>
												<select name="data[UF_BANK_BIK]" class="form__underline-input js-dadata-bik">
													<option value="<?=$arResult["COMPANY"]["UF_BANK_BIK"]?>"><?=$arResult["COMPANY"]["UF_BANK_BIK"]?></option>
												</select>
											</div>
										</div>
										<div class="col-3">
											<div class="form-item required disabled">
												<label class="form-item__label">Корреспондентский счёт</label>
												<span class="form__error"></span>
												<input name="data[UF_BANK_KORR]" type="text" maxlength="34" class="form__underline-input js-dadata-correspondent" readonly value="<?=$arResult["COMPANY"]["UF_BANK_KORR"]?>">
											</div>
										</div>
                    <div class="col-6">
                        <div class="form-item required disabled">
                            <label class="form-item__label">Полное наименование банка включая отделение</label>
                            <span class="form__error"></span>
                            <input name="data[UF_BANK_NAME]" type="text" class="form__underline-input js-dadata-bank-name" readonly value="<?=$arResult["COMPANY"]["UF_BANK_NAME"]?>">
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-item required">
                            <label class="form-item__label">Расчётный счёт</label>
                            <span class="form__error"></span>
                            <input name="data[UF_BANK_RS]" type="text" maxlength="34" class="form__underline-input js-validate-input-rs" value="<?=$arResult["COMPANY"]["UF_BANK_RS"]?>">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-item">
                            <label class="form-item__label">Комментарий для перевода денежных средств</label>
                            <span class="form__error"></span>
                            <input name="data[UF_BANK_COMMENT]" type="text" class="form__underline-input js-format-no-special" value="<?=$arResult["COMPANY"]["UF_BANK_COMMENT"]?>" maxlength="256">
                        </div>
                    </div>
                </form>
							</div>
            </div>
            <div class="create-event__body" data-tabs-item=""  <?if($curStep != 4) echo 'hidden=""';?>>
							<div class="grey__body grey__body--p1">
                <h2 class="h2 mb-3">Способ подтверждения</h2>
                <form action="<?=$arParams["SEF_FOLDER"]?>?action=setContract&step=4" class="row gy-2 gx-3 js-select-show-hide-wrap">
                    <div class="col-4">
                        <div class="form-item">
                            <label class="form-item__label">Выбор способа подтверждения</label>
                            <div class="form-select js-form-select borderless js-select-show-hide">
                                <div class="form-select__selected-option js-form-select-option js-option-change" data-placeholder="Выберите из списка">
                                    <?if($arResult["COMPANY"]["UF_CONTRACT_TYPE_CONFIRM"]):?>
                                        <?=$arResult["HL_FIELDS_ENUM"]["UF_CONTRACT_TYPE_CONFIRM"][$arResult["COMPANY"]["UF_CONTRACT_TYPE_CONFIRM"]]["ENUM_VALUE"]?>
                                    <?else:?>
                                        <?=reset($arResult["HL_FIELDS_ENUM"]["UF_CONTRACT_TYPE_CONFIRM"])["ENUM_VALUE"]?>
                                    <?endif;?>
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <?foreach ($arResult["HL_FIELDS_ENUM"]["UF_CONTRACT_TYPE_CONFIRM"] as $item):?>
                                            <li class="form-select-options__item js-form-select-options-item" data-option="<?=$item["ENUM_ID"]?>">
                                                <?=$item["ENUM_VALUE"]?>
                                            </li>
                                        <?endforeach;?>
                                    </ul>
                                </div>
                                <?if($arResult["COMPANY"]["UF_CONTRACT_TYPE_CONFIRM"]):?>
                                    <input name="data[UF_CONTRACT_TYPE_CONFIRM]" type="hidden" value="<?=$arResult["COMPANY"]["UF_CONTRACT_TYPE_CONFIRM"]?>">
                                <?else:?>
                                    <input name="data[UF_CONTRACT_TYPE_CONFIRM]" type="hidden" value="<?=reset($arResult["HL_FIELDS_ENUM"]["UF_CONTRACT_TYPE_CONFIRM"])["ENUM_ID"]?>">
                                <?endif;?>
                            </div>
                        </div>
                    </div>
                    <div class="col-12"></div>
                    <div class="col-6 js-select-show-hide-block" data-show-id="68">
                        <div class="mb-1 requisit__item">
                            <a class="color__blue" href="/documents/org_license_agreement.pdf" target="_blank">
                                Ознакомиться с договором
                            </a>
                        </div>
                    </div>
                    <div class="col-6 js-select-show-hide-block" data-show-id="69">
                        <div class="mb-1 requisit__item">
                            <a class="color__blue" href="/documents/org_license_agreement.pdf" target="_blank">
                                Ознакомиться с договором
                            </a>
                        </div>
                        <div class="mb-1 requisit__item">

                            <div>
                                <small>
                                    <a class="color__blue" href="/documents/statement_of_acceptance_org_license_agreement.docx?v=1" target="_blank">
                                        Шаблон документа
                                    </a>
                                    необходимо распечатать, подписать и принести по адресу:<br>г. Москва, улица Верейская, дом 29, строение 33
                                </small>
                            </div>
                        </div>
                    </div>
                </form>
							</div>
            </div>
        </div>
    </div>
    <div class="event-create__navigation">
        <button type="submit" class="btn btn__blue btn__big btn-contract-next-step js-form-validate-btn">
            Дальше
        </button>
    </div>
</div>
<?endif;?>