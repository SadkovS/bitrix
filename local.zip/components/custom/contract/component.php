<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use \Bitrix\Main\Localization\Loc;
use \Custom\Core\Contract as Contract;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest()->toArray();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
$stepCount = 4;

$noReqFields = ["UF_BANK_COMMENT"];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('catalog') ||
    !Loader::IncludeModule("iblock")
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    if(!$request['action'])
    {


        $query = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany   = $query
            ->setFilter(['ID' => $companyID])
            ->setSelect([
                '*',
            ])
            ->setLimit(1)
            ->exec();
        if($company = $resCompany->fetch())
        {
            if($company["UF_STEP"] && $stepCount != $company["UF_STEP"])
                $company["UF_STEP"] ++;
            else
                $company["UF_STEP"] = 1;

            foreach ($company as $propKey => &$value)
            {
                if($value && strpos($propKey, "FILE") !== false)
                {
                    $buf = json_decode($value, true);

                    if($buf["path"])
                        $value = str_replace($_SERVER["DOCUMENT_ROOT"], "", $buf["path"]);
                }
            }

            $arResult["COMPANY"] = $company;

            $arFields = Contract::getHLfilelds(Contract::HLNAME_ORGANIZATION);
            $arResult["HL_FIELDS_ENUM"] = $arFields;

            //echo "<pre>"; print_r($company); echo "</pre>";
        }


    }

    if (
        isset($request['action']) &&
        isset($request['xml_id']) &&
        $request['action'] == 'delFile'
    )
    {
        if($companyID)
        {
            \Custom\Core\Users\CompaniesTable::update(
                $companyID,
                [
                    $request['xml_id'] => null,
                    "UF_STEP" => 1,
                ]
            );

            echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
            die();
        }
    }

    if (
        isset($request['action']) &&
        $request['action'] == 'setContract'
    )
    {
        $APPLICATION->RestartBuffer();

        if($companyID)
        {
            $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_ORGANIZATION_ID"])->fetch();
            $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
            $hlbClass = $entity->getDataClass();

            $arData = $request['data'];

            /*if($arData["UF_INN"])
            {
                $obCheckINN = $hlbClass::getList([
                    "filter" => [
                        "!ID" => $companyID,
                        "UF_INN" => $arData["UF_INN"],
                    ],
                    "select" => ["ID"]
                ]);

                if($obCheckINN->fetch())
                {
                    throw new Exception('Договор для ИНН '.$arData["UF_INN"].' уже существует');
                }
            }*/

            $obCompany = $hlbClass::getList([
                "filter" => [
                    "ID" => $companyID
                ],
                "select" => [
                    "UF_FILE_PASPORT_1",
                    "UF_FILE_PASPORT_2",
                    "UF_FILE_SNILS",
                    "UF_FILE_SELF_EMPLOYED",
                    "ORGANIZER_TYPE_XML_ID"    => "COMPANY_TYPE_REF.XML_ID",
                ],
                "runtime" => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'COMPANY_TYPE_REF',
                        '\Custom\Core\FieldEnumTable',
                        ['=this.UF_TYPE' => 'ref.ID'],
                        ['join_type' => 'LEFT']
                    ),
                ]
            ]);

            $arCompany = $obCompany->fetch();

            if($_FILES)
            {
                $Questionnaires = new \Custom\Core\Questionnaires();
                $includeSystem = $Questionnaires->extensions;
                $maxSize = $Questionnaires->fileSize;

                foreach ($_FILES as $fileKey => $fileArray)
                {
                    if (is_array($fileArray) && !$fileArray["tmp_name"] && !$arCompany[$fileKey]) {
                        throw new Exception('Прикрепите необходимые файлы');
                    }

                    if (
                        $fileArray["tmp_name"] &&
                        (
                            !in_array(strtolower(pathinfo($fileArray["name"], PATHINFO_EXTENSION)), $includeSystem)
                            || $fileArray["size"] > $maxSize
                        )
                    ) {
                        throw new \Exception("Загрузка файла {$fileArray["name"]} запрещена.");
                    }
                }

                foreach ($_FILES as $fileKey => $fileArray)
                {
                    if(is_array($fileArray) && $fileArray["tmp_name"])
                    {
                        $tmpDirName = time();
                        $tmpDir = mkdir($_SERVER['DOCUMENT_ROOT'] . '/upload/tmp/docs/' . $tmpDirName, 0777, true);
                        $newFilePath = $_SERVER['DOCUMENT_ROOT'] . '/upload/tmp/docs/' . $tmpDirName . '/' . $fileArray['name'];

                        if (move_uploaded_file($fileArray['tmp_name'], $newFilePath)) {
                            $arData[$fileKey] = json_encode(
                                [
                                    "name" => $fileArray['name'],
                                    "path" => $newFilePath
                                ],
                                JSON_UNESCAPED_UNICODE
                            );
                        } else {
                            throw new Exception('Ошибка загрузки файла');
                        }
                    }
                }
            }

            foreach ($arData as $keyD => $val)
            {
                if(!$val && !in_array($keyD, $noReqFields))
                {
                    throw new Exception('Заполните обязательные поля');
                }
            }

            if($arCompany["ORGANIZER_TYPE_XML_ID"] == "ip" && $arData["UF_FIO"])
            {
                $arData["UF_FULL_NAME"] = 'ИП '.$arData["UF_FIO"];
            }

            if($request['step'])
                $arData["UF_STEP"] = $request['step'];

            $resUpdate = $hlbClass::update($companyID, $arData);
            if (!$resUpdate->isSuccess())
            {
                echo json_encode(['status' => 'error', 'message' => str_replace("<br>", "\n", implode(', ', $resUpdate->getErrors()))], JSON_UNESCAPED_UNICODE);
            }

            if($stepCount == $request['step'] && $request['only-save'] !== 'true')
            {
                Contract::sendContractB24($companyID);
                echo json_encode(['status' => 'success', 'close' => 'true', 'message' => 'Договор отправлен на проверку'], JSON_UNESCAPED_UNICODE);
                die();
            }
            echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
            die();
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_NO_COMPANY_FOR_USER")], JSON_UNESCAPED_UNICODE);
            die;
        }
    }

    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}



?>