<?
$MESS ['HLB_EVENTS_NAME'] = "События";
$MESS ['HLB_EVENTS_DESCRIPTION'] = "Раздел событий";
$MESS ['HLB_EVENTS_DESC'] = "События";
?>