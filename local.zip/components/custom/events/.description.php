<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("HLB_EVENTS_NAME"),
	"DESCRIPTION" => GetMessage("HLB_EVENTS_DESCRIPTION"),
	"COMPLEX" => "Y",
	"PATH" => array(
        "ID" => "custom",
		"CHILD" => array(
			"ID" => "events",
			"NAME" => GetMessage("HLB_EVENTS_DESC"),
			"SORT" => 10,
			"CHILD" => array(
				"ID" => "events_cmpx",
			),
		),
	),
);

?>