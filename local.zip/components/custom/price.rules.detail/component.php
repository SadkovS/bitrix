<?

if ( ! defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
	die();
}
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Custom\Core\PriceRules;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();

if ( ! Loader::includeModule("highloadblock") || ! Loader::includeModule('custom.core') || ! Loader::includeModule(
		'catalog'
	) || ! Loader::includeModule('sale') || ! Loader::includeModule('iblock')) {
	ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
	
	return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if ( ! isset($arParams["CACHE_TIME"])) {
	$arParams["CACHE_TIME"] = 180;
}


if ((int)$arParams['EVENT_ID'] < 1 || (int)$arParams['EVENT_ID'] < 1) {
	$this->AbortResultCache();
	ShowError(GetMessage("WRONG_COMPONENT_PARAMS"));
	
	return;
}


try {
	if (empty($arParams['ACTION'])) {
		throw new Exception('Не задан обязательный параметр action');
	}
	
	$eventId = (int)$arParams['EVENT_ID'];
	$itemId  = (int)$arParams['ELEMENT_ID'];
	
	// проверим имеет ли пользователь доступ к меорприятию
	$eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
	$eventClass  = $eventEntity->getEntity()->getDataClass();
	$query       = $eventEntity->setSelect(['ID', 'UF_CREATED_BY'])->setFilter(
		['ID' => $eventId/*, 'UF_CREATED_BY' => $USER->GetID()*/]
	)->countTotal(true)->exec();
	if ($query->getCount() < 1) {
		throw new \Exception('Event not found');
	}
	
	
	if (isset($arParams['ACTION']) && $arParams['ACTION'] == 'getFormGroup') {

		$arTypes = [];
		foreach ($arParams['EVENT_TYPES'] as $type) {
			$type["SKU_CONCAT_TYPE_PRICE"] = $type["SKU_TYPE"].". ".\Custom\Core\Helper::priceFormat($type["SKU_PRICE"]);
			$arTypes[$type['SKU_ID']] = $type;
		}

		$arParams['EVENT_TYPES'] = $arTypes;
		unset($arTypes);
		
		$arResult['DISCOUNT_TYPES'] = \Custom\Core\Helper::getDiscountTypes();
		
		if ((int)$arParams['ELEMENT_ID'] > 0) {
			$arResult['ACTION'] = 'editGroup';
			
			$filter           = [
				'ID'                  => $itemId,
				'REF_EVENTS_ID.VALUE' => $eventId,
				'UF_TYPE'             => PRICE_RULE_TYPE_GROUP,
			];
			$arResult['ITEM'] = getPriceRuleGroup($filter);
		} else {
			$arResult['ACTION'] = 'addGroup';
		}
		
		$this->IncludeComponentTemplate();
	}
	
	if (isset($arParams['ACTION']) && ($arParams['ACTION'] == 'editGroup' || $arParams['ACTION'] == 'addGroup')) {
		$APPLICATION->RestartBuffer();
		
		$hlblockPriceRules  = HL\HighloadBlockTable::getById(HL_PRICE_RULES_ID)->fetch();
		$entityPriceRules   = HL\HighloadBlockTable::compileEntity($hlblockPriceRules);
		$hlbClassPriceRules = $entityPriceRules->getDataClass();
		
		$hlblockPromoCodes  = HL\HighloadBlockTable::getById(HL_PROMOCODES_ID)->fetch();
		$entityPromoCodes   = HL\HighloadBlockTable::compileEntity($hlblockPromoCodes);
		$hlbClassPromoCodes = $entityPromoCodes->getDataClass();
		
		$elementId                = (int)$arParams['ELEMENT_ID'];
		$needCreatePromoCodeCount = (int)($request->get('PROMOCODE_COUNTS') ?: 0);
		
		if ($needCreatePromoCodeCount > 5000) {
			throw new \Exception('Количество промокодов не может быть больше 5000');
		}
		
		if (isset($request['UF_DISCOUNT'])) {
			
			if ((float)$request['UF_DISCOUNT'] <= 0) {
				throw new \Exception('Поле «Размер скидки» должно быть больше 0');
			}
			
			// не более 100%
			if (!isset($request['UF_DISCOUNT_TYPE']) && (float)$request['UF_DISCOUNT'] > 100) {
				throw new \Exception('Поле «Размер скидки» не должно быть больше 100%');
			}
			
			if (!isset($request['PROMOCODE_COUNTS'])) {
				throw new \Exception('Не задано требуемое количество промокодов');
			} else {
				if ((int)$request['PROMOCODE_COUNTS'] < 1) {
					throw new \Exception('Количество не может быть меньше 1');
				}
			}
			
		} else {
			throw new \Exception('Поле «Размер скидки» обязательно для заполнения');
		}
		
		if (isset($request['UF_DATE_START']) && $request['UF_DATE_START'] && ! preg_match(
				'/^[0-3][0-9]\.[0-1][0-9]\.[0-9][0-9]$/',
				$request->get('UF_DATE_START')
			)) {
			throw new \Exception('Дата начала указана некорректно');
		}
		
		if (isset($request['UF_DATE_END']) && $request['UF_DATE_END']&& ! preg_match(
				'/^[0-3][0-9]\.[0-1][0-9]\.[0-9][0-9]$/',
				$request->get('UF_DATE_END')
			)) {
			throw new \Exception('Дата окончания указана некорректно');
		}
		
		if (isset($request['UF_DATE_START']) && $request['UF_DATE_START'] && isset($request['UF_DATE_END']) && $request['UF_DATE_END']) {
			$start = DateTime::createFromFormat('d.m.y', $request->get('UF_DATE_START'));
			$end   = DateTime::createFromFormat('d.m.y', $request->get('UF_DATE_END'));
			
			if ($start->getTimestamp() >= $end->getTimestamp()) {
				throw new \Exception('Срок действия укзан некорректно!');
			}
		}
		
		if(!$request['UF_TYPE_APPLY'])
		{
			throw new \Exception('Поле «Вид применения» обязательно для заполнения');
		}
		
		if (isset($request['UF_TYPE_APPLY']) && $request['UF_TYPE_APPLY'] === 'range') {			
			if (isset($request['UF_TYPE_APPLY_MIN']) && !is_numeric($request['UF_TYPE_APPLY_MIN']) && isset($request['UF_TYPE_APPLY_MAX']) && !is_numeric($request['UF_TYPE_APPLY_MAX'])) {
				throw new \Exception('Поле «Вид применения» обязательно для заполнения');
			} else {
				if (isset($request['UF_TYPE_APPLY_MIN']) && is_numeric($request['UF_TYPE_APPLY_MIN']) && (int)$request['UF_TYPE_APPLY_MIN'] < 1) {
					throw new \Exception('Минимальное значение "Вида применения" не может быть меньше 1');
				}
				
				if (isset($request['UF_TYPE_APPLY_MAX']) && is_numeric($request['UF_TYPE_APPLY_MAX']) && (int)$request['UF_TYPE_APPLY_MAX'] < 1) {
					throw new \Exception('Максимальное значение "Вида применения" не может быть меньше 1');
				}
				
				if (isset($request['UF_TYPE_APPLY_MIN']) && isset($request['UF_TYPE_APPLY_MAX']) && is_numeric($request['UF_TYPE_APPLY_MIN']) && is_numeric($request['UF_TYPE_APPLY_MAX']) && (int)$request['UF_TYPE_APPLY_MIN'] > (int)$request['UF_TYPE_APPLY_MAX']) {
					throw new \Exception('Минимальное значение "Вида применения" не может быть больше максимального');
				}
			}
		}
		
		
		if ($arParams['ACTION'] == 'editGroup' && $itemId > 0) { // update
			
			if (!$request->get('UF_NAME')) {
				throw new \Exception('Поле «Название группы» обязательно для заполнения');
			}
			
			if (!$request->get('UF_TICKETS_TYPE')) {
				throw new \Exception('Поле «Категории билетов» обязательно для заполнения');
			}
			
			$obElementPriceRule = getPriceRule($itemId, $eventId, PRICE_RULE_TYPE_GROUP);
			if (PriceRules::isPriceRuleNameUnique(
				$request->get('UF_NAME'),
				$eventId,
				$obElementPriceRule->get('UF_XML_ID')
			)) {
				throw new \Exception('Группа с именем «' . $request->get('UF_NAME') . '» уже существует');
			}
			
			$obElementPromoCodes     = $hlbClassPromoCodes::getList(
				[
					'select' => ['UF_CODE'],
					'filter' => [
						'UF_RULE_ID' => $obElementPriceRule->getId(),
					],
				]
			);
			$alreadyCreatedPromoCode = $obElementPromoCodes->fetchAll();
			
			if (isset($request['UF_TYPE_APPLY']) && in_array($request->get('UF_TYPE_APPLY'), ['all', 'range'])) {
				if ($request->get('UF_TYPE_APPLY') === 'all') {
					$obElementPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', 1);
					$obElementPriceRule->set('UF_TYPE_APPLY_MIN', null);
					$obElementPriceRule->set('UF_TYPE_APPLY_MAX', null);
				} else {
					$obElementPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', 0);
					$obElementPriceRule->set('UF_TYPE_APPLY_MIN', (isset($request['UF_TYPE_APPLY_MIN']) && is_numeric($request->get('UF_TYPE_APPLY_MIN'))) ? (int)$request->get('UF_TYPE_APPLY_MIN') : null);
					$obElementPriceRule->set('UF_TYPE_APPLY_MAX', (isset($request['UF_TYPE_APPLY_MAX']) && is_numeric($request->get('UF_TYPE_APPLY_MAX'))) ? (int)$request->get('UF_TYPE_APPLY_MAX') : null);
				}
			} else {
				$obElementPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', null);
				$obElementPriceRule->set('UF_TYPE_APPLY_MIN', null);
				$obElementPriceRule->set('UF_TYPE_APPLY_MAX', null);
			}
			
			$obElementPriceRule->set('UF_NAME', $request->get('UF_NAME'));
			$obElementPriceRule->set(
				'UF_DISCOUNT_TYPE',
				$request->get('UF_DISCOUNT_TYPE') ? DISCOUNT_TYPE_RUB : DISCOUNT_TYPE_PERCENT
			);
			$obElementPriceRule->set('UF_DISCOUNT', (float)$request->get('UF_DISCOUNT'));
			$obElementPriceRule->set(
				'UF_DATE_START',
				isset($request['UF_DATE_START']) && $request['UF_DATE_START'] ? DateTime::createFromFormat(
					'd.m.y',
					$request->get('UF_DATE_START')
				)->setTime(0, 0)->format('d.m.Y H:i:s') : null
			);
			$obElementPriceRule->set(
				'UF_DATE_END',
				isset($request['UF_DATE_END']) && $request['UF_DATE_END'] ? DateTime::createFromFormat(
					'd.m.y',
					$request->get('UF_DATE_END')
				)->setTime(0, 0)->format('d.m.Y H:i:s') : null
			);
			$obElementPriceRule->set('UF_MIN_COUNT_TICKETS', null);
			$obElementPriceRule->set('UF_TYPE', PRICE_RULE_TYPE_GROUP);
			
			$obElementPriceRule->set('UF_IS_SUM', isset($request['UF_IS_SUM']) && $request['UF_IS_SUM'] ? 1 : 0);

			$obElementPriceRule->set('UF_FOR_EACH_TICKET', isset($request['UF_FOR_EACH_TICKET']) && $request['UF_FOR_EACH_TICKET'] ? 1 : 0);
			
			if (isset($request['UF_TICKETS_TYPE']) && is_array($request->get('UF_TICKETS_TYPE')) && in_array('all', $request->get('UF_TICKETS_TYPE'))) {
				$obElementPriceRule->set('UF_TICKETS_TYPE', []);
				$obElementPriceRule->set('UF_FOR_ALL_TYPES', 1);
			} else {
				$obElementPriceRule->set('UF_TICKETS_TYPE', $request->get('UF_TICKETS_TYPE'));
				$obElementPriceRule->set('UF_FOR_ALL_TYPES', 0);
			}
			
			$resUpdate = $obElementPriceRule->save();
			
			if ( ! $resUpdate->isSuccess()) {
				throw new \Exception(implode(', ', $resUpdate->getErrors()));
			}
			
			$countPromoCode = createPromoCodes(
				$obElementPriceRule->getId(),
				$needCreatePromoCodeCount,
				$hlbClassPromoCodes,
				array_map(function ($item) {
					return $item['UF_CODE'];
				}, $alreadyCreatedPromoCode ?? []),
			);
			
			$obElementPriceRule->set('UF_MAX_NUMBER_OF_USES', $countPromoCode);
			$resUpdate = $obElementPriceRule->save();
			
			if ( ! $resUpdate->isSuccess()) {
				throw new \Exception(implode(', ', $resUpdate->getErrors()));
			}
		} else { // create
			
			if (!$request->get('UF_NAME')) {
				throw new \Exception('Поле «Название группы» обязательно для заполнения');
			}
			
			if (!$request->get('UF_TICKETS_TYPE')) {
				throw new \Exception('Поле «Категории билетов» обязательно для заполнения');
			}
			
			if (PriceRules::isPriceRuleNameUnique(
				$request->get('UF_NAME'),
				$eventId,
			)) {
				throw new \Exception('Группа с именем «' . $request->get('UF_NAME') . '» уже существует');
			}
			
			$objPriceRule = $hlbClassPriceRules::createObject();
			$uuid         = \Custom\Core\UUID::uuid4();
			
			$dateStart = $request->get('UF_DATE_START') ? DateTime::createFromFormat(
				'd.m.y',
				$request->get('UF_DATE_START')
			)->setTime(0, 0)->format('d.m.Y H:i:s') : null;
			
			$dateEnd = $request->get('UF_DATE_END') ? DateTime::createFromFormat(
				'd.m.y',
				$request->get('UF_DATE_END')
			)->setTime(0, 0)->format('d.m.Y H:i:s') : null;
			
			$objPriceRule->set('UF_XML_ID', $uuid);
			$objPriceRule->set('UF_EVENT_ID', $eventId);
			
			
			if (isset($request['UF_TYPE_APPLY']) && in_array($request['UF_TYPE_APPLY'], ['all', 'range'])) {
				if ($request['UF_TYPE_APPLY'] === 'all') {
					$objPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', 1);
					$objPriceRule->set('UF_TYPE_APPLY_MIN', null);
					$objPriceRule->set('UF_TYPE_APPLY_MAX', null);
				} else {
					$objPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', 0);
					$objPriceRule->set('UF_TYPE_APPLY_MIN', isset($request['UF_TYPE_APPLY_MIN']) && is_numeric($request['UF_TYPE_APPLY_MIN']) ? (int)$request['UF_TYPE_APPLY_MIN'] : null);
					$objPriceRule->set('UF_TYPE_APPLY_MAX', isset($request['UF_TYPE_APPLY_MAX']) && is_numeric($request['UF_TYPE_APPLY_MAX']) ? (int)$request['UF_TYPE_APPLY_MAX'] : null);
				}
			} else {
				$objPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', null);
				$objPriceRule->set('UF_TYPE_APPLY_MIN', null);
				$objPriceRule->set('UF_TYPE_APPLY_MAX', null);
			}
			
			$objPriceRule->set('UF_NAME', $request->get('UF_NAME'));
			$objPriceRule->set(
				'UF_DISCOUNT_TYPE',
				$request->get('UF_DISCOUNT_TYPE') ? DISCOUNT_TYPE_RUB : DISCOUNT_TYPE_PERCENT
			);
			$objPriceRule->set('UF_DISCOUNT', (float)$request->get('UF_DISCOUNT'));
			
			$objPriceRule->set('UF_DATE_START', $dateStart);
			$objPriceRule->set('UF_DATE_END', $dateEnd);
			$objPriceRule->set('UF_MIN_COUNT_TICKETS', null);
			$objPriceRule->set('UF_NUMBER_OF_USES', 0);
			$objPriceRule->set('UF_MAX_NUMBER_OF_USES', 0);
			$objPriceRule->set('UF_TYPE', PRICE_RULE_TYPE_GROUP);
			$objPriceRule->set('UF_IS_SUM', isset($request['UF_IS_SUM']) && $request['UF_IS_SUM'] ? 1 : 0);
			$objPriceRule->set('UF_FOR_EACH_TICKET', isset($request['UF_FOR_EACH_TICKET']) && $request['UF_FOR_EACH_TICKET'] ? 1 : 0);
			$objPriceRule->set('UF_IS_ACTIVITY', 1);
			
			if (is_array($request->get('UF_TICKETS_TYPE')) && in_array('all', $request->get('UF_TICKETS_TYPE'))) {
				$objPriceRule->set('UF_TICKETS_TYPE', []);
				$objPriceRule->set('UF_FOR_ALL_TYPES', 1);
			} else {
				$objPriceRule->set('UF_TICKETS_TYPE', $request->get('UF_TICKETS_TYPE'));
				$objPriceRule->set('UF_FOR_ALL_TYPES', 0);
			}
			
			$resAdd = $objPriceRule->save();
			
			if ($resAdd->isSuccess()) {
				$priceRuleId = $resAdd->getId();
				
				$countPromoCode = createPromoCodes(
					$priceRuleId,
					$needCreatePromoCodeCount,
					$hlbClassPromoCodes
				);
				
				$objPriceRule->set('UF_MAX_NUMBER_OF_USES', $countPromoCode);
				$resUpdate = $objPriceRule->save();
				
				if ( ! $resUpdate->isSuccess()) {
					throw new \Exception(implode(', ', $resUpdate->getErrors()));
				}
			} else {
				throw new \Exception(implode(', ', $resAdd->getErrors()));
			}
		}
		
		
		echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
		die;
	}
	
	
	if (isset($arParams['ACTION']) && $arParams['ACTION'] == 'deletePromoCodeFromGroup') {
		if ( ! (isset($request['ID']) && is_string($request['ID']) && strlen($request['ID']) === 36)) {
			throw new Exception('Wrong param ID');
		}
		$promoCodeEntity = new ORM\Query\Query('Custom\Core\Events\PromoCodesTable');
		$query           = $promoCodeEntity->setSelect(['*'])->setFilter(['UF_XML_ID' => $request['ID']])->setLimit(
			1
		)->exec();
		
		if ($objPromoCode = $query->fetchObject()) {
			$obElementPriceRule = getPriceRule($objPromoCode->get('UF_RULE_ID'), $eventId, PRICE_RULE_TYPE_GROUP);
			
			$newMaxNumberOfUse = max($obElementPriceRule->get('UF_MAX_NUMBER_OF_USES') - 1, 0);
			$obElementPriceRule->set('UF_MAX_NUMBER_OF_USES', $newMaxNumberOfUse);
			$resUpdate = $obElementPriceRule->save();
			
			if ( ! $resUpdate->isSuccess()) {
				throw new \Exception(implode(', ', $resUpdate->getErrors()));
			}
			
			$objPromoCode->delete();
		} else {
			throw new Exception('Промокод не найден');
		}
		
		echo json_encode(['status' => 'success', 'payload' => $newMaxNumberOfUse], JSON_UNESCAPED_UNICODE);
		die;
	}
	
	if (isset($arParams['ACTION']) && $arParams['ACTION'] == 'getStats') {
		$APPLICATION->RestartBuffer();
		require_once __DIR__ . '/export_excel.php';
		exit;
	}
	
	if (isset($arParams['ACTION']) && $arParams['ACTION'] == 'setActivity') {
		$obElementPriceRule = getPriceRule($itemId, $eventId);
		
		$currentState = ! $obElementPriceRule->get('UF_IS_ACTIVITY');
		$obElementPriceRule->set('UF_IS_ACTIVITY', $currentState);
		
		$resUpdate = $obElementPriceRule->save();
		
		if ( ! $resUpdate->isSuccess()) {
			throw new \Exception(implode(', ', $resUpdate->getErrors()));
		}
		
		echo json_encode(['status' => 'success', 'payload' => $currentState], JSON_UNESCAPED_UNICODE);
		die;
	}
} catch (\Exception $e) {
	$APPLICATION->RestartBuffer();
	// header("Content-type: application/json; charset=utf-8");
	echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
	die;
}


/**
 * @param array $filter
 *
 * @return array
 * @throws Exception
 */
function getPriceRuleGroup(array $filter)
{
	$res              = null;
	$priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');
	
	$query = $priceRulesEntity->setSelect([
		                                      '*',
		                                      'CREATED_BY' => 'REF_EVENTS.UF_CREATED_BY',
	                                      ])->setFilter($filter)->countTotal(true)->exec();
	
	
	if ($query->getCount() === 0) {
		throw new Exception('Группа не найдена!');
	}
	
	if ($priceRule = $query->fetch()) {
		$res = [
			'ID'        => $priceRule['ID'],
			'UF_XML_ID' => $priceRule['UF_XML_ID'],
			
			'UF_TYPE_APPLY_ALL_ORDER' => (int)$priceRule['UF_TYPE_APPLY_ALL_ORDER'],
			'UF_TYPE_APPLY_MIN'       => (int)$priceRule['UF_TYPE_APPLY_MIN'],
			'UF_TYPE_APPLY_MAX'       => (int)$priceRule['UF_TYPE_APPLY_MAX'],
			'UF_NAME'                 => $priceRule['UF_NAME'],
			'UF_DISCOUNT_TYPE'        => $priceRule['UF_DISCOUNT_TYPE'],
			'UF_DISCOUNT'             => (float)$priceRule['UF_DISCOUNT'],
			'UF_DATE_START'           => is_object($priceRule['UF_DATE_START']) ? $priceRule['UF_DATE_START']->format(
				'd.m.y'
			) : null,
			'UF_DATE_END'             => is_object($priceRule['UF_DATE_END']) ? $priceRule['UF_DATE_END']->format(
				'd.m.y'
			) : null,
			'UF_EVENT_ID'             => $priceRule['UF_EVENT_ID'],
			'UF_TICKETS_TYPE'         => $priceRule['UF_TICKETS_TYPE'],
			'UF_FOR_ALL_TYPES'        => $priceRule['UF_FOR_ALL_TYPES'],
			'UF_MIN_COUNT_TICKETS'    => $priceRule['UF_MIN_COUNT_TICKETS'],
			'UF_IS_SUM'               => $priceRule['UF_IS_SUM'],
			'UF_FOR_EACH_TICKET'      => $priceRule['UF_FOR_EACH_TICKET'],
			'UF_TYPE'                 => $priceRule['UF_TYPE'],
			'UF_NUMBER_OF_USES'       => $priceRule['UF_NUMBER_OF_USES'],
			'UF_MAX_NUMBER_OF_USES'   => $priceRule['UF_MAX_NUMBER_OF_USES'],
			'UF_IS_ACTIVITY'          => $priceRule['UF_IS_ACTIVITY'],
			'PROMOCODES'              => []
		];
		
		
		$promoCodesEntity = new ORM\Query\Query('Custom\Core\Events\PromoCodesTable');
		$promoCodeQuery   = $promoCodesEntity->setSelect(['ID', 'UF_CODE', 'UF_IS_USE', 'UF_XML_ID'])->setFilter(
				['UF_RULE_ID' => $priceRule['ID']]
			)->exec();
		
		while ($promoCodeItem = $promoCodeQuery->fetch()) {
			$res['PROMOCODES'][] = [
				'ID'     => $promoCodeItem['ID'],
				'NAME'   => $promoCodeItem['UF_CODE'],
				'IS_USE' => $promoCodeItem['UF_IS_USE'],
				'XML_ID' => $promoCodeItem['UF_XML_ID'],
			];
		}
	}
	
	return $res;
}

function generateCode()
{
	$chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$res   = "";
	for ($i = 0; $i < 8; $i++) {
		$res .= $chars[mt_rand(0, strlen($chars) - 1)];
	}
	
	return $res;
}

function generateGroupCode(int $count, array $alreadyCreatedPromoCode): array
{
	$buffer = [];
	$tries  = 10;
	
	for ($i = 0; $i < $count; $i++) {
		for ($j = 0; $j < $tries; $j++) {
			$code = generateCode();
			if ( ! in_array($code, $buffer) && ! in_array($code, $alreadyCreatedPromoCode)) {
				$buffer[] = $code;
				break;
			}
		}
	}
	
	return $buffer;
}

function createPromoCodes(
	int $ruleId,
	int $needCreatePromoCodeCount,
	string $hlbClassPromoCodes,
	array $alreadyCreatedPromoCode = []
) {
	$alreadyCreatedPromoCodeCount = count($alreadyCreatedPromoCode);
	
	if ($needCreatePromoCodeCount > $alreadyCreatedPromoCodeCount) {
		$needCount     = $needCreatePromoCodeCount - $alreadyCreatedPromoCodeCount;
		$notCreate     = 0;
		$genPromoCodes = generateGroupCode($needCount, $alreadyCreatedPromoCode);
		for ($i = 0; $i < $needCount; $i++) {
			if ( ! isset($genPromoCodes[$i])) {
				$notCreate++;
				continue;
			}
			$objCoupon  = $hlbClassPromoCodes::createObject();
			$uuidCoupon = \Custom\Core\UUID::uuid4();
			
			$objCoupon->set('UF_XML_ID', $uuidCoupon);
			$objCoupon->set('UF_CODE', $genPromoCodes[$i]);
			$objCoupon->set('UF_RULE_ID', $ruleId);
			$objCoupon->set('UF_IS_USE', 0);
			
			$resAddPromoCode = $objCoupon->save();
			
			if ( ! $resAddPromoCode->isSuccess()) {
				throw new \Exception(implode(', ', $resAddPromoCode->getErrors()));
			}
			
			unset($priceRuleId);
			unset($uuidCoupon);
		}
		
		return max($needCreatePromoCodeCount - $notCreate, 0);
	} elseif ($needCreatePromoCodeCount === $alreadyCreatedPromoCodeCount) {
		return $needCreatePromoCodeCount;
	} elseif ($needCreatePromoCodeCount < $alreadyCreatedPromoCodeCount) {
		throw new Exception('Удалите из формы лишние промокоды');
	}
}

/**
 * @param int      $itemId
 * @param int      $eventId
 * @param int|null $type
 *
 * @throws Exception
 */
function getPriceRule(int $itemId, int $eventId, int $type = null)
{
	$filter = ['ID' => $itemId, 'EVENT_ID' => $eventId];
	
	if ( ! is_null($type)) {
		$filter['UF_TYPE'] = PRICE_RULE_TYPE_GROUP;
	}
	$priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');
	$query            = $priceRulesEntity->setSelect([
		                                                 '*',
		                                                 'EVENT_ID' => 'REF_EVENTS_ID.VALUE',
	                                                 ])->setFilter($filter)->setLimit(1)->exec();
	
	$obElementPriceRule = $query->fetchObject();
	
	if ( ! (is_object($obElementPriceRule) && $obElementPriceRule->getId() > 1)) {
		throw new Exception('Группа не найдена ');
	}
	
	return $obElementPriceRule;
}

?>
