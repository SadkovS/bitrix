<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("HLB_PRICE_RULES_DETAIL"),
	"DESCRIPTION" => GetMessage("HLB_PRICE_RULES_DETAIL_DESC"),
	"CACHE_PATH" => "Y",
	"SORT" => 40,
	"PATH" => array(
        "ID" => "custom",
		"CHILD" => array(
            "ID" => "price_rules",
			"NAME" => GetMessage("C_HLDB_CAT_PRICE_RULES"),
			"SORT" => 20,
            "CHILD" => array(
                "ID" => 'price_rules_cmpx'
            )
		)
	),
);
?>