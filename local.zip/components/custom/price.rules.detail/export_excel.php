<?php
use Custom\Core\ExportExcel;

$arrColumns = [
    'NAME' => ['name' => 'Промокод'],
    'IS_USE' => ['name' => 'Использован'],
];

$filter           = [
	'ID'                  => $itemId,
	'REF_EVENTS_ID.VALUE' => $eventId,
	'UF_TYPE'             => PRICE_RULE_TYPE_GROUP,
	'CREATED_BY'          => $USER->GetID(),
];
$arResult['ITEM'] = getPriceRuleGroup($filter);

if(!isset($arResult['ITEM'])) throw new Exception('Group not found');
$obExport = new ExportExcel();

$dateTime = (new \DateTime())->format('d.m.Y H:i');
$obExport->setFileName("Статистика группы ". $arResult['ITEM']['UF_NAME']  . " промокодов от " . $dateTime .'.xlsx');

$date = new DateTime();
$date = $date->format('d.m.Y');
$obExport->setFilePath($_SERVER['DOCUMENT_ROOT'] . '/upload/tmp');
$xls = $obExport->createFile();
$xls->getProperties()->setTitle("Тестовый файл");
$xls->getProperties()->setCreated($date);
$xls->setActiveSheetIndex(0);
$sheet = $xls->getActiveSheet();
$sheet->setTitle('Отчет');
$sheet->getRowDimension("1")->setRowHeight(50);
$sheet->getRowDimension("2")->setRowHeight(30);
$sheet->getRowDimension("3")->setRowHeight(40);

$sheet->setCellValue("A1", "Статистика по группе «" . $arResult['ITEM']['UF_NAME'] . "» промокодов от " . $dateTime);
$sheet->mergeCells("A1:L1");
$sheet->getStyle("A1")->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$sheet->getStyle("A1")->getFont()->setSize(22);
$sheet->getStyle("A1")->getFont()->setBold(true);

$i            = 0;
$rowNum       = 4;
$columnsCount = 0;
$arTable      = [];

$arTable['HEAD'] = array_values($arrColumns);

foreach ($arResult['ITEM']['PROMOCODES'] as $promoCode) {
	$row = $arrColumns;
	foreach ($arrColumns as $key => $col) {
		if ($key == 'NAME') {
			$row[$key]['value'] = $promoCode[$key];
		} elseif ($key == 'IS_USE') {
			$row[$key]['value'] = (int)$promoCode[$key] ? 'Да' : 'Нет';
		}
	}
	$arTable['BODY'][] = $row;
}

foreach ($arTable['HEAD'] as $key => $headItem) {
    $colLetter = $obExport->getColumnLetter($key + 1);
    $sheet->setCellValue($colLetter . '3', $headItem['name']??'');
    $sheet->getStyle($colLetter . '3')->getFont()->setSize(14);
    $sheet->getStyle($colLetter . '3')->getFont()->setBold(true);
    $sheet->getStyle($colLetter . '3')->getFont()->setItalic(true);
    $sheet->getStyle($colLetter . '3')->applyFromArray([
                                                           'fill' => array(
                                                               'type' => PHPExcel_Style_Fill::FILL_SOLID,
                                                               'color' => array('rgb' => 'e4efdc')
                                                           )
                                                       ]);
    $sheet->getStyle($colLetter . '3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle($colLetter . '3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
unset($key,$row,$i);

foreach ($arTable['BODY'] as $key => $row) {
    $i = 0;
    foreach ($row as $keyCol => $colID) {
        $indexCol = $i + 1;
        $colLetter = $obExport->getColumnLetter($indexCol);
		
        if(strlen(strip_tags($colID['value']??'')) > 300){
            $sheet->getColumnDimension($colLetter)->setAutoSize(false);
            $sheet->getColumnDimension($colLetter)->setWidth(150);
        }
        $sheet->setCellValue($colLetter . $rowNum, strip_tags($colID['value']??''));
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setWrapText(true);
        $sheet->getStyle($colLetter . $rowNum)->getFont()->setSize(14);
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        if($keyCol == 'IS_USE'){
            $styleStatus = $obExport->getBoolStyle(strip_tags($colID['value']));
            $sheet->getStyle($colLetter . $rowNum)->applyFromArray([
                                                                       'fill' => array(
                                                                           'type' => PHPExcel_Style_Fill::FILL_SOLID,
                                                                           'color' => array('rgb' => $styleStatus['background'])
                                                                       )
                                                                   ]);
            $sheet->getStyle($colLetter . $rowNum)->getFont()->getColor()->setRGB($styleStatus['color']);
            $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
        }
        $i++;
    }
    $rowNum ++;
}
$endColLetter = $obExport->getColumnLetter(count($arTable['HEAD']));
$sheet->getStyle("A3:".$endColLetter.($rowNum-1))->applyFromArray($obExport->getBorderStyle());
$obExport->downloadFile($xls);

exit;
