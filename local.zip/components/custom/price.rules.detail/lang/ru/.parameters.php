<?
$MESS["HLB_PRICE_RULES_ID"] = "ID хайлоадблока ценовых правил";
$MESS["HLB_PROMOCODES_ID"] = "ID хайлоадблока промокодов";
$MESS["EVENT_ID"] = "ID мероприятия";
$MESS["EVENT_TYPES"] = "Типы мероприятия";
$MESS["IBLOCK_ANY"] = "(любой)";
$MESS["IBLOCK_SECTION_ID"] = "ID раздела";
$MESS["CP_BPR_CACHE_GROUPS"] = "Учитывать права доступа";
?>