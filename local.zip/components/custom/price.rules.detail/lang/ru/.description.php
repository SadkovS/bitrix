<?
$MESS ['HLB_PRICE_RULES_DETAIL'] = "Форма ценового правила";
$MESS ['HLB_PRICE_RULES_DETAIL_DESC'] = "Показывает форму для создания/редактирования";
$MESS ['C_HLDB_CAT_PRICE_RULES'] = "Ценовые правила";
?>