<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME"        => GetMessage("CMPX_REFUNDS_NAME"),
    "DESCRIPTION" => GetMessage("CMPX_REFUNDS_DESC"),
    "CACHE_PATH"  => "Y",
    "COMPLEX"     => "Y",
    "PATH"        => [
        "ID"    => "custom",
        "CHILD" => [
            "ID"    => "orders",
            "NAME"  => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT"  => 20,
            "CHILD" => [
                "ID" => 'refunds_cmpx',
            ]
        ]
    ],
];
?>