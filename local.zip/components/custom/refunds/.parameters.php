<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/** @var array $arCurrentValues */


$arComponentParameters = [
    "PARAMETERS" => [
        "AJAX_MODE"       => [],
        "USE_PERMISSIONS" => [
            "PARENT"  => "ADDITIONAL_SETTINGS",
            "NAME"    => GetMessage("T_IBLOCK_DESC_USE_PERMISSIONS"),
            "TYPE"    => "CHECKBOX",
            "DEFAULT" => "N",
            "REFRESH" => "Y",
        ],
        "CACHE_TIME"      => ["DEFAULT" => 36000000],
        "CACHE_FILTER"    => [
            "PARENT"  => "CACHE_SETTINGS",
            "NAME"    => GetMessage("IBLOCK_CACHE_FILTER"),
            "TYPE"    => "CHECKBOX",
            "DEFAULT" => "N",
        ],
        "CACHE_GROUPS"    => [
            "PARENT"  => "CACHE_SETTINGS",
            "NAME"    => GetMessage("CP_BP_CACHE_GROUPS"),
            "TYPE"    => "CHECKBOX",
            "DEFAULT" => "Y",
        ],
    ],
];


CIBlockParameters::Add404Settings($arComponentParameters, $arCurrentValues);


if (($arCurrentValues["USE_PERMISSIONS"] ?? 'N') !== "Y") {
    unset($arComponentParameters["PARAMETERS"]["GROUP_PERMISSIONS"]);
}
