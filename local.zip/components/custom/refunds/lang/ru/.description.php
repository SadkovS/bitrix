<?
$MESS ['CMPX_REFUNDS_NAME'] = "Возвраты";
$MESS ['CMPX_REFUNDS_DESC'] = "Выводит информацию по возвратам";
$MESS ['C_HLDB_CAT_ORDERS'] = "Заказы";
?>