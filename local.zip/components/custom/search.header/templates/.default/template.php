<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Catalog\ProductTable;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>
<div id="<?=$arParams["SEARCH_POPUP_ID"]?>" class="popup search__popup bg-icons-1 dark:bg-primary lg:!bg-transparent"
     data-in=".js-xl-search, 1799">
    <div class="popup__wrapper">
        <div class="popup__content ">
            <div class="inline-flex flex-col w-full gap-c_lg  p-c_narrow lg:p-0">
                <div class="inline-flex flex-col gap-c_sm flex-auto">
                    <div class="from__item">
                        <div class="form__item-wrapper">
                            <button type="button" class="search__input-back" data-close>
                                <i class="svg_icon-arrow rotate-[215deg]"></i>
                            </button>
                            <input type="text" class="input search__input" placeholder="Поиск" id="search"
                                   spellcheck="false" name="q" value="<?=$arResult["q"]?>">
                            <button class="search__input-clear" type="button" data-close>
                                <i class="svg_icon-cross-s"></i>
                            </button>
                        </div>
                    </div>
                    <div class="flex-auto  overflow-y-auto inline-flex flex-col search__content">
                        <?/*<div class="search__history">
                            <div class="inline-flex justify-between gap-5 search__title">
                                <div class="text-sm font-gothic md:text-xl">История</div>
                                <button class="text-warning text-xs" type="button">Очистить</button>
                            </div>
                            <ul class="search__history-list">
                                <li>
                                    <a href="#">Концерт на Патриках</a>
                                </li>
                                <li>
                                    <a href="#">Джаз</a>
                                </li>
                                <li>
                                    <a href="#">Новогоднее</a>
                                </li>
                                <li>
                                    <a href="#">Красная площадь</a>
                                </li>
                                <li>
                                    <a href="#">Планетарий</a>
                                </li>
                                <li>
                                    <a href="#">Океанариум</a>
                                </li>
                            </ul>
                        </div>*/?>
                        <div class="recommend">
                            <?/*<div class="search__title">
                                <div class="text-sm font-gothic md:text-xl">Рекомендуем</div>
                            </div>*/?>
                            <ul class="recommend__list search__list">
                                <?if($arResult["q"]):?>
                                    <?if($arResult["ITEMS"]):?>

                                        <?foreach($arResult["ITEMS"] as $item):?>
                                            <li>
                                                <a href="<?=$item["URL"]?>">
                                                    <span><?=$item["TITLE"]?></span>
                                                    <?if($item["INFO_EVENT_BY_SEARCH"]):?>
                                                        <small><?=$item["INFO_EVENT_BY_SEARCH"]?></small>
                                                    <?endif;?>
                                                </a>
                                            </li>
                                        <?endforeach;?>
                                    <?else:?>
                                        <li>Ничего не найдено!</li>
                                    <?endif;?>
                                <?endif;?>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



