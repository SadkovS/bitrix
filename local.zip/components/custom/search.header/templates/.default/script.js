$(function() {
	
	$(document).on("input", ".search__input[name=q]",  function (e) {
		var q = $(this).val();
		e.preventDefault();
		BX.ajax.runComponentAction("custom:search.header", "search", {
		    mode: "class",
		    data: {q: $(this).val()}
		}).then(function (response) {
		    $(".search__list").replaceWith($(response.data).find(".search__list"));
		    
		    if(q.length)
		    	$(".search__form").addClass("list-active");
		    else
		    	$(".search__form").removeClass("list-active");
		});
		
	});
	
	$(document).on("submit", ".search__form",  function (e) {
		e.preventDefault();
		return false;
	});
	
});