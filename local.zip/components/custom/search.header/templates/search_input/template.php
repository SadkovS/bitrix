<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Catalog\ProductTable;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>
<div
        class="flex-1 js-xl-search laptop:justify-between laptop:relative laptop:inline-flex laptop:gap-10">
    <div class="form__item-wrapper h-fit flex-1" data-popup="#<?=$arParams["SEARCH_POPUP_ID"]?>"
         data-popup-focus="#search">
        <input type="text" class="input search__input" placeholder="Поиск по сайту">
        <button type="submit" class="search__input-icon">
            <i class="svg_icon-search "></i>
        </button>
    </div>
</div>



