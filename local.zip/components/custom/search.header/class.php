<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();

use Bitrix\Main;
use Bitrix\Main\Error;
use Bitrix\Main\ErrorCollection;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Application;
use Bitrix\Main\Context;
use Bitrix\Main\Request;
use Bitrix\Main\ORM;

class SearchCustom extends CBitrixComponent implements \Bitrix\Main\Engine\Contract\Controllerable
{
	public function configureActions()
    {
        return [
            'search' => [
                'prefilters' => [],
                'postfilters' => []
            ],
        ];
    }

    public static function getEventData($productId = null)
    {
        $productEntity     = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $productClass  = $productEntity->getDataClass();

        $propFieldEventID  = $productEntity->getField('EVENT_ID');
        $propEventIDEntity = $propFieldEventID->getRefEntity();

        $res = $productClass::getList(
            [
                'select' => [
                    'ID',
                    'EVENT' => 'EVENT_REF.ID',
                    'EVENT_NAME' => 'EVENT_REF.UF_NAME',
                    'IS_CLOSED'  => 'IS_CLOSED_EVENT.VALUE',
                    'ON_MODERATION'  => 'MODERATION.VALUE',
                ],
                'filter' => [
                    'ID' => $productId,
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROP',
                        $propEventIDEntity,
                        ['this.ID' => 'ref.IBLOCK_ELEMENT_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'EVENT_REF',
                        'Custom\Core\Events\EventsTable',
                        ['this.PROP.VALUE' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ]
            ]
        );

        if ($arItem = $res->fetch()) {
            return $arItem;
        }

        return [];
    }

	public function searchAction($q)
	{
		if ((CModule::IncludeModule('search'))&&(CModule::IncludeModule('iblock'))){
			$this->arResult["q"] = $q;
			$this->arResult["ITEMS"] = [];
			
			$q = preg_replace('/(\S+)/', '"\\1"',$q);
			
		    $obSearch = new CSearch;
		    $obSearch->Search(
	    		array(
	            	"QUERY" => $q,
	            	"SITE_ID" => LANG,
	            	"MODULE_ID" => 'iblock',
	            	"CHECK_DATES" => 'Y',
	            	"PARAM2" => "4"
	            ),
	            array(
	            	"RANK"=>"DESC", 
	            	"DATE_CHANGE"=>"DESC"
				)
            );

		    $result = array();

		    while ($res = $obSearch->GetNext()){
		        $id = $res['ITEM_ID'];

		        if (strripos($id, 'S')===false)
		        {
                    $result_item = $this->getEventData($id);

                    if($this->checkEvent($result_item))
                    {
                        $result_item = [];
                        $result_item['TITLE'] = $res['TITLE'];
                        $result_item['URL'] = $res['URL'];

                        /*$result_item['BODY_FORMATED'] = $res['BODY_FORMATED'];

                        $addInfo = [];

                        if($result_item["CATEGORY_NAME"])
                            $addInfo[] = $result_item["CATEGORY_NAME"];

                        if($result_item["DATE_TIME"]["DATE_RU_SHORT"])
                            $addInfo[] = $result_item["DATE_TIME"]["DATE_RU_SHORT"];

                        if($result_item["DATE_TIME"]["DATE"] && $result_item["DATE_TIME"]["DATE_END"])
                        if($result_item["DATE_TIME"]["DATE"] != $result_item["DATE_TIME"]["DATE_END"])
                        {
                            $addInfo[] = "открыто до {$result_item["DATE_TIME"]["TIME_END"]} {$result_item["DATE_TIME"]["DATE_END_RU"]}";
                        }
                        else
                        {
                            $addInfo[] = "открыто до {$result_item["DATE_TIME"]["TIME_END"]}";
                        }

                        $result_item['INFO_EVENT_BY_SEARCH'] = implode(", ", $addInfo);*/

                        $this->arResult["ITEMS"][] = $result_item;
                    }
		        }
		    }
			
			global $APPLICATION;
			$APPLICATION->RestartBuffer();
			ob_start();
			$this->includeComponentTemplate();
			$content = ob_get_contents();
			ob_end_clean();
			
			return $content;
		}
	}

    public function checkEvent($event)
    {
        if(
            $event["IS_CLOSED"] ||
            $event["ON_MODERATION"] ||
            !$event["EVENT"]
        )
        {
            return false;
        }

        return true;
    }

	public function onPrepareComponentParams($arParams)
	{
        if(!$arParams["SEARCH_POPUP_ID"])
            $arParams["SEARCH_POPUP_ID"] = "search-popup";

		return $arParams;
	}
	
	public function executeComponent()
	{
		$this->includeComponentTemplate();
	}
	
	protected static function getSession(): ?Session
	{
		/** @var Session $session */
		$session = Application::getInstance()->getSession();
		if (!$session->isAccessible())
		{
			return null;
		}

		return $session;
	}

}
