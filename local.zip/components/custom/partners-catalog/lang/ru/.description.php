<?
$MESS ['IBLOCK_CATALOG_NAME'] = "Каталог партнеров";
$MESS ['IBLOCK_CATALOG_DESCRIPTION'] = "Полный каталог партнеров";
$MESS ['T_IBLOCK_DESC_CATALOG'] = "Каталог партнеров";
?>