<?
$MESS ['IBLOCK_CATALOG_NAME'] = "Catalog partners";
$MESS ['IBLOCK_CATALOG_DESCRIPTION'] = "Full catalog partners";
$MESS ['T_IBLOCK_DESC_CATALOG'] = "Catalog partners";
?>
