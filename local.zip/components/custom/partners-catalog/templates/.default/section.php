<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
use Bitrix\Main\Loader;
use Bitrix\Main\ModuleManager;

$this->setFrameMode(true);
?>
	<div class="row col-12">
		<h1>
			<?
			$APPLICATION->IncludeComponent("bitrix:breadcrumb", "partners", Array(
			"PATH" => "",
			"SITE_ID" => "s1",
			"START_FROM" => "0",
		), false);?>
			<? $APPLICATION->AddChainItem('Партнеры');?>
		</h1>
		
		<? if ($APPLICATION->GetCurPage() !== $arParams['SEF_FOLDER']): ?>
			<a href="<?= isset($_SERVER['HTTP_REFERER']) ? 'javascript:history.back()': $arParams['SEF_FOLDER'] ?>" class="back-link"><span class="_icon-arrow"></span>Назад</a>
		<? endif; ?>
	</div>

	<div class="partner-grid">
      <? $sectionsComponent = $APPLICATION->IncludeComponent(
          "bitrix:catalog.section.list",
          "partners",
          array(
              "IBLOCK_TYPE" => $arParams["IBLOCK_TYPE"],
              "IBLOCK_ID" => $arParams["IBLOCK_ID"],
              "SECTION_ID" => $arResult["VARIABLES"]["SECTION_ID"],
              "SECTION_CODE" => $arResult["VARIABLES"]["SECTION_CODE"],
              "CACHE_TYPE" => $arParams["CACHE_TYPE"],
              "CACHE_TIME" => $arParams["CACHE_TIME"],
              "CACHE_GROUPS" => $arParams["CACHE_GROUPS"],
              "COUNT_ELEMENTS" => $arParams["SECTION_COUNT_ELEMENTS"],
              "TOP_DEPTH" => $arParams["SECTION_TOP_DEPTH"],
              "SECTION_URL" => $arResult["FOLDER"] . $arResult["URL_TEMPLATES"]["section"],
              "VIEW_MODE" => $arParams["SECTIONS_VIEW_MODE"],
              "SECTION_USER_FIELDS" => ['UF_LINK'],
              "SHOW_PARENT_NAME" => $arParams["SECTIONS_SHOW_PARENT_NAME"],
              "HIDE_SECTION_NAME" => (isset($arParams["SECTIONS_HIDE_SECTION_NAME"]) ? $arParams["SECTIONS_HIDE_SECTION_NAME"] : "N"),
              "ADD_SECTIONS_CHAIN" => (isset($arParams["ADD_SECTIONS_CHAIN"]) ? $arParams["ADD_SECTIONS_CHAIN"] : ''),
              "AVAILABLE_USER_SERVICES" => $arParams['AVAILABLE_USER_SERVICES'],
              "FILTER_NAME" => $arParams["FILTER_NAME"],
          ),
                $component,
                array("HIDE_ICONS" => "Y"),
            );
      ?>
      
      
   <?
      //global $partnerCatalogFilter;
     // $partnerCatalogFilter = ["SECTION_CODE" => $arResult['VARIABLES']['SECTION_CODE']];?>
      <? $itemsComponent = $APPLICATION->IncludeComponent(
	"bitrix:catalog.section",
	"partners",
	array(
		"ACTION_VARIABLE" => "action",
		"ADD_PROPERTIES_TO_BASKET" => "Y",
		"ADD_SECTIONS_CHAIN" => "N",
		"AJAX_MODE" => "N",
		"AJAX_OPTION_ADDITIONAL" => "",
		"AJAX_OPTION_HISTORY" => "N",
		"AJAX_OPTION_JUMP" => "N",
		"AJAX_OPTION_STYLE" => "Y",
		"BACKGROUND_IMAGE" => "-",
		"BASKET_URL" => "/personal/basket.php",
		"BROWSER_TITLE" => "-",
		"CACHE_FILTER" => "N",
		"CACHE_GROUPS" => "Y",
		"CACHE_TIME" => "36000000",
		"CACHE_TYPE" => "N",
		"COMPATIBLE_MODE" => "N",
		"CONVERT_CURRENCY" => "N",
		"CUSTOM_FILTER" => "{\"CLASS_ID\":\"CondGroup\",\"DATA\":{\"All\":\"AND\",\"True\":\"True\"},\"CHILDREN\":[]}",
		"DETAIL_URL" => "",
		"DISABLE_INIT_JS_IN_COMPONENT" => "N",
		"DISPLAY_BOTTOM_PAGER" => "Y",
		"DISPLAY_COMPARE" => "N",
		"DISPLAY_TOP_PAGER" => "N",
		"ELEMENT_SORT_FIELD" => "sort",
		"ELEMENT_SORT_FIELD2" => "id",
		"ELEMENT_SORT_ORDER" => "asc",
		"ELEMENT_SORT_ORDER2" => "desc",
		"FILTER_NAME" => "",//partnerCatalogFilter
		"HIDE_NOT_AVAILABLE" => "N",
		"HIDE_NOT_AVAILABLE_OFFERS" => "N",
		"IBLOCK_ID" => "8",
		"IBLOCK_TYPE" => "news",
		"INCLUDE_SUBSECTIONS" => "N",
		"LINE_ELEMENT_COUNT" => "3",
		"MESSAGE_404" => "",
		"META_DESCRIPTION" => "-",
		"META_KEYWORDS" => "-",
		"OFFERS_LIMIT" => "5",
		"PAGER_BASE_LINK_ENABLE" => "N",
		"PAGER_DESC_NUMBERING" => "N",
		"PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
		"PAGER_SHOW_ALL" => "N",
		"PAGER_SHOW_ALWAYS" => "N",
		"PAGER_TEMPLATE" => ".default",
		"PAGER_TITLE" => "Партнеры",
		"PAGE_ELEMENT_COUNT" => "30",
		"PARTIAL_PRODUCT_PROPERTIES" => "N",
		"PRICE_CODE" => array(
		),
		"PRICE_VAT_INCLUDE" => "Y",
		"PRODUCT_ID_VARIABLE" => "id",
		"PRODUCT_PROPS_VARIABLE" => "prop",
		"PRODUCT_QUANTITY_VARIABLE" => "quantity",
		"SECTION_CODE" => $arResult['VARIABLES']['SECTION_CODE'],
		"SECTION_ID" => $_REQUEST["SECTION_ID"],
		"SECTION_ID_VARIABLE" => "SECTION_ID",
		"SECTION_URL" => "",
		"SECTION_USER_FIELDS" => array(
			0 => "UF_LINK",
			1 => "",
		),
		"SEF_MODE" => "N",
		"SET_BROWSER_TITLE" => "Y",
		"SET_LAST_MODIFIED" => "N",
		"SET_META_DESCRIPTION" => "Y",
		"SET_META_KEYWORDS" => "Y",
		"SET_STATUS_404" => "Y",
		"SET_TITLE" => "Y",
		"SHOW_404" => "N",
		"SHOW_ALL_WO_SECTION" => "N",
		"SHOW_PRICE_COUNT" => "1",
		"USE_MAIN_ELEMENT_SECTION" => "N",
		"USE_PRICE_COUNT" => "N",
		"USE_PRODUCT_QUANTITY" => "N",
		"COMPONENT_TEMPLATE" => ".default"
	),
	);
	?>
	</div>

