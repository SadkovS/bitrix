<?php
$MESS["ORGANIZER_EVENT_STATUSES_NAME"] = "Просмотр статусов мерооприятий";
$MESS["ORGANIZER_EVENT_STATUSES_DESCRIPTION"] = "Позволяет просмотреть статусы мероприятий";
$MESS["MEDIA"] = "Медиа";