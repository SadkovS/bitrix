<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("ORGANIZER_EVENT_STATUSES_NAME"),
	"DESCRIPTION" => GetMessage("ORGANIZER_EVENT_STATUSES_DESCRIPTION"),
	"COMPLEX" => "N",
	"PATH" => array(
        "ID" => "custom",
        "NAME" => GetMessage("C_HLDB_COMPONENTS"),
        "CHILD" => array(
            "ID" => "events",
            "NAME" => GetMessage("C_HLDB_CAT_EVENTS"),
            "SORT" => 20,
            "CHILD" => array(
                "ID" => "organizer.event.statuses",
            ),
        )
	),
);
?>