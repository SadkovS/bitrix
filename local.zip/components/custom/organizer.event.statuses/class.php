<?php

use Bitrix\Main\Localization\Loc;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

Loc::loadMessages(__FILE__);

use Bitrix\Main\ORM;

class OrganizerEventStatusesComponent extends \CBitrixComponent {
    protected $companyID;
    protected $needle_statuses = [1, 2, 3, 5];
    public function __construct($component = null)
    {
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        if (!$this->companyID) return;
        parent::__construct($component);
    }

    public function getStatuses(array $statuses): array
    {
        $result                        = [];
        $query                         = new ORM\Query\Query('\Custom\Core\Events\EventsStatusTable');

        $resStatus                     = $query
            ->setSelect(['ID', 'UF_NAME'])
            ->setFilter(['ID' => $statuses])
            ->setOrder(['UF_SORT' => 'ASC'])
            ->setCacheTtl(3600)
            ->exec();
        while ($status = $resStatus->fetch()) {
            $status['CNT']  = 0;
            $result[$status['ID']] = $status;
        }

        return $result;
    }

    public function executeComponent()
    {
        $statuses                = $this->getStatuses($this->needle_statuses);
        if (count($statuses) == 0) return;
        $eventEntity             = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $query                   = $eventEntity
            ->setSelect(['UF_STATUS', 'CNT'])
            ->setFilter(['UF_STATUS' => $this->needle_statuses, 'UF_COMPANY_ID' => $this->companyID])
            ->setGroup('UF_STATUS')
            ->registerRuntimeField(
                'CNT', [
                         'data_type'  => 'integer',
                         'expression' => ['COUNT(*)']
                     ]
            )
            ->setCacheTtl('600')
            ->exec();

        while ($item = $query->fetch()) {
            $statuses[$item['UF_STATUS']]['CNT'] = $item['CNT'];
        }
        $this->arResult['ITEMS'] = $statuses;

        $this->includeComponentTemplate();
    }

}