<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<div class="adminpanel__header-item-title">
    <h3>Статусы мероприятий</h3>
</div>
<div class="header-status-list">
    <? foreach ($arResult['ITEMS'] as $item): ?>
        <?
            $statusClass = '';
            switch ($item['ID']) {
                case '1':
                    $statusClass = 'c-orange';
                    break;
                case '2':
                    $statusClass = 'c-gray';
                    break;
                case '5':
                    $statusClass = 'c-success';
                    break;
                case '3':
                    $statusClass = 'c-error';
                    break;
            }
        ?>
        <div class="header-status-list__itm <?=$statusClass?>"><?=$item['UF_NAME']?>: <span
                    class="header-status-list__itm__val"><?=$item['CNT']?></span></div>
    <? endforeach; ?>
</div>
