<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Application;
use Bitrix\Main\Page\Asset;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
?>
<form class="admin-body__item wide js-form-chart" data-dataset="no-sync">
    <input type="hidden" name="ajax_chart" value="Y">
    <?=bitrix_sessid_post()?>
    <div class="chart-head">
        <div class="chart-head-date">
            <label class="range-two-date">
                <div class="range-two-date__val"><?=$arResult['DATE_START_FORMATED']?></div>
                <div class="range-two-date__sep">—</div>
                <div class="range-two-date__val"><?=$arResult['DATE_END_FORMATED']?></div>
                <input class="js-range-two-date js-reload-chart" data-date="range" value="<?=$arResult['DATE_START']?> - <?=$arResult['DATE_END']?>" name="d" type="text">
            </label>
        </div>

        <div class="chart-head-filter">
            <?
            $activeTab = 0;
            if(isset($request['tab']) && key_exists($request['tab'],$arResult['TABS'])){
                $activeTab = $request['tab'];
            }
            ?>
            <?foreach ($arResult['TABS'] as $key => $tab):?>
            <label class="chart-head-filter-itm">
                <input class="js-reload-chart" <?=$key == $activeTab ? 'checked' : ''?> name="tab" type="radio" value="<?=$key?>">
                <span class="chart-head-filter-itm__val"><?=implode(' / ', $tab)?></span>
            </label>
            <?endforeach;?>
        </div>

    </div>
    <div class="graphic">
        <canvas data-adress="/admin_panel/?ajax_chart=Y" id="chart" role="img"></canvas>
    </div>
    <div class="chart-foot">
        <div class="chart-foot-filter">
            <label class="chart-foot-filter-itm">
                <input checked class="js-checkbox-interval-chart" name="chart-foot-filter" type="radio" value="Дни">
                <span class="chart-foot-filter-itm__val">Дни</span>
            </label>

            <label class="chart-foot-filter-itm">
                <input class="js-checkbox-interval-chart" name="chart-foot-filter" type="radio" value="Недели">
                <span class="chart-foot-filter-itm__val">Недели</span>
            </label>

            <label class="chart-foot-filter-itm">
                <input class="js-checkbox-interval-chart" name="chart-foot-filter" type="radio" value="Месяцы">
                <span class="chart-foot-filter-itm__val">Месяцы</span>
            </label>
        </div>
    </div>
</form>