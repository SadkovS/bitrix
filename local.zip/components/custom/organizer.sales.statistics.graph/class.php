<?php

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Custom\Core\Helper;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

Loc::loadMessages(__FILE__);
Loader::includeModule('custom.core');
Loader::includeModule('sale');

class OrganizerSalesStatisticGraphComponent extends \CBitrixComponent {
    protected $companyID;
    protected $defaultDateStart;
    protected $defaultDateEnd;

    protected $dateFrom;
    protected $dateTo;

    protected $tabs = [
        ['Заказы', 'Оплаченные заказы'],
        ['Оборот', 'Оплаченные заказы'],
        ['Оборот', 'Оплаченные билеты']
    ];
    protected $months = [
        'Январь',
        'Февраль',
        'Март',
        'Апрель',
        'Май',
        'Июнь',
        'Июль',
        'Август',
        'Сентябрь',
        'Октябрь',
        'Ноябрь',
        'Декабрь'
    ];

    const COLOR1 = '#75C39C';
    const COLOR2 = '#8191A3';

    public function __construct($component = null)
    {
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        if (!$this->companyID) return;
        parent::__construct($component);


        $date                   = new DateTime();
        $this->defaultDateEnd   = $date->format('d.m.Y');
        $this->defaultDateStart = $date->modify('-1 month')->format('d.m.Y');

        if (!isset($this->request['d']) || count(explode(' - ', $this->request['d'])) != 2) {
            $this->dateFrom = $this->defaultDateStart;
            $this->dateTo   = $this->defaultDateEnd;
        }else{
            $dates = explode(' - ', $this->request['d']);
            $this->dateFrom = $dates[0];
            $this->dateTo   = $dates[1];
        }

        if(isset($this->request['ajax_chart']) && $this->request['ajax_chart'] == 'Y'){
            global $APPLICATION;
            $APPLICATION->RestartBuffer();
            echo $this->makeResultJson($this->dateFrom,$this->dateTo);
            die;
        }
    }

    public function executeComponent()
    {


        $this->arResult['DATE_START']          = $this->defaultDateStart;
        $this->arResult['DATE_START_FORMATED'] = Helper::getFormatDate($this->defaultDateStart, 'dmnY');
        $this->arResult['DATE_END']            = $this->defaultDateEnd;
        $this->arResult['DATE_END_FORMATED']   = Helper::getFormatDate($this->defaultDateEnd, 'dmnY');
        $this->arResult['TABS']                = $this->tabs;



        $this->includeComponentTemplate();
    }

    private function makeResultJson($from, $to)
    {

        $from = DateTime::createFromFormat('d.m.Y', $from);
        $to   = DateTime::createFromFormat('d.m.Y', $to);


        $result = [
            "period" => $this->months[$from->format('n') - 1] . ' ' . $from->format('Y'),
            "charts" => $this->makeCharts($from, $to, $this->request['tab'])
        ];

        return json_encode($result, JSON_UNESCAPED_UNICODE);
    }

    private function makeCharts(DateTime $from, DateTime $to, $tab = 0)
    {

        $charts    = [];
        $dateRange = $this->getDatesFromRange($from->format('d.m.Y'), $to->format('d.m.Y'));

        if ($tab == 0) {

            $chartData1 = $this->getCountAllOrders($from->format('d.m.Y'), $to->format('d.m.Y'));
            $chartData1 = array_merge($dateRange, $chartData1);

            $chart = [
                'title' => $this->tabs[$tab][0],
                'color' => self::COLOR1,
                'currency' => 'шт.'
            ];
            foreach ($chartData1 as $date => $count) {
                $chart['data'][] = ['day' => (new DateTime($date))->format('d'), 'count' => $count];
            }
            unset($date, $count);
            $charts[]   = $chart;
            $chartData2 = $this->getCountPayedOrders($from->format('d.m.Y'), $to->format('d.m.Y'));
            $chartData2 = array_merge($dateRange, $chartData2);
            $chart      = [
                'title' => $this->tabs[$tab][1],
                'color' => self::COLOR2,
                'currency' => 'шт.'
            ];
            foreach ($chartData2 as $date => $count) {
                $chart['data'][] = ['day' => (new DateTime($date))->format('d'), 'count' => $count];
            }
            unset($date, $count);
            $charts[] = $chart;

        }elseif ($tab == 1){

            $chartData1 = $this->getPayedOrdersSum($from->format('d.m.Y'), $to->format('d.m.Y'));
            $chartData1 = array_merge($dateRange, $chartData1);

            $chart = [
                'title' => $this->tabs[$tab][0],
                'color' => self::COLOR1,
                'currency' => '₽',
            ];
            foreach ($chartData1 as $date => $count) {
                $chart['data'][] = ['day' => (new DateTime($date))->format('d'), 'count' => $count];
            }
            unset($date, $count);
            $charts[]   = $chart;

            $chartData2 = $this->getCountPayedOrders($from->format('d.m.Y'), $to->format('d.m.Y'));
            $chartData2 = array_merge($dateRange, $chartData2);
            $chart      = [
                'title' => $this->tabs[$tab][1],
                'color' => self::COLOR2,
                'currency' => 'шт.'
            ];
            foreach ($chartData2 as $date => $count) {
                $chart['data'][] = ['day' => (new DateTime($date))->format('d'), 'count' => $count];
            }
            unset($date, $count);
            $charts[] = $chart;

        }elseif ($tab == 2){
            $chartData1 = $this->getPayedOrdersSum($from->format('d.m.Y'), $to->format('d.m.Y'));
            $chartData1 = array_merge($dateRange, $chartData1);

            $chart = [
                'title' => $this->tabs[$tab][0],
                'color' => self::COLOR1,
                'currency' => '₽',
            ];
            foreach ($chartData1 as $date => $count) {
                $chart['data'][] = ['day' => (new DateTime($date))->format('d'), 'count' => $count];
            }
            unset($date, $count);
            $charts[]   = $chart;

            $chartData2 = $this->getCountPayedTickets($from->format('d.m.Y'), $to->format('d.m.Y'));
            $chartData2 = array_merge($dateRange, $chartData2);
            $chart      = [
                'title' => $this->tabs[$tab][1],
                'color' => self::COLOR2,
                'currency' => 'шт.'
            ];
            foreach ($chartData2 as $date => $count) {
                $chart['data'][] = ['day' => (new DateTime($date))->format('d'), 'count' => $count];
            }
            unset($date, $count);
            $charts[] = $chart;
        }
        return $charts;
    }

    private function getCountAllOrders($from, $to)
    {
        $dbRes  = \Bitrix\Sale\Order::getList(
            [
                'select'  => [
                    'DATE_FORMAT',
                    'CNT'
                ],
                'filter'  => [
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID',
                    "PROPERTY_ORGANIZER.VALUE" => $this->companyID,
                    [
                        "LOGIC" => 'AND',
                        [">=DATE_INSERT" => $from . ' 00:00:00'],
                        ["<=DATE_INSERT" => $to . ' 23:59:59'],
                    ],
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'CNT', 'COUNT(%s)', ['ID']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'DATE_FORMAT', 'DATE_FORMAT(%s, "%%Y-%%m-%%d")', ['DATE_INSERT']
                    ),
                ],
                'group'   => ['DATE_FORMAT'],
            ]
        );
        $result = [];
        while ($order = $dbRes->fetch()) {
            $result[$order['DATE_FORMAT']] = $order['CNT'];
        }
        return $result;
    }

    private function getCountPayedOrders($from, $to)
    {
        $dbRes  = \Bitrix\Sale\Order::getList(
            [
                'select'  => [
                    'DATE_FORMAT',
                    'CNT'
                ],
                'filter'  => [
                    "PAYED"                    => "Y",
                    //"STATUS_ID" => ['F','P'],
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID',
                    "PROPERTY_ORGANIZER.VALUE" => $this->companyID,
                    [
                        "LOGIC" => 'AND',
                        [">=DATE_INSERT" => (new DateTime($from))->format('d.m.Y') . ' 00:00:00'],
                        ["<=DATE_INSERT" => (new DateTime($to))->format('d.m.Y') . ' 23:59:59'],
                    ],
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'CNT', 'COUNT(%s)', ['ID']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'DATE_FORMAT', 'DATE_FORMAT(%s, "%%Y-%%m-%%d")', ['DATE_INSERT']
                    ),
                ],
                'group'   => ['DATE_FORMAT'],
            ]
        );
        $result = [];
        while ($order = $dbRes->fetch()) {
            $result[$order['DATE_FORMAT']] = $order['CNT'];
        }
        return $result;
    }

    private function getDatesFromRange($from, $to): array
    {
        $from = new DateTime($from);
        $to   = new DateTime($to);

        $period  = new DatePeriod($from, new DateInterval('P1D'), $to);
        $arDates = [];
        foreach (iterator_to_array($period) as $item) {
            $arDates[$item->format('Y-m-d')] = 0;
        }
        return $arDates;
    }

    private function getPayedOrdersSum($from, $to)
    {
        $dbRes  = \Bitrix\Sale\Order::getList(
            [
                'select'  => [
                    'DATE_FORMAT',
                    'SUM',
                ],
                'filter'  => [
                    "PAYED"                    => "Y",
                    //"STATUS_ID" => ['F','P'],
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID',
                    "PROPERTY_ORGANIZER.VALUE" => $this->companyID,
                    [
                        "LOGIC" => 'AND',
                        [">=DATE_INSERT" => $from . ' 00:00:00'],
                        ["<=DATE_INSERT" => $to . ' 23:59:59'],
                    ],
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    //            new \Bitrix\Main\Entity\ReferenceField(
                    //                'BASKET_REFS',
                    //                'Bitrix\Sale\Internals\BasketTable',
                    //                ['this.ID' => 'ref.ORDER_ID'],
                    //                ['join_type' => 'left']
                    //            ),//QUANTITY
                    new \Bitrix\Main\Entity\ExpressionField(
                        'SUM', 'SUM(%s-%s)', ['PRICE','PRICE_DELIVERY']
                    ),
//                    new \Bitrix\Main\Entity\ExpressionField(
//                        'CNT', 'COUNT(%s)', ['ID']
//                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'DATE_FORMAT', 'DATE_FORMAT(%s, "%%Y-%%m-%%d")', ['DATE_INSERT']
                    ),

//                                new \Bitrix\Main\Entity\ExpressionField(
//                                    'SUM_QUANTITY', 'SUM(%s)', ['BASKET_REFS.QUANTITY']
//                                ),
                ],
                'group'   => ['DATE_FORMAT'],
            ]
        );
        $result = [];
        while ($order = $dbRes->fetch()) {
            $result[$order['DATE_FORMAT']] = $order['SUM'];
        }
        return $result;
    }

    private function getCountPayedTickets($from, $to)
    {
        $dbRes  = \Bitrix\Sale\Order::getList(
            [
                'select'  => [
                    'DATE_FORMAT',
                    'SUM_QUANTITY'
                ],
                'filter'  => [
                    "PAYED"                    => "Y",
                    //"STATUS_ID" => ['F','P'],
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID',
                    "PROPERTY_ORGANIZER.VALUE" => $this->companyID,
                    [
                        "LOGIC" => 'AND',
                        [">=DATE_INSERT" => $from . ' 00:00:00'],
                        ["<=DATE_INSERT" => $to . ' 23:59:59'],
                    ],
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_REFS',
                        'Bitrix\Sale\Internals\BasketTable',
                        ['this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),//QUANTITY
                    new \Bitrix\Main\Entity\ExpressionField(
                        'DATE_FORMAT', 'DATE_FORMAT(%s, "%%Y-%%m-%%d")', ['DATE_INSERT']
                    ),

                    new \Bitrix\Main\Entity\ExpressionField(
                        'SUM_QUANTITY', 'SUM(%s)', ['BASKET_REFS.QUANTITY']
                    ),
                ],
                'group'   => ['DATE_FORMAT'],
            ]
        );
        $result = [];
        while ($order = $dbRes->fetch()) {
            $result[$order['DATE_FORMAT']] = $order['SUM_QUANTITY'];
        }
        return $result;
    }

    private function showError($message)
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        echo json_encode(['status' => 'error', 'message' => $message], JSON_UNESCAPED_UNICODE);
        die;
    }

}