<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("ORGANIZER_SALES_STATISTICS_GRAPH_NAME"),
	"DESCRIPTION" => GetMessage("ORGANIZER_SALES_STATISTICS_GRAPH_DESCRIPTION"),
	"COMPLEX" => "N",
	"PATH" => array(
        "ID" => "custom",
        "CHILD" => array(
            "ID" => "orders",
            "NAME" => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT" => 20,
            "CHILD" => array(
                "ID" => 'organizer.sales.statistics.graph',
            )
        )
	),
);
?>