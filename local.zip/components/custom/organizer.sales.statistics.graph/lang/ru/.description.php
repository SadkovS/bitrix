<?php
$MESS["ORGANIZER_SALES_STATISTICS_GRAPH_NAME"] = "Просмотр графиков";
$MESS["ORGANIZER_SALES_STATISTICS_GRAPH_DESCRIPTION"] = "Позволяет просмотреть статистику продаж";
$MESS["C_HLDB_CAT_ORDERS"] = "Заказы";