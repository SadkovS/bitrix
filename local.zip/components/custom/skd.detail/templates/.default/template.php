<? if ( ! defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
	die();
}
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;

Loader::includeModule('custom.core');
$APPLICATION->RestartBuffer();

$isEdit = $arResult['ACTION'] === 'edit';
?>
	
	<form class="popup__content"
	      action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=<?= $arResult['ACTION'] ?>&ajax=y"
	      id="create-skd-form">
		<button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i></button>
		<div class="popup__name h2 wrap-balance"><?= $isEdit ? 'Редактирование ' : 'Добавление ' ?>доступа к СКД</div>
		
		<div class="skd-form__item required">
			<div class="finance-grid-itm__desc finance-grid-itm__clue">
				<span>Мероприятие</span>
			</div>
			
			<div class="search__body finance-grid-itm__line<?= $isEdit ? ' disabled' : ''; ?>" data-search="">

				<div class="search__form search__form--w100 js-search-page-g" data-url="<?= $arParams['SEF_FOLDER']?>">
					<input type="hidden" class="js-search-page-g-id" name="EVENT_ID" value="<?= $arResult['ITEM']['UF_EVENT_ID'] ?? ''?>">
					<input name="ev" <?= $isEdit ? ' readonly' : ''; ?> autocomplete="off" class="search__input" placeholder="Поиск" type="text" value="<?= $arResult['ITEM']['EVENT_NAME'] ?? ''?>">
					<ul class="search__list"></ul>
				</div>
			</div>

		</div>
		
		<div class="form-item required">
			<label class="form-item__label">ФИО</label>
			<span class="form__error"></span> <input class="form__underline-input" placeholder="Имя" type="text" name="FIO"
			                                         value="<?= $arResult['ITEM']['USER_FIO']; ?>"/>
		</div>
		
		<div class="skd-widget-form-itm js-skd-widget-select-wrap">
			<div class="skd-widget-form-itm__head">
				<div class="skd-widget-form-itm__title">Категории билетов</div>
				<div class="skd-widget-select js-skd-widget-select">
					<div class="skd-widget-select-btn">
						<a class="btn btn-sm js-skd-widget-select-btn" href=""><i class="_icon-plus"></i>Выбрать</a>
					</div>
					<div class="skd-widget-select-list" data-entry="ticket_types">
						<label class="skd-widget-select-itm js-all-skd-widget-select">
							<span class="skd-widget-select-itm__val">Все</span>
						</label>
						
						<? if (isset($arResult['TICKET_TYPES']) && is_array($arResult['TICKET_TYPES'])): ?>
							<? foreach ($arResult['TICKET_TYPES'] as $ticketType):?>
								<? if (isset($ticketType['ID']) && $ticketType['ID'] && isset($ticketType['NAME']) && $ticketType['NAME']): ?>
									<label class="skd-widget-select-itm">
										<input <?= in_array($ticketType['ID'], $arResult['ITEM']['UF_TICKETS_TYPE'] ?? []) ? 'checked' : ''?> type="checkbox" value="<?= $ticketType['ID']?>" name="TICKET_TYPES[]"> <span
											class="skd-widget-select-itm__val"><?= $ticketType['NAME']?></span>
									</label>
								<? endif; ?>
							<? endforeach; ?>
						<? endif; ?>
					</div>
				</div>
			</div>
			
			<div class="skd-widget-list js-skd-widget-select-list">
			
			</div>
		</div>
		
		<div class="skd-widget-form-itm js-skd-widget-select-wrap">
			<div class="skd-widget-form-itm__head">
				<div class="skd-widget-form-itm__title">Дата/даты на которую действует данный код доступа</div>
			</div>
			
			<div class="skd-widget-list js-skd-widget-select-list">
				<button class="skd-widget skd-widget--plus js-skd-widget-select-btn"></button>
			</div>
			
			<div class="js-skd-widget-select">
				<div class="skd-widget-select-list skd-widget-select-list--left" data-entry="dates">
					<label class="skd-widget-select-itm js-all-skd-widget-select">
						<span class="skd-widget-select-itm__val">Все</span>
					</label>
					<? if (isset($arResult['EVENT_DATES']) && is_array($arResult['EVENT_DATES'])): ?>
						<? foreach ($arResult['EVENT_DATES'] as $eventDate): ?>
							<? if (isset($eventDate['DATE_SHORT']) && $eventDate['DATE_SHORT'] && isset($eventDate['DATE']) && $eventDate['DATE']): ?>
								<label class="skd-widget-select-itm">
									<input <?= in_array($eventDate['DATE'], $arResult['ITEM']['UF_DATE'] ?? []) ? 'checked' : ''?> type="checkbox" value="<?= $eventDate['DATE_SHORT']?>" name="DATES[]"> <span
										class="skd-widget-select-itm__val"><?= $eventDate['DATE_SHORT']?></span>
								</label>
							<? endif; ?>
						<? endforeach; ?>
					<? endif; ?>
				</div>
			</div>
		</div>
		
		<div class="d-flex">
			<label class="form-switch me-2">
				<input type="checkbox" name="UF_IS_ALLOW_EXIT" <?= isset($arResult['ITEM']['UF_IS_ALLOW_EXIT']) && $arResult['ITEM']['UF_IS_ALLOW_EXIT'] ? 'checked': '' ?> value="1"/>
				<i class="slider round"></i>
			</label>
			<small>Разрешить вход/выход</small>
		</div>
		
		<div class="d-flex">
			<label class="form-switch me-2">
				<input type="checkbox" name="UF_IS_CONFIRMATION_REQUIRED" <?= isset($arResult['ITEM']['UF_IS_CONFIRMATION_REQUIRED']) && $arResult['ITEM']['UF_IS_CONFIRMATION_REQUIRED'] ? 'checked': '' ?> value="1"/>
				<i class="slider round"></i>
			</label>
			<small>Необходимость подтверждения или отклонения прохода</small>
		</div>
		
		<div class="row d-flex justify-content-end">
			<div class="col-auto">
				<button class="btn btn__blue btn__big"
				        type="submit"><?= $isEdit ? 'Сохранить' : 'Сгенерировать код' ?></button>
			</div>
		</div>
	</form>

<? die(); ?>