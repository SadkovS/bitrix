<?

if ( ! defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Custom\Core\PriceRules;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

if ( ! Loader::includeModule("highloadblock") || ! Loader::includeModule('custom.core') || ! Loader::includeModule('iblock')) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if ( ! isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    if (empty($arParams['ACTION'])) {
        throw new Exception('Не задан обязательный параметр action');
    }
    
    $itemId  = (int)$arParams['ELEMENT_ID'];
    
     if ($arParams['ACTION'] == 'eventGetInfo' && isset($request['ajax']) && $request['ajax'] === 'y' && isset($request['eventId']) && (int)$request['eventId'] > 0) {
         $APPLICATION->RestartBuffer();
         $eventId  = (int)$request['eventId'];
         
         $payload['dates'] = getEventDates($eventId);
         $payload['ticket_types'] = getTicketTypes($eventId);
         
         unset($eventId);
         
         echo json_encode(['status' => 'success', 'payload' => $payload], JSON_UNESCAPED_UNICODE);
         die;
     }
    
    if ($arParams['ACTION'] == 'getForm') {
  
        if ((int)$arParams['ELEMENT_ID'] > 0) {
            $arResult['ACTION'] = 'edit';
            
            $arResult['ITEM'] = getSkd($itemId, $companyID);
       
            if (isset($arResult['ITEM']['UF_EVENT_ID'])) {
                $arResult['EVENT_DATES'] = getEventDates((int)$arResult['ITEM']['UF_EVENT_ID']);
                $arResult['TICKET_TYPES'] = getTicketTypes((int)$arResult['ITEM']['UF_EVENT_ID']);
            } else {
                throw new Exception('СКД доступ не найден!');
            }
        } else {
            $arResult['ACTION'] = 'add';
        }
        
        $this->IncludeComponentTemplate();
    }
    
    if ($arParams['ACTION'] == 'edit' || $arParams['ACTION'] == 'add') {
        $APPLICATION->RestartBuffer();
	    
	    if (!isset($request['EVENT_ID']) || (int)$request['EVENT_ID'] < 1) {
		    throw new Exception('Мероприятие не выбрано!');
	    }
		
        if (!isset($request['FIO']) || mb_strlen(trim($request['FIO'])) < 1) {
            throw new Exception('ФИО не заполнено!');
        }
        
        if (!isset($request['TICKET_TYPES']) || empty($request['TICKET_TYPES'])) {
            throw new Exception('Категории билетов не выбраны!');
        }
        
        if (!isset($request['DATES']) || empty($request['DATES'])) {
            throw new Exception('Даты действия кода доступа не выбраны!');
        }
        
        $fio = preg_split('@\s@', preg_replace('@\s{2,}@', '', htmlspecialchars($request['FIO'] ?? '')), -1, PREG_SPLIT_NO_EMPTY);
        $ticketTypes = $request['TICKET_TYPES'] ?? [];
        
        $dates = $request['DATES'] ?? [];
        $dates = count($dates) > 0 ? array_map(fn($item) => \DateTime::createFromFormat('d.m.y', $item)->format('d.m.Y'), $dates) : [];
        
        $entitySkdAccess   = HL\HighloadBlockTable::compileEntity('AccessSKD');
        $hlbClassSkdAccess = $entitySkdAccess->getDataClass();
        
        if ($arParams['ACTION'] == 'edit' && $itemId > 0) { // update
            $skd = getSkd($itemId, $companyID);
            
            if (!$skd) {
                throw new Exception('СКД доступ не найден!');
            }
            
            if ($userId = $skd['UF_USER_ID']) {
				$arrData = [
		            'NAME' => $fio[1] ?? '',
		            'LAST_NAME' => $fio[0] ?? '',
		            'SECOND_NAME' => $fio[2] ?? '',
	            ];
	            $user = new \CUser;
	            $user->update($userId, $arrData);
	            
	            if($user->LAST_ERROR) {
		            throw new Exception($user->LAST_ERROR);
	            }
            }
            
            $resUpdate                        = $hlbClassSkdAccess::update($skd['ID'], [
                'UF_TICKETS_TYPE' => $ticketTypes,
                'UF_DATE' => $dates,
                'UF_IS_ALLOW_EXIT' => isset($request['UF_IS_ALLOW_EXIT']) ? 1 : 0,
                'UF_IS_CONFIRMATION_REQUIRED' => isset($request['UF_IS_CONFIRMATION_REQUIRED']) ? 1 : 0,
            ]);
            if (!$resUpdate->isSuccess()) throw new \Exception(str_replace('<br>', ';', implode(', ', $resUpdate->getErrors())));
            
        } else { // create
            $arrData = [
                'NAME' => $fio[1] ?? '',
                'LAST_NAME' => $fio[0] ?? '',
                'SECOND_NAME' => $fio[2] ?? '',
                'EMAIL' =>  microtime(true) . "@mail.test",
                'PASSWORD' => \Custom\Core\Helper::genPass(),
            ];
            
            $user = new \CUser;
            $arFields = [
                "NAME" => $arrData['NAME'],
                "LAST_NAME" => $arrData['LAST_NAME'],
                "SECOND_NAME" => $arrData['SECOND_NAME'],
                "EMAIL" => $arrData['EMAIL'],
                "LOGIN" => $arrData['EMAIL'],
                "ACTIVE" => "Y",
                "PASSWORD" => $arrData['PASSWORD'],
                "CONFIRM_PASSWORD" => $arrData['PASSWORD'],
            ];
            
            $controllerGroupId = Custom\Core\Helper::getGroupByCode('controllers')['ID'] ?? null;
            if ($controllerGroupId) {
                $arFields['GROUP_ID'] = [$controllerGroupId];
            }
            
            $userId = $user->Add($arFields);
            if (intval($userId) > 0) {
                $token = helper()->generateToken($userId, $arFields['LOGIN']);
                $user->Update($userId, ['UF_REST_API_TOKEN' => $token, "UF_API_TOKEN_EXPIRE" => date('d.m.Y', strtotime('+3 years'))]);
                
                if($user->LAST_ERROR) {
                    $user->delete($userId);
                    throw new Exception($user->LAST_ERROR);
                }
	       
                $resAdd                        = $hlbClassSkdAccess::add([
                    'UF_EVENT_ID' => (int)$request['EVENT_ID'],
                    'UF_USER_ID' => (int)$userId,
                    'UF_TICKETS_TYPE' => $ticketTypes,
                    'UF_DATE' => $dates,
                    'UF_IS_ALLOW_EXIT' => isset($request['UF_IS_ALLOW_EXIT']) ? 1 : 0,
                    'UF_IS_CONFIRMATION_REQUIRED' => isset($request['UF_IS_CONFIRMATION_REQUIRED']) ? 1 : 0,
                ]);
                
                if (!$resAdd->isSuccess()) {
                    throw new Exception(str_replace('<br>', ';', implode(', ', $resAdd->getErrors())));
                }
	           
            } else {
                throw new Exception($user->LAST_ERROR);
            }
        }
        
        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }
    
    if ($arParams['ACTION'] == 'del') {
        $APPLICATION->RestartBuffer();
        
        if ( ! (isset($request['ID']) && is_numeric($request['ID']))) {
            throw new Exception('Неверный параметр ID');
        }
        
        $skd = getSkd($itemId, $companyID);
        
        if (!$skd) {
            throw new Exception('СКД доступ не найден!');
        }
        
        if ($userId = $skd['UF_USER_ID']) {
            \CUser::Delete($userId);
        }
        
        $historyEntity = new ORM\Query\Query('Custom\Core\Skd\HistorySKDTable');
        $historyQuery   = $historyEntity->setSelect(['ID'])->setFilter(
            ['UF_ACCESS_SKD_ID' => $skd['ID']]
        )->exec();
        
        while ($historyItem = $historyQuery->fetchObject()) {
            $historyItem->delete();
        }
        
        $entityAccessSkd   = HL\HighloadBlockTable::compileEntity('AccessSKD');
        $hlbClassAccessSkd = $entityAccessSkd->getDataClass();
        
        $hlbClassAccessSkd::delete($skd['ID']);
        
        echo json_encode(['status' => 'success', 'title' => 'Удаление', 'message' => 'Доступ СКД успешно удален'], JSON_UNESCAPED_UNICODE);
        die;
    }
    
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}


/**
 * @param int $id
 * @param int $companyId
 *
 * @return array|false
 * @throws DateMalformedStringException
 */
function getSkd(int $id, int $companyId): array|false
{
    $skdEntity                      = new ORM\Query\Query('Custom\Core\Skd\AccessSKDTable');
    $query                            = $skdEntity
        ->setSelect(
            [
                'ID',
                'UF_USER_ID',
                'UF_EVENT_ID',
                'UF_DATE',
                'UF_TICKETS_TYPE',
                //'DATE',
                'TICKETS_TYPE',
                'UF_IS_ALLOW_EXIT',
                'UF_IS_CONFIRMATION_REQUIRED',
                'EVENT_NAME' => 'REF_EVENT.UF_NAME',
                'COMPANY_ID' => 'REF_EVENT.UF_COMPANY_ID',
                'EVENT_STATUS' => 'REF_EVENT.UF_STATUS',
                'TOKEN'      => 'REF_USER.UF_REST_API_TOKEN',
                'USER_FIO',
            ]
        )
        ->setFilter([
                        'ID' => $id,
                        //'EVENT_STATUS' => EVENT_STATUS_PUBLISHED,
                        'COMPANY_ID' => $companyId,
                    ])
        ->setLimit(1)
        ->exec();
    
    $res = $query->fetch();
    
    if ($res) {
        $res['UF_DATE'] = array_map(fn($d) => (new \DateTime($d))->format('d.m.Y'), $res['UF_DATE']);
    }
    
    return $res;
}

/**
 * @param int $eventsId
 *
 * @return array
 */
function getEventDates(int $eventsId): array
{
    $hlblLocation     = HL\HighloadBlockTable::getById(HL_EVENTS_LOCATION_ID)->fetch();
    $entityLocation   = HL\HighloadBlockTable::compileEntity($hlblLocation);
    $hlbClassLocation = $entityLocation->getDataClass();
    
    $obElement                        = $hlbClassLocation::getList(
        [
            'select' => [
                'UF_DATE_TIME',
            ],
            'filter' => ['UF_EVENT_ID' => $eventsId],
        ]
    );
    $arDates              = [];
    while ($location = $obElement->fetch()) {
        if (is_array($location['UF_DATE_TIME']) && count($location['UF_DATE_TIME']) > 0) {
            foreach ($location['UF_DATE_TIME'] as $key => $dateItem) {
                $dateTimeStart                   = ($dateItem)->format('d.m.Y H:i');
                $currentDate                     = ($dateItem)->format('d.m.Y');
                $currentDateShort                = ($dateItem)->format('d.m.y');
                $timeStamp                       = strtotime($dateTimeStart);
                $arDates[$timeStamp] = [
                    'DATE'              => $currentDate,
                    'DATE_SHORT'        => $currentDateShort,
                ];
            }
            unset($dateItem, $key);
        } else {
            $dateTimeStart                   = (new DateTime())->format('d.m.Y H:i');
            $currentDate                     = new DateTime();
            $currentDateShort                = $currentDate->format('d.m.y');
            $currentDate                     = $currentDate->format('d.m.Y');
            $timeStamp                       = strtotime($dateTimeStart);
            
            $arDates[$timeStamp] = [
                'DATE'              => $currentDate,
                'DATE_SHORT'        => $currentDateShort
            ];
        }
    }
    ksort($arDates, SORT_NUMERIC);
    return $arDates;
}

function getTicketTypes(int $eventsId): array
{
    $res = [];
    $elementEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
    $propField     = $elementEntity->getField('CML2_LINK');
    $propEntity    = $propField->getRefEntity();
    
    $offerEntity         = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
    $propFieldType       = $offerEntity->getField('TYPE');
    $propFieldTypeEntity = $propFieldType->getRefEntity();
    
    $eventTicketsType = \Bitrix\Iblock\Elements\ElementTicketsTable::getList(
        [
            'select'  => [
                'OFFER_ID'             => 'OFFER.ID',
                'OFFER_NAME'           => 'TICKET_TYPE_REF.VALUE',
            ],
            'filter'  => ['EVENT_ID.VALUE' => $eventsId],
            'runtime' => [
                new \Bitrix\Main\Entity\ReferenceField(
                    'TICKETS',
                    $propEntity,
                    ['this.ID' => 'ref.VALUE'],
                    ['join_type' => 'LEFT'],
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'OFFER',
                    $elementEntity,
                    ['this.TICKETS.IBLOCK_ELEMENT_ID' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'TICKET_TYPE_REF',
                    $propFieldTypeEntity,
                    ['this.OFFER.ID' => 'ref.IBLOCK_ELEMENT_ID'],
                    ['join_type' => 'LEFT'],
                ),
            ]
        ]
    );
    while ($sku = $eventTicketsType->fetch()) {
        $res[$sku['OFFER_ID']] = [
            'ID' => $sku['OFFER_ID'],
            'NAME' => $sku['OFFER_NAME'],
        ];
    }
    
    return $res;
}

?>
