<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

/** @var array $arCurrentValues */

$arComponentParameters = [
    "GROUPS"     => [
    ],
    "PARAMETERS" => [
	    "HLB_SKD_ACCESS_ID" => [
		    "PARENT" => "BASE",
		    "NAME" => GetMessage("HLB_SKD_ACCESS_ID"),
		    "TYPE" => "STRING",
		    "DEFAULT" => '',
	    ],
	    "HLB_SKD_HISTORY_ID" => [
		    "PARENT" => "BASE",
		    "NAME" => GetMessage("HLB_SKD_HISTORY_ID"),
		    "TYPE" => "STRING",
		    "DEFAULT" => '',
	    ],
        "CACHE_TIME"   => ["DEFAULT" => 180],
        "CACHE_GROUPS" => [
            "PARENT"  => "CACHE_SETTINGS",
            "NAME"    => GetMessage("CP_BPR_CACHE_GROUPS"),
            "TYPE"    => "CHECKBOX",
            "DEFAULT" => "Y",
        ],
    ],
];
