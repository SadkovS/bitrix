<?
$MESS["HLB_SKD_ACCESS_ID"] = "ID хайлоадблока доступов СКД";
$MESS["HLB_SKD_HISTORY_ID"] = "ID хайлоадблока истории СКД";
$MESS["IBLOCK_ANY"]          = "(любой)";
$MESS["CP_BPR_CACHE_GROUPS"] = "Учитывать права доступа";
?>