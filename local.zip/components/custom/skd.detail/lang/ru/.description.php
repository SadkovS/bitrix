<?
$MESS ['SKD_DETAIL_NAME'] = "СКД элемент";
$MESS ['SKD_DETAIL_DESC'] = "Показывает СКД элемент";
$MESS ['C_HLDB_CAT_SKD']  = "СКД доступы";
?>