<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME"        => GetMessage("SKD_DETAIL_NAME"),
    "DESCRIPTION" => GetMessage("SKD_DETAIL_DESC"),
    "CACHE_PATH"  => "Y",
    "SORT"        => 40,
    "PATH"        => [
        "ID"    => "custom",
        "CHILD" => [
            "ID"    => "skd",
            "NAME"  => GetMessage("C_HLDB_CAT_SKD"),
            "SORT"  => 20,
            "CHILD" => [
                "ID" => 'skd_detail',
            ]
        ]
    ],
];
?>