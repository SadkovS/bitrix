<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => GetMessage("HLB_COUPONS_AND_DISCOUNTS"),
    "DESCRIPTION" => GetMessage("HLB_COUPONS_AND_DISCOUNTS_DESC"),
    "CACHE_PATH" => "Y",
    "SORT" => 40,
    "PATH" => array(
        "ID" => "custom",
        "CHILD" => array(
            "ID" => "events",
            "NAME" => GetMessage("HLB_EVENTS_DESC"),
            "SORT" => 20,
        )
    ),
);

?>