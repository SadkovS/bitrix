<?
$MESS ['HLB_COUPONS_AND_DISCOUNTS'] = "Список купонов и скидок";
$MESS ['HLB_COUPONS_AND_DISCOUNTS_DESC'] = "Показывает список купонов и скидок организатора";
$MESS ['HLB_EVENTS_DESC'] = "События";
?>