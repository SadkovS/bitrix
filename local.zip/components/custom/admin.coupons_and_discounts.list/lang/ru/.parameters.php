<?
$MESS["IBLOCK_ANY"] = "(любой)";
$MESS["CP_BPR_CACHE_GROUPS"] = "Учитывать права доступа";
$MESS["DISCOUNT_PER_PAGE"] = "Количество скидок на странице";
?>