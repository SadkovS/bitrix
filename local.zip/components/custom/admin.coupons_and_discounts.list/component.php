<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */


use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\ORM;
use Custom\Core\Events\EventsTable;

$limit   = (int)$arParams['DISCOUNT_PER_PAGE'] ?: 10;
$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
Loader::includeModule('custom.core');
//Loader::includeModule('sale');
//Loader::includeModule("catalog");

$curPage = (int)$request['PAGEN_1'] > 0 ? (int)$request['PAGEN_1'] : 1;
if (!isset($_REQUEST['PAGEN_1']) || (int)$_REQUEST['PAGEN_1'] <= 1)
    $offset = 0;
else
    $offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $limit;

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"]))
    $arParams["CACHE_TIME"] = 180;
$query                   = new ORM\Query\Query('\Custom\Core\FieldEnumTable');
$this->arResult['TYPES'] = [];
$resType                 = $query
    ->setSelect(['ID', 'UF_NAME' => 'VALUE'])
    ->setOrder(['SORT' => 'ASC'])
    ->setFilter(['USER_FIELD_ID' => 121])
    ->setCacheTtl(3600)
    ->exec();
while ($type = $resType->fetch()) {
    $this->arResult['TYPES'][$type['ID']] = $type;
}
unset($query, $resType, $type);

$query                           = new ORM\Query\Query('\Custom\Core\FieldEnumTable');
$this->arResult['DISCOUNT_TYPE'] = [];
$resType                         = $query
    ->setSelect(['ID', 'UF_NAME' => 'VALUE'])
    ->setOrder(['SORT' => 'ASC'])
    ->setFilter(['USER_FIELD_ID' => 112])
    ->setCacheTtl(3600)
    ->exec();
while ($type = $resType->fetch()) {
    $this->arResult['DISCOUNT_TYPE'][$type['ID']] = $type;
}
unset($query, $resType, $type);

$filter = ['REF_EVENTS.UF_COMPANY_ID' => $companyID];

if (isset($request['q']) && $request['q'] != '') {
    $filter['%UF_NAME'] = $request['q'];
}

if (isset($request['dsct']) && (int)$request['dsct'] > 0) {
    $filter['UF_DISCOUNT'] = $request['dsct'];
}

if (isset($request['ds']) && $request['ds'] != '') {
    $date_start = DateTime::createFromFormat('d.m.y', $request['ds'])->format('d.m.Y');
    $filter[]   = [
        "LOGIC" => 'OR',
        [">=UF_DATE_START" => $date_start],
        ["UF_DATE_START" => false],
    ];
}

if (isset($request['de']) && $request['de'] != '') {
    $date_send = DateTime::createFromFormat('d.m.y', $request['de'])->format('d.m.Y');
    $filter[]  = [
        "LOGIC" => 'OR',
        ["<=UF_DATE_END" => $date_send],
        ["UF_DATE_END" => false],
    ];
}

if (isset($request['events']) && is_array($request['events']) && count($request['events']) > 0) {
    $filter[] = [
        "LOGIC" => 'OR',
        ['REF_EVENTS.ID' => $request['events']],
    ];
}

switch ($request['sort']) {
    case 'old':
        $order = ['ID' => 'ASC'];
        break;
    case 'date_a':
        $order = ['UF_DATE_START' => 'ASC'];
        break;
    case 'date_d':
        $order = ['UF_DATE_START' => 'DESC'];
        break;
    case 'dscnt_a':
        $order = ['UF_DISCOUNT' => 'ASC'];
        break;
    case 'dscnt_d':
        $order = ['UF_DISCOUNT' => 'DESC'];
        break;
    default:
        $order = ['ID' => 'DESC'];
        break;
}

if (isset($request['ACTION']) && $request['ACTION'] == 'eSearch') {

    $APPLICATION->RestartBuffer();
    $eventEntity             = new ORM\Query\Query('Custom\Core\Events\EventsTable');
    $selected                = $request['events'] ?? [];
    $filter                  = [];

    $filter['UF_COMPANY_ID'] = $companyID;

    if (isset($request['es_q']) && $request['es_q'] != '') {
        $filter['%TITLE'] = trim($request['es_q']);
    }
    if (isset($request['events']) && is_array($request['events']) && count($request['events']) > 0) {
        unset($filter['%TITLE']);
        $filter[] = ['LOGIC' => 'OR',
                     ['%TITLE' => $request['es_q']],
                     ['ID' => $request['events']]];
    }

    $query = $eventEntity
        ->setSelect(
            [
                'ID',
                'TITLE'         => 'UF_NAME',
                'DATE_TIME'     => 'UF_LOCATION_REF.DATE_TIME.VALUE',
                'CATEGORY_NAME' => 'UF_CATEGORY_REF.UF_NAME',
            ]
        )
        ->setFilter($filter)
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ReferenceField(
                'UF_CATEGORY_REF',
                '\Custom\Core\Events\EventsCategoryTable',
                ['this.UF_CATEGORY' => 'ref.ID'],
                ['join_type' => 'LEFT']
            )
        )
        ->setLimit(count($selected) + 10)
        ->countTotal(true)
        ->exec();

    $result = [];

    while ($event = $query->fetch()) {
        $arSub = [];
        if (is_object($event['DATE_TIME'])) $event['DATE_TIME'] = $event['DATE_TIME']->format('d.m.Y H:i');
        if ($event['CATEGORY_NAME']) $arSub[] = $event['CATEGORY_NAME'];
        if ($event['DATE_TIME']) $arSub[] = $event['DATE_TIME'];
        unset($event['CATEGORY_NAME'], $event['DATE_TIME']);
        $event['SUB_TITLE']   = implode(', ', $arSub);
        $result[$event['ID']] = $event;
    }

    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    die;
}
if (isset($request['ACTION']) && $request['ACTION'] == 'export') $limit = 10000;
$discountEntity              = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');
$query                       = $discountEntity
    ->setSelect(['*'])
    ->setOffset($offset)
    ->setLimit($limit)
    ->setOrder($order)
    ->setFilter($filter)
    ->setGroup('ID')
    ->countTotal(true)
    ->exec();
$arEvents                    = [];
$arOffers                    = [];
$this->arResult['ALL_COUNT'] = $query->getCount();
while ($discount = $query->fetch()) {
    $date = (new DateTime())->format('d.m.Y');
    if (is_object($discount['UF_DATE_START'])) $discount['UF_DATE_START'] = $discount['UF_DATE_START']->format('d.m.y');
    if (is_object($discount['UF_DATE_END'])) {
        $date_end                = $discount['UF_DATE_END']->format('d.m.Y');
        $discount['UF_DATE_END'] = $discount['UF_DATE_END']->format('d.m.y');
    } else {
        $date_end = $date;
    }

    $arEvents                                 = array_merge($arEvents, $discount['UF_EVENT_ID']);
    $arOffers                                 = array_merge($arOffers, $discount['UF_TICKETS_TYPE']);
    $this->arResult['ITEMS'][$discount['ID']] = $discount;
}

$arEvents = array_unique($arEvents);
$arOffers = array_unique($arOffers);

if (count($arEvents) > 0) {
    $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
    $query       = $eventEntity
        ->setSelect(['ID', 'UF_NAME'])
        ->setFilter(['ID' => $arEvents])
        ->exec();
    while ($event = $query->fetch()) {
        $this->arResult['EVENTS'][$event['ID']] = $event;
    }
}

if (count($arOffers) > 0) {
    $elementEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
    $query         = new ORM\Query\Query($elementEntity);
    $query         = $query
        ->setSelect(['ID', 'UF_NAME' => 'TYPE.VALUE'])
        ->setFilter(['ID' => $arOffers])
        ->exec();
    while ($offer = $query->fetch()) {
        $this->arResult['OFFERS'][$offer['ID']] = $offer;
    }
}
if (isset($request['ACTION']) && $request['ACTION'] == 'export')
    require_once 'export_excel.php';

$this->nav = new \CDBResult();
$this->nav->NavStart($arParams['DISCOUNT_PER_PAGE']);
$this->nav->NavPageCount      = ceil((int)$arResult['ALL_COUNT'] / $limit);
$this->nav->NavPageNomer      = $curPage;
$this->nav->NavRecordCount    = $arResult['ALL_COUNT'];
$this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');

$this->IncludeComponentTemplate();
//$this->AbortResultCache();
?>
