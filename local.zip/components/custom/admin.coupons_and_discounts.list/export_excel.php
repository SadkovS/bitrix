<?

//if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
use Bitrix\Main\ORM;
use Custom\Core\ExportExcel;

$arrColumns = [
    'title'           => ['name' => 'Название'],
    'type'            => ['name' => 'Тип'],
    'discount'        => ['name' => 'Скидка'],
    'number_of_uses'  => ['name' => 'Количество использований / всего'],
    'validity_period' => ['name' => 'Срок действия'],
    'event'           => ['name' => 'Мероприятие'],
    'type_of_tickets' => ['name' => 'Типы билетов'],
    'status'          => ['name' => 'Статус'],
];
$date = new DateTime();
$date = $date->format('d.m.Y H:i');
$obExport = new ExportExcel();
$obExport->setFileName("Выгрузка статистики промокодов и скидок от " . $date .'.xlsx');

$obExport->setFilePath($_SERVER['DOCUMENT_ROOT'] . '/upload/tmp');
$xls = $obExport->createFile();
$xls->getProperties()->setTitle("Выгрузка статистики");
$xls->getProperties()->setCreated($date);
$xls->setActiveSheetIndex(0);
$sheet = $xls->getActiveSheet();
$sheet->setTitle('Выгрузка статистики');
$sheet->getRowDimension("1")->setRowHeight(50);
$sheet->getRowDimension("2")->setRowHeight(30);
$sheet->getRowDimension("3")->setRowHeight(40);
$sheet->setCellValue("A1", "Выгрузка статистики промокодов и скидок от " . $date);
$sheet->mergeCells("A1:H1");
$sheet->getStyle("A1")->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$sheet->getStyle("A1")->getFont()->setSize(22);
$sheet->getStyle("A1")->getFont()->setBold(true);

$i            = 0;
$rowNum       = 4;
$columnsCount = 0;
$arTable      = [];
foreach ($arResult['ITEMS'] as $row) {
    $colHead = $arrColumns;
    if ($i == 0) {
        $arTable['HEAD'] = array_values($colHead);
    }
    foreach ($colHead as $key => &$col) {
        if ($key == 'title') $col['value'] = $row['UF_NAME'];
        elseif ($key == 'type') $col['value'] = $arResult['TYPES'][$row['UF_TYPE']]['UF_NAME'];
        elseif ($key == 'discount') $col['value'] = $row['UF_DISCOUNT'].($arResult['DISCOUNT_TYPE'][$row['UF_DISCOUNT_TYPE']]['UF_NAME'] == 'Проценты' ? '%' : '₽');
        elseif ($key == 'number_of_uses'){
            $col['value'] = (int)$row['UF_NUMBER_OF_USES'];
            if($arResult['TYPES'][$row['UF_TYPE']]['UF_NAME'] == 'Группа')
                $col['value'] .= ' / '.(int)$row['COUNT_CODES'];
            else
                $col['value'] .= ' / '.((int)$row['UF_MAX_NUMBER_OF_USES'] > 0 ?$row['UF_MAX_NUMBER_OF_USES']: '∞');
        }
        elseif ($key == 'validity_period') $col['value'] = ($row['UF_DATE_START'] ?: '∞') . ' - ' . ($row['UF_DATE_END'] ?: '∞') ;
        elseif ($key == 'event'){
            $arEventName = [];
            foreach ($row['UF_EVENT_ID'] as $event_id)
                $arEventName[] = $arResult['EVENTS'][$event_id]['UF_NAME'];
            $col['value'] = implode(', ', $arEventName);
            unset($event_id, $arEventName);
        }
        elseif ($key == 'type_of_tickets'){
            $arTicketName = [];
            foreach ($row['UF_TICKETS_TYPE'] as $offer_id)
                $arTicketName[] = $arResult['OFFERS'][$offer_id]['UF_NAME'];
            $col['value'] = implode(', ', $arTicketName);
            unset($offer_id, $arTicketName);
        }
        elseif ($key == 'status'){
            $col['value'] = $row['UF_IS_ACTIVITY'] ? 'Активен' : 'Не активен';
        }
    }
    $arTable['BODY'][] = $colHead;
}
foreach ($arTable['HEAD'] as $key => $headItem) {
    $colLetter = $obExport->getColumnLetter($key + 1);
    $sheet->setCellValue($colLetter . '3', $headItem['name']??'');
    $sheet->getStyle($colLetter . '3')->getFont()->setSize(14);
    $sheet->getStyle($colLetter . '3')->getFont()->setBold(true);
    $sheet->getStyle($colLetter . '3')->getFont()->setItalic(true);
    $sheet->getStyle($colLetter . '3')->applyFromArray([
                                                           'fill' => array(
                                                               'type' => PHPExcel_Style_Fill::FILL_SOLID,
                                                               'color' => array('rgb' => 'e4efdc')
                                                           )
                                                       ]);
    $sheet->getStyle($colLetter . '3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle($colLetter . '3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
unset($key,$row,$i);
foreach ($arTable['BODY'] as $key => $row) {
    $i = 0;
    foreach ($row as $keyCol => $colID) {
        $indexCol = $i + 1;
        $colLetter = $obExport->getColumnLetter($indexCol);
        if(strlen(strip_tags($colID['value']??'')) > 300){
            $sheet->getColumnDimension($colLetter)->setAutoSize(false);
            $sheet->getColumnDimension($colLetter)->setWidth(150);
        }
        $sheet->setCellValue($colLetter . $rowNum, strip_tags($colID['value']??''));
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setWrapText(true);
        $sheet->getStyle($colLetter . $rowNum)->getFont()->setSize(14);
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        if($keyCol == '_status'){
            $styleStatus = $obExport->getStatusStyle(strip_tags($colID['value']));
            $sheet->getStyle($colLetter . $rowNum)->applyFromArray([
                                                                       'fill' => array(
                                                                           'type' => PHPExcel_Style_Fill::FILL_SOLID,
                                                                           'color' => array('rgb' => $styleStatus['background'])
                                                                       )
                                                                   ]);
            $sheet->getStyle($colLetter . $rowNum)->getFont()->getColor()->setRGB($styleStatus['color']);
            $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
        }
        $i++;
    }
    $rowNum ++;
}
$endColLetter = $obExport->getColumnLetter(count($arTable['HEAD']));
$sheet->getStyle("A3:".$endColLetter.($rowNum-1))->applyFromArray($obExport->getBorderStyle());
$obExport->downloadFile($xls);

exit;