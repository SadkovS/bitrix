<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Application;
use Bitrix\Main\Page\Asset;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");
?>
<div class="admin-body__item wide events promo" data-custom-navigation>
    <div class="admin-body__item-header">
        <h1>Скидки и промокоды</h1>
        <div class="events__create">
            <button type="button" class="btn btn__clear" data-promo-statistic="ACTION=export" download>
                <i>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                        <g clip-path="url(#clip0_4180_17874)">
                            <path d="M12.375 17.998H5.625C4.69308 17.9634 4.69378 16.626 5.625 16.5917H12.375C13.3069 16.6263 13.3062 17.9638 12.375 17.998ZM13.7812 15.1855H4.21801C1.89221 15.1855 0 13.2933 0 10.9674V5.20112C0 2.8749 1.89253 0.982369 4.21875 0.982369H6.15234C7.08427 1.01693 7.08356 2.35438 6.15234 2.38862H4.21875C2.66794 2.38862 1.40625 3.65031 1.40625 5.20112V10.9674C1.40625 12.5179 2.66762 13.7792 4.21801 13.7792H13.7812C15.3321 13.7792 16.5938 12.5175 16.5938 10.9667V5.20108C16.5938 3.65027 15.3321 2.38858 13.7812 2.38858H11.7773C10.8454 2.35403 10.8461 1.01658 11.7773 0.982334H13.7812C16.1075 0.982334 18 2.87487 18 5.20108V10.9667C18 13.293 16.1075 15.1855 13.7812 15.1855ZM9.01758 10.4384C8.46527 10.4385 7.91206 10.2271 7.49292 9.80557L6.17977 8.47178C5.9073 8.19506 5.91082 7.74988 6.18754 7.47745C6.46425 7.20499 6.90943 7.20847 7.18186 7.48522L8.49284 8.8168C8.7827 9.10487 9.25249 9.10487 9.54239 8.8168L10.8534 7.48522C11.1258 7.20847 11.571 7.20499 11.8477 7.47745C12.1244 7.74988 12.1279 8.19506 11.8555 8.47178L10.5423 9.80557C10.1231 10.2271 9.56988 10.4385 9.01758 10.4384ZM9 7.31049C8.61166 7.31049 8.29688 6.9957 8.29688 6.60737V0.701119C8.33143 -0.230803 9.66888 -0.2301 9.70312 0.701119V6.60737C9.70312 6.9957 9.38834 7.31049 9 7.31049Z"
                                  fill="#919DAC"/>
                        </g>
                        <defs>
                            <clipPath id="clip0_4180_17874">
                                <rect width="18" height="18" fill="white"/>
                            </clipPath>
                        </defs>
                    </svg>
                </i>
                Выгрузка статистики
            </button>
        </div>
    </div>
    <div class="admin-body__item-sort">
        <div class="promo__list" data-promo-filters>
            <div class="promo__item reset" data-promo-filters-reset>
                <span>Сбросить фильтры</span>
                <i class="_icon-plus"></i>
            </div>
        </div>
        <div class="admin-body__item-sort-form">
            <div class="form-select js-form-select sort__select">
                <div class="form-select__selected-option js-form-select-option js-option-change"
                     data-placeholder="Выберите из списка">Сначала новые
                </div>
                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                <div class="form-select-options-wrap js-form-select-options-wrap">
                    <ul class="form-select-options form-select__options">
                        <li class="form-select-options__item js-form-select-options-item _icon-checkbox"
                            data-option="new"><span>Сначала новые</span></li>
                        <li class="form-select-options__item js-form-select-options-item" data-option="old"><span>Сначала старые</span>
                        </li>
                        <li class="form-select-options__item js-form-select-options-item" data-option="date_a"><span>Срок действия: раньше</span>
                        </li>
                        <li class="form-select-options__item js-form-select-options-item" data-option="date_d"><span>Срок действия: позже</span>
                        </li>
                        <li class="form-select-options__item js-form-select-options-item" data-option="dscnt_a"><span>По возрастанию скидки</span>
                        </li>
                        <li class="form-select-options__item js-form-select-options-item" data-option="dscnt_d"><span>По убыванию скидки</span>
                        </li>
                    </ul>
                </div>
                <input type="hidden" name="sort" value="" data-url-search="change">
            </div>
        </div>
    </div>
    <table class="events__table ">
        <thead>
        <tr>
            <td>
                <div class="events__table-item">
                    <div class="events__form-item lg">
                        <input type="text" name="q" class="events__form-input" value="<?= $request['q'] ?>"
                               placeholder="Название" data-url-search="input">
                        <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item text-center">
                    <p>Тип</p>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <div class="events__form-item med">
                        <input type="text" name="dsct" value="<?= $request['dsct'] ?>" class="events__form-input"
                               placeholder="Скидка" data-url-search="input">
                        <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item text-center">
                    <p>Использовано <br>
                         / всего</p>
                </div>
            </td>
            <td>
                <div class="events__table-item align-items-center">
                    <p>Срок действия</p>
                    <div class="date__split">
                        <input type="text" name="ds" value="<?= $request['ds'] ?>" placeholder="дд.мм.гг"
                               class="promo-date input__bordered"
                               data-date="" data-date-split-start="" data-formatted-date readonly=""
                               data-url-search="change">
                        -
                        <input type="text" name="de" value="<?= $request['de'] ?>" placeholder="дд.мм.гг"
                               class="promo-date input__bordered"
                               data-date="" data-date-split-end="" data-formatted-date readonly=""
                               data-url-search="change">
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <div action="#" class="events__form-item events__form-multyple-item">
                        <div class="form-select__multyple" data-multyple-search-select>
                            <button type="button" class="form-select__search" data-multyple-search-select-btn>
                                <i class="_icon-search"></i>
                            </button>
                            <input class="form-select__selected-option" placeholder="Мероприятие промокода"
                                   data-multyple-search-select-input>
                            <i class="form-select__icon _icon-chev" data-multyple-search-select-open></i>
                            <div class="form-select-options-wrap" data-multyple-search-select-options>
                                <ul class="form-select-options">

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </td>

            <td>
                <div class="events__table-item">
                    <p>Типы билетов</p>
                </div>
            </td>
            <td>
                <div class="events__table-item text-center">
                    <p>Статус</p>
                </div>
            </td>
            <td></td>
        </tr>
        </thead>
        <tbody>
        <? foreach ($arResult['ITEMS'] as $item): ?>
            <tr>
                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?= $item['UF_NAME'] ?></p>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name text-center">
                            <p class="color__grey"><?= $arResult['TYPES'][$item['UF_TYPE']]['UF_NAME'] ?></p>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name text-center">
                            <p><?= $item['UF_DISCOUNT'] ?><?= $arResult['DISCOUNT_TYPE'][$item['UF_DISCOUNT_TYPE']]['UF_NAME'] == 'Проценты' ? '%' : '₽' ?></p>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item text-center">
                        <p>
                            <?= (int)$item['UF_NUMBER_OF_USES'] ?> / <?= $item['UF_MAX_NUMBER_OF_USES'] ?: '∞' ?>
                        </p>
                    </div>
                </td>

                <td>
                    <div class="events__table-item text-center">
                        <p><?= $item['UF_DATE_START'] ?: '∞' ?> - <?= $item['UF_DATE_END'] ?: '∞' ?></p>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
                        <div class="promo__list">
                            <? foreach ($item['UF_EVENT_ID'] as $event_id): ?>
                                <div class="promo__item">
                                    <span><?= $arResult['EVENTS'][$event_id]['UF_NAME'] ?></span>
                                    <!--                                    <i class="_icon-plus"></i>-->
                                </div>
                            <? endforeach; ?>

                            <!--                            <div class="promo__item">-->
                            <!--                                <span>+2</span>-->
                            <!--                            </div>-->
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <div class="promo__list">
                            <? if ((int)$item['UF_TICKETS_TYPE'][0] > 0): ?>
                                <div class="promo__item">
                                    <span><?= $arResult['OFFERS'][$item['UF_TICKETS_TYPE'][0]]['UF_NAME'] ?></span>
                                    <!--                                    <i class="_icon-plus"></i>-->
                                </div>
                            <? endif; ?>
                            <? if (count($item['UF_TICKETS_TYPE']) > 1): ?>
                                <div class="promo__item">
                                    <span>+<?= count($item['UF_TICKETS_TYPE']) - 1 ?></span>
                                </div>
                            <? endif; ?>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item js-price-rule-activity">
                        <? if ($item['UF_IS_ACTIVITY']): ?>
                            <div class="status__active">Активен</div>
                        <? else: ?>
                            <div class="status__inactive">Не активен</div>
                        <? endif; ?>
                    </div>
                </td>
                <td>
                    <div class="events__table-controls" data-event-controls>
                        <button type="button" class="btn__icon" data-event-controls-btn>
                            <i class="_icon-rounds"></i>
                        </button>
                        <div class="events__table-controls-body" data-event-controls-body>
                            <ul>
                                <? if ($item['UF_IS_ACTIVITY']): ?>
                                    <li><a href="javascript:void(0);"
                                           data-price-rule-activity="/admin_panel/price_rules/<?= $item['ID'] ?>/?action=setActivity&ajax=y&event-id=<?= $item['UF_EVENT_ID'][0] ?>">Деактивировать</a>
                                    </li>
                                <? else: ?>
                                    <li><a href="javascript:void(0);"
                                           data-price-rule-activity="/admin_panel/price_rules/<?= $item['ID'] ?>/?action=setActivity&ajax=y&event-id=<?= $item['UF_EVENT_ID'][0] ?>">Активировать</a>
                                    </li>
                                <? endif; ?>
                                <? if ($arResult['TYPES'][$item['UF_TYPE']]['UF_NAME'] == 'Группа'): ?>
                                    <li>
                                        <a href="/admin_panel/price_rules/<?= $item['ID'] ?>/?action=getStats&ajax=y&event-id=<?= $item['UF_EVENT_ID'][0] ?>"
                                           data-ajax="get">Выгрузить статистику <br> промокодов</a>
                                    </li>
                                <? endif; ?>
                            </ul>
                        </div>
                    </div>
                </td>
            </tr>
        <? endforeach; ?>
        </tbody>
    </table>
    <?= $arResult['NAV_STRING'] ?>
</div>


