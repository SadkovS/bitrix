<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("CP_BSAC_COMPONENT_NAME"),
	"DESCRIPTION" => GetMessage("CP_BSAC_COMPONENT_DESCRIPTION"),
	"COMPLEX" => "N",
	"PATH" => array(
        "ID" => "custom",
        "CHILD" => array(
            "ID" => "system",
            "NAME" => GetMessage("SYSTEM"),
            "SORT" => 20,
            "CHILD" => array(
                "ID" => 'system.auth.confirmation',
            )
        )
	),
);
?>