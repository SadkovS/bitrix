<?php

use Bitrix\Main\Localization\Loc;

global $APPLICATION;
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

Loc::loadMessages(__FILE__);

class SystemAuthConfirmationComponent extends \CBitrixComponent {
    protected $objUser;

    public function __construct($component = null)
    {
        parent::__construct($component);

        $this->objUser = new \CUser();
    }

    public function onPrepareComponentParams($arParams)
    {
        $arParams = parent::onPrepareComponentParams($arParams);
        $arParams = $this->normalizeParams($arParams);
        return $arParams;
    }

    private function normalizeParams($arParams)
    {
        $defaultValues = [
            'USER_ID'      => 'confirm_user_id',
            'CONFIRM_CODE' => 'confirm_code',
            'LOGIN'        => 'login',
        ];

        foreach ($defaultValues as $param => $defaultValue) {
            $arParams[$param] = trim($arParams[$param]) ?: $defaultValue;
        }

        return $arParams;
    }

    public function executeComponent()
    {
        
        $this->arResult["~USER_ID"] = $this->request[$this->arParams["USER_ID"]];
        $this->arResult["USER_ID"]  = intval($this->arResult["~USER_ID"]);

        $this->arResult["~CONFIRM_CODE"] = trim($this->request[$this->arParams["CONFIRM_CODE"]]);
        $this->arResult["CONFIRM_CODE"]  = htmlspecialcharsbx($this->arResult["~CONFIRM_CODE"]);

        $this->arResult["~LOGIN"] = trim($this->request[$this->arParams["LOGIN"]]);
        $this->arResult["LOGIN"]  = htmlspecialcharsbx($this->arResult["~LOGIN"]);

        if ($this->objUser->IsAuthorized()) $this->handleAuthorizedUser();
        else $this->handleUnauthorizedUser();

        global $APPLICATION;
        $this->arResult["~FORM_ACTION"] = $APPLICATION->GetCurPage();
        $this->arResult["FORM_ACTION"]  = htmlspecialcharsbx($this->arResult["~FORM_ACTION"]);

        $this->includeComponentTemplate();
    }

    private function getUser()
    {
        if ($this->arResult["USER_ID"] <= 0 && $this->arResult["~LOGIN"] != '') {
            return $this->objUser::GetByLogin($this->arResult["~LOGIN"])->fetch();
        } else {
            return $this->objUser::GetByID($this->arResult["USER_ID"])->fetch();
        }
    }

    private function activateUser($user)
    {
        $resUpdate = $this->objUser->Update($user["ID"], ["ACTIVE" => "Y", "CONFIRM_CODE" => ""]);

        if ($resUpdate) {
            $this->arResult["MESSAGE_TEXT"] = Loc::getMessage("CC_BSAC_MESSAGE_E06");
            $this->arResult["MESSAGE_CODE"] = "E06";
            $this->arResult["SHOW_FORM"]    = false;
            $this->objUser->Authorize($user["ID"]);
            if ($this->arParams['REDIRECT_URL'] != '') LocalRedirect($this->arParams['REDIRECT_URL'], true);
        } else {
            $this->arResult["MESSAGE_TEXT"] = Loc::getMessage("CC_BSAC_MESSAGE_E07");
            $this->arResult["MESSAGE_CODE"] = "E07";
            $this->arResult["SHOW_FORM"]    = false;
        }
    }

    private function handleUnauthorizedUser()
    {
        $user = $this->getUser();

        if (!$user) {
            $this->arResult["MESSAGE_TEXT"] = Loc::getMessage("CC_BSAC_MESSAGE_E01");
            $this->arResult["MESSAGE_CODE"] = "E01";
            $this->arResult["SHOW_FORM"]    = true;
            return;
        }

        if ($user["ACTIVE"] === "Y") {
            $this->arResult["MESSAGE_TEXT"] = Loc::getMessage("CC_BSAC_MESSAGE_E03");
            $this->arResult["MESSAGE_CODE"] = "E03";
            $this->arResult["SHOW_FORM"]    = false;
            return;
        }

        if ($this->arResult["CONFIRM_CODE"] == '') {
            $this->arResult["MESSAGE_TEXT"] = Loc::getMessage("CC_BSAC_MESSAGE_E04");
            $this->arResult["MESSAGE_CODE"] = "E04";
            $this->arResult["SHOW_FORM"]    = true;
            return;
        }

        if ($this->arResult["~CONFIRM_CODE"] !== $user["CONFIRM_CODE"]) {
            $this->arResult["MESSAGE_TEXT"] = Loc::getMessage("CC_BSAC_MESSAGE_E05");
            $this->arResult["MESSAGE_CODE"] = "E05";
            $this->arResult["SHOW_FORM"]    = true;
            return;
        }

        $this->activateUser($user);
    }

    private function handleAuthorizedUser()
    {
        $this->arResult["MESSAGE_TEXT"] = Loc::getMessage("CC_BSAC_MESSAGE_E02");
        $this->arResult["MESSAGE_CODE"] = "E02";
        $this->arResult["SHOW_FORM"]    = false;
    }
}