<?php
$MESS["CP_BSAC_COMPONENT_NAME"] = "Просмотр pdf-файлов";
$MESS["CP_BSAC_COMPONENT_DESCRIPTION"] = "Позволяет просмотреть любые файлы формата .pdf";
$MESS["SYSTEM"] = "Служебные";