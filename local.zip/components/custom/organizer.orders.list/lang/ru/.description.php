<?
$MESS ['HLB_ORDERS_ORGANIZER'] = "Список заказов организатора";
$MESS ['HLB_ORDERS_ORGANIZER_DESC'] = "Показывает список заказов организатора мероприятия";
$MESS ['C_HLDB_CAT_ORDERS'] = "Заказы";
?>