<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => GetMessage("HLB_ORDERS_ORGANIZER"),
    "DESCRIPTION" => GetMessage("HLB_ORDERS_ORGANIZER_DESC"),
    "CACHE_PATH" => "Y",
    "SORT" => 40,
    "PATH" => array(
        "ID" => "custom",
        "CHILD" => array(
            "ID" => "orders",
            "NAME" => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT" => 20,
            "CHILD" => array(
                "ID" => 'organizer.orders.list'
            )
        )
    ),
);

?>