<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */

?>
<div>
    <div class="adminpanel__header-item-head">
        <h3>Заказы</h3>
        <a class="btn btn__medium btn__fix-width" href="/admin_panel/analytics/orders/">Все заказы</a>
    </div>


    <div class="scrolltable__wrapper">
        <div class="scrolltable">
            <table class="adminpanel__table">
                <thead>
                <tr>
                    <th>
                        <div class="adminpanel__item">
                            <p>Номер заказа</p>
                        </div>
                    </th>
                    <th>
                        <div class="adminpanel__item">
                            <p>Дата</p>
                        </div>
                    </th>
                    <th>
                        <div class="adminpanel__item">
                            <p>Сумма, ₽</p>
                        </div>
                    </th>
                    <th>
                        <div class="adminpanel__item">
                            <p>Статус</p>
                        </div>
                    </th>
                </tr>
                </thead>
                <tbody>
                <?foreach ($arResult['ITEMS'] as $order):?>
                <tr>
                    <td>
                        <div class="adminpanel__item">
                            <p><?=$order['ACCOUNT_NUMBER']?></p>
                        </div>
                    </td>
                    <td>
                        <div class="adminpanel__item">
                            <p><?= is_object($order['DATE_INSERT'])?$order['DATE_INSERT']->format('d.m.Y'):''?></p>
                        </div>
                    </td>
                    <td>
                        <div class="adminpanel__item">
                            <p><?=$order['ORDER_SUM_FORMAT']?></p>
                        </div>
                    </td>
                    <td>
                        <div class="adminpanel__item">
                            <?
                            $statusColor = '';
                            if($order['STATUS_NAME'] == 'Принят' || $order['STATUS_NAME'] == 'Выполнен')
                                $statusColor = 'c-green';
                            elseif($order['STATUS_NAME'] == 'Оплачен')
                                $statusColor = 'c-yellow';
                            elseif($order['STATUS_NAME'] == 'Отменен' || $order['STATUS_NAME'] == 'Отменён')
                                $statusColor = 'c-error';
                            elseif($order['STATUS_NAME'] == 'Частичный возврат')
                                $statusColor = 'c-blue';
                            else
                                $statusColor = 'c-dark';
                            ?>
                            <p class="<?=$statusColor?>"><?=$order['STATUS_NAME']?></p>
                        </div>
                    </td>
                </tr>
                <?endforeach;?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<? /*
<div class="adminpanel__header-item-title">
    <h3>Заказы</h3>
    <a href="/admin_panel/analytics/orders-and-tickets/" class="btn">На странцу заказов</a>
</div>
<div class="adminpanel__header-item-desc"></div>
<div class="scrolltable__wrapper">
    <div class="scrolltable">
        <table class="adminpanel__table">
            <thead>
            <tr>
                <th>
                    <div class="adminpanel__item">
                        <p>Название</p>
                    </div>
                </th>
                <th>
                    <div class="adminpanel__item">
                        <p>Билеты, шт.</p>
                    </div>
                </th>
                <th>
                    <div class="adminpanel__item">
                        <p>Сумма, ₽</p>
                    </div>
                </th>
                <th>
                    <div class="adminpanel__item" data-event-controls>
                        <button class="btn__sort" data-event-controls-btn>Статус <i class="_icon-vector"></i></button>
                        <div class="events__table-controls-body" data-event-controls-body>
                            <ul>
                                <li>
                                    <a href="<?=$APPLICATION->GetCurPageParam('',['os'])?>">Все</a>
                                </li>
                                <?foreach ($arResult['STATUS_LIST'] as $key => $status):?>
                                    <li>
                                        <a href="<?=$APPLICATION->GetCurPageParam('os='.$key,['os'])?>"><?=$status['NAME']?></a>
                                    </li>
                                <?endforeach;?>
                            </ul>
                        </div>
                    </div>
                </th>
            </tr>
            </thead>
            <tbody>
            <? foreach ($arResult['ITEMS'] as $order): ?>
                <tr>
                    <td>
                        <div class="adminpanel__item">
                            <p><?= $order['EVENT_NAME'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="adminpanel__item">
                            <p><?= $order['QUANTITY'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="adminpanel__item">
                            <p><?= (int)$order['PRICE'] ?> ₽</p>
                        </div>
                    </td>
                    <td>
                        <div class="adminpanel__item">
                            <p class="draft"><?= $order['STATUS_NAME'] ?></p>
                        </div>
                    </td>
                </tr>
            <? endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

*/ ?>



