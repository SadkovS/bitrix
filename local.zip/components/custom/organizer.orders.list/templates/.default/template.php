<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Application;
use Bitrix\Main\Page\Asset;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");

?>
<div class="admin-body__item wide events">
    <div class="admin-body__item-header">
        <div class="admin-body__item-header__left">
            <h1>Заказы</h1>
            <div class="chart-head-date">
                <label class="range-two-date">
                    <div class="range-two-date__val"></div>
                    <div class="range-two-date__sep">—</div>
                    <div class="range-two-date__val"></div>
                    <input class="js-range-two-date js-reload-chart" data-date="range" name="d" type="text"
                           value="<?= $request['d'] ?? '' ?>" data-url-search="change">
                </label>
            </div>
        </div>
        <a class="btn btn__fix-width js-downloadLink" data-change-href
           href="<?= $APPLICATION->GetCurPageParam("action=export", ["action"]) ?>">Выгрузка</a>
    </div>
    <div class="scrolltable-x__wrapper">
        <div class="scrolltable-x" aria-labelledby="caption" tabindex="0">
            <table class="events__table js-check-table-before-download">
                <thead>
                <tr>
                    <!-- <td>
                        <div class="events__table-select">
                            <button class="btn__icon">
                                <i class="_icon-e-table"></i>
                            </button>
                        </div>
                    </td> -->

                    <td>
                        <div class="events__table-item">
                            <p>Название мероприятия</p>
                            <div class="events__form-item">
                                <input type="text" class="events__form-input" name="q" placeholder="Найти" data-url-search="input"
                                       value="<?= $request['q'] ?>">
                                <i class="_icon-search"></i>
                            </div>
                        </div>

                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Номер</p>
                            <div class="events__form-item">
                                <input type="text" class="events__form-input" name="n" placeholder="Найти" data-url-search="input"
                                       value="<?= $request['n'] ?>">
                                <i class="_icon-search"></i>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Дата оформления заказа</p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Дата оплаты заказа</p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Тип оплаты</p>
                            <div class="events__form-item">
                                <div class="form-select js-form-select">
                                    <div class="form-select__selected-option js-form-select-option js-option-change">
                                        <?
                                        if ((int)$request['pt'] == 1)
                                            echo 'Эквайринг';
                                        else if ((int)$request['pt'] == 2)
                                            echo 'ЮЛ по счету';
                                        else
                                            echo 'Все';
                                        ?>
                                    </div>
                                    <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                    <div class="form-select-options-wrap js-form-select-options-wrap">
                                        <ul class="form-select-options form-select__options">
                                            <li class="form-select-options__item js-form-select-options-item" data-option="">
                                                Все
                                            </li>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="1" <? (int)$request['pt'] == 1 ? 'selected' : '' ?> >
                                                Эквайринг
                                            </li>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="2" <? (int)$request['pt'] == 2 ? 'selected' : '' ?>>
                                                ЮЛ по счету
                                            </li>
                                        </ul>
                                    </div>
                                    <input type="hidden" name="pt" data-url-search="change" value="<?= (int)$request['pt'] ?>">
                                </div>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <p>К-во билетов</p>

                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Категории билетов в заказе</p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Сумма</p>

                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Покупатель</p>
                            <div class="events__form-item">
                                <input type="text" class="events__form-input" name="c" placeholder="Найти" data-url-search="input">
                                <i class="_icon-search"></i>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Использование промокода</p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p>Статус</p>
                            <div class="events__form-item">
                                <div class="form-select js-form-select">
                                    <div class="form-select__selected-option js-form-select-option js-option-change">
                                        <?= $request['os'] ? $arResult['STATUS_LIST'][$request['os']]['NAME'] : 'Все' ?>
                                    </div>
                                    <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                    <div class="form-select-options-wrap js-form-select-options-wrap">
                                        <ul class="form-select-options form-select__options">
                                            <li class="form-select-options__item js-form-select-options-item" data-option="">
                                                Все
                                            </li>
                                            <?php foreach ($arResult['STATUS_LIST'] as $key => $status): ?>
                                                <li class="form-select-options__item js-form-select-options-item"
                                                    data-option="<?= $key ?>">
                                                    <?= $status['NAME'] ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                    <input type="hidden" name="os" value="<?= $request['os'] ?>" data-url-search="change">
                                </div>
                            </div>
                        </div>
                    </td>
                    <td></td>
                </tr>
                </thead>
                <tbody>

                <?php foreach ($arResult['ITEMS'] as $item): ?>
                    <tr>
                        <td>
                            <div class="events__table-item">
                                <div class="events__table-item-name">
                                    <p><?= $item['EVENT_NAME'] ?></p>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="events__table-item">
                                <?= $item['ACCOUNT_NUMBER'] ?>
                            </div>
                        </td>
                        <td>
                            <div class="events__table-item">
                                <div class="events__table-item-name">
                                    <?php if (is_object($item['DATE_INSERT'])): ?>
                                        <p><?= $item['DATE_INSERT']->format('d.m.Y H:i') ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="events__table-item">
                                <p><?= $item['DATE_PAYED'] ?></p>
                            </div>
                        </td>
                        <td>
                            <div class="events__table-item">
                                <p><?= (int)$item['PERSON_TYPE_ID'] == 2 ? 'ЮЛ по счету' : 'Эквайринг' ?></p>
                            </div>
                        </td>
                        <td>
                            <div class="events__table-item">
                                <p><?= $item['QUANTITY'] ?></p>
                            </div>
                        </td>
                        <td>
                            <div class="events__table-item">
                                <p><?= $item['TICKET_TYPES'] ?></p>
                            </div>
                        </td>
                        <td>
                            <div class="events__table-item">
                                <p class="no-wrap"><?= $item['ORDER_SUM_FORMAT'] ?> ₽</p>
                            </div>
                        </td>
                        <td>
                            <div class="events__table-item">
                                <div class="events__table-item-name" data-event-controls>
                                    <button class="table-link" data-event-controls-btn
                                            type="button"><span><?= $item['BUYER'] ?></span></button>

                            <div class="events__table-controls-body table-controls-notification"
                                 data-event-controls-body>
                                <div class="table-controls-notification__close">
                                    <img alt="" class="svg" src="<?= SITE_TEMPLATE_PATH ?>/img/svg/cross.svg">
                                </div>
                                <div class="table-controls-notification__title">
                                    <p>Email: <?= $item['EMAIL'] ?></p>
                                    <p>Телефон: <?= $item['PHONE'] ?></p>
                                    <? if ($item['COMPANY']): ?>
                                        <p>Компания: <?= $item['COMPANY'] ?></p>
                                    <? endif ?>
                                    <? if ($item['INN']): ?>
                                        <p>ИНН: <?= $item['INN'] ?></p>
                                    <? endif ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p><?= $item['PROMOCODES'] ?></p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <?php
                        $statusColor = '';
                        if ($item['STATUS_NAME'] == 'Принят' || $item['STATUS_NAME'] == 'Выполнен')
                            $statusColor = 'c-green';
                        elseif ($item['STATUS_NAME'] == 'Оплачен')
                            $statusColor = 'c-yellow';
                        elseif ($item['STATUS_NAME'] == 'Отменен' || $item['STATUS_NAME'] == 'Отменён')
                            $statusColor = 'c-error';
                        elseif ($item['STATUS_NAME'] == 'Частичный возврат')
                            $statusColor = 'c-blue';
                        else
                            $statusColor = 'c-dark';
                        ?>
                        <span class="events__table-item-status <?= $statusColor ?>"><?= $item['STATUS_NAME'] ?></span>
                    </div>
                </td>
                <td>
                    <?php
                    $controlItems = [];

                            if ($item['PAYED'] === 'Y' && in_array($item['STATUS_ID'], ['P', 'F', 'RR', 'PR'])) {
                                $controlItems[] = '<a data-popup-src="' . $arParams['SEF_FOLDER'] . $item['ID'] . '/?action=getForm&ajax=y" data-popup="#ticket-repayment" href="javascript:void(0)">Погашение билета</a>';
                            }
                            if ($item['PAYED'] !== 'Y' && $item['PERSON_TYPE_ID'] == 2) {
                                $controlItems[] = '<a data-popup="#ticket-extend-reservation" href="javascript:void(0)" data-reservation-id="' . $item['ID'] . '" data-reservation-move="' . $item["RESERVE_TIME"] . '">Продлить бронь</a>';
                            }

                            if ($item['PERSON_TYPE_ID'] == 2 && in_array($item['STATUS_ID'], ['N', 'F'])) {
                                $controlItems[] = '<a href="javascript:void(0)" class="js-send-tickets" data-order-id="' . $item['ID'] . '">Отправить билеты</a>';
                            }
                            ?>

                            <?php if (count($controlItems) > 0): ?>
                                <div class="events__table-controls controls__sticky" data-event-controls>
                                    <button class="btn__icon" data-event-controls-btn type="button">
                                        <i class="_icon-rounds"></i>
                                    </button>
                                    <div class="events__table-controls-body" data-event-controls-body>
                                        <ul>
                                            <?php foreach ($controlItems as $controlItem): ?>
                                                <li>
                                                    <?= $controlItem ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
     </div>
    <?= $arResult['NAV_STRING'] ?>
</div>

<div aria-hidden="true" class="popup popup__prelarge" id="ticket-extend-reservation">
    <div class="popup__wrapper">
        <form class="popup__content js-form-validate" action="?action=extend_reserve" method="post">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>

            <input type="hidden" name="" value="" class="js-extend-reservation-date-start">
            <input type="hidden" name="order_id" value="" class="js-reservation-order-id">

            <div class="reservation-extend-form">
                <div class="reservation-extend-form__body">
                    <div class="popup__name h2 wrap-balance ta-c">Укажите дату, до которой хотите продлить бронь</div>

                    <div class="form-item required">
                        <label class="form-item__label">Дата окончания брони</label>
                        <div class="form-item__input">
                            <input name="extend_time" type="text" placeholder="дд.мм.гггг"
                                   class="promo-date form__underline-input js-extend-reservation-date" readonly
                                   value=""/>
                            <div class="form-item__ico form-item__ico--date"></div>
                        </div>
                        <span class="form__error"></span>
                    </div>

                    <div class="reservation-extend-form__btns">
                        <button type="button"
                                class="btn btn__blue btn__big js-form-validate-btn js-ajax-form-submit-btn js-extend-reservation-submit"
                                data-need-reload=".events__table">Продлить
                        </button>

                        <button type="button" class="btn btn__clean btn__big" data-close-all-popups>Отмена</button>
                    </div>
                </div>
                <div class="reservation-extend-form__calendar">
                    <div class="event__time">
                        <label class="form-item__label" hidden="hidden">Дата события</label>
                        <input type="text" data-static-date="1" data-range="false" value=""
                               class="d-none js-extend-reservation-calendar"
                               data-value-target=".js-extend-reservation-date"/>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Обработчик клика на "Отправить билеты"
        document.addEventListener('click', function (e) {
            if (e.target.classList.contains('js-send-tickets')) {
                e.preventDefault();

                const orderId = e.target.getAttribute('data-order-id');
                if (!orderId) return;

                if (!confirm('Отправить билеты на email покупателя?')) return;

                const formData = new FormData();
                formData.append('action', 'send_tickets');
                formData.append('order_id', orderId);

                fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            alert(data.message || 'Билеты отправлены');
                        } else {
                            alert('Ошибка: ' + (data.message || 'Неизвестная ошибка'));
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Произошла ошибка при отправке билетов');
                    });
            }
        });
    });
</script>

