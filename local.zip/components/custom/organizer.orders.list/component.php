<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */


use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\ORM;
use Custom\Core\Helper as Helper;

$limit = (int)$arParams['ORDER_PER_PAGE'];

$app       = Application::getInstance();
$context   = $app->getContext();
$request   = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
Loader::includeModule('custom.core');
Loader::includeModule('sale');
Loader::includeModule("catalog");
if ($request['action'] == 'export') $limit = 0;
$curPage = (int)$request['PAGEN_1'] > 0 ? (int)$request['PAGEN_1'] : 1;
if (!isset($_REQUEST['PAGEN_1']) || (int)$_REQUEST['PAGEN_1'] <= 1)
    $offset = 0;
else
    $offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $limit;

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"]))
    $arParams["CACHE_TIME"] = 180;
//Список статусов заказа
$statusResult = \Bitrix\Sale\Internals\StatusLangTable::getList(
    [
        'order'  => ['STATUS.SORT' => 'ASC'],
        'filter' => ['STATUS.TYPE' => 'O', 'LID' => LANGUAGE_ID],
        'select' => ['STATUS_ID', 'NAME'],
        'cache'  => ['ttl' => 3600]
    ]
);

while ($status = $statusResult->fetch()) {
    $this->arResult['STATUS_LIST'][$status['STATUS_ID']] = $status;
}


//$this->arResult['EVENT_TYPE_LIST'] = getPropertiesEnum('Events', 'UF_TYPE');

$filter = [
    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID', //по свойству
    "PROPERTY_ORGANIZER.VALUE" => $companyID, //и по его значению
    "PROPERTY_BUYER.CODE"      => 'FIO', //по свойству
    "PROPERTY_EVENT_ID.CODE"   => "EVENT_ID", //и по его значению
    "PROPERTY_RESERVE_TIME.CODE"   => "RESERVE_TIME", //и по его значению
];
if (isset($request['os']) && $request['os'] != '') {
    $filter['STATUS_ID'] = $request['os'];
}
if (isset($request['n']) && $request['n'] != '') {
    $filter['%ACCOUNT_NUMBER'] = $request['n'];
}
if (isset($request['q']) && $request['q'] != '') {
    $filter['%EVENT_NAME'] = $request['q'];
}
if (isset($request['c']) && $request['c'] != '') {
    $filter['%BUYER'] = $request['c'];
}

if (isset($request['pt']) && $request['pt'] != '') {
    $filter['PERSON_TYPE_ID'] = $request['pt'];
}
if (isset($request['d']) && !empty($request['d'])) {
    $date = explode('-', $request['d']);
    if (count($date) > 1) {
        $filter[] = [
            "LOGIC" => 'AND',
            [">=DATE_INSERT" => $date[0] . ' 00:00:00'],
            ["<=DATE_INSERT" => $date[1] . ' 23:59:59'],
        ];
    } else {
        $filter[] = [
            "LOGIC" => 'AND',
            [">=DATE_INSERT" => $date[0] . ' 00:00:00'],
            ["<=DATE_INSERT" => $date[0] . ' 23:59:59'],
        ];
    }
}
$offerEntity         = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
$propFieldType       = $offerEntity->getField('TYPE');
$propFieldTypeEntity = $propFieldType->getRefEntity();


$dbRes = \Bitrix\Sale\Order::getList(
    [
        'select'      => [
            'ID',
            'ACCOUNT_NUMBER',
            'PRICE',
            'USER_ID',
            'PAYED',
            'DATE_INSERT',
            'STATUS_ID',
            'ORGANIZER_ID' => 'PROPERTY_ORGANIZER.VALUE',
            'EVENT_ID'     => 'PROPERTY_EVENT_ID.VALUE',
            'STATUS_NAME'  => 'STATUS.NAME',
            'BUYER'        => 'PROPERTY_BUYER.VALUE',
            'EVENT_NAME'   => 'EVENT.UF_NAME',
            'RESERVE_TIME' => 'PROPERTY_RESERVE_TIME.VALUE',
            'INN'     => 'PROPERTY_INN.VALUE',
            'COMPANY' => 'PROPERTY_COMPANY.VALUE',
            'EMAIL'   => 'PROPERTY_EMAIL.VALUE',
            'PHONE'   => 'PROPERTY_PHONE.VALUE',
            'TICKET_TYPES',
            'PERSON_TYPE_ID',
            'PROMOCODES',
            'BASKET_ITEM_PRICE',
            'DATE_PAYED'
        ],
        'filter'      => $filter,
        'runtime'     => [
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_ORGANIZER',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_BUYER',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_EVENT_ID',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_RESERVE_TIME',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_INN',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                [
                    '=this.ID'  => 'ref.ORDER_ID',
                    '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?s', 'INN')
                ],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_COMPANY',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                [
                    '=this.ID'  => 'ref.ORDER_ID',
                    '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?s', 'COMPANY')
                ],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_EMAIL',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                [
                    '=this.ID'  => 'ref.ORDER_ID',
                    '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?s', 'EMAIL')
                ],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_PHONE',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                [
                    '=this.ID'  => 'ref.ORDER_ID',
                    '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?s', 'PHONE')
                ],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'EVENT',
                'Custom\Core\Events\EventsTable',
                ['=this.EVENT_ID' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'BASKET_REFS',
                'Bitrix\Sale\Internals\BasketTable',
                ['this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'OFFER_REF',
                '\Bitrix\Iblock\Elements\ElementTicketsOffers',
                ['=this.BASKET_REFS.ID' => 'ref.ID'],
                ['join_type' => 'LEFT']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'TICKET_TYPE_REF',
                $propFieldTypeEntity,
                ['this.BASKET_REFS.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'APPLY_PROMOCODES_REF',
                'Custom\Core\Events\DiscountApplyTable',
                ['this.BASKET_REFS.ID' => 'ref.UF_BASKET_ITEM_ID'],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ExpressionField(
                'PROMOCODES', 'GROUP_CONCAT(DISTINCT %s, " / " ,%s, %s)', ['APPLY_PROMOCODES_REF.UF_PROMOCODE', 'APPLY_PROMOCODES_REF.UF_DISCOUNT', 'APPLY_PROMOCODES_REF.UF_DISCOUNT_TYPE']
            ),
            new \Bitrix\Main\Entity\ExpressionField(
                'BASKET_ITEM_PRICE', 'GROUP_CONCAT(DISTINCT %s, "-" ,%s SEPARATOR ";")', ['BASKET_REFS.ID', 'BASKET_REFS.PRICE']
            ),
            new \Bitrix\Main\Entity\ExpressionField(
                'TICKET_TYPES', 'GROUP_CONCAT(DISTINCT %s)', ['TICKET_TYPE_REF.VALUE']
            ),
        ],
        'limit'       => $limit,
        'offset'      => $offset,
        'order'       => ['DATE_INSERT' => 'DESC'],
        'count_total' => true,
    ]
);

while ($order = $dbRes->fetch()) {

    $order['PROMOCODES']                   = str_replace('prc', '%', $order['PROMOCODES']);
    $order['PROMOCODES']                   = str_replace('rub', '₽', $order['PROMOCODES']);
    $order['PROMOCODES']                   = str_replace(',', '<br>', $order['PROMOCODES']);
    $order['TICKET_TYPES']                 = str_replace(',', '<br>', $order['TICKET_TYPES']);
    $order['RESERVE_TIME'] = date('d.m.Y', $order['RESERVE_TIME']);

    if (is_object($order['DATE_PAYED'])) $order['DATE_PAYED'] = $order['DATE_PAYED']->format('d.m.Y H:i');
    if($order['BASKET_ITEM_PRICE'])
    {
        $arBasketItemsPrice = Helper::prepareStringSqlResultToArray($order['BASKET_ITEM_PRICE']);
        $order['ORDER_SUM'] = array_sum($arBasketItemsPrice);
        $order['ORDER_SUM_FORMAT'] = Helper::priceFormat($order['ORDER_SUM'], false);
        $order['QUANTITY'] = count($arBasketItemsPrice);
    }

    $this->arResult['ITEMS'][$order['ID']] = $order;
}

if (isset($request['action']) &&
    $request['action'] == 'export') {
    $APPLICATION->RestartBuffer();
    require_once 'export_excel.php';
    exit;
}

if(
    isset($request['action']) &&
    $request['action'] == 'extend_reserve'
){
    $APPLICATION->RestartBuffer();
    try{
        if(!isset($request['order_id']) || (int)$request['order_id'] < 1)
            throw new \Exception('Не передан ID заказа');
        if(!isset($request['extend_time']) || $request['extend_time'] == '')
            throw new \Exception('Не передано время продления резерва');

        $newReserveTime = new DateTime($request['extend_time'] . ' 23:59:59');
        $newReserveTime = $newReserveTime->getTimestamp();

        $order = \Bitrix\Sale\Order::load($request['order_id']);

        if(!is_object($order)) throw new \Exception('Заказ не найден');

        if ($order->getField('STATUS_ID') != 'N') throw new \Exception('Продлить резерв можно только для заказа в статусе "Принят"');

        $propertyCollection = $order->getPropertyCollection();
        $organizer = $propertyCollection->getItemByOrderPropertyCode("ORGANIZER_ID")->getValue();

        if((int)$organizer != $companyID) throw new \Exception('Заказ не найден');

        $curReserveTime = $propertyCollection->getItemByOrderPropertyCode("RESERVE_TIME")->getValue();

        if($newReserveTime <= $curReserveTime) throw new \Exception('Новое время резерва должно быть больше текущего');

        $propertyCollection->getItemByOrderPropertyCode("RESERVE_TIME")->setValue($newReserveTime);
        $result = $order->save();

        if (!$result->isSuccess()) throw new \Exception($result->getErrorMessages()[0]);

        echo json_encode(['status' => 'success', 'message' => 'Успешно продлено'], JSON_UNESCAPED_UNICODE);
        die;
    }catch(\Exception $e){
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        die;
    }

}

if (
    isset($request['action']) &&
    $request['action'] == 'send_tickets'
) {
    $APPLICATION->RestartBuffer();
    try {
        if (!isset($request['order_id']) || (int)$request['order_id'] < 1)
            throw new \Exception('Не передан ID заказа');

        $orderId = (int)$request['order_id'];
        $order   = \Bitrix\Sale\Order::load($orderId);

        if (!is_object($order)) throw new \Exception('Заказ не найден');

        // Проверяем принадлежность заказа организатору
        $propertyCollection = $order->getPropertyCollection();
        $organizer          = $propertyCollection->getItemByOrderPropertyCode("ORGANIZER_ID")->getValue();

        if ((int)$organizer != $companyID) throw new \Exception('Заказ не найден');

        // Формируем данные для отправки письма
        $arFields = [
            'ORDER_REAL_ID' => $orderId,
            'ORDER_ID'      => $order->getField('ACCOUNT_NUMBER'),
        ];

        // Отправляем событие SALE_ORDER_PAID для формирования билетов
        \CEvent::Send(
            'SALE_ORDER_PAID',
            SITE_ID,
            $arFields
        );

        echo json_encode(['status' => 'success', 'message' => 'Билеты отправлены'], JSON_UNESCAPED_UNICODE);
        die;
    } catch (\Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        die;
    }
}
$this->arResult['ALL_COUNT'] = $dbRes->getCount();
$this->nav                   = new \CDBResult();
$this->nav->NavStart($arParams["EVENTS_COUNT"]);
$this->nav->NavPageCount      = ceil((int)$arResult['ALL_COUNT'] / $limit);
$this->nav->NavPageNomer      = $curPage;
$this->nav->NavRecordCount    = $arResult['ALL_COUNT'];
$this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');
//$this->SetResultCacheKeys(
//	[
//	]
//);
$this->IncludeComponentTemplate();
//$this->AbortResultCache();


/**
 * @param string $hlName
 * @param string $fieldName
 * @param string $resKey
 * @param string $xmlID
 *
 * @return array|int
 */
function getPropertiesEnum(string $hlName, string $fieldName, string $resKey = '', string $xmlID = ''): array|int
{
    $filter = [
        "HL.NAME"    => $hlName,
        "FIELD_NAME" => $fieldName,
    ];

    if (!empty($xmlID)) $filter["ENUM.XML_ID"] = $xmlID;

    $query = \Bitrix\Main\UserFieldTable::getList(
        [
            "filter"  => $filter,
            "select"  => [
                "ENUM_ID"     => "ENUM.ID",
                "ENUM_XML_ID" => "ENUM.XML_ID",
                "ENUM_NAME"   => "ENUM.VALUE",
            ],
            "runtime" => [
                new \Bitrix\Main\Entity\ExpressionField(
                    'HL_ID',
                    'REPLACE(%s, "HLBLOCK_", "")',
                    ['ENTITY_ID']
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'HL',
                    '\Bitrix\Highloadblock\HighloadBlockTable',
                    ['this.HL_ID' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'ENUM',
                    '\Custom\Core\FieldEnumTable',
                    ['this.ID' => 'ref.USER_FIELD_ID'],
                    ['join_type' => 'LEFT'],
                ),
            ],
            'order'   => ['ENUM_ID' => 'ASC'],
            'cache'   => ['ttl' => 3600],
        ]
    );
    $res   = !empty($xmlID) ? 0 : [];
    while ($item = $query->fetch()) {
        if (!empty($xmlID)) $res = (int)$item['ENUM_ID'];
        else $res[$item[$resKey ?:'ENUM_ID']] = [
            "ENUM_ID"     => (int)$item["ENUM_ID"],
            "ENUM_XML_ID" => $item["ENUM_XML_ID"],
            "ENUM_NAME"   => $item["ENUM_NAME"],
        ];
    }
    return $res;
}
?>
