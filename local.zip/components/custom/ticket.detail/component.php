<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */


use Bitrix\Main\ORM;
use Bitrix\Main\Loader;
use Bitrix\Sale\Order;
use Bitrix\UI\Barcode\BarcodeDictionary;
use Bitrix\UI\Barcode\Barcode;
use Bitrix\Main\Application;
use Custom\Core\Helper;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();


/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"]))
    $arParams["CACHE_TIME"] = 180;

if (empty($arParams["ORDER_NUM"])) {
    $this->AbortResultCache();
    ShowError(GetMessage("EMPTY_ORDER_NUM"));
    return;
}

if (empty($arParams["TICKET_UUID"])) {
    $this->AbortResultCache();
    ShowError(GetMessage("EMPTY_TICKET_UUID"));
    return;
}

if (
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('sale') ||
    !Loader::includeModule('iblock') ||
    !Loader::includeModule("catalog")) {
    $this->AbortResultCache();
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

if (!function_exists('locationItemFill')) {
    function locationItemFill(array $eventLocation, ?string $ticketDate = null): array
    {
        if (!is_null($ticketDate)) {
            $dateFormat = array_map(fn($item) => \DateTime::createFromFormat('Y.m.d H:i:s', $item)->getTimestamp(), [$ticketDate]);
        } else {
            $dateFormat = array_map(fn($item) => (new \DateTime($item))->getTimestamp(), $eventLocation['UF_DATE_TIME']);
        }
        $locationItem = [
            'ADDRESS'     => $eventLocation['UF_ADDRESS'] ?? '',
            'DATE_FORMAT' => $dateFormat,
            'DURATION' => $eventLocation['UF_DURATION'],
        ];
        if (!empty($locationItem['ADDRESS']) && !empty($eventLocation['UF_ROOM']))
            $locationItem['ADDRESS'] .= ', помещение ' . $eventLocation['UF_ROOM'];
        $link = json_decode($eventLocation['UF_LINK'][0] ?? '', true);
        if ($link && ((isset($link[0]) && $link[0]) || (isset($link[1]) && $link[1]))) {
            $locationItem["LINK"] = [
                'TITLE' => $link[0] ?? '',
                'URL'   => $link[1] ?? '',
            ];

            ($locationItem["LINK"]["URL"] && strpos($locationItem["LINK"]["URL"], "://") !== false)?: $locationItem["LINK"]["URL"] = "https://".$locationItem["LINK"]["URL"];
        }

        return $locationItem;
    }
}

if (!function_exists('getEventLocation')) {
    function getEventLocation(int $eventId): array
    {
        $res                    = [];
        $queryEventDateLocation = new ORM\Query\Query('\Custom\Core\Events\EventsDateAndLocationTable');
        $obEventDateLocationRes = $queryEventDateLocation
            ->setSelect(['ID', 'UF_EVENT_ID', 'UF_DATE_TIME', 'UF_DURATION', 'UF_ADDRESS', 'UF_ROOM', 'UF_LINK']) // DATE_TIME
            ->setFilter(['UF_EVENT_ID' => $eventId])
            ->setCacheTtl(3600)
            ->exec();

        while ($location = $obEventDateLocationRes->fetch()) {
            $location['UF_DATE_TIME']        = unserialize($location['UF_DATE_TIME']) ?? [];
            $location['UF_DATE_TIME_FORMAT'] = array_map(fn($item) => (new \DateTime($item))->format('Y.m.d'), $location['UF_DATE_TIME']);

            $location['UF_TIME_START'] = array_reduce($location['UF_DATE_TIME'], function ($carry, $item) {
                $carry[(new \DateTime($item))->format('Y.m.d')] = (new \DateTime($item))->format('H:i:s');
                return $carry;
            });

            $res[]                           = $location;
        }

        return $res;
    }
}

$serverName = $context->getServer()->get('REQUEST_SCHEME') . '://' . $context->getServer()->getServerName();

$offerEntity         = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
$propFieldType       = $offerEntity->getField('TYPE');
$propFieldTypeEntity = $propFieldType->getRefEntity();

$propFieldDateAll       = $offerEntity->getField('DATES_ALL');
$propFieldDateAllEntity = $propFieldDateAll->getRefEntity();

$propFieldDates       = $offerEntity->getField('DATES');
$propFieldDatesEntity = $propFieldDates->getRefEntity();

$propFieldPt       = $offerEntity->getField('TYPE_PARTICIPATION');
$propFieldPtEntity = $propFieldPt->getRefEntity();

$dbRes = Order::getList(
    [
        'select'      => [
            'ID',

            'SUM_PAID',
            'PRICE_DELIVERY',

            'ACCOUNT_NUMBER',
            'PAYED',
            'DATE_INSERT',
            'STATUS_ID',
            'CREATED_BY',
            'OFFER_ID'          => 'BASKET_REF.PRODUCT_ID',
            'TICKET_UUID'       => 'BASKET_PROPS_UUID_REF.VALUE',
            'TICKET_BARCODE'    => 'BARCODE.UF_BARCODE',
            'TICKET_SERIES'     => 'BARCODE.UF_SERIES',
            'TICKET_NUMBER'     => 'BARCODE.UF_TICKET_NUM',
            'TICKET_TYPE'       => 'TICKET_TYPE_REF.VALUE',
            'TICKET_DATE_ALL'   => 'TICKET_DATE_ALL_REF.VALUE',
            'EVENT_ID'          => 'PROPERTY_EVENT_ID.VALUE',
            'EVENT_NAME'        => 'EVENT.UF_NAME',
            'EVENT_CATEGORY'    => 'EVENT_CAT_REF.UF_NAME',
            'EVENT_AGE_LIMIT'   => 'EVENT_AGE_LIMIT_REF.VALUE',
            'EVENT_TYPE'        => 'EVENT_TYPE_REF.VALUE',
            'EVENT_TYPE_XML_ID' => 'EVENT_TYPE_REF.XML_ID',

            'IMG_SRC',
            'TICKET_IMG_SRC',
            'TICKET_PRICE'      => 'BASKET_REF.PRICE',

            'ORGANIZER_TYPE'    => 'ORGANIZER_REF.UF_TYPE',
            'ORGANIZER_TYPE_XML_ID'    => 'COMPANY_TYPE_REF.XML_ID',
            'ORGANIZER_NAME'    => 'ORGANIZER_REF.UF_FULL_NAME',
            'ORGANIZER_INN'     => 'ORGANIZER_REF.UF_INN',
            'ORGANIZER_OGRN'    => 'ORGANIZER_REF.UF_OGRN',
            'ORGANIZER_OGRNIP'  => 'ORGANIZER_REF.UF_OGRNIP',
            'ORGANIZER_ADDRESS' => 'ORGANIZER_REF.UF_REGISTRATION_ADDRESS',
            'ORGANIZER_FIO'     => 'ORGANIZER_REF.UF_FIO',

            'BASKET_ITEM_ID' => 'BASKET_REF.ID',
            'USER_FIO'       => 'USER_FIO_REF.UF_FULL_NAME',
            'TICKET_DATES',
            'DESCRIPTION'    => 'OFFER_REF.PREVIEW_TEXT',
            'TICKET_TYPE_PARTICIPATION' => 'TICKET_TYPE_PARTICIPATION_REF_ENUM.XML_ID',
            'TICKET_TYPE_PARTICIPATION_RU' => 'TICKET_TYPE_PARTICIPATION_REF_ENUM.VALUE',
        ],
        'filter'      => [
            'PAYED'                         => 'Y',
            'BARCODE_STATUS.XML_ID'         => ['sold', 'used', 'request_refund'],
            'ACCOUNT_NUMBER'                => $arParams["ORDER_NUM"],
            'BASKET_PROPS_UUID_REF.VALUE'   => $arParams["TICKET_UUID"],
            "PROPERTY_EVENT_ID.CODE"        => "EVENT_ID",
            "BASKET_PROPS_UUID_REF.CODE"    => "UUID",
            "BASKET_PROPS_BARCODE_REF.CODE" => "BARCODE",
        ],
        'runtime'     => [
            new \Bitrix\Main\Entity\ReferenceField(
                'COMPANY_TYPE_REF',
                '\Custom\Core\FieldEnumTable',
                ['=this.ORGANIZER_REF.UF_TYPE' => 'ref.ID'],
                ['join_type' => 'LEFT']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'BASKET_REF',
                '\Bitrix\Sale\Internals\BasketTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'BASKET_PROPS_UUID_REF',
                '\Bitrix\Sale\Internals\BasketPropertyTable',
                ['=this.BASKET_REF.ID' => 'ref.BASKET_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'BASKET_PROPS_BARCODE_REF',
                '\Bitrix\Sale\Internals\BasketPropertyTable',
                ['=this.BASKET_REF.ID' => 'ref.BASKET_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'BARCODE',
                'Custom\Core\Tickets\BarcodesTable',
                ['=this.BASKET_PROPS_BARCODE_REF.VALUE' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'BARCODE_STATUS',
                '\Custom\Core\FieldEnumTable',
                ['this.BARCODE.UF_STATUS' => 'ref.ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_EVENT_ID',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'EVENT',
                'Custom\Core\Events\EventsTable',
                ['=this.EVENT_ID' => 'ref.ID'],
                ['join_type' => 'inner']
            ),///\Custom\Core\Events\EventsCategoryTable
            new \Bitrix\Main\Entity\ReferenceField(
                'EVENT_CAT_REF',
                'Custom\Core\Events\EventsCategoryTable',
                ['=this.EVENT.UF_CATEGORY' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'EVENT_AGE_LIMIT_REF',
                'Custom\Core\FieldEnumTable',
                ['=this.EVENT.UF_AGE_LIMIT' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'EVENT_TYPE_REF',
                'Custom\Core\FieldEnumTable',
                ['=this.EVENT.UF_TYPE' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'LOCATION_REF',
                'Custom\Core\Events\EventsDateAndLocationTable',
                ['=this.EVENT_ID' => 'ref.UF_EVENT_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'ORGANIZER_REF',
                'Custom\Core\Users\CompaniesTable',
                ['=this.EVENT.UF_COMPANY_ID' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'QUESTIONNAIRE_REF',
                'Custom\Core\Events\EventsQuestionnaireUfTicketTable',
                ['=this.BASKET_ITEM_ID' => 'ref.VALUE'],
                ['join_type' => 'LEFT']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'USER_FIO_REF',
                'Custom\Core\Events\EventsQuestionnaireTable',
                ['=this.QUESTIONNAIRE_REF.ID' => 'ref.ID'],
                ['join_type' => 'LEFT']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'OFFER_REF',
                '\Bitrix\Iblock\Elements\ElementTicketsOffers',
                ['=this.BASKET_REF.ID' => 'ref.ID'],
                ['join_type' => 'LEFT']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'TICKET_TYPE_REF',
                $propFieldTypeEntity,
                ['this.OFFER_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'TICKET_DATE_ALL_REF',
                $propFieldDateAllEntity,
                ['this.OFFER_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'TICKET_DATES_REF',
                $propFieldDatesEntity,
                ['this.OFFER_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ExpressionField(
                'TICKET_DATES',
                "GROUP_CONCAT(%s SEPARATOR ';')", // DISTINCT
                ['TICKET_DATES_REF.VALUE']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'TICKET_TYPE_PARTICIPATION_REF',
                $propFieldPtEntity,
                ['this.OFFER_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'TICKET_TYPE_PARTICIPATION_REF_ENUM',
                '\Bitrix\Iblock\PropertyEnumerationTable',
                ['this.TICKET_TYPE_PARTICIPATION_REF.VALUE' => 'ref.ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PICTURE',
                '\Bitrix\Main\FileTable',
                ['this.EVENT.UF_IMG' => 'ref.ID'],
                ['join_type' => 'LEFT'],
            ),
            new \Bitrix\Main\Entity\ExpressionField(
                'IMG_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['PICTURE.SUBDIR', 'PICTURE.FILE_NAME']
            ),
            //            new \Bitrix\Main\Entity\ReferenceField(
            //                'STATUS',
            //                'Bitrix\Sale\Internals\StatusLangTable',
            //                [
            //                    '=this.STATUS_ID' => 'ref.STATUS_ID'
            //                ],
            //                ['join_type' => 'inner']
            //            ),
	        new \Bitrix\Main\Entity\ReferenceField(
		        'TICKET_IMG',
		        '\Bitrix\Main\FileTable',
		        ['this.EVENT.UF_TICKET_IMG' => 'ref.ID'],
		        ['join_type' => 'LEFT'],
	        ),
	        new \Bitrix\Main\Entity\ExpressionField(
		        'TICKET_IMG_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['TICKET_IMG.SUBDIR', 'TICKET_IMG.FILE_NAME']
	        ),
        ],
        'group'       => ['ID'],
        //'limit'       => 1,
        'count_total' => true,
    ]
);

if ($item = $dbRes->fetch()) {
    $dbResTicketDetail = Order::getList(
        [
            'select'      => [
                'ID',
                'BASKET_ITEM_ID' => 'BASKET_REF.ID',
                'TICKET_ROW'      => 'BASKET_PROPS_ROW_REF.VALUE',
                'TICKET_PLACE'      => 'BASKET_PROPS_PLACE_REF.VALUE',
                'TICKET_SECTOR'      => 'BASKET_PROPS_SECTOR_REF.VALUE',
            ],
            'filter'      => [
                "ID" => $item["ID"],
                "BASKET_ITEM_ID" => $item["BASKET_ITEM_ID"],
                "BASKET_PROPS_ROW_REF.CODE"  => "ROW",
                "BASKET_PROPS_PLACE_REF.CODE"  => "PLACE",
                "BASKET_PROPS_SECTOR_REF.CODE"  => "SECTOR",
            ],
            'runtime'     => [
                new \Bitrix\Main\Entity\ReferenceField(
                    'BASKET_REF',
                    '\Bitrix\Sale\Internals\BasketTable',
                    ['=this.ID' => 'ref.ORDER_ID'],
                    ['join_type' => 'inner']
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'BASKET_PROPS_ROW_REF',
                    '\Bitrix\Sale\Internals\BasketPropertyTable',
                    ['=this.BASKET_REF.ID' => 'ref.BASKET_ID'],
                    ['join_type' => 'left']
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'BASKET_PROPS_PLACE_REF',
                    '\Bitrix\Sale\Internals\BasketPropertyTable',
                    ['=this.BASKET_REF.ID' => 'ref.BASKET_ID'],
                    ['join_type' => 'left']
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'BASKET_PROPS_SECTOR_REF',
                    '\Bitrix\Sale\Internals\BasketPropertyTable',
                    ['=this.BASKET_REF.ID' => 'ref.BASKET_ID'],
                    ['join_type' => 'left']
                ),
            ],
        ]);
    if ($ticketDetail = $dbResTicketDetail->fetch())  {
        $item['TICKET_ROW'] = $ticketDetail['TICKET_ROW'];
        $item['TICKET_PLACE'] = $ticketDetail['TICKET_PLACE'];
        $item['TICKET_SECTOR'] = $ticketDetail['TICKET_SECTOR'];
    }

    $item['TICKET_DATES'] = $item['TICKET_DATES'] ? array_map(fn($item) => (new DateTime($item))->format('Y.m.d'), array_unique(explode(';', $item['TICKET_DATES']))) : [];
    sort($item['TICKET_DATES']);

    $item['DATE_INSERT'] = $item['DATE_INSERT']->format('d.m.Y');

    // Сервисный сбор в билете = цена билета/сумму заказа (без доставки) * стоимость доставки
    if($item['SUM_PAID'] - $item['PRICE_DELIVERY'] > 0)
        $item['SERVICE_FREE'] = $item['TICKET_PRICE'] / ($item['SUM_PAID'] - $item['PRICE_DELIVERY']) * $item['PRICE_DELIVERY'];

    $eventLocations = getEventLocation($item['EVENT_ID']);

    if ($item['TICKET_DATE_ALL'] === 'all') {
        foreach ($eventLocations as $eventLocation) {
            $item['LOCATION'][] = locationItemFill($eventLocation);
        }
    } else {
        foreach ($item['TICKET_DATES'] as $ticketDate) {
            foreach ($eventLocations as $eventLocation) {
                if (in_array($ticketDate, $eventLocation['UF_DATE_TIME_FORMAT']) && $eventLocation['UF_TIME_START'][$ticketDate]) {
                    $item['LOCATION'][] = locationItemFill(
                        $eventLocation,
                        $ticketDate." ".$eventLocation['UF_TIME_START'][$ticketDate]
                    );
                }
            }
        }
    }

    $dates = [];

    foreach ($item['LOCATION'] as $keyLoc => $location) {
        foreach ($location['DATE_FORMAT'] as $timeStamp) {
            $dates[$timeStamp] = $keyLoc;
        }
    }

    ksort($dates);
    unset($keyLoc, $location, $timeStamp);

    $item['LOCATIONS_AND_DATES'] = [];
    $rangeDates                  = [];
    

    
    foreach ($dates as $timeStamp => $keyLoc) {
        $objDate      = (new DateTime())->setTimestamp($timeStamp);
        $nextDay      = $objDate->modify('+1 day')->getTimestamp();
        $rangeDates[] = $timeStamp;

        if (!isset($dates[$nextDay]) || $dates[$timeStamp] != $dates[$nextDay]) {
            if (count($rangeDates) > 1) {

                $date                          = Helper::getFormatDate((new DateTime())->setTimestamp($rangeDates[0])->format('d.m.Y'), 'dmnY', showYearSymbol: false) . ' - ' . (Helper::getFormatDate((new DateTime())->setTimestamp($timeStamp)->format('d.m.Y H:i:s'), false, true, ', <br>', false));

                if($item['LOCATION'][$dates[$timeStamp]]['DURATION'])
                {
                    $date .= " - ".(new DateTime())->setTimestamp($timeStamp)->modify("+{$item['LOCATION'][$dates[$timeStamp]]['DURATION']} minutes")->format('H:i');
                }

                $item['LOCATIONS_AND_DATES'][] = [
                    'DATE'         => explode(",", $date)[0],
                    'DATE_TIME'    => $date,
                    'ADDRESS'      => $item['LOCATION'][$dates[$timeStamp]]['ADDRESS'],
                    'LINK'         => $item['LOCATION'][$dates[$timeStamp]]['LINK'],
                ];
                unset($rangeDates);
            } else {
                $date                          = Helper::getFormatDate((new DateTime())->setTimestamp($rangeDates[0])->format('d.m.Y, H:i:s'), false, true, ', <br>', false);

                if($item['LOCATION'][$dates[$timeStamp]]['DURATION'])
                {
                    $date .= " - ".(new DateTime())->setTimestamp($timeStamp)->modify("+{$item['LOCATION'][$dates[$timeStamp]]['DURATION']} minutes")->format('H:i');
                }

                $item['LOCATIONS_AND_DATES'][] = [
                    'DATE'         => explode(",", $date)[0],
                    'DATE_TIME'    => $date,
                    'ADDRESS'      => $item['LOCATION'][$dates[$timeStamp]]['ADDRESS'],
                    'LINK'         => $item['LOCATION'][$dates[$timeStamp]]['LINK'],
                ];
                unset($rangeDates);
            }
        }
    }

    if (isset($item['TICKET_BARCODE']) && $item['TICKET_BARCODE']) {

        $item['SVG_CODE']['QR'] = (new Barcode())
            ->type(BarcodeDictionary::TYPE_QR)
            ->format(BarcodeDictionary::FORMAT_SVG)
            //->option('sf', 3)
            ->option('w', 94)
            ->option('h', 94)
            ->option('p', 0)
            ->render($item['TICKET_BARCODE']);

        $item['SVG_CODE']['128'] = (new Barcode())
            ->type(BarcodeDictionary::TYPE_CODE128)
            ->format(BarcodeDictionary::FORMAT_SVG)
            // ->option('sf', 1)
            ->option('w', 176)
            ->option('h', 78)
            ->option('pt', 0)
            ->render($item['TICKET_BARCODE']);

        if (is_string($item['SVG_CODE']['QR']) && strlen($item['SVG_CODE']['QR']) > 0) {
            $item['SVG_CODE']['QR'] = str_replace('<?xml version="1.0"?>', '', $item['SVG_CODE']['QR']);
        }

        if (is_string($item['SVG_CODE']['128']) && strlen($item['SVG_CODE']['128']) > 0) {
            $item['SVG_CODE']['128'] = str_replace('<?xml version="1.0"?>', '', $item['SVG_CODE']['128']);
        }
    }

    $ogrn = match ((int)$item['ORGANIZER_TYPE']) {
        COMPANY_TYPE_SE => $item['ORGANIZER_OGRNIP'] ? 'ОГРНИП: ' . $item['ORGANIZER_OGRNIP'] : null,
        COMPANY_TYPE_LE => $item['ORGANIZER_OGRN'] ? 'ОГРН: ' . $item['ORGANIZER_OGRN'] : null,
        default         => null,
    };

    $item['ORGANIZER_INFO'] = match ($item['ORGANIZER_TYPE_XML_ID']) {
        "person" => implode(
            ', ',
            array_filter(
                [
                    ($item['ORGANIZER_FIO'] ?: null),
                    ($item['ORGANIZER_ADDRESS'] ?: null),
                    ($item['ORGANIZER_INN'] ? 'ИНН: ' . $item['ORGANIZER_INN'] : null),
                ], fn($item) => !is_null($item)
            )
        ),
        "legal" => implode(
            ', ',
            array_filter(
                [
                    ($item['ORGANIZER_NAME'] ?: null),
                    ($item['ORGANIZER_ADDRESS'] ?: null),
                    ($item['ORGANIZER_INN'] ? 'ИНН: ' . $item['ORGANIZER_INN'] : null),
                    ($item['ORGANIZER_OGRN'] ? 'ОГРН: ' . $item['ORGANIZER_OGRN'] : null),
                ], fn($item) => !is_null($item)
            )
        ),
        "ip" => implode(
            ', ',
            array_filter(
                [
                    ($item['ORGANIZER_NAME'] ?: null),
                    ($item['ORGANIZER_ADDRESS'] ?: null),
                    ($item['ORGANIZER_INN'] ? 'ИНН: ' . $item['ORGANIZER_INN'] : null),
                    ($item['ORGANIZER_OGRNIP'] ? 'ОГРНИП: ' . $item['ORGANIZER_OGRNIP'] : null),
                ], fn($item) => !is_null($item)
            )
        ),
        default         => null,
    };

    unset($item['TICKET_BARCODE'], $item['ORGANIZER_TYPE'], $item['ORGANIZER_NAME'], $item['ORGANIZER_INN'], $item['ORGANIZER_OGRN'], $item['ORGANIZER_OGRNIP'], $item['ORGANIZER_ADDRESS'], $item['ORGANIZER_FIO'], $item['LOCATION'], $location);

    $arResult['TICKET'] = $item;

} else {
    \Bitrix\Iblock\Component\Tools::process404(
        "404 Not Found",
        true,
        true,
        true,
        "/404.php"
    );
}

$this->SetResultCacheKeys([]);
$this->IncludeComponentTemplate();
//$this->AbortResultCache();
?>
