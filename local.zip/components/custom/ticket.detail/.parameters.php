<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

/** @var array $arCurrentValues */

$arComponentParameters = [
    "GROUPS"     => [
    ],
    "PARAMETERS" => [
        "ORDER_NUM"    => [
            "PARENT"  => "BASE",
            "NAME"    => GetMessage("ORDER_NUM"),
            "TYPE"    => "STRING",
            "DEFAULT" => '',
        ],
        "TICKET_UUID"  => [
            "PARENT"  => "BASE",
            "NAME"    => GetMessage("TICKET_UUID"),
            "TYPE"    => "STRING",
            "DEFAULT" => '',
        ],
        "CACHE_TIME"   => ["DEFAULT" => 180],
        "CACHE_GROUPS" => [
            "PARENT"  => "CACHE_SETTINGS",
            "NAME"    => GetMessage("CP_BPR_CACHE_GROUPS"),
            "TYPE"    => "CHECKBOX",
            "DEFAULT" => "Y",
        ],
    ],
];
