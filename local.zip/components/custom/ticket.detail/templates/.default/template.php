<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
	die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */

$host = parse_url('//' . $_SERVER['HTTP_HOST'], PHP_URL_HOST);

?>

<div class="md:pt-30 wrapper inline-flex h-full w-full flex-auto flex-col justify-between">
	<main class="flex-auto">
		<section class="flex flex-col">
			<div class="container__wide inline-flex flex-col gap-5 lg:gap-10">

				<div class="ticket-header">
					<div class="ticket-header__ico">
						<a class="inline-flex flex-col  gap-1 lg:gap-0 text-center" href="/">
							<div class="header__logo block"
								style="background-image:url(<?= SITE_TEMPLATE_PATH ?>/img/logo-dark.svg)"></div>
						</a>
					</div>
					<div class="ticket-header__btns">

						<button class="btn__gray-mid inset-x-[22px] items-center md:items-center js-save-pdf"
							type="button">
							<img alt="" class="svg" src="<?= SITE_TEMPLATE_PATH ?>/svgicons/save.svg" />
							<span class="font-gothic lg:text-xl">Сохранить</span>
						</button>

						<button class="btn__gray-mid inset-x-[22px] items-center md:items-center" type="button"
							onclick="window.print()">
							<img alt="" class="svg" src="<?= SITE_TEMPLATE_PATH ?>/svgicons/printer.svg" />
							<span class="font-gothic lg:text-xl">Распечатать</span>
						</button>

					</div>
				</div>

				<div class="ticket-container">

					<div class="ticket-pdf-container">
						<div class="ticket-pdf">
							<div class="ticket-pdf-col">
								<div class="ticket-pdf-col__head">
									<div class="ticket-pdf-head">
										<a class="inline-flex flex-col  gap-1 lg:gap-0 text-center" href="/">
											<div class="header__logo block"
												>
												<svg xmlns="http://www.w3.org/2000/svg" width="123" height="36" viewBox="0 0 123 36" fill="none">
                                                    <path d="M115.385 26.6976H116.384L116.384 33.2969H116.466L121.051 26.6976H122.033L122.033 35.0818L121.018 35.0818L121.018 28.4989H120.936L116.367 35.0818H115.385L115.385 26.6976ZM119.511 24.6016H120.412C120.412 25.0437 120.259 25.4053 119.954 25.6864C119.648 25.9675 119.233 26.1081 118.709 26.1081C118.193 26.1081 117.782 25.9675 117.477 25.6864C117.174 25.4053 117.022 25.0437 117.022 24.6016H117.923C117.923 24.8144 117.982 25.0014 118.099 25.1624C118.219 25.3234 118.422 25.404 118.709 25.404C118.996 25.404 119.2 25.3234 119.323 25.1624C119.449 25.0014 119.511 24.8144 119.511 24.6016Z" fill="#C92341"/>
                                                    <path d="M103.592 26.6973H104.591L104.591 33.2966H104.673L109.258 26.6973H110.24L110.24 35.0815L109.225 35.0815L109.225 28.4986H109.143L104.574 35.0815H103.592L103.592 26.6973Z" fill="#C92341"/>
                                                    <path d="M92.625 27.5979V26.6973L98.9132 26.6973V27.5979L96.2767 27.5979L96.2767 35.0815H95.2614L95.2614 27.5979L92.625 27.5979Z" fill="#C92341"/>
                                                    <path d="M87.9356 35.0815L86.9203 35.0815L86.9203 27.5979H85.1354C84.6823 27.5979 84.318 27.6675 84.0423 27.8067C83.7667 27.9432 83.5661 28.1369 83.4405 28.388C83.315 28.6391 83.2522 28.9325 83.2522 29.2682C83.2522 29.6039 83.3136 29.8932 83.4364 30.1361C83.562 30.3763 83.7612 30.5619 84.0341 30.6929C84.3098 30.8239 84.6714 30.8894 85.119 30.8894L87.3788 30.8894L87.3788 31.8064L85.0862 31.8064C84.4367 31.8064 83.9031 31.6986 83.4855 31.483C83.068 31.2646 82.7582 30.9644 82.5562 30.5823C82.3543 30.2002 82.2533 29.7622 82.2533 29.2682C82.2533 28.7742 82.3543 28.3334 82.5562 27.9459C82.7582 27.5583 83.0693 27.254 83.4896 27.033C83.9099 26.8092 84.4476 26.6973 85.1026 26.6973L87.9356 26.6973L87.9356 35.0815ZM83.9891 31.3151L85.1354 31.3151L83.1048 35.0815H81.9258L83.9891 31.3151Z" fill="#C92341"/>
                                                    <path d="M70.8047 26.6973H71.8036L71.8036 33.2966H71.8855L76.4706 26.6973H77.4531L77.4531 35.0815L76.4378 35.0815L76.4378 28.4986H76.356L71.7872 35.0815H70.8047L70.8047 26.6973Z" fill="#C92341"/>
                                                    <path d="M60.375 35.0815L60.375 26.6973L63.2079 26.6973C63.8657 26.6973 64.4034 26.816 64.8209 27.0534C65.2412 27.2881 65.5524 27.6061 65.7543 28.0073C65.9563 28.4085 66.0573 28.8561 66.0573 29.3501C66.0573 29.8441 65.9563 30.293 65.7543 30.697C65.5551 31.1009 65.2467 31.4229 64.8291 31.6631C64.4115 31.9006 63.8766 32.0193 63.2243 32.0193L61.1938 32.0193V31.1186L63.1916 31.1186C63.6419 31.1186 64.0035 31.0409 64.2764 30.8853C64.5494 30.7297 64.7472 30.5196 64.8701 30.2548C64.9956 29.9874 65.0584 29.6858 65.0584 29.3501C65.0584 29.0144 64.9956 28.7142 64.8701 28.4494C64.7472 28.1847 64.548 27.9773 64.2724 27.8272C63.9967 27.6743 63.631 27.5979 63.1752 27.5979L61.3903 27.5979L61.3903 35.0815H60.375Z" fill="#C92341"/>
                                                    <path d="M55.2144 26.6973L55.2144 35.0815L54.1991 35.0815L54.1991 27.5979L49.9743 27.5979L49.9743 35.0815H48.959L48.959 26.6973L55.2144 26.6973Z" fill="#C92341"/>
                                                    <path d="M44.1224 30.8907C44.1224 31.775 43.9627 32.5392 43.6434 33.1833C43.3241 33.8274 42.8861 34.3241 42.3293 34.6735C41.7725 35.0228 41.1366 35.1975 40.4216 35.1975C39.7065 35.1975 39.0706 35.0228 38.5138 34.6735C37.957 34.3241 37.519 33.8274 37.1997 33.1833C36.8804 32.5392 36.7207 31.775 36.7207 30.8907C36.7207 30.0065 36.8804 29.2423 37.1997 28.5982C37.519 27.9541 37.957 27.4573 38.5138 27.108C39.0706 26.7587 39.7065 26.584 40.4216 26.584C41.1366 26.584 41.7725 26.7587 42.3293 27.108C42.8861 27.4573 43.3241 27.9541 43.6434 28.5982C43.9627 29.2423 44.1224 30.0065 44.1224 30.8907ZM43.1399 30.8907C43.1399 30.1647 43.0184 29.552 42.7755 29.0526C42.5353 28.5531 42.2092 28.1751 41.7971 27.9186C41.3877 27.662 40.9292 27.5338 40.4216 27.5338C39.9139 27.5338 39.454 27.662 39.0419 27.9186C38.6325 28.1751 38.3064 28.5531 38.0635 29.0526C37.8233 29.552 37.7032 30.1647 37.7032 30.8907C37.7032 31.6167 37.8233 32.2294 38.0635 32.7289C38.3064 33.2283 38.6325 33.6063 39.0419 33.8629C39.454 34.1194 39.9139 34.2477 40.4216 34.2477C40.9292 34.2477 41.3877 34.1194 41.7971 33.8629C42.2092 33.6063 42.5353 33.2283 42.7755 32.7289C43.0184 32.2294 43.1399 31.6167 43.1399 30.8907Z" fill="#C92341"/>
                                                    <path d="M26.6152 35.0815L26.6152 26.6973L29.4482 26.6973C30.1059 26.6973 30.6436 26.816 31.0612 27.0534C31.4815 27.2881 31.7926 27.6061 31.9946 28.0073C32.1965 28.4085 32.2975 28.8561 32.2975 29.3501C32.2975 29.8441 32.1965 30.293 31.9946 30.697C31.7953 31.1009 31.4869 31.4229 31.0694 31.6631C30.6518 31.9006 30.1168 32.0193 29.4646 32.0193L27.434 32.0193L27.434 31.1186L29.4318 31.1186C29.8821 31.1186 30.2438 31.0409 30.5167 30.8853C30.7896 30.7297 30.9875 30.5196 31.1103 30.2548C31.2358 29.9874 31.2986 29.6858 31.2986 29.3501C31.2986 29.0144 31.2358 28.7142 31.1103 28.4494C30.9875 28.1847 30.7882 27.9773 30.5126 27.8272C30.2369 27.6743 29.8712 27.5979 29.4154 27.5979L27.6305 27.5979L27.6305 35.0815H26.6152Z" fill="#C92341"/>
                                                    <path d="M16.6152 35.0815L16.6152 26.6973L21.6752 26.6973V27.5979L17.6305 27.5979L17.6305 30.4309L21.4132 30.4309V31.3315L17.6305 31.3315L17.6305 34.1808L21.7407 34.1808V35.0815L16.6152 35.0815Z" fill="#C92341"/>
                                                    <path d="M3.24609 26.6973L4.45788 26.6973L7.3072 33.6568H7.40546L10.2548 26.6973L11.4666 26.6973L11.4666 35.0815H10.5168L10.5168 28.7114H10.4349L7.81484 35.0815H6.89782L4.27775 28.7114H4.19587L4.19587 35.0815H3.24609L3.24609 26.6973Z" fill="#C92341"/>
                                                    <path d="M116.964 1.15625L121.766 1.15625L121.766 21.9072L116.964 21.9072L116.964 1.15625ZM107.537 21.9072L102.734 21.9072L102.734 1.15625L107.537 1.15625L107.537 21.9072ZM117.319 13.3993L107.181 13.3993L107.181 9.33806L117.319 9.33806L117.319 13.3993Z" fill="#C92341"/>
                                                    <path d="M86.317 22.2632C84.6767 22.2632 83.1549 21.9964 81.7518 21.4628C80.3684 20.9292 79.1628 20.1782 78.1352 19.2098C77.1273 18.2415 76.3368 17.1051 75.7636 15.8008C75.2103 14.4964 74.9336 13.0735 74.9336 11.532C74.9336 9.99049 75.2103 8.56757 75.7636 7.26322C76.3368 5.95887 77.1372 4.82251 78.1648 3.85413C79.1925 2.88576 80.398 2.13477 81.7814 1.60117C83.1648 1.06758 84.6668 0.800781 86.2873 0.800781C87.9276 0.800781 89.4296 1.06758 90.7933 1.60117C92.1767 2.13477 93.3723 2.88576 94.3802 3.85413C95.4079 4.82251 96.2083 5.95887 96.7814 7.26322C97.3545 8.5478 97.6411 9.97073 97.6411 11.532C97.6411 13.0735 97.3545 14.5063 96.7814 15.8304C96.2083 17.1347 95.4079 18.2711 94.3802 19.2395C93.3723 20.1881 92.1767 20.9292 90.7933 21.4628C89.4296 21.9964 87.9375 22.2632 86.317 22.2632ZM86.2873 18.1723C87.2162 18.1723 88.066 18.0142 88.8367 17.698C89.6272 17.3818 90.3189 16.9272 90.9118 16.3344C91.5047 15.7415 91.9593 15.0399 92.2755 14.2296C92.6114 13.4193 92.7794 12.5201 92.7794 11.532C92.7794 10.5438 92.6114 9.64464 92.2755 8.83436C91.9593 8.02409 91.5047 7.32251 90.9118 6.72962C90.3387 6.13674 89.6569 5.68219 88.8664 5.36599C88.0759 5.04979 87.2162 4.89168 86.2873 4.89168C85.3585 4.89168 84.4988 5.04979 83.7083 5.36599C82.9375 5.68219 82.2557 6.13674 81.6628 6.72962C81.0699 7.32251 80.6055 8.02409 80.2696 8.83436C79.9534 9.64464 79.7952 10.5438 79.7952 11.532C79.7952 12.5004 79.9534 13.3996 80.2696 14.2296C80.6055 15.0399 81.0601 15.7415 81.6332 16.3344C82.2261 16.9272 82.9178 17.3818 83.7083 17.698C84.4988 18.0142 85.3585 18.1723 86.2873 18.1723Z" fill="#C92341"/>
                                                    <path d="M52.957 21.9072L52.957 1.15625L61.9392 1.15625C63.7969 1.15625 65.3977 1.46257 66.7416 2.07522C68.0855 2.6681 69.123 3.52779 69.8542 4.65427C70.5855 5.78075 70.9511 7.12462 70.9511 8.68588C70.9511 10.2274 70.5855 11.5614 69.8542 12.6879C69.123 13.7946 68.0855 14.6444 66.7416 15.2373C65.3977 15.8301 63.7969 16.1266 61.9392 16.1266L55.625 16.1266L57.7594 14.0218L57.7594 21.9072L52.957 21.9072ZM66.1487 21.9072L60.961 14.3776L66.0894 14.3776L71.3365 21.9072L66.1487 21.9072ZM57.7594 14.5554L55.625 12.3025L61.6724 12.3025C63.1546 12.3025 64.2614 11.9863 64.9926 11.3539C65.7238 10.7017 66.0894 9.81236 66.0894 8.68588C66.0894 7.53964 65.7238 6.65031 64.9926 6.0179C64.2614 5.38549 63.1546 5.06929 61.6724 5.06929L55.625 5.06929L57.7594 2.78668L57.7594 14.5554Z" fill="#C92341"/>
                                                    <path d="M36.5396 22.2632C34.8993 22.2632 33.3776 21.9964 31.9744 21.4628C30.591 20.9292 29.3855 20.1782 28.3578 19.2098C27.3499 18.2415 26.5594 17.1051 25.9863 15.8008C25.4329 14.4964 25.1562 13.0735 25.1562 11.532C25.1562 9.99049 25.4329 8.56757 25.9863 7.26322C26.5594 5.95887 27.3598 4.82251 28.3875 3.85413C29.4151 2.88576 30.6207 2.13477 32.0041 1.60117C33.3875 1.06758 34.8894 0.800781 36.51 0.800781C38.1503 0.800781 39.6523 1.06758 41.0159 1.60117C42.3993 2.13477 43.595 2.88576 44.6029 3.85413C45.6305 4.82251 46.4309 5.95887 47.004 7.26322C47.5772 8.5478 47.8637 9.97073 47.8637 11.532C47.8637 13.0735 47.5772 14.5063 47.004 15.8304C46.4309 17.1347 45.6305 18.2711 44.6029 19.2395C43.595 20.1881 42.3993 20.9292 41.0159 21.4628C39.6523 21.9964 38.1602 22.2632 36.5396 22.2632ZM36.51 18.1723C37.4388 18.1723 38.2886 18.0142 39.0594 17.698C39.8499 17.3818 40.5416 16.9272 41.1345 16.3344C41.7274 15.7415 42.1819 15.0399 42.4981 14.2296C42.8341 13.4193 43.0021 12.5201 43.0021 11.532C43.0021 10.5438 42.8341 9.64464 42.4981 8.83436C42.1819 8.02409 41.7274 7.32251 41.1345 6.72962C40.5614 6.13674 39.8795 5.68219 39.089 5.36599C38.2985 5.04979 37.4388 4.89168 36.51 4.89168C35.5811 4.89168 34.7215 5.04979 33.9309 5.36599C33.1602 5.68219 32.4784 6.13674 31.8855 6.72962C31.2926 7.32251 30.8282 8.02409 30.4922 8.83436C30.176 9.64464 30.0179 10.5438 30.0179 11.532C30.0179 12.5004 30.176 13.3996 30.4922 14.2296C30.8282 15.0399 31.2827 15.7415 31.8558 16.3344C32.4487 16.9272 33.1404 17.3818 33.9309 17.698C34.7215 18.0142 35.5811 18.1723 36.51 18.1723Z" fill="#C92341"/>
                                                    <path d="M9.75334 21.9072L0.800781 1.15625L5.98852 1.15625L13.8146 19.5357L10.7612 19.5357L18.7059 1.15625L23.4786 1.15625L14.4964 21.9072L9.75334 21.9072Z" fill="#C92341"/>
                                                </svg>
											</div>
										</a>
										<div class="ticket-pdf-normal">Электронный билет</div>
									</div>

									<div class="ticket-pdf-title">
					            <?= str_replace(['(', ')'], ['<span>&#40;</span>', '<span>&#41;</span>'], $arResult['TICKET']['EVENT_NAME'] ?? '') ?>
									</div>
									<div class="ticket-pdf-title-cat">
										<?= $arResult['TICKET']['TICKET_TYPE_PARTICIPATION_RU'] ?? $arResult['TICKET']['EVENT_TYPE'] ?>
									</div>

									<div class="ticket-pdf-subtitle">
										<?= $arResult['TICKET']['EVENT_CATEGORY'] ?? '' ?><? if (isset($arResult['TICKET']['EVENT_AGE_LIMIT'])): ?><span
												class="ticket-pdf-subtitle__age"><?= $arResult['TICKET']['EVENT_AGE_LIMIT'] ?></span><? endif; ?>
									</div>

									<? if ($arResult['TICKET']['TICKET_IMG_SRC']): ?>
										<div class="ticket-pdf-image">
											<img src="<?= $arResult['TICKET']['TICKET_IMG_SRC']?>" class="fill-img" alt="ticket-img">
										</div>
									<? endif; ?>
								</div>
								<div class="ticket-pdf-col__foot">

									<div class="ticket-pdf-itm-list">

										<? if (isset($arResult['TICKET']['LOCATIONS_AND_DATES']) && is_array($arResult['TICKET']['LOCATIONS_AND_DATES']) && count($arResult['TICKET']['LOCATIONS_AND_DATES']) > 0): ?>
											<div class="ticket-pdf-itm">
												<div class="ticket-pdf-itm__ico">
													<img alt="" src="<?= SITE_TEMPLATE_PATH ?>/img/ticket/calendar.png">
												</div>
												<div class="ticket-pdf-itm__body">
													<? foreach ($arResult['TICKET']['LOCATIONS_AND_DATES'] as $item): ?>
														<div class="ticket-pdf-itm__name"><?= $item['DATE_TIME'] ?? '' ?> <span
																class="ticket-pdf-itm__desc">(UTC+03:00)</span></div>
													<? endforeach; ?>
												</div>
											</div>
											<? if ($arResult['TICKET']['EVENT_TYPE_XML_ID'] !== 'online'): ?>
												<?
												$firstKey = array_key_first($arResult['TICKET']['LOCATIONS_AND_DATES']);
												$addressElements = explode(' | ', $arResult['TICKET']['LOCATIONS_AND_DATES'][$firstKey]['ADDRESS'] ?? []);
												?>
												<? if (count($addressElements) > 0): ?>
													<div class="ticket-pdf-itm">
														<div class="ticket-pdf-itm__ico">
															<img alt="location"
																src="<?= SITE_TEMPLATE_PATH ?>/img/ticket/location.png">
														</div>
														<div class="ticket-pdf-itm__body">
															<? foreach ($addressElements as $address): ?>
																<div class="ticket-pdf-itm__name"><?= $address ?></div>
															<? endforeach; ?>
														</div>
													</div>
												<? endif; ?>
											<? endif; ?>
										<? endif; ?>
									</div>

									<div class="ticket-pdf-barcode">
										<?= $arResult['TICKET']['SVG_CODE']['128'] ?? '' ?>
									</div>

								</div>
							</div>

							<div class="ticket-pdf-col">

								<div class="ticket-pdf-col__head">
									<div class="ticket-pdf-info-head">
										<div class="ticket-pdf-info-head__left">
											<table class="ticket-pdf-info-table">
												<tr>
													<td>Номер заказа</td>
													<td><?= $arResult['TICKET']['ACCOUNT_NUMBER'] ?? '' ?></td>
												</tr>
												<tr>
													<td>Дата заказа</td>
													<td><?= $arResult['TICKET']['DATE_INSERT'] ?? '' ?></td>
												</tr>
												<tr>
													<td>Покупатель</td>
													<td><?= $arResult['TICKET']['USER_FIO'] ?? '' ?></td>
												</tr>
												<tr>
													<td>Стоимость билета</td>
													<td><?= number_format($arResult['TICKET']['TICKET_PRICE'] ?? 0, 2, ".", '') ?>
														₽</td>
												</tr>
												<tr>
													<td>Сервисный сбор</td>
													<td><?= number_format($arResult['TICKET']['SERVICE_FREE'] ?? 0, 2, ".", '') ?>
														₽</td>
												</tr>
												<tr>
													<td>Серия и номер билета</td>
													<td><?= $arResult['TICKET']['TICKET_SERIES'] ?><?= (isset($arResult['TICKET']['TICKET_NUMBER']) && $arResult['TICKET']['TICKET_NUMBER']) ? ' № ' . $arResult['TICKET']['TICKET_NUMBER'] : '' ?>
													</td>
												</tr>
											</table>
										</div>
										<div class="ticket-pdf-info-head__right">
											<div class="ticket-pdf-qr">
												<?= $arResult['TICKET']['SVG_CODE']['QR'] ?? '' ?>
											</div>
										</div>
									</div>

									<?// if (in_array($arResult['TICKET']['EVENT_TYPE_XML_ID'], ['offline', 'offline_online'])): ?>
									<div class="ticket-pdf-border-table-wrap">
										<table class="ticket-pdf-border-table ticket-pdf-border-table--online">
											<td>
												<div class="ticket-pdf-border-table__title">Тип билета</div>
												<div class="ticket-pdf-border-table__val">
													<?= $arResult['TICKET']['TICKET_TYPE'] ?? '' ?>
												</div>
											</td>
											<? if (isset($arResult['TICKET']['TICKET_SECTOR']) && $arResult['TICKET']['TICKET_SECTOR']): ?>
												<td>
													<div class="ticket-pdf-border-table__title">Сектор</div>
													<div class="ticket-pdf-border-table__val">
														<?= $arResult['TICKET']['TICKET_SECTOR'] ?>
													</div>
												</td>
											<? endif; ?>
											<? if (isset($arResult['TICKET']['TICKET_ROW']) && $arResult['TICKET']['TICKET_ROW']): ?>
												<td>
													<div class="ticket-pdf-border-table__title">Ряд</div>
													<div class="ticket-pdf-border-table__val">
														<?= $arResult['TICKET']['TICKET_ROW'] ?>
													</div>
												</td>
											<? endif; ?>
											<? if (isset($arResult['TICKET']['TICKET_PLACE']) && $arResult['TICKET']['TICKET_PLACE']): ?>
												<td>
													<div class="ticket-pdf-border-table__title">Место</div>
													<div class="ticket-pdf-border-table__val">
														<?= $arResult['TICKET']['TICKET_PLACE'] ?>
													</div>
												</td>
											<? endif; ?>
										</table>
									</div>
									<?// endif; ?>

									<? if (
										in_array($arResult['TICKET']['EVENT_TYPE_XML_ID'], ['online'])
										|| (in_array($arResult['TICKET']['EVENT_TYPE_XML_ID'], ['offline_online']) && in_array($arResult['TICKET']['TICKET_TYPE_PARTICIPATION'], ['online', 'offline_online']))
									): ?>
										<div class="ticket-pdf-border-table-wrap">
											<table class="ticket-pdf-border-table ticket-pdf-border-table--online">

												<? if (isset($arResult['TICKET']['LOCATIONS_AND_DATES']) && is_array($arResult['TICKET']['LOCATIONS_AND_DATES']) && count($arResult['TICKET']['LOCATIONS_AND_DATES']) > 0): ?>
													<? if (count($arResult['TICKET']['LOCATIONS_AND_DATES']) === 1): ?>
														<tr>
															<td class="text-center">
																<a class="ticket-pdf-btn" target="_blank"
																	href="<?= $item['LINK']['URL'] ?? '#' ?>"><span><?= $item['LINK']['TITLE'] ?? 'Онлайн-трансляция' ?></span></a>
																<br>
																<a class="ticket-pdf-btn-desc" target="_blank"
																	href="<?= $item['LINK']['URL'] ?? '#' ?>"><?= $item['LINK']['URL'] ?? '' ?></a>

															</td>
														</tr>
													<? else: ?>
														<? foreach ($arResult['TICKET']['LOCATIONS_AND_DATES'] as $item): ?>
															<tr>
																<td>
																	<div class="ticket-pdf-border-table__title">
																		<?= $item['DATE'] ?? '' ?>
																	</div>
																</td>
																<td>
																	<a href="<?= $item['LINK']['URL'] ?? '#' ?>" target="_blank"
																		class="ticket-pdf-btn-small"><?= $item['LINK']['TITLE'] ?? 'Онлайн-трансляция' ?></a>
																</td>
																<td>
																	<div class="ticket-pdf-border-table__small">
																		<?= $item['LINK']['URL'] ?? '' ?>
																	</div>
																</td>
															</tr>
														<? endforeach; ?>
													<? endif; ?>
												<? endif; ?>
											</table>
										</div>
									<? endif; ?>
								</div>

								<div class="ticket-pdf-col__foot">
									<div class="ticket-pdf-desc-grid">

										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">Организатор</div>
											<div class="ticket-pdf-desc-grid-itm__text">
												<?= $arResult['TICKET']['ORGANIZER_INFO'] ?? '' ?>
											</div>
										</div>


										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">Билетный агент</div>
											<div class="ticket-pdf-desc-grid-itm__text">
												ООО «ФАНТАМ»<br />
												ИНН 9715428584<br />
												ОГРН 1227700611852<br />
												121357, г. Москва, ул. Верейская, д. 29, стр. 33, помещение 1н/2
											</div>
										</div>


										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">Безопасность</div>
											<div class="ticket-pdf-desc-grid-itm__text">
												Не публикуйте билет в интернете. Покупайте билеты только у официальных
												продавцов.
											</div>
										</div>


										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">Подтверждение участия</div>
											<div class="ticket-pdf-desc-grid-itm__text">Электронный билет подтверждает
												оплату участия в мероприятии. Возьмите его с собой (в распечатанном или
												электронном виде).</div>
										</div>


										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">Документ при себе</div>
											<div class="ticket-pdf-desc-grid-itm__text">Организатор может потребовать
												паспорт или иной документ, удостоверяющий личность владельца билета.
											</div>
										</div>


										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">Возврат билетов</div>
											<div class="ticket-pdf-desc-grid-itm__text">Условия возврата устанавливает
												организатор. Можно ознакомиться по ссылке:
												<a href="https://<?= $host ?>/documents/org_buyer_contract_offer.pdf"
													target="_blank"><?= $host ?>/documents/org_buyer_contract_offer.pdf</a>
											</div>
										</div>


										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">На мероприятии запрещено</div>
											<div class="ticket-pdf-desc-grid-itm__text">
												<ul>
													<li>Проносить оружие, острые предметы, стеклянную тару, напитки, еду
														в твёрдой упаковке, крупные предметы.</li>
													<li>Использовать фото-, видеосъёмку и аудиозапись.</li>
													<li>Совершать действия, мешающие проведению мероприятия.</li>
												</ul>
											</div>
										</div>


										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">Ответственность организатора
											</div>
											<div class="ticket-pdf-desc-grid-itm__text">Всю ответственность за
												содержание, организацию и проведение мероприятия несёт организатор. ООО
												«ФанТам» не гарантирует соответствие мероприятия ожиданиям зрителя и не
												несёт ответственности за отмену, перенос или замену программы.</div>
										</div>


										<div class="ticket-pdf-desc-grid-itm">
											<div class="ticket-pdf-desc-grid-itm__title">Юридическая информация</div>
											<div class="ticket-pdf-desc-grid-itm__text">Билет соответствует требованиям
												Приказа Минкультуры РФ №702 от 29.06.2020. При покупке вы соглашаетесь с
												условиями публичной оферты – Пользовательского соглашения,
												расположенного на сайте:
												<a href="https://<?= $host ?>/documents/user_agreement_and_terms_of_use.pdf"
													target="_blank"><?= $host ?>/documents/user_agreement_and_terms_of_use.pdf</a>
											</div>
										</div>

									</div>

									<div class="ticket-pdf-limitation">
										<img src="<?= SITE_TEMPLATE_PATH ?>/img/ticket/limitations.png" alt="">
									</div>

								</div>

							</div>

						</div>
					</div>

				</div>

			</div>
		</section>
	</main>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>

	function svgToPng(svgElement) {
		return new Promise((resolve) => {
			const canvas = document.createElement('canvas');
			const ctx = canvas.getContext('2d');
			const img = new Image();
			const width = svgElement.width.baseVal.value
			const height = svgElement.height.baseVal.value

			const scale = 4;
			canvas.width = width * scale;
			canvas.height = height * scale;

			ctx.imageSmoothingEnabled = false;
			ctx.scale(scale, scale);

			const svgData = new XMLSerializer().serializeToString(svgElement);
			const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
			const url = URL.createObjectURL(svgBlob);

			img.onload = () => {
				ctx.drawImage(img, 0, 0, width, height);
				URL.revokeObjectURL(url);
				resolve(canvas.toDataURL('image/png', 1.0));
			};

			img.src = url;
		});
	}

	async function svgReplacer(svg) {
		try {
			const pngDataUrl = await svgToPng(svg);
			const img = new Image();
			img.src = pngDataUrl;

			img.style.width = svg.width.baseVal.value + 'px';
			img.style.height = svg.height.baseVal.value + 'px';
			img.style.objectFit = "contain";
			img.style.imageRendering = "crisp-edges";

			img.onload = () => {
				svg.replaceWith(img);
			}
		} catch (error) {
			console.error('Ошибка преобразования SVG в PNG:', error);
		}
	}
	function userAgent(pattern) {
		if (typeof window !== 'undefined' && window.navigator) {
			return !! /*@__PURE__*/navigator.userAgent.match(pattern);
		}
	}

	function addSafaiClass() {

		const isSafari = userAgent(/safari/i) && !userAgent(/chrome/i) && !userAgent(/android/i);
		if (isSafari) {
			document.body.classList.add('safari');
		}
	}

	document.addEventListener('DOMContentLoaded', async () => {

		addSafaiClass();
		const qrSvg = document.querySelector('.ticket-pdf-qr svg');

		if (qrSvg) {
			svgReplacer(qrSvg);
		}

		const barcodeSvg = document.querySelector('.ticket-pdf-barcode svg');
		if (barcodeSvg) {
			svgReplacer(barcodeSvg);
		}

		const checkTicketHeight = () => {
			let container = document.querySelector('.ticket-container')
			if (!container) return;

			let height = document.querySelector('.ticket-pdf').getBoundingClientRect().height
			container.style.setProperty('--ticket-height', height + 'px')
		}

		document.querySelector('.js-save-pdf').addEventListener('click', () => {

			var opt = {
				margin: 0,
				filename: 'ticket_<?= $arResult['TICKET']['TICKET_NUMBER'] ?>.pdf',
				html2canvas: {
					scale: 10,
					letterRendering: true,
					width: 1150,
					windowWidth: 1150,
					scrollX: 30,
					scrollY: 23,
					x: 22,
					y: 15,
					//windowHeight: document.querySelector('.ticket-pdf').offsetHeight,
					useCORS: true,
					removeContainer: true,
					allowTaint: true,
					logging: false,
					imageTimeout: 15000,
				},
				jsPDF: {
					unit: 'mm',
					format: 'a4',
					orientation: 'l',
					precision: 14,
					hotfixes: ["px_scaling"],
					enableLinks: true,
					// 		    pagesplit: false
				}
			};

			html2pdf()
				.set(opt)
				.from(document.querySelector('.ticket-pdf'))
				// 				.to('pdf')
				// 				.output('pdf')
				.save();
		});

		checkTicketHeight()

	});
</script>