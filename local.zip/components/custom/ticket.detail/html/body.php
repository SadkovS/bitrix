<div class="ticket-widget-wrap">
    <div class="ticket">
        <div class="ticket-container">
            <div class="ticket-container-column">
                <div class="ticket-container-column__header">
                    <img alt="logo" class="logo" src="<?= $serverName . TICKET_TEMPLATE_PATH ?>/img/logo-voroh-event.png">
                    <h4>Электронный билет</h4>
                </div>
                <h1><?= $item['EVENT_NAME'] ?? '' ?></h1>

                <div class="info__list-wrap">
                    <? foreach ($item['LOCATIONS_AND_DATES'] as $location): ?>
                        <div class="info__list">
                            <div class="info__item">
                                <img alt="clock" class="icon"
                                     src="<?= $serverName . TICKET_TEMPLATE_PATH ?>/img/ticket/clock.png">
                                <p><?= $location['DATE'] ?></p>
                            </div>
                            <div class="info__item">
                                <img alt="place" class="icon"
                                     src="<?= $serverName . TICKET_TEMPLATE_PATH ?>/img/ticket/place.png">
                                <p><?= $location['ADDRESS'] ?></p>
                            </div>
                            <? if (($item['EVENT_TYPE_XML_ID'] == 'offline_online' || $item['EVENT_TYPE_XML_ID'] == 'online') && !empty($location['LINK']['URL'])): ?>
                                <a class="btn"
                                   href="<?= $location['LINK']['URL'] ?>"><?= $location['LINK']['TITLE'] ?: 'Онлайн трансляция' ?></a>
                            <? endif; ?>
                        </div>
                    <? endforeach; ?>
                </div>

                <div class="number">
                    <small> <b>Номер заказа:</b> <?= $item['ACCOUNT_NUMBER'] ?? '' ?></small>
                </div>

                <div class="ticket__info">
                    <div class="ticket__info-item">
                        <div>
                            <small><b>Тип билета</b></small>
                        </div>
                        <div>
                            <small><?= $item['TICKET_TYPE'] ?? '' ?></small>
                        </div>
                    </div>
                    <? /*
                    <div class="ticket__info-item">
                        <div>
                            <small><b>Сектор</b></small>
                        </div>
                        <div>
                            <small>A</small>
                        </div>
                    </div>
                    <div class="ticket__info-item">
                        <div>
                            <small><b>Ряд</b></small>
                        </div>
                        <div>
                            <small>1</small>
                        </div>
                    </div>
                    <div class="ticket__info-item">
                        <div>
                            <small><b>Место</b></small>
                        </div>
                        <div>
                            <small>1</small>
                        </div>
                    </div>
                    */ ?>
                </div>

                <div class="customer">
                    <small> <b>Покупатель: </b> <?= $item['USER_FIO'] ?? '' ?></small>
                </div>
                <div class="customer">
                    <small> <b>Описание: </b> <br><?= $item['DESCRIPTION'] ?></small>
                </div>
                <div class="price">
                    <small> <b>Цена:</b> <?= number_format($item['TICKET_PRICE'] ?? 0, 2, ".", '') ?> ₽</small>
                </div>
            </div>
            <div class="ticket-container-column">
                <div class="image">
                    <img alt="event-logo"
                         src="<?= isset($item['IMG_SRC']) && $item['IMG_SRC'] ? $serverName . $item['IMG_SRC'] : '' ?>">
                </div>
                <div class="event__text">
                    <p>Уважаемые зрители! Просим не опаздывать на мероприятие.</p>
                </div>
                <div class="age">
                    <h4><b>Возрастное ограничение</b></h4>
                    <div class="age__icon">
                        <img alt="<?= $item['EVENT_AGE_LIMIT'] ?? 'age' ?>"
                             src="<?= $serverName . TICKET_TEMPLATE_PATH ?>/img/ticket/age-<?= preg_replace('/[^0-9]/', '', $item['EVENT_AGE_LIMIT'] ?? '0') ?>.jpg">
                    </div>
                </div>

                <div class="ticket-event-small-description">
                    Билет соответствует требованиям, указанным в Приказе Министерства культуры Российской Федерации от
                    29 июня 2020 № 702
                </div>
            </div>
        </div>
        <div class="ticket-container ticket-container--foot">
            <div class="ticket-container-column">
                <div class="barcodes">
                    <div class="barcodes__left">
                        <div class="barcode__pic">
                            <div>
                                <? if (isset($item['SVG_CODE']['128']) && $item['SVG_CODE']['128']): ?>
                                    <div class="barcode__pic">
                                        <?= $item['SVG_CODE']['128'] ?>
                                    </div>
                                <? endif; ?>
                            </div>
                        </div>
                        <div class="barcode__info">
                            <div><small><b>Серия и номер билета:</b></small></div>
                            <div><small>Серия <?= $item['TICKET_SERIES'] ?></small></div>
                            <div><small>№ <?= $item['TICKET_NUMBER'] ?></small></div>
                        </div>
                    </div>
                    <? if (isset($item['SVG_CODE']['QR']) && $item['SVG_CODE']['QR']): ?>
                        <div class="barcodes__right">
                            <?= $item['SVG_CODE']['QR'] ?>
                        </div>
                    <? endif; ?>
                </div>
            </div>
            <div class="ticket-container-column">
                <div class="organizer__info">
                    <div class="organizer__info-item">
                        <small><b>Билетный агент</b></small>

                        <div class="organizer__info-text">
	                        ООО «ФАНТАМ»<br/>
	                        ИНН 9715428584<br/>
	                        ОГРН 1227700611852<br/>
	                        121357, г. Москва, ул. Верейская, д. 29, стр. 33, помещение 1н/2
                        </div>

                    </div>
                    <div class="organizer__info-item">
                        <small><b>Организатор</b></small>

                        <div class="organizer__info-text">
                            <?= $item['ORGANIZER_INFO'] ?? '' ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
