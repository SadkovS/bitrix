<?
$MESS["ORDER_NUM"]           = "Номер заказа";
$MESS["TICKET_UUID"]         = "UUID билета";
$MESS["IBLOCK_ANY"]          = "(любой)";
$MESS["CP_BPR_CACHE_GROUPS"] = "Учитывать права доступа";
?>