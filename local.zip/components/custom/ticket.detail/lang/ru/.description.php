<?
$MESS ['TICKET_DETAIL_NAME'] = "Билет";
$MESS ['TICKET_DETAIL_DESC'] = "Показывает купленный билет";
$MESS ['C_HLDB_CAT_ORDERS']  = "Заказы";
?>