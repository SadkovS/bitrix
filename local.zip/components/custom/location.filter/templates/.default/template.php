<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>
<?$this->SetViewTarget('filter_template');?>
<div class="self-center lg:relative">
    <button type="button"
            class="inline-flex gap-2.5 dark:text-white lg:flex-row-reverse *:hover:text-warning"
            data-place-tooltip-button>
        <span class="text-xs hidden sm:block md:text-xs duration-300 lg:text-sm"></span>
        <i class="svg_icon-point text-warning lg:text-lg"></i>
    </button>
    <div id="place-popup" aria-hidden="false" class="popup place__popup bg-icons-1 dark:bg-background-1 lg:!bg-transparent" data-set-location="<?=$arResult["SET_LOCATION_SCRIPT"]?>">
        <div class="popup__wrapper">
            <div class="popup__content">
                <div class="inline-flex w-full flex-col gap-c_lg bg-t-1 p-c_narrow dark:bg-primary lg:p-c_lg">
                    <div class="inline-flex w-full justify-between gap-5">
                        <div class="font-gothic text-xl leading-[110%] dark:text-white">
                            Город
                        </div>
                        <button class="link__red" type="button" data-close>
                            <i class="svg_icon-arrow rotate-[215deg]"></i>
                            <span>
                                  Отмена
                                </span>
                        </button>
                    </div>

                    <div class="from__item">
                        <div class="form__item-wrapper">
                            <input type="text" class="input search__input" placeholder="Поиск" data-place-search />
                            <button type="submit" class="search__input-icon">
                                <i class="svg_icon-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="hidden text-sm text-xs font-medium leading-150 dark:text-white lg:text-base" data-place-empty>
                        Ничего на найдено. Попробуйте выбрать город из доступного списка или попробовать ввести название заново.
                    </div>
                    <ul class="place__list" data-place-list>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="header__tooltip " data-place-tooltip data-set-location="<?=$arResult["SET_LOCATION_SCRIPT"]?>">
    <div data-place-tooltip-arrow class="header__tooltip-arrow"></div>
    <div class="inline-flex flex-col gap-c_md w-full">
        <div class="text-xl font-gothic dark:text-white">
            Ваш город: &nbsp;  <span data-place-tooltip-name></span>
        </div>
        <div class="inline-flex gap-2.5 items-center w-full *:flex-auto">
            <button type="button" class="btn__primary" data-popup="#place-popup">Другой</button>
            <button type="button" class="btn__red" data-place-tooltip-accept>Верно</button>
        </div>
    </div>
</div>
<?$this->EndViewTarget();?>