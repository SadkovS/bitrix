$(function() {
    document.addEventListener("place-change", async ({ detail }) => {
        const t = document.querySelector('[data-set-location]');
        if (!t) return;
        const url = t.dataset.setLocation;

        addLoader();

        $.ajax({
            url: url,
            method: 'post',
            dataType: 'json',
            data: {place: detail},
            success: function(data){

                $.ajax({
                    url: '',
                    method: 'get',
                    dataType: 'html',
                    success: function(result){
                        $("main").replaceWith($(result).find("main"));

                        removeLoader();
                    }
                });

                //window.location.reload();
            }
        });
    });
});