<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

if($_REQUEST && $_REQUEST["place"])
{
    $_SESSION["place"] = $_REQUEST["place"];

    echo json_encode(['status' => 'success', 'message' => 'Город установлен']); die();
}
else
{
    echo json_encode(['status' => 'error', 'message' => 'Ошибка']); die();
}

die();