<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
    die();

use Bitrix\Catalog;
use Bitrix\Iblock;
use Bitrix\Main;
use Bitrix\Main\Error;
use Bitrix\Main\ErrorCollection;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use \Bitrix\Main\Application;
use \Bitrix\Main\Context;
use \Bitrix\Main\Request;
use \Custom\Core\UUID;
use \Custom\Core\Events;
use \Bitrix\Main\ORM;
use Bitrix\Highloadblock as HL;

class LocationFilter extends CBitrixComponent
{
    const defCoord = "55.755864,37.617698";
    public function onPrepareComponentParams($arParams)
    {
        return $arParams;
    }

    public function getFilterEvents()
    {
        $area = (1 / 111) * 100;
        $cord = explode(',', $_SESSION["place"]["coordinates"]);

        foreach ($cord as &$val)
        {
            $val = trim($val);
        }unset($val);

        $productEntity     = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $productPropField  = $productEntity->getField('EVENT_ID');
        $productPropEntity = $productPropField->getRefEntity();
        $propFieldClosed       = $productEntity->getField('IS_CLOSED_EVENT');
        $propFieldClosedEntity = $propFieldClosed->getRefEntity();

        $propFieldModeration       = $productEntity->getField('MODERATION');
        $propFieldModerationEntity = $propFieldModeration->getRefEntity();

        $dbRes = \Custom\Core\Events\EventsTable::getList(
            [
                'select'      => [
                    'ID'
                ],
                'filter'      => [
                    "=STATUS_REF.UF_XML_ID" => ["published"],
                    "=ELEMENT.ACTIVE" => "Y",
                    "=PROP_CLOSED_REF.VALUE" => null,
                    "=PROP_MODERATION_REF.VALUE" => null,
                    [
                        'LOGIC' => 'OR',
                        ['ELEMENT.ACTIVE_FROM' => false],
                        ['<=ELEMENT.ACTIVE_FROM' => date('d.m.Y H:i:s')]
                    ],
                    [
                        'LOGIC' => 'OR',
                        ['ELEMENT.ACTIVE_TO' => false],
                        ['>=ELEMENT.ACTIVE_TO' => date('d.m.Y H:i:s')]
                    ],
                    [
                        "LOGIC" => "OR",
                        [
                            ">=COORD1" => $cord[0]-$area,
                            "<=COORD1" => $cord[0]+$area,
                            ">=COORD2" => $cord[1]-$area,
                            "<=COORD2" => $cord[1]+$area,
                        ],
                        [
                            "TYPE_REF.XML_ID" => ["online", "offline_online"]
                        ]
                    ]
                ],
                'runtime'     => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'LOCATION',
                        '\Custom\Core\Events\EventsDateAndLocationTable',
                        ['=this.ID' => 'ref.UF_EVENT_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'COORD1', "SUBSTRING_INDEX(%s, ',', 1)", ['LOCATION.UF_COORDINATES']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'COORD2', "SUBSTRING_INDEX(%s, ',', -1)", ['LOCATION.UF_COORDINATES']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'TYPE_REF',
                        '\Custom\Core\FieldEnumTable',
                        ['=this.UF_TYPE' => 'ref.ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'STATUS_REF',
                        '\Custom\Core\Events\EventsStatusTable',
                        ['=this.UF_STATUS' => 'ref.ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'EVENT_REF',
                        $productPropEntity,
                        ['=this.ID' => 'ref.VALUE'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'ELEMENT',
                        $productEntity,
                        ['=this.EVENT_REF.IBLOCK_ELEMENT_ID' => 'ref.ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROP_CLOSED_REF',
                        $propFieldClosedEntity,
                        ['this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROP_MODERATION_REF',
                        $propFieldModerationEntity,
                        ['this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ],
            ]
        );

        while($obEvents = $dbRes->fetch())
        {
            $eventIds[$obEvents["ID"]] = $obEvents["ID"];
        }

        if($eventIds)
        {
            if($GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"])
            {
                $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"] += $eventIds;
            }
            else
            {
                $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"] = $eventIds;
            }
        }
        else
        {
            $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"] = false;
        }
    }

    public function executeComponent()
    {
        $this->arResult["SET_LOCATION_SCRIPT"] = $this->GetPath()."/set_location.php";

        if(!$_SESSION["place"])
        {
            $_SESSION["place"] = ["coordinates" => self::defCoord];
        }

        if(!$GLOBALS["DISABLE_FILTER_LOCATION"])
            $this->getFilterEvents();

        $this->includeComponentTemplate();
    }

    protected static function getSession(): ?Session
    {
        /** @var Session $session */
        $session = Application::getInstance()->getSession();
        if (!$session->isAccessible())
        {
            return null;
        }

        return $session;
    }

}
