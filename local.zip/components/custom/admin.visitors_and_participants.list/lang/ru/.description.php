<?
$MESS ['VISITORS_AND_PARTICIPANTS_LIST_NAME'] = "Посетители/Участники";
$MESS ['VISITORS_AND_PARTICIPANTS_LIST_DESC'] = "Показывает список заказов Посетителей/Участников";
$MESS ['C_HLDB_CAT_ORDERS'] = "Заказы";
?>