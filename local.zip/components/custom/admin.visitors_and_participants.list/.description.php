<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => GetMessage("VISITORS_AND_PARTICIPANTS_LIST_NAME"),
    "DESCRIPTION" => GetMessage("VISITORS_AND_PARTICIPANTS_LIST_DESC"),
    "CACHE_PATH" => "Y",
    "SORT" => 40,
    "PATH" => array(
        "ID" => "custom",
        "CHILD" => array(
            "ID" => "orders",
            "NAME" => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT" => 20,
            "CHILD" => array(
                "ID" => 'admin.visitors_and_participants.list'
            )
        )
    ),
);

?>