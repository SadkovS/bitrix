<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Custom\Core\ExportExcel;
$arHead = [
    'ФИО',
    'E-mail',
    'Номер телефона',
    'Название мероприятия',
    'Количество заказов',
    'Количество билетов',
    'Сумма потраченная'
];

$obExport = new ExportExcel();
$obExport->setFileName("Выгрузка информации про посетителей/участников.xlsx");
$date = new DateTime();
$date = $date->format('d.m.Y');
$obExport->setFilePath($_SERVER['DOCUMENT_ROOT'] . '/upload/tmp');
$xls = $obExport->createFile();
$xls->getProperties()->setTitle("Тестовый файл");
$xls->getProperties()->setCreated($date);
$xls->setActiveSheetIndex(0);
$sheet = $xls->getActiveSheet();
$sheet->setTitle('Отчет');
$sheet->getRowDimension("1")->setRowHeight(50);
$sheet->getRowDimension("2")->setRowHeight(30);
$sheet->getRowDimension("3")->setRowHeight(40);
$sheet->setCellValue("A1", "Выгрузка информации про посетителей/участников");
$sheet->mergeCells("A1:H1");
$sheet->getStyle("A1")->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$sheet->getStyle("A1")->getFont()->setSize(22);
$sheet->getStyle("A1")->getFont()->setBold(true);
$i            = 0;
$rowNum       = 4;
$columnsCount = 0;
foreach ($arHead as $key => $headItem) {
    $colLetter = $obExport->getColumnLetter($key + 1);
    $sheet->setCellValue($colLetter . '3', $headItem ?? '');
    $sheet->getStyle($colLetter . '3')->getFont()->setSize(14);
    $sheet->getStyle($colLetter . '3')->getFont()->setBold(true);
    $sheet->getStyle($colLetter . '3')->getFont()->setItalic(true);
    $sheet->getStyle($colLetter . '3')->applyFromArray(
        [
            'fill' => [
                'type'  => PHPExcel_Style_Fill::FILL_SOLID,
                'color' => ['rgb' => 'e4efdc']
            ]
        ]
    );
    $sheet->getStyle($colLetter . '3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle($colLetter . '3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
unset($key, $row, $i);
$arTable['BODY'] = [];
foreach ($arResult['ITEMS'] as $key => $value) {
    $arTable['BODY'][] = [
        0 => $value['FULL_NAME'],
        1 => $value['EMAIL'],
        2 => $value['PHONE'],
        3 => $value['EVENT_NAME'],
        4 => $value['ORDERS_QTY'],
        5 => $value['TICKETS_QTY'],
        6 => $value['ORDERS_SUM'],
    ];
}
unset($key, $row, $i);
foreach ($arTable['BODY'] as $key => $row) {
    $i = 0;
    foreach ($row as $keyCol => $colVal) {
        $indexCol = $i + 1;
        $colLetter = $obExport->getColumnLetter($indexCol);

        if(strlen(strip_tags($colVal??'')) > 300){
            $sheet->getColumnDimension($colLetter)->setAutoSize(false);
            $sheet->getColumnDimension($colLetter)->setWidth(150);
        }
        $sheet->setCellValue($colLetter . $rowNum, strip_tags($colVal??''));
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setWrapText(true);
        $sheet->getStyle($colLetter . $rowNum)->getFont()->setSize(14);
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $i++;
    }
    $rowNum ++;
}

$endColLetter = $obExport->getColumnLetter(count($arHead));
$sheet->getStyle("A3:".$endColLetter.($rowNum-1))->applyFromArray($obExport->getBorderStyle());
$obExport->downloadFile($xls);