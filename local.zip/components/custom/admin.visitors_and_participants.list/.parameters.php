<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
{
	die();
}

use Bitrix\Main\Loader;



$arComponentParameters = [
	"GROUPS" => [
	],
	"PARAMETERS" => [
		"ORDER_PER_PAGE" => [
			"PARENT" => "ADDITIONAL_SETTINGS",
			"NAME" => GetMessage("ORDER_PER_PAGE"),
			"TYPE" => "STRING",
			"DEFAULT" => '10',
		],
		"CACHE_TIME"  =>  ["DEFAULT"=>180],
		"CACHE_GROUPS" => [
			"PARENT" => "CACHE_SETTINGS",
			"NAME" => GetMessage("CP_BPR_CACHE_GROUPS"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "Y",
		],
	],
];
