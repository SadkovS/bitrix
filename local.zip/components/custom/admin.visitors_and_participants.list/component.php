<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */


use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\ORM;

//$limit     = (int)$arParams['ORDER_PER_PAGE'];
$limit     = 10;
$app       = Application::getInstance();
$context   = $app->getContext();
$request   = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
Loader::includeModule('custom.core');
Loader::includeModule('sale');
Loader::includeModule("catalog");

$curPage = (int)$request['PAGEN_1'] > 0 ? (int)$request['PAGEN_1'] : 1;
if (!isset($_REQUEST['PAGEN_1']) || (int)$_REQUEST['PAGEN_1'] <= 1)
    $offset = 0;
else
    $offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $limit;

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"]))
    $arParams["CACHE_TIME"] = 180;

$filter = [
    "PAYED"                    => "Y", //оплаченные
    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID', //по свойству
    "PROPERTY_ORGANIZER.VALUE" => $companyID, //и по его значению
    "PROPERTY_BUYER.CODE"      => 'FIO', //по свойству
    "PROPERTY_EMAIL.CODE"      => 'EMAIL', //по свойству
    "PROPERTY_EVENT_ID.CODE"   => "EVENT_ID", //и по его значению
];
if (isset($request['n']) && $request['n'] != '') {
    $filter['%FULL_NAME'] = $request['n'];
}
if (isset($request['em']) && $request['em'] != '') {
    $filter['%EMAIL'] = $request['em'];
}
if (isset($request['ev']) && $request['ev'] != '') {
    $filter['%EVENT_NAME'] = $request['ev'];
}
if (isset($request['p']) && $request['p'] != '') {
    $filter['%PHONE'] = $request['p'];
}

if (isset($request['export']) && $request['export'] == 'y'){
    $offset = 0;
    $limit = false;
    unset($filter['%FULL_NAME'],$filter['%EMAIL'],$filter['%PHONE']);
}

if (isset($request['q']) && $request['q'] != '') require_once 'search.php';

$dbRes = \Bitrix\Sale\Order::getList(
    [
        'select'      => [
            'EVENT_ID'   => 'PROPERTY_EVENT_ID.VALUE',
            'IS_BUYER'    => 'QUESTIONNAIRE_REF.UF_BUYER',
            'EVENT_NAME' => 'EVENT.UF_NAME',
            'FULL_NAME'  => 'QUESTIONNAIRE_REF.UF_FULL_NAME',
            'PHONE'      => 'QUESTIONNAIRE_REF.UF_PHONE',
            'EMAIL'      => 'QUESTIONNAIRE_REF.UF_EMAIL',
            'ORDERS',
        ],
        'filter'      => $filter,
        'runtime'     => [
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_ORGANIZER',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_BUYER',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_EMAIL',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_EVENT_ID',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'EVENT',
                'Custom\Core\Events\EventsTable',
                ['=this.EVENT_ID' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'QUESTIONNAIRE_REF',
                '\Custom\Core\Events\EventsQuestionnaireTable',
                ['=this.ID' => 'ref.UF_ORDER_ID'],
                ['join_type' => 'left']
            ),
            new \Bitrix\Main\Entity\ExpressionField(
                'ORDERS',
                "GROUP_CONCAT( %s SEPARATOR ',')",
                ['ID']
            ),

        ],
        'limit'       => $limit,
        'offset'      => $offset,
        'group'       => ['EVENT_ID', 'EMAIL','FULL_NAME','PHONE'],
        'order' => ['DATE_INSERT' => 'DESC'],
        'count_total' => true,
    ]
);

$arOrders = [];
while ($order = $dbRes->fetch()) {
    $order['ORDERS'] = explode(",", $order['ORDERS']);
    $order['ORDERS_QTY'] = count($order['ORDERS']);
    if (!$order['IS_BUYER']) unset($order['ORDERS'], $order['ORDERS_QTY']);
    else $arOrders = array_merge($arOrders, $order['ORDERS'] ?? []);
    $this->arResult['ITEMS'][] = $order;
}

if (count($arOrders) > 0) {
    $objBaskets = \Bitrix\Sale\Internals\BasketTable::getList(
        [

            'select' => ['ORDER_ID','CNT_TICKETS','SUM_PRICE'],
            'filter' => ['ORDER_ID' => $arOrders],
            'runtime' => [
                new \Bitrix\Main\Entity\ExpressionField(
                    'CNT_TICKETS', 'SUM(%s)', ['QUANTITY']
                ),
                new \Bitrix\Main\Entity\ExpressionField(
                    'SUM_PRICE', 'SUM(%s)', ['PRICE']
                ),
            ],
            'group'  => ['ORDER_ID'],
            'order' => ['ORDER_ID' => 'DESC'],
        ]
    );
    while ($resBasket = $objBaskets->fetch()) {
        $arBasket[$resBasket['ORDER_ID']] = $resBasket;
    }

    foreach ($this->arResult['ITEMS'] as &$item) {
        $quantity = 0;
        $order_sum = 0;

        if(isset($item['ORDERS'])) {
            foreach ($item['ORDERS'] as $order_id) {
                $quantity += $arBasket[$order_id]['CNT_TICKETS'];
                $order_sum += $arBasket[$order_id]['SUM_PRICE'];
            }
            $item['TICKETS_QTY'] = $quantity;
            $item['ORDERS_SUM'] = $order_sum;
            unset($quantity, $order_sum,$item['ORDERS']);
        }
    }
}
if (isset($request['export']) && $request['export'] == 'y') {
    $APPLICATION->RestartBuffer();
    require_once 'export_excel.php';
    die;
}


$this->arResult['ALL_COUNT'] = $dbRes->getCount();
$this->nav                   = new \CDBResult();
$this->nav->NavStart($arParams["EVENTS_COUNT"]);
$this->nav->NavPageCount      = ceil((int)$arResult['ALL_COUNT'] / $limit);
$this->nav->NavPageNomer      = $curPage;
$this->nav->NavRecordCount    = $arResult['ALL_COUNT'];
$this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');

$this->IncludeComponentTemplate();

?>
