<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$filter = [
    "PAYED"                    => "Y", //оплаченные
    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID', //по свойству
    "PROPERTY_ORGANIZER.VALUE" => $companyID, //и по его значению
    "PROPERTY_EVENT_ID.CODE"   => "EVENT_ID", //и по его значению
    "%EVENT_NAME" => $request['q']
];

$dbRes = \Bitrix\Sale\Order::getList(
    [
        'select'      => [
            'EVENT_ID'   => 'PROPERTY_EVENT_ID.VALUE',
            'EVENT_NAME' => 'EVENT.UF_NAME',
        ],
        'filter'      => $filter,
        'runtime'     => [
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_ORGANIZER',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_EVENT_ID',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'inner']
            ),
            new \Bitrix\Main\Entity\ReferenceField(
                'EVENT',
                'Custom\Core\Events\EventsTable',
                ['=this.EVENT_ID' => 'ref.ID'],
                ['join_type' => 'inner']
            ),
        ],
        'limit'       => 10,
        'offset'      => 0,
        'group' => ['EVENT_ID', 'EVENT_NAME'],
        'count_total' => true,
    ]
);
$result = [];
while ($resNames = $dbRes->fetch()) {
    $result[] = ['id' => $resNames['EVENT_ID'],'name' => $resNames['EVENT_NAME']];
}

$APPLICATION->RestartBuffer();
echo json_encode($result, JSON_UNESCAPED_UNICODE);
die;
