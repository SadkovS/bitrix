<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
use Bitrix\Main\Application;
use Bitrix\Main\Page\Asset;
$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
//Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
//Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");

//echo "<pre style='display: block;width: 100%;'>";
//print_r($arResult);
//echo "<br>";
//echo "</pre>";
?>

<div class="admin-body">
    <div class="admin-body__item wide events">
        <div class="admin-body__item-header">
            <h1>Посетители/Участники</h1>
            <button class="btn btn__fix-width" data-popup="#participants-export">Выгрузка</button>
        </div>

        <table class="events__table ">
            <thead>

            <tr>

                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">ФИО</span>
                        <div class="events__form-item lg min-width-select">
                            <input class="events__form-input" name="n" placeholder="Найти" type="text"> <i class="_icon-search"></i>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">E-mail</span>
                        <div class="events__form-item lg min-width-select">
                            <input class="events__form-input" placeholder="Найти" name="em" type="text"> <i class="_icon-search"></i>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn no-wrap">Номер телефона</span>
                        <div class="events__form-item lg min-width-select">
                            <input class="events__form-input" name="p" placeholder="Найти" type="text"> <i class="_icon-search"></i>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">Название мероприятия</span>
                        <div class="events__form-item lg min-width-select">
                            <input class="events__form-input" name="ev" placeholder="Найти" type="text"> <i class="_icon-search"></i>
                        </div>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
												<span class="events__table-btn">Количество
													заказов</span>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
												<span class="events__table-btn">Количество
													билетов</span>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
												<span class="events__table-btn">Сумма
													потраченная</span>
                    </div>
                </td>

            </tr>
            </thead>


            <tbody>
            <?foreach ($arResult['ITEMS'] as $item):?>
            <tr>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['FULL_NAME']?></p>
                        </div>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <a href="mailto:<?=$item['EMAIL']?>"><?=$item['EMAIL']?></a>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <a href="tel:<?=$item['PHONE']?>"><?=$item['PHONE']?></a>
                        </div>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['EVENT_NAME']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['ORDERS_QTY']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['TICKETS_QTY']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['ORDERS_SUM'] ?$item['ORDERS_SUM'].' ₽':''?></p>
                        </div>
                    </div>
                </td>


            </tr>
            <?endforeach;?>
            </tbody>
        </table>


        <?=$arResult['NAV_STRING']?>


    </div>
</div>
<div aria-hidden="true" class="popup popup__medium" id="participants-export">
    <div class="popup__wrapper">
        <form action="" class="popup__content gap-0 popup-transfer js-form-validate">
					<input type="hidden" name="export" value="y">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i></button>

            <div class="popup-transfer__name refund-title h1">Выгрузка информации про посетителей/участников</div>

						<div class="required">
							<div class="clue__box finance-grid-itm__desc finance-grid-itm__clue form-item__label">
									<span>Мероприятие</span>
							</div>

							<div class="search__body finance-grid-itm__line" data-search="">

									<div class="search__form search__form--w100 open list-active js-search-page-g" data-url="/admin_panel/visitors/">
										  <input type="hidden" class="js-search-page-g-id">
											<input name="ev" autocomplete="off" class="search__input" placeholder="Поиск" type="text" value="">
											<ul class="search__list">

													<li>
															<a href="/novoe-meropriyatie-ivanov2-27cd53ea/">
																	<span>В поисках бессмертия: Сальвадор Дали</span>
																	<p class="search__list-desc">Лекция, 01.04.25</p>
															</a>
													</li>
											</ul>
									</div>
							</div>
						</div>

            <div class="d-flex gap-3 justify-content-end">
                <button type="submit" class="btn btn__blue btn__big js-form-validate-btn">Выгрузить</button>
            </div>

        </form>
    </div>
</div>

