$(document).ready(function () {
    // Изменение фильтра
    async function getUrlVars() {
        let url = new Url(window.location.href);
        const [name, email, phone, event] = [
            document.querySelector('[name="n"]').value,
            document.querySelector('[name="em"]').value,
            document.querySelector('[name="p"]').value,
            document.querySelector('[name="ev"]').value
        ];

	    url.query.ajax = 'Y';
	    name === '' ? delete url.query.n : url.query.n = name;
	    email === '' ? delete url.query.em : url.query.em = email;
	    phone === '' ? delete url.query.p : url.query.p = phone;
	    event === '' ? delete url.query.ev : url.query.ev = event;

	    delete url.query.PAGEN_1;

	    const address = url.toString();

        const response = await fetch(address);
        if (!response.ok) {
            return
        }
        const data = await response.text()
        let doc = new DOMParser().parseFromString(data, "text/html");
        const tbody = doc.querySelector('tbody');
        const pagination = doc.querySelector('.pagination.events__pagination');
        delete url.query.ajax;

        window.history.pushState("event search", "", url.toString());
        document.querySelector('.events__table tbody').replaceWith(tbody);
        document.querySelector('.events__pagination').replaceWith(pagination);
    }
// Эвент фильтрации по инпуту
    function inputFilter(e) {
        const target = e.target;
        if (!target.closest('[name="n"]') && !target.closest('[name="em"]') && !target.closest('[name="p"]') && !target.closest('[name="ev"]')) return;
        getUrlVars();
    }
// Бинд всех эвентов на страницу
    [
        ['input', debounce(inputFilter, 500)],
    ].forEach(([event, fn]) => {
        document.addEventListener(event, fn)
    });

// Функция дебаунса
    function debounce(func, wait, immediate) {
        let timeout;
        return function() {
            const context = this;
            const args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

	document.querySelector('#participants-export .js-form-validate').addEventListener('submit',(e)=>{
		document.querySelector('#participants-export [data-close]').click()
	})
});

