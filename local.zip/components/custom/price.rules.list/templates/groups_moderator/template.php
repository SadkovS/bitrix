<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
?>

<div class="scroll__table-x">
    <table class="price__table">
        <thead>
        <tr>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Группа
                        <span class="clue" data-clue>
                  <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                  <span class="clue-body" data-clue-body>
                    Введите название группы
                    <span data-popper-arrow></span>
                  </span>
                </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Количество
                        <span class="clue" data-clue>
                  <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                  <span class="clue-body" data-clue-body>
                     Введите количество кодов для генерации
                     <span data-popper-arrow></span>
                  </span>
                </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Размер скидки
                        <span class="clue" data-clue>
                 <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                 <span class="clue-body" data-clue-body>
                   Укажите размер скидки и выберите единицу измерения: в рублях или процентах
                    <span data-popper-arrow></span>
                 </span>
               </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Вид применения
                        <span class="clue" data-clue>
                 <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                 <span class="clue-body" data-clue-body>
                   Укажите, к какому количеству билетов в заказе будет применен промокод: ко всем или к ограниченному числу. Вы можете задать минимальное и максимальное количество билетов для применения промокода. Также возможно указать только минимальное или только максимальное количество.
                    <span data-popper-arrow></span>
                 </span>
                </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Срок действия
                        <span class="clue" data-clue>
                 <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                 <span class="clue-body" data-clue-body>
                   Укажите период, в течение которого промокод будет действителен. После истечения указанного срока использование скидки станет недоступным
                    <span data-popper-arrow></span>
                 </span>
                </span>
                    </p>
                </div>
            </th>

            <th>
                <div class="price__table-item">
                    <p class="clue__box">
                        Категории билетов
                        <span class="clue" data-clue>
                 <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                 <span class="clue-body" data-clue-body>
                   Укажите на какие типы билетов распрострааняется данный промокод
                    <span data-popper-arrow></span>
                 </span>
                </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Суммируется
                        <span class="clue" data-clue>
                    <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                    <span class="clue-body" data-clue-body>
                      Включите этот параметр, если данный промокод можно использовать одновременно с другими промокодами, группами промокодов или скидками
                       <span data-popper-arrow></span>
                    </span>
                   </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Статус
                        <span class="clue" data-clue>
                 <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                 <span class="clue-body" data-clue-body>
                    Статус промокода отображается автоматически в зависимости от даты действия и настроек активации.
                    <span data-popper-arrow></span>
                 </span>
                </span>
                    </p>
                </div>
            </th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <? if (isset($arResult['ITEMS']) && count($arResult['ITEMS']) > 0): ?>
            <? foreach ($arResult['ITEMS'] as $item): ?>
                <tr>
                    <td>
                        <div class="price__table-item">
                            <p><?= $item['UF_NAME'] ?? '' ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="promo__list">
                                <p><?= $item['UF_MAX_NUMBER_OF_USES'] ?: 0 ?></p>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <p><?= $item['UF_DISCOUNT'] ?? '' ?><?= (empty($item["UF_DISCOUNT_TYPE"]) || $arResult["DISCOUNT_TYPES"][$item["UF_DISCOUNT_TYPE"]]["UF_NAME"] == "Проценты") ? '%' : '₽' ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <p><?= $item['UF_TYPE_APPLY_ALL_ORDER'] ? 'Ко всему заказу' : ($item['UF_TYPE_APPLY_MIN'] || $item['UF_TYPE_APPLY_MAX'] ? '<div class="form-select__content"><input value="' . ($item["UF_TYPE_APPLY_MIN"] ? $item["UF_TYPE_APPLY_MIN"] : '') . '" placeholder="Min" readonly  class="input__grey min" type="text"/>-<input value="' . ($item["UF_TYPE_APPLY_MAX"] ? $item["UF_TYPE_APPLY_MAX"] : '') . '" placeholder="Max" readonly  class="input__grey min" type="text"/></div>' : '') ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <?
                            $dateStart = $item['UF_DATE_START'] ?: '∞';
                            $dateEnd   = $item['UF_DATE_END'] ?: '∞';

                            if ($dateStart === '∞' && $dateEnd === '∞') {
                                $promoCodeLive = '∞';
                            } else {
                                $promoCodeLive = $dateStart . '-' . $dateEnd;
                            }
                            ?>
                            <p><?= $promoCodeLive ?></p>
                        </div>
                    </td>
                    <td>

                        <div class="price__table-item">
                            <div class="promo__list">
                                <? if ((!is_array($item['UF_TICKETS_TYPE']) || count($item['UF_TICKETS_TYPE']) < 1) && (int)$item['UF_FOR_ALL_TYPES'] < 1): ?>
                                <? elseif ((int)$item['UF_FOR_ALL_TYPES'] == 1): ?>
                                    <div class="promo__item">
                                        <span>Все</span>
                                    </div>
                                <? else: ?>
                                    <? foreach ($item['UF_TICKETS_TYPE'] as $type): ?>
                                        <div class="promo__item">
		                                <span>
		                                    <?= $arParams['EVENT_TYPES'][$type]['SKU_TYPE'] ?>
		                                </span>
                                        </div>
                                    <? endforeach;
                                    unset($type); ?>
                                <? endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <p>
                                <? if ($item['UF_IS_SUM'] == 1): ?>
                                    Да
                                <? else: ?>
                                    Нет
                                <? endif; ?>
                            </p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item js-price-rule-activity">
                            <? if ($item['UF_IS_ACTIVITY']): ?>
                                <div class="status__active">Активен</div>
                            <? else: ?>
                                <div class="status__inactive">Не активен</div>
                            <? endif; ?>
                        </div>
                    </td>
                    <td></td>
                </tr>

            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
