<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
?>
<div class="adminpanel__header-item-title justify-content-between">
	<?php if($arParams['DISABLED'] !== 'disabled'):?>
    <button type="button" data-discounts-add class="btn btn-right">Добавить</button>
  <?php endif;?>
</div>
<div class="promocodes__controls mx-4">
    <small>Автоматическая скидка применяется <br> при покупке билетов от определенного количества</small>
</div>
<div class="scroll__table-x">
    <table class="price__table table-ticket-discount">
        <thead>
        <tr>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Скидка <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Введите название скидки
											 <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>

            <th>
                <div class="price__table-item">
                    <p class="clue__box">Размер скидки <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите размер скидки и выберите единицу измерения: в рублях или процентах
											 <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Типы билетов <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите на какие типы билетов распространяется данная скидка
											 <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Количество Min
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите, начиная с какого количества билетов в заказе будет применяться данная скидка
                          <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Срок действия
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите период, в течение которого скидка будет действительна. После истечения указанного срока использование скидки станет недоступным
                          <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Суммируется
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Включите этот параметр, если данную скидку можно использовать одновременно с другими промокодами, группами промокодов или скидками
                          <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
		        <th>
			        <div class="price__table-item">
				        <p class="clue__box">Применять к каждому<br> отдельному билету в заказе
					        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                        При выборе данной опции промокод будет применяться к каждому отдельному билету, а не к общей сумме заказа.
                        <span data-popper-arrow></span>
                     </span>
                  </span>
				        </p>
			        </div>
		        </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Статус
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Статус скидки отображается автоматически в зависимости от даты действия и настроек активации.
                          <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th></th>
        </tr>
        </thead>
        <tbody>

        <? if (isset($arResult['ITEMS']) && count($arResult['ITEMS']) > 0): ?>
            <? foreach ($arResult['ITEMS'] as $item): ?>
                <tr>
                    <td>
                        <div class="price__table-item">
                            <input type="text" name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_NAME]"  <?=$arParams['DISABLED']?>
                                   value="<?= $item['UF_NAME'] ?? '' ?>" placeholder="Введите название"
                                   data-dynamic-input="">
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="price__grid">
                                <input name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_DISCOUNT]"
                                       type="text"
		                                  <?=$arParams['DISABLED']?>
                                       value="<?= $item['UF_DISCOUNT'] ?? '' ?>"
                                       placeholder=""
                                       class="input__grey short"
                                       data-filter-number
                                       data-dynamic-input
                                       data-discount-input-mask
                                />
                                <label class="form-num-switch">
                                    <input
                                            type="checkbox"  <?=$arParams['DISABLED']?>
                                            name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_DISCOUNT_TYPE]"
                                            value="<?= DISCOUNT_TYPE_RUB ?>"
                                            <? if (empty($item["UF_DISCOUNT_TYPE"]) || $arResult["DISCOUNT_TYPES"][$item["UF_DISCOUNT_TYPE"]]["UF_NAME"] == "Проценты"): ?><? else: ?>checked<? endif; ?>
                                    >
                                    <span>%</span>
                                    <span>₽</span>
                                </label>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="form-select__split">
                                <div class="promo__list" data-promocodes-category-grid>
                                    <? if ((!is_array($item['UF_TICKETS_TYPE']) || count($item['UF_TICKETS_TYPE']) < 1) && (int)$item['UF_FOR_ALL_TYPES'] < 1): ?>
                                    <? elseif ((int)$item['UF_FOR_ALL_TYPES'] == 1): ?>
                                        <div class="promo__item">
                                            <span>Все</span>
                                            <input type="hidden" value="all"
                                                   name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]">
	                                        <?php if($arParams['DISABLED'] !== 'disabled'):?>
                                            <i class="_icon-plus"></i>
                                          <?php endif;?>
                                        </div>
                                    <? else: ?>
                                        <? foreach ($item['UF_TICKETS_TYPE'] as $type): ?>
                                            <div class="promo__item">
                                <span>
                                    <?= $arParams['EVENT_TYPES'][$type]['SKU_CONCAT_TYPE_PRICE'] ?>
                                </span>
                                                <input type="hidden" value="<?= $type ?>"
                                                       name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]">
                                                <i class="_icon-plus"></i>
                                            </div>
                                        <? endforeach;
                                        unset($type); ?>
                                    <? endif; ?>
                                </div>
                                <div class="form-select form-select__group js-form-select"
                                     data-multyple-select="[data-promocodes-category-grid]"
                                     data-multyple-guid="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]"
                                     data-all-guid="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]"
                                >
	                                <?php if($arParams['DISABLED'] !== 'disabled'):?>
                                    <div class="form-select__selected-option  js-form-select-option js-option-change">
                                        <button type="button" class="form-select__add-btn">
                                            <i class="_icon-plus"></i>
                                        </button>
                                    </div>
                                  <?php endif;?>

                                    <div class="form-select-options-wrap js-form-select-options-wrap">
                                        <ul class="form-select-options form-select__options">
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="all">
                                                <b><b>Все</b></b>
                                            </li>
                                            <? foreach ($arParams['EVENT_TYPES'] as $type): ?>
                                                <li class="form-select-options__item js-form-select-options-item <? if ($item['UF_TICKETS_TYPE'] && in_array($type['SKU_ID'], $item['UF_TICKETS_TYPE'])) echo "_icon-checkbox"; ?>"
                                                    data-option="<?= $type['SKU_ID'] ?>">
                                                    <p><?= $type['SKU_CONCAT_TYPE_PRICE'] ?></p>
                                                </li>
                                            <? endforeach;
                                            unset($type); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <input type="text" name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_MIN_COUNT_TICKETS]" <?=$arParams['DISABLED']?>
                                   value="<?= $item['UF_MIN_COUNT_TICKETS'] ?? '' ?>" placeholder="Введите кол-во"
                                   data-dynamic-input="" data-filter-number class="short">
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="date__split">
                                <div class="date__split">
                                    <input type="text" value="<?= $item['UF_DATE_START'] ?>" <?=$arParams['DISABLED']?>
                                           name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_DATE_START]"
                                           placeholder="дд.мм.гг" class="promo-date input__bordered" data-date=""
                                           data-date-split-start="" data-formatted-date readonly="">
                                    -
                                    <input type="text" value="<?= $item['UF_DATE_END'] ?>" <?=$arParams['DISABLED']?>
                                           name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_DATE_END]"
                                           placeholder="дд.мм.гг" class="promo-date input__bordered" data-date=""
                                           data-date-split-end="" data-formatted-date readonly="">
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <label class="form-bool-switch">
                                <input type="checkbox" <?=$arParams['DISABLED']?>
                                       name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_IS_SUM]"
                                       value="1"
                                    <? if ($item['UF_IS_SUM'] == 1): ?>
                                        checked
                                    <? else: ?>
                                    <? endif; ?>
                                >
                                <span>НЕТ</span>
                                <span>ДА</span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <label class="form-bool-switch">
                                <input type="checkbox" <?=$arParams['DISABLED']?>
                                       name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_FOR_EACH_TICKET]"
                                       value="1"
                                    <? if ($item['UF_FOR_EACH_TICKET'] == 1): ?>
                                        checked
                                    <? else: ?>
                                    <? endif; ?>
                                >
                                <span>НЕТ</span>
                                <span>ДА</span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item js-price-rule-activity">
                            <? if ($item['UF_IS_ACTIVITY']): ?>
                                <div class="status__active">Активен</div>
                            <? else: ?>
                                <div class="status__inactive">Не активен</div>
                            <? endif; ?>
                        </div>
                    </td>
                    <td>
	                    <?php if($arParams['DISABLED'] !== 'disabled'):?>
                        <div class="events__table-controls" data-event-controls="">
                            <button type="button" class="btn__icon" data-event-controls-btn="">
                                <i class="_icon-rounds"></i>
                            </button>
                            <div class="events__table-controls-body" data-event-controls-body="">
                                <ul>
                                    <li>
                                        <a href="javascript:void(0);"
                                           data-price-rule-activity="<?= $arParams['SEF_FOLDER'] . $item['ID'] ?>/?action=setActivity&ajax=y&event-id=<?= $arParams['EVENT_ID'] ?>"><?= ($item['UF_IS_ACTIVITY']) ? 'Деактивировать' : 'Активировать' ?></a>
                                    </li>
                                    <? if ($item['UF_NUMBER_OF_USES'] < 1): ?>
                                        <li>
                                            <a href="javascript:void(0);"
                                               data-delete-confirm-title="скидку <?= $item['UF_NAME'] ?? '' ?>"
                                               data-delete-confirm="<?= $item['UF_XML_ID'] ?>">Удалить</a>
                                        </li>
                                    <? endif; ?>
                                </ul>
                            </div>
                        </div>
	                    <?php endif;?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="price__save-wrapper">
	<?php if($arParams['DISABLED'] !== 'disabled'):?>
    <a href="javascript:void(0);" class="btn btn__fix-width btn-right" data-event-price-save>Сохранить</a>
  <?php endif;?>
</div>