<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
?>

<div class="promocodes__controls mx-4">
    <small>Автоматическая скидка применяется <br> при покупке билетов от определенного количества</small>
</div>
<div class="scroll__table-x">
    <table class="price__table">
        <thead>
        <tr>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Скидка <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Введите название скидки
											 <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>

            <th>
                <div class="price__table-item">
                    <p class="clue__box">Размер скидки <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите размер скидки и выберите единицу измерения: в рублях или процентах
											 <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Типы билетов <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите на какие типы билетов распространяется данная скидка
											 <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Количество Min
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите, начиная с какого количества билетов в заказе будет применяться данная скидка
                          <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Срок действия
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите период, в течение которого скидка будет действительна. После истечения указанного срока использование скидки станет недоступным
                          <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Суммируется
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Включите этот параметр, если данную скидку можно использовать одновременно с другими промокодами, группами промокодов или скидками
                          <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Статус
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Статус скидки отображается автоматически в зависимости от даты действия и настроек активации.
                          <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th></th>
        </tr>
        </thead>
        <tbody>

        <? if (isset($arResult['ITEMS']) && count($arResult['ITEMS']) > 0): ?>
            <? foreach ($arResult['ITEMS'] as $item): ?>
                <tr>
                    <td>
                        <div class="price__table-item">
	                        <div><?= $item['UF_NAME'] ?? '' ?></div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="price__grid">
	                            <span class="input__grey short"><?= $item['UF_DISCOUNT'] ?? '' ?></span>
                                <label class="form-num-switch">
                                    <input
                                            type="checkbox"
                                            name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_DISCOUNT_TYPE]"
                                            value="<?= DISCOUNT_TYPE_RUB ?>"
                                            disabled="disabled"
                                            <? if (empty($item["UF_DISCOUNT_TYPE"]) || $arResult["DISCOUNT_TYPES"][$item["UF_DISCOUNT_TYPE"]]["UF_NAME"] == "Проценты"): ?><? else: ?>checked<? endif; ?>
                                    >
                                    <span>%</span>
                                    <span>₽</span>
                                </label>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="form-select__split">
                                <div class="promo__list" data-promocodes-category-grid>
                                    <? if ((!is_array($item['UF_TICKETS_TYPE']) || count($item['UF_TICKETS_TYPE']) < 1) && (int)$item['UF_FOR_ALL_TYPES'] < 1): ?>
                                    <? elseif ((int)$item['UF_FOR_ALL_TYPES'] == 1): ?>
                                        <div class="promo__item">
                                            <span>Все</span>
                                        </div>
                                    <? else: ?>
                                        <? foreach ($item['UF_TICKETS_TYPE'] as $type): ?>
                                            <div class="promo__item">
                                <span>
                                    <?= $arParams['EVENT_TYPES'][$type]['SKU_CONCAT_TYPE_PRICE'] ?>
                                </span>
                                                <input type="hidden" value="<?= $type ?>"
                                                       name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]">
                                            </div>
                                        <? endforeach;
                                        unset($type); ?>
                                    <? endif; ?>
                                </div>
                                <div class="form-select form-select__group js-form-select"
                                     data-multyple-select="[data-promocodes-category-grid]"
                                     data-multyple-guid="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]"
                                     data-all-guid="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]"
                                >
                                    <div class="form-select__selected-option  js-form-select-option js-option-change">
                                        <button type="button" class="form-select__add-btn">
                                            <i class="_icon-plus"></i>
                                        </button>
                                    </div>

                                    <div class="form-select-options-wrap js-form-select-options-wrap">
                                        <ul class="form-select-options form-select__options">
                                            <li class="form-select-options__item"
                                                data-option="all">
                                                <b><b>Все</b></b>
                                            </li>
                                            <? foreach ($arParams['EVENT_TYPES'] as $type): ?>
                                                <li class="form-select-options__item <? if ($item['UF_TICKETS_TYPE'] && in_array($type['SKU_ID'], $item['UF_TICKETS_TYPE'])) echo "_icon-checkbox"; ?>"
                                                    data-option="<?= $type['SKU_ID'] ?>">
                                                    <p><?= $type['SKU_CONCAT_TYPE_PRICE'] ?></p>
                                                </li>
                                            <? endforeach;
                                            unset($type); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
	                        <div><?= $item['UF_MIN_COUNT_TICKETS'] ?? '' ?></div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="date__split">
                                <div class="date__split">
	                                <div class="promo-date input__bordered"><?= $item['UF_DATE_START'] ?></div>
                                    -
	                                <div class="promo-date input__bordered"><?= $item['UF_DATE_END'] ?></div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <label class="form-bool-switch cursor-auto">
                                <input type="checkbox"
                                       name="DISCOUNTS[<?= $item['UF_XML_ID'] ?>][UF_IS_SUM]"
                                       value="1" disabled
                                    <? if ($item['UF_IS_SUM'] == 1): ?>
                                        checked
                                    <? else: ?>
                                    <? endif; ?>
                                >
                                <span>НЕТ</span>
                                <span>ДА</span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item js-price-rule-activity">
                            <? if ($item['UF_IS_ACTIVITY']): ?>
                                <div class="status__active">Активен</div>
                            <? else: ?>
                                <div class="status__inactive">Не активен</div>
                            <? endif; ?>
                        </div>
                    </td>
                    <td></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>