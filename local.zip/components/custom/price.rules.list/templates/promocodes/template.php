<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
?>
<div class="adminpanel__header-item-title justify-content-between">
	<?php if($arParams['DISABLED'] !== 'disabled'):?>
    <button type="button" data-promocodes-add class="btn btn-right">Добавить</button>
  <?php endif;?>
</div>
<div class="scroll__table-x">
    <table class="price__table table-ticket-promocode">
        <thead>
        <tr>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Промокод <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Наименование промокода
                        <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>

            <th>
                <div class="price__table-item">
                    <p class="clue__box">Размер скидки <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите размер скидки и выберите единицу измерения: в рублях или процентах
                        <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Вид применения <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите, к какому количеству билетов в заказе будет применен промокод: ко всем или к ограниченному числу. Вы можете задать минимальное и максимальное количество билетов для применения промокода. Также возможно указать только минимальное или только максимальное количество.
                        <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Доступное <br> количество
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Общее количество возможных применений данного промокода
                        <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Срок действия
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите период, в течение которого промокод будет действителен. После истечения указанного срока использование промокода станет недоступным
                        <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Типы билетов <span class="star-required color__red me-1">*</span>
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Укажите на какие типы билетов распрострааняется данный промокод
                        <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Суммируется
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                        Включите этот параметр, если данный промокод можно использовать одновременно с другими промокодами, группами промокодов или скидками
                        <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>
		        <th>
			        <div class="price__table-item">
				        <p class="clue__box">Применять к каждому<br> отдельному билету в заказе
					        <span class="clue" data-clue>
		                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
		                     <span class="clue-body" data-clue-body>
		                        При выборе данной опции промокод будет применяться к каждому отдельному билету, а не к общей сумме заказа.
		                        <span data-popper-arrow></span>
		                     </span>
		                    </span>
				        </p>
			        </div>
		        </th>
            <th>
                <div class="price__table-item">
                    <p class="clue__box">Статус
                        <span class="clue" data-clue>
                     <i class="_icon-question-mark clue-icon" data-clue-icon></i>
                     <span class="clue-body" data-clue-body>
                       Статус промокода отображается автоматически в зависимости от даты действия и настроек активации.
                        <span data-popper-arrow></span>
                     </span>
                    </span>
                    </p>
                </div>
            </th>

            <th></th>
        </tr>
        </thead>
        <tbody>
        <? if (isset($arResult['ITEMS']) && count($arResult['ITEMS']) > 0): ?>
            <? foreach ($arResult['ITEMS'] as $item): ?>
                <tr>
                    <td>
                        <div class="price__table-item">
                            <p><?= $item['PROMOCODES'][0]['NAME'] ?? '' ?></p>
                            <!--<input name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_CODE]" type="text" data-uppercase-input
						       value="<?= $item['PROMOCODES'][0]['NAME'] ?? '' ?>" placeholder="Введите название" class='lg'>-->
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <p><?= $item['UF_DISCOUNT'] ?? '' ?>
                                <? if (empty($item["UF_DISCOUNT_TYPE"]) || $arResult["DISCOUNT_TYPES"][$item["UF_DISCOUNT_TYPE"]]["UF_NAME"] == "Проценты"): ?>%<? else: ?>₽<? endif; ?>
                            </p>
                            <!--<div class="price__grid">
							<input type="text" name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_DISCOUNT]" data-discount-input-mask
							       value="<?= $item['UF_DISCOUNT'] ?? '' ?>" class="input__grey short" data-filter-number data-dynamic-input>
							<label class="form-num-switch">
								<input
									type="checkbox"
									name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_DISCOUNT_TYPE]"
									value="<?= DISCOUNT_TYPE_RUB ?>"
									<? if (empty($item["UF_DISCOUNT_TYPE"]) || $arResult["DISCOUNT_TYPES"][$item["UF_DISCOUNT_TYPE"]]["UF_NAME"] == "Проценты"): ?><? else: ?>checked<? endif; ?>
								>
								<span>%</span>
								<span>₽</span>
							</label>
						</div>-->
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="form-select select__transparent" data-content-select>
                                <input type="hidden" name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_TYPE_APPLY]"
                                       value="<?= $item['UF_TYPE_APPLY_ALL_ORDER'] ? 'all' : ($item['UF_TYPE_APPLY_MIN'] || $item['UF_TYPE_APPLY_MAX'] ? 'range' : '') ?>"/>
                                <!-- empty all range-->
                                <div class="form-select__selected-option">
                                    <span>Выбрать</span>
                                    <div class="form-select__content" data-content-selected-item="all">
                                        <p>Ко всему заказу</p>
	                                    <?php if($arParams['DISABLED'] !== 'disabled'):?>
                                        <i data-content-select-icon>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13"
                                                 viewBox="0 0 12 13" fill="none">
                                                <g clip-path="url(#clip0_4382_23989)">
                                                    <path d="M2.16037 10.6041C2.28037 10.6041 2.30437 10.5921 2.41237 10.5681L4.57237 10.1361C4.80037 10.0761 5.02837 9.96807 5.20837 9.78807L10.4404 4.55607C11.2444 3.75207 11.2444 2.37207 10.4404 1.56807L9.99637 1.10007C9.19237 0.29607 7.80037 0.29607 6.99637 1.10007L1.76437 6.34407C1.59637 6.51207 1.47637 6.75207 1.41637 6.98007L0.960369 9.16407C0.900369 9.57207 1.02037 9.96807 1.30837 10.2561C1.53637 10.4841 1.87237 10.6041 2.16037 10.6041ZM2.56837 7.20807L7.80037 1.96407C8.14837 1.61607 8.78437 1.61607 9.12037 1.96407L9.57637 2.42007C9.98437 2.82807 9.98437 3.40407 9.57637 3.80007L4.35637 9.04407L2.13637 9.41607L2.56837 7.20807Z"
                                                          fill="#2D4765" fill-opacity="0.5"/>
                                                    <path d="M10.3929 11.3477H1.53694C1.18894 11.3477 0.960938 11.5757 0.960938 11.9237C0.960938 12.2717 1.24894 12.4997 1.53694 12.4997H10.3449C10.6929 12.4997 10.9809 12.2717 10.9809 11.9237C10.9689 11.5757 10.6809 11.3477 10.3929 11.3477Z"
                                                          fill="#2D4765" fill-opacity="0.5"/>
                                                </g>
                                                <defs>
                                                    <clipPath id="clip0_4382_23989">
                                                        <rect width="12" height="12" fill="white"
                                                              transform="translate(0 0.5)"/>
                                                    </clipPath>
                                                </defs>
                                            </svg>
                                        </i>
                                      <?php endif;?>
                                    </div>
                                    <div class="form-select__content" data-content-selected-item="range">
                                        <input data-filter-number type="text" placeholder="Min." class="input__grey min"  <?=$arParams['DISABLED']?>
                                               name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_TYPE_APPLY_MIN]"
                                               value="<?= (isset($item['UF_TYPE_APPLY_MIN']) && $item['UF_TYPE_APPLY_MIN'] > 0) ? $item['UF_TYPE_APPLY_MIN'] : '' ?>">-<input
                                                data-filter-number type="text" placeholder="Max."
                                                class="input__grey min"
                                                name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_TYPE_APPLY_MAX]"
                                                value="<?= (isset($item['UF_TYPE_APPLY_MAX']) && $item['UF_TYPE_APPLY_MAX'] > 0) ? $item['UF_TYPE_APPLY_MAX'] : '' ?>">
	                                    <?php if($arParams['DISABLED'] !== 'disabled'):?>
                                        <i data-content-select-icon>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13"
                                                 viewBox="0 0 12 13" fill="none">
                                                <g clip-path="url(#clip0_4382_23989)">
                                                    <path d="M2.16037 10.6041C2.28037 10.6041 2.30437 10.5921 2.41237 10.5681L4.57237 10.1361C4.80037 10.0761 5.02837 9.96807 5.20837 9.78807L10.4404 4.55607C11.2444 3.75207 11.2444 2.37207 10.4404 1.56807L9.99637 1.10007C9.19237 0.29607 7.80037 0.29607 6.99637 1.10007L1.76437 6.34407C1.59637 6.51207 1.47637 6.75207 1.41637 6.98007L0.960369 9.16407C0.900369 9.57207 1.02037 9.96807 1.30837 10.2561C1.53637 10.4841 1.87237 10.6041 2.16037 10.6041ZM2.56837 7.20807L7.80037 1.96407C8.14837 1.61607 8.78437 1.61607 9.12037 1.96407L9.57637 2.42007C9.98437 2.82807 9.98437 3.40407 9.57637 3.80007L4.35637 9.04407L2.13637 9.41607L2.56837 7.20807Z"
                                                          fill="#2D4765" fill-opacity="0.5"/>
                                                    <path d="M10.3929 11.3477H1.53694C1.18894 11.3477 0.960938 11.5757 0.960938 11.9237C0.960938 12.2717 1.24894 12.4997 1.53694 12.4997H10.3449C10.6929 12.4997 10.9809 12.2717 10.9809 11.9237C10.9689 11.5757 10.6809 11.3477 10.3929 11.3477Z"
                                                          fill="#2D4765" fill-opacity="0.5"/>
                                                </g>
                                                <defs>
                                                    <clipPath id="clip0_4382_23989">
                                                        <rect width="12" height="12" fill="white"
                                                              transform="translate(0 0.5)"/>
                                                    </clipPath>
                                                </defs>
                                            </svg>
                                        </i>
                                      <?php endif;?>
                                    </div>
                                </div>

                                <div class="form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li
                                                class="form-select-options__item"
                                                data-option="all"
                                                data-content-select-item
                                        >
                                            <p>Ко всему заказу</p>
                                        </li>
                                        <li
                                                class="form-select-options__item"
                                                data-option="range"
                                                data-content-select-item
                                        >
                                            <p>Указать количество билетов</p>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <input type="text" name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_MAX_NUMBER_OF_USES]"  <?=$arParams['DISABLED']?>
                                   class="min"
                                   value="<?= $item['UF_MAX_NUMBER_OF_USES'] ?? '' ?>" placeholder="Введите кол-во"
                                   data-filter-number>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="date__split">
                                <input type="text" value="<?= $item['UF_DATE_START'] ?? '' ?>"  <?=$arParams['DISABLED']?>
                                       name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_DATE_START]"
                                       placeholder="дд.мм.гг" class="promo-date input__bordered" data-date=""
                                       data-date-split-start="" data-formatted-date readonly="">
                                -
                                <input type="text" value="<?= $item['UF_DATE_END'] ?? '' ?>"  <?=$arParams['DISABLED']?>
                                       name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_DATE_END]" placeholder="дд.мм.гг"
                                       class="promo-date input__bordered" data-date="" data-date-split-end=""
                                       data-formatted-date readonly="">
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <div class="form-select__split">
                                <div class="promo__list" data-promocodes-category-grid>
                                    <? if ((!is_array($item['UF_TICKETS_TYPE']) || count($item['UF_TICKETS_TYPE']) < 1) && (int)$item['UF_FOR_ALL_TYPES'] < 1): ?>
                                    <? elseif ((int)$item['UF_FOR_ALL_TYPES'] == 1): ?>
                                        <div class="promo__item">
                                            <span>Все</span>
                                            <input type="hidden" value="all"  <?=$arParams['DISABLED']?>
                                                   name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]">
	                                        <?php if($arParams['DISABLED'] !== 'disabled'):?>
                                            <i class="_icon-plus"></i>
	                                        <?php endif;?>
                                        </div>
                                    <? else: ?>
                                        <? foreach ($item['UF_TICKETS_TYPE'] as $type): ?>
                                            <div class="promo__item">
                                <span>
                                    <?= $arParams['EVENT_TYPES'][$type]['SKU_CONCAT_TYPE_PRICE'] ?>
                                </span>
                                                <input type="hidden" value="<?= $type ?>"  <?=$arParams['DISABLED']?>
                                                       name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]">
	                                            <?php if($arParams['DISABLED'] !== 'disabled'):?>
                                                <i class="_icon-plus"></i>
	                                            <?php endif;?>
                                            </div>
                                        <? endforeach;
                                        unset($type); ?>
                                    <? endif; ?>
                                </div>
                                <div class="form-select form-select__group js-form-select"
                                     data-multyple-select="[data-promocodes-category-grid]"
                                     data-multyple-guid="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]"
                                     data-all-guid="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_TICKETS_TYPE][]"
                                >
	                                <?php if($arParams['DISABLED'] !== 'disabled'):?>
                                    <div class="form-select__selected-option js-form-select-option js-option-change">
                                        <button type="button" class="form-select__add-btn">
                                            <i class="_icon-plus"></i>
                                        </button>
                                    </div>
                                  <?php endif;?>
                                    <div class="form-select-options-wrap js-form-select-options-wrap">
                                        <ul class="form-select-options form-select__options">
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="all">
                                                <p><b>Все</b></p>
                                            </li>
                                            <? foreach ($arParams['EVENT_TYPES'] as $type): ?>
                                                <li class="form-select-options__item js-form-select-options-item <? if ($item['UF_TICKETS_TYPE'] && in_array($type['SKU_ID'], $item['UF_TICKETS_TYPE'])) echo "_icon-checkbox"; ?>"
                                                    data-option="<?= $type['SKU_ID'] ?>">
                                                    <p><?= $type['SKU_CONCAT_TYPE_PRICE'] ?></p>
                                                </li>
                                            <? endforeach;
                                            unset($type); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="price__table-item">
                            <label class="form-bool-switch">
                                <input <?=$arParams['DISABLED']?> type="checkbox"
                                       name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_IS_SUM]"
                                       value="<?= (int)$item['UF_IS_SUM'] ?>"
                                    <? if ($item['UF_IS_SUM'] == 1): ?>
                                        checked
                                    <? else: ?>
                                    <? endif; ?>
                                >
                                <span>НЕТ</span>
                                <span>ДА</span>
                            </label>

                        </div>
                    </td>
		                <td>
			                <div class="price__table-item">
				                <label class="form-bool-switch">
					                <input <?=$arParams['DISABLED']?> type="checkbox"
					                       name="PROMOCODES[<?= $item['UF_XML_ID'] ?>][UF_FOR_EACH_TICKET]"
					                       value="<?= (int)$item['UF_FOR_EACH_TICKET'] ?>"
				                <? if ($item['UF_FOR_EACH_TICKET'] == 1): ?>
								                checked
				                <? else: ?>
				                <? endif; ?>
					                >
					                <span>НЕТ</span>
					                <span>ДА</span>
				                </label>

			                </div>
		                </td>
                    <td>
                        <div class="events__table-item js-price-rule-activity">
                            <? if ($item['UF_IS_ACTIVITY']): ?>
                                <div class="status__active">Активен</div>
                            <? else: ?>
                                <div class="status__inactive">Не активен</div>
                            <? endif; ?>
                        </div>
                    </td>
                    <td>
	                    <?php if($arParams['DISABLED'] !== 'disabled'):?>
                        <div class="events__table-controls" data-event-controls="">
                            <button type="button" class="btn__icon" data-event-controls-btn="">
                                <i class="_icon-rounds"></i>
                            </button>
                            <div class="events__table-controls-body" data-event-controls-body="">
                                <ul>
                                    <li>
                                        <a href="javascript:void(0);"
                                           data-price-rule-activity="<?= $arParams['SEF_FOLDER'] . $item['ID'] ?>/?action=setActivity&ajax=y&event-id=<?= $arParams['EVENT_ID'] ?>"><?= ($item['UF_IS_ACTIVITY']) ? 'Деактивировать' : 'Активировать' ?></a>
                                    </li>
                                    <? if (!$item['PROMOCODES'][0]['IS_USE']): ?>
                                        <li>
                                            <a href="javascript:void(0);"
                                               data-delete-confirm-title="промокод <?= $item['PROMOCODES'][0]['NAME'] ?? '' ?>"
                                               data-delete-confirm="<?= $item['UF_XML_ID'] ?>">Удалить</a>
                                        </li>
                                    <? endif; ?>
                                </ul>
                            </div>
                        </div>
                      <?php endif;?>
                    </td>
                </tr>
            <? endforeach; ?>
        <? endif; ?>
        </tbody>
    </table>
</div>
<div class="price__save-wrapper">
	<?php if($arParams['DISABLED'] !== 'disabled'):?>
    <a href="javascript:void(0);" class="btn btn__fix-width btn-right" data-event-price-save>Сохранить</a>
  <?php endif;?>
</div>