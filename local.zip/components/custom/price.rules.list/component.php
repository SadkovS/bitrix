<?

if ( ! defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
	die();
}
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\ORM;
use Bitrix\Main\Application;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if ( ! isset($arParams["CACHE_TIME"])) {
	$arParams["CACHE_TIME"] = 180;
}
$arParams["EVENT_ID"] = intval($arParams["EVENT_ID"]);

if ( ! CModule::IncludeModule("highloadblock")) {
	$this->AbortResultCache();
	ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
	
	return;
}

$arTypes = [];
foreach ($arParams['EVENT_TYPES'] as $type) {
	$type["SKU_CONCAT_TYPE_PRICE"] = $type["SKU_TYPE"].". ".\Custom\Core\Helper::priceFormat($type["SKU_PRICE"]);
	$arTypes[$type['SKU_ID']] = $type;
}

$arParams['EVENT_TYPES'] = $arTypes;
unset($arTypes);

$this->arResult['DISCOUNT_TYPES'] = \Custom\Core\Helper::getDiscountTypes();


$query                         = new ORM\Query\Query('\Custom\Core\FieldEnumTable');
$this->arResult['APPLY_TYPES'] = [];
$resType                       = $query->setSelect(['ID', 'UF_NAME' => 'VALUE'])->setOrder(['SORT' => 'ASC']
)->setFilter(['USER_FIELD_ID' => FIELD_TYPE_OF_APPLY_ID])->setCacheTtl(3600)->exec();
while ($type = $resType->fetch()) {
	$this->arResult['APPLY_TYPES'][$type['ID']] = $type;
}

unset($query, $resType, $type);


if ( ! function_exists('getPromoCodeList')) {
	function getPromoCodeList(int $userId, int $eventId)
	{
		$res              = [];
		$priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');
		
		$filter = [
			/*'CREATED_BY'          => $userId,*/
			'REF_EVENTS_ID.VALUE' => $eventId,
			'UF_TYPE'             => PRICE_RULE_TYPE_COUPON
		];
		
		$query = $priceRulesEntity->setSelect([
			                                      '*',
			                                      'PROMOCODE_ID'     => 'REF_PROMOCODE.ID',
			                                      'PROMOCODE_NAME'   => 'REF_PROMOCODE.UF_CODE',
			                                      'PROMOCODE_XML_ID' => 'REF_PROMOCODE.UF_XML_ID',
			                                      'PROMOCODE_IS_USE' => 'REF_PROMOCODE.UF_IS_USE',
			                                      'CREATED_BY'       => 'REF_EVENTS.UF_CREATED_BY',
		                                      ])->setFilter($filter)->countTotal(true)->exec();
		
		while ($priceRule = $query->fetch()) {
			if ((int)$priceRule['PROMOCODE_ID'] <= 0) {
				continue;
			}
			if ( ! isset($res[$priceRule['ID']])) {
				$res[$priceRule['ID']] = array_merge(fillPriceRuleItemArr($priceRule), ['PROMOCODES' => []]);
			}
			
			if (isset($res[$priceRule['ID']]['PROMOCODES']) && (int)$priceRule['PROMOCODE_ID'] > 0) {
				$res[$priceRule['ID']]['PROMOCODES'][] = [
					'ID'     => $priceRule['PROMOCODE_ID'],
					'NAME'   => $priceRule['PROMOCODE_NAME'],
					'IS_USE' => $priceRule['PROMOCODE_IS_USE'],
					'XML_ID' => $priceRule['PROMOCODE_XML_ID'],
				];
			}
		}
		
		return $res;
	}
}

if ( ! function_exists('getGroupOrDiscountList')) {
	function getGroupOrDiscountList(int $userId, int $eventId, int $type)
	{
		if ( ! in_array($type, [PRICE_RULE_TYPE_GROUP, PRICE_RULE_TYPE_DISCOUNT])) {
			throw new Exception('Некорректный тип ценового правила!');
		}
		
		$res = [];
		
		$filter = [
			/*'CREATED_BY'          => $userId,*/
			'REF_EVENTS_ID.VALUE' => $eventId,
			'UF_TYPE'             => $type
		];
		
		$priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');
		$query            = $priceRulesEntity->setSelect([
			                                                 '*',
			                                                 'CREATED_BY' => 'REF_EVENTS.UF_CREATED_BY',
		                                                 ])->setFilter($filter)->countTotal(true)->exec();
		
		while ($priceRule = $query->fetch()) {
			if ( ! isset($res[$priceRule['ID']])) {
				$res[$priceRule['ID']] = fillPriceRuleItemArr($priceRule);
			}
		}
		
		return $res;
	}
}

if ( ! function_exists('fillPriceRuleItemArr')) {
	function fillPriceRuleItemArr(array $priceRule): array
	{
		return [
			'ID'                      => $priceRule['ID'],
			'UF_XML_ID'               => $priceRule['UF_XML_ID'],
			'UF_TYPE_APPLY_ALL_ORDER' => (int)$priceRule['UF_TYPE_APPLY_ALL_ORDER'],
			'UF_TYPE_APPLY_MIN'       => (int)$priceRule['UF_TYPE_APPLY_MIN'],
			'UF_TYPE_APPLY_MAX'       => (int)$priceRule['UF_TYPE_APPLY_MAX'],
			'UF_NAME'                 => $priceRule['UF_NAME'],
			'UF_DISCOUNT_TYPE'        => $priceRule['UF_DISCOUNT_TYPE'],
			'UF_DISCOUNT'             => $priceRule['UF_DISCOUNT'],
			'UF_DATE_START'           => is_object(
				$priceRule['UF_DATE_START']
			) ? $priceRule['UF_DATE_START']->format(
				'd.m.y'
			) : null,
			'UF_DATE_END'             => is_object($priceRule['UF_DATE_END']) ? $priceRule['UF_DATE_END']->format(
				'd.m.y'
			) : null,
			'UF_EVENT_ID'             => $priceRule['UF_EVENT_ID'],
			'UF_TICKETS_TYPE'         => $priceRule['UF_TICKETS_TYPE'],
			'UF_FOR_ALL_TYPES'        => $priceRule['UF_FOR_ALL_TYPES'],
			'UF_MIN_COUNT_TICKETS'    => $priceRule['UF_MIN_COUNT_TICKETS'],
			'UF_IS_SUM'               => $priceRule['UF_IS_SUM'],
			'UF_FOR_EACH_TICKET'      => $priceRule['UF_FOR_EACH_TICKET'],
			'UF_TYPE'                 => $priceRule['UF_TYPE'],
			'UF_NUMBER_OF_USES'       => $priceRule['UF_NUMBER_OF_USES'],
			'UF_MAX_NUMBER_OF_USES'   => $priceRule['UF_MAX_NUMBER_OF_USES'],
			'UF_IS_ACTIVITY'          => $priceRule['UF_IS_ACTIVITY'],
		];
	}
}


if ($arParams['EVENT_ID'] > 0) {
	switch ($arParams['COMPONENT_TEMPLATE'] ?? 'promocodes') {
		case 'groups':
		{
			$this->arResult['ITEMS'] = getGroupOrDiscountList(
				$USER->GetID(),
				$arParams['EVENT_ID'],
				PRICE_RULE_TYPE_GROUP
			);
			break;
		}
		case 'discounts':
		{
			$this->arResult['ITEMS'] = getGroupOrDiscountList(
				$USER->GetID(),
				$arParams['EVENT_ID'],
				PRICE_RULE_TYPE_DISCOUNT
			);
			break;
		}
		default:
		{
			$this->arResult['ITEMS'] = getPromocodeList($USER->GetID(), $arParams['EVENT_ID']);
			break;
		}
	}
} else {
	$this->AbortResultCache();
	ShowError(GetMessage("WRONG_COMPONENT_PARAMS"));
	
	return;
}
$this->SetResultCacheKeys(array());
$this->IncludeComponentTemplate();

?>
