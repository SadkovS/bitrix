<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
{
	die();
}

/** @var array $arCurrentValues */

use Bitrix\Main\Loader;

if (!Loader::includeModule('highloadblock'))
{
	return;
}

$arComponentParameters = [
	"GROUPS" => [
	],
	"PARAMETERS" => [
		"HLB_PRICE_RULES_ID" => [
			"PARENT" => "BASE",
			"NAME" => GetMessage("HLB_PRICE_RULES_ID"),
			"TYPE" => "STRING",
			"VALUE" => '',
			"DEFAULT" => 12,
		],
		"HLB_PROMOCODES_ID" => [
			"PARENT" => "BASE",
			"NAME" => GetMessage("HLB_PROMOCODES_ID"),
			"TYPE" => "STRING",
			"VALUE" => '',
			"DEFAULT" => 12,
		],
		"EVENT_ID" => [
			"PARENT" => "BASE",
			"NAME" => GetMessage("EVENT_ID"),
			"TYPE" => "STRING",
			"DEFAULT" => '',
		],
		"COMPONENT_TEMPLATE" => [
			"PARENT" => "BASE",
			"NAME" => GetMessage("COMPONENT_TEMPLATE"),
			"TYPE" => "STRING",
			"DEFAULT" => '',
		],
		"EVENT_TYPES" => [
			"PARENT" => "BASE",
			"NAME" => GetMessage("EVENT_ID"),
			"TYPE" => "LIST",
			"VALUES" => [],
			"DEFAULT" => '',
		],
		"CACHE_TIME"  =>  ["DEFAULT"=>180],
		"CACHE_GROUPS" => [
			"PARENT" => "CACHE_SETTINGS",
			"NAME" => GetMessage("CP_BPR_CACHE_GROUPS"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "Y",
		],
	],
];
