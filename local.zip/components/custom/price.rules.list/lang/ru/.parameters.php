<?
$MESS["HLB_PRICE_RULES_ID"] = "ID хайлоадблока ценовых правил";
$MESS["HLB_PROMOCODES_ID"] = "ID хайлоадблока промокодов";
$MESS["EVENT_ID"] = "ID мероприятия";
//$MESS["FIELD_TYPE_OF_APPLY_ID"] = "ID списка тип применения";
//$MESS["FIELD_DISCOUNT_TYPE_ID"] = "ID тип скидки";
$MESS["EVENT_TYPES"] = "Типы мероприятия";
$MESS["IBLOCK_ANY"] = "(любой)";
$MESS["CP_BPR_CACHE_GROUPS"] = "Учитывать права доступа";
$MESS["COMPONENT_TEMPLATE"] = "Шаблон";

?>