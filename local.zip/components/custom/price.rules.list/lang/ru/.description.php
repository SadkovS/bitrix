<?
$MESS ['C_HLB_PRICE_RULES_LIST'] = "Список ценовых правил";
$MESS ['C_HLB_CAT_PRICE_RULES'] = "Ценовые правила";
$MESS ['C_HLB_PRICE_RULES_LIST_DESC'] = "Выводит ценовые правила";
$MESS ['C_HLB_COMPONENTS'] = "FunStore";
?>