<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME"        => GetMessage("CMPX_TICKETS_NAME"),
    "DESCRIPTION" => GetMessage("CMPX_TICKETS_DESC"),
    "CACHE_PATH"  => "Y",
    "COMPLEX"     => "Y",
    "PATH"        => [
        "ID"    => "custom",
        "CHILD" => [
            "ID"    => "orders",
            "NAME"  => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT"  => 20,
            "CHILD" => [
                "ID" => 'tickets_cmpx',
            ]
        ]
    ],
];
?>