<?
$MESS ['CMPX_TICKETS_NAME'] = "Билеты";
$MESS ['CMPX_TICKETS_DESC'] = "Выводит информацию о купленных билетах";
$MESS ['C_HLDB_CAT_ORDERS'] = "Заказы";
?>