<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$APPLICATION->RestartBuffer();

$is_telegram = $_REQUEST['type'] === 'telegram' || $arResult["TYPES"][$arResult['UF_TYPE']]["ENUM_XML_ID"] == "telegram";
?>

<div class="popup__content">
    <?if(!isset($_REQUEST['under_popup'])):?>
        <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i></button>
    <?else:?>
        <button class="popup__close profile__popup-close" data-under-close type="button"><i class="_icon-plus"></i></button>
    <?endif;?>
    <style>
        .js-color-vars {
            --widget-bg: <?=$arResult['UF_BG_COLOR']?:'#E9EBF1'?>;
            --widget-card: <?=$arResult['UF_CARDS_COLOR']?:'#FFF'?>;
            --widget-font: <?=$arResult['UF_TEXT_COLOR']?:'#021231'?>;
            --widget-btn: <?=$arResult['UF_TEXT_BUTTON_COLOR']?:'#FFF'?>;
            --widget-accent: <?=$arResult['UF_ACCENT_COLOR']?:'#C92341'?>;
        }
    </style>
    <div class="widget-grid js-color-vars">
        <?php
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $templatePath = SITE_TEMPLATE_PATH;

        $url = $protocol . '://' . $host . $templatePath;
        $iframePath = "$protocol://" . $_SERVER["SERVER_NAME"] . "/widget/event/" . $arResult['PRODUCT_ID'] . "/" . $arResult['UF_UUID'] . "/";

        if ($is_telegram)
        {
            $tgBotName = \Bitrix\Main\Config\Option::get("custom.core", "TG_BOT_NAME");
            $tgPath = "t.me/".$tgBotName."/tg_app?startapp=".$arResult['PRODUCT_ID']."_".$arResult['UF_UUID'];
	          $iframePath = "$protocol://" . $_SERVER["SERVER_NAME"] ."/tg/?tgWebAppStartParam=".$arResult['PRODUCT_ID']."_".$arResult['UF_UUID'];
        }

        ?>
	      <input type="hidden" class="js-full-tg-path-frist" value="<?="t.me/".$tgBotName."/tg_app?startapp="?>">
	      <input type="hidden" class="js-widget-uuid" value="<?=$arResult['UF_UUID']?>">
	      <input type="hidden" class="js-product-id" value="">
        <input class="js-template-url" type="hidden" value="<?=$url?>">

        <div class="widget-grid__body create-event grey__body">
            <div class="widget-tabs p-0" data-tabs>
                <nav class="" data-tabs-titles="">
                    <button class="price__title tab-active" type="button"><span>Предпросмотр</span></button>
                    <button class="price__title" type="button"><span><?= $is_telegram ? "Ссылка для Telegram" : "Код для вставки" ?></span></button>
                </nav>

                <div class="widget-tabs__content" data-tabs-body>
                    <div class="widget-tabs__body">
                        <iframe class="widget-tabs__iframe <?= $is_telegram ? 'widget-tabs__iframe--mobile' : ''?>" frameborder="0" id="widget-iframe"
                                src="<?=$iframePath?>?preview=Y"></iframe>
                    </div>
                    <div class="widget-tabs__body">
	                    <div class="widget-code-head">
	                      <?php if ($is_telegram && !$arResult['PRODUCT_ID']): ?>
				                    <a class="btn btn__fix-width js-btn-get-t-link" href="#">Получить ссылку</a>
		                        <a class="btn btn__fix-width js-copy-widget-code  js-btn-copy-link hide" data-copy=".js-widget-code" href="#">Скопировать</a>
	                      <?php else: ?>
				                    <a class="btn btn__fix-width js-copy-widget-code" data-copy=".js-widget-code" href="#">Скопировать</a>
	                      <?php endif; ?>
	                    </div>
	                    <div class="widget-code js-widget-code">
	                      <?php if ($is_telegram): ?>
			                      <?php if ($arResult['PRODUCT_ID']): ?>
						                    <?= $tgPath ?>
			                      <?php else: ?>
			                          <span class="" style="color: rgba(0, 0, 0, 0.30);">t.me//</span>
			                      <?php endif; ?>

	                      <?php else: ?>

			                      <?php $templateWidgetPath = "$protocol://" . $_SERVER["SERVER_NAME"] . "/local/templates/widget/assets/"; ?>
				                    <textarea readonly><div class="widget-inner-iframe">
	<link rel="stylesheet" href="<?= "$protocol://" . $_SERVER["SERVER_NAME"] . \Custom\Core\Helper::asset_with_version("/local/templates/widget/assets/widget-popup-style.css") ?>">
	<script src="<?= "$protocol://" . $_SERVER["SERVER_NAME"] . \Custom\Core\Helper::asset_with_version("/local/templates/widget/assets/widget-popup.js") ?>"></script>
	<iframe class="widget-tabs__iframe" referrerpolicy="same-origin" data-analytic='iframe' frameborder="0" id="widget-iframe" src="<?= $iframePath ?>" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
 allow="clipboard-write"></iframe>
								</div></textarea>
	                      <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <form action="<?=$arParams['SEF_FOLDER'].(int)$arParams['ELEMENT_ID']?>/" method="POST" class="widget-grid__aside grey__body js-form-validate">
	        <input type="hidden" name="action" value="setWidget">
            <input type="hidden" name="UUID" value="<?=$arResult['UF_UUID']?>">

            <?if(!$arResult['DISABLED']):?>
                <div class="widget-grid__aside-head">
                    <a class="btn btn__fix-width js-reset-param" href="#">Сбросить настройки</a>
                </div>
            <?endif;?>


            <div class="form-item gap-1 required">
				<span class="form-item__label form-item__label--bold d-flex align-items-center clue__box">
					<span>Название</span>
					<span class="clue" data-clue="">
						<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
						<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
							Пожалуйста, добавляйте отдельный виджет для каждого вашего сайта — это необходимо для корректной работы аналитики
							<span data-popper-arrow=""></span>
						</span>
					</span>
				</span>

                <div class="search__body finance-grid-itm__line" >
                    <div class="search__form search__form--w100">
                        <input <?=$arResult['DISABLED']?> autocomplete="off" class="search__input" name="UF_NAME"
                               placeholder="Введите название виджета" type="text" value="<?=$arResult['UF_NAME']?>">
                    </div>
                </div>
            </div>


            <div class="form-item gap-1 required">
				<span class="form-item__label form-item__label--bold d-flex align-items-center">
					<span>Мероприятие</span>
				</span>

                <div class="search__body finance-grid-itm__line <?=isset($_REQUEST['under_popup']) || (int)$arResult['ORDERS_CNT'] > 0 ?'disabled':''?>" data-search="">
                    <div class="search__form search__form--w100 js-search-page-g" data-url="<?=$arParams['SEF_FOLDER'].(int)$arParams['ELEMENT_ID'].'/?action=searchEvent'?>">
                        <input class="js-search-page-g-id" name="UF_EVENT_ID" type="hidden" value="<?=$arResult['UF_EVENT_ID']?>">
                        <input <?=$arResult['DISABLED']?> autocomplete="off" class="search__input" placeholder="Поиск"
                               type="text" value="<?=$arResult['EVENT_NAME']?>" <?=isset($_REQUEST['under_popup']) || (int)$arResult['ORDERS_CNT'] > 0 ?'disabled':''?>>
                        <ul class="search__list"></ul>
                    </div>
                </div>
            </div>


	        <?php if(!$is_telegram):?>
                <div class="form-item gap-1 mb-3">
                    <span class="form-item__label form-item__label--bold d-flex align-items-center">
                        <span>Выбор типа виджета</span>
                    </span>

                    <div class="form-radio-switch form-radio-switch--no-padding">
                        <?foreach ($arResult['TYPES'] as $type):?>
                            <?if($type["ENUM_XML_ID"] == "telegram") continue;?>
                            <label>
                                <input <?=$arResult['DISABLED']?> class="js-change-widget-type" <?=$type['ENUM_ID'] == $arResult['UF_TYPE'] || $type['CHECKED'] == 'Y' ?'checked':''?>  name="UF_TYPE" type="radio" value="<?=$type['ENUM_ID']?>">
                                <span class="form-radio-switch__itm"><?=$type['ENUM_NAME']?></span>
                            </label>
                        <?endforeach;?>
                    </div>
                </div>
            <?php else:?>
                <?foreach ($arResult['TYPES'] as $type):?>
                    <?if($type["ENUM_XML_ID"] != "telegram") continue;?>
                    <input name="UF_TYPE" value="<?=$type['ENUM_ID']?>" hidden>
                <?endforeach;?>
            <?php endif; ?>

            <div class="form-item gap-1">
				<span class="form-item__label form-item__label--bold d-flex align-items-center">
					<span>Выбор цвета</span>
				</span>

                <div class="widget-color-list">

                    <div class="widget-color-itm">
                        <div class="widget-color-itm__name">Цвет фона</div>
                        <div class="widget-color-itm__value color-field">
                            <input <?=$arResult['DISABLED']?> class="color-field__input" data-coloris data-var="--widget-bg" type="text"
                                   value="<?=$arResult['UF_BG_COLOR']?:'#E9EBF1'?>" name="UF_BG_COLOR">
                            <div class="color-field__round" style="background-color: var(--widget-bg)"></div>
                        </div>
                    </div>

                    <div class="widget-color-itm">
                        <div class="widget-color-itm__name">Цвет карточек</div>
                        <div class="widget-color-itm__value color-field">
                            <input <?=$arResult['DISABLED']?> class="color-field__input" data-coloris data-var="--widget-card" type="text"
                                   value="<?=$arResult['UF_CARDS_COLOR']?:'#FFF'?>" name="UF_CARDS_COLOR">
                            <div class="color-field__round" style="background-color: var(--widget-card)"></div>
                        </div>
                    </div>

                    <div class="widget-color-itm">
                        <div class="widget-color-itm__name">Цвет текста</div>
                        <div class="widget-color-itm__value color-field">
                            <input <?=$arResult['DISABLED']?> class="color-field__input" data-coloris data-var="--widget-font" type="text"
                                   value="<?=$arResult['UF_TEXT_COLOR']?:'#021231'?>" name="UF_TEXT_COLOR">
                            <div class="color-field__round" style="background-color: var(--widget-font)"></div>
                        </div>
                    </div>

                    <div class="widget-color-itm">
                        <div class="widget-color-itm__name">Цвет текста кнопок</div>
                        <div class="widget-color-itm__value color-field">
                            <input <?=$arResult['DISABLED']?> class="color-field__input" data-coloris data-var="--widget-btn" type="text"
                                   value="<?=$arResult['UF_TEXT_BUTTON_COLOR']?:'#FFF'?>" name="UF_TEXT_BUTTON_COLOR">
                            <div class="color-field__round" style="background-color: var(--widget-btn)"></div>
                        </div>
                    </div>

                    <div class="widget-color-itm">
                        <div class="widget-color-itm__name">Акцентный цвет</div>
                        <div class="widget-color-itm__value color-field">
                            <input <?=$arResult['DISABLED']?> class="color-field__input" data-coloris data-var="--widget-accent"
                                   type="text" value="<?=$arResult['UF_ACCENT_COLOR']?:'#C92341'?>" name="UF_ACCENT_COLOR">
                            <div class="color-field__round"
                                 style="background-color: var(--widget-accent)"></div>
                        </div>
                    </div>
                </div>

            </div>


	        <div class="form-item gap-1">

	          <?php if (!$is_telegram): ?>
				        <span class="form-item__label form-item__label--bold d-flex align-items-center clue__box">
									<span>Счетчик метрики</span>
									<span class="clue" data-clue="">
										<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
										<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
											Чтобы получить данные об источниках заказов в вашем счетчике Яндекс Метрике, включите отчеты по электронной торговле в настройках счетчика. Затем скопируйте ID счетчика и вставьте его в это поле.
											<span data-popper-arrow=""></span>
										</span>
									</span>
								</span>

				        <div class="search__body finance-grid-itm__line">
					        <div class="search__form search__form--w100">
						        <input <?=$arResult['DISABLED']?> autocomplete="off" class="search__input js-format-only-number" name="UF_METRIC_COUNTER" placeholder="Введите счётчик Яндекс.Метрики" type="text" value="<?= $arResult['UF_METRIC_COUNTER'] ?>">
					        </div>
				        </div>


				        <span class="form-item__label form-item__label--bold d-flex align-items-center clue__box">
									<span>Measurement Protocol Токен</span>
								</span>

				        <div class="search__body finance-grid-itm__line">
					        <div class="search__form search__form--w100">
						        <input <?=$arResult['DISABLED']?> autocomplete="off" class="search__input" name="UF_MS_TOKEN" placeholder="Введите Measurement Protocol Токен" type="text" value="<?= $arResult['UF_MS_TOKEN'] ?>">
					        </div>
				        </div>
	          <?php endif; ?>

		        <div class="widget-btn-foot">
                    <?if(!$arResult['DISABLED']):?>
                        <button class="btn btn__blue btn__fix-width btn__big js-form-validate-btn js-ajax-form-submit-btn" <?= (isset($_REQUEST['under_popup'])) ? 'data-need-reload-event="true" data-need-reload=".js-event-widget-block"' : 'data-need-reload=".admin-body__item.events"' ?>>
                            Сохранить
                        </button>
                    <?endif;?>
		        </div>
	        </div>
        </form>
    </div>

</div>
<?die;?>