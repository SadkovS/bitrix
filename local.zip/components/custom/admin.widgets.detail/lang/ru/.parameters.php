<?php
$MESS['WIDGET_COUNT'] = 'Количество на странице';