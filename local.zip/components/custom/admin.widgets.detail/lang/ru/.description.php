<?php
$MESS["ADMIN_WIDGET_COMPONENT_DETAIL_NAME"] = "Виджет";
$MESS["ADMIN_WIDGET_COMPONENT_DETAIL_DESCRIPTION"] = "Выводит форму создания/редактирования виджета";