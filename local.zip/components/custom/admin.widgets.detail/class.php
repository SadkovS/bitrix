<?php

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM;
use Custom\Core\Events as Events;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

Loc::loadMessages(__FILE__);

class AdminWidgetsComponent extends \CBitrixComponent {
    private $companyID;
    use \Custom\Core\Traits\PropertyEnumTrait;

    public function __construct($component = null)
    {
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        if ($this->companyID <= 0) return false;
        parent::__construct($component);
    }

    public function executeComponent()
    {
        if($this->request['event'] > 0)
            $eventId = $this->request['event'];
        else
            $eventId = $this->getEventId($this->arParams['ELEMENT_ID']);

        $eventBlockChanges = Events::blockChanges($eventId);

        if (!empty($this->arParams['ACTION']) ) {
            if($eventBlockChanges)
            {
                global $APPLICATION;

                $APPLICATION->RestartBuffer();
                echo json_encode(['status' => 'error', 'message' => 'Запрет на редактирование завершенных событий'], JSON_UNESCAPED_UNICODE);
            }
            else
            {
                $this->execAction($this->arParams['ACTION']);
            }

            die;
        }

        $productEntity         = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $propFieldEventID      = $productEntity->getField('EVENT_ID');
        $propEventIDEntity     = $propFieldEventID->getRefEntity();

        if((int)$this->request['event'] > 0) $filter['UF_EVENT_ID'] = $this->request['event'];

        $widgetEntity = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
        $query        = $widgetEntity
            ->setSelect(
                [
                    '*',
                    'EVENT_NAME' => 'EVENT_REF.UF_NAME',
                    'PRODUCT_ID' => 'PRODUCT.IBLOCK_ELEMENT_ID'
                ]
            )
            ->setFilter(
                [
                    'UF_COMPANY_ID' => $this->companyID,
                    'ID'            => (int)$this->arParams['ELEMENT_ID']
                ]
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'EVENT_REF',
                    'Custom\Core\Events\EventsTable',
                    ['this.UF_EVENT_ID' => 'ref.ID'],
                    ['join_type' => 'left']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PRODUCT',
                    $propEventIDEntity,
                    ['this.UF_EVENT_ID' => 'ref.VALUE'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->exec();
        while ($widget = $query->fetch()) {
            $this->arResult = $widget;
        }
        if(!$this->arResult['UF_UUID']) $this->arResult['UF_UUID'] = \Custom\Core\UUID::uuid8();

        $this->arResult['TYPES'] = $this->getWidgetTypes();
        if(empty($this->arResult['UF_TYPE'])){
            foreach ($this->arResult['TYPES'] as &$type)
                if($type['ENUM_XML_ID'] == 'frame') $type['CHECKED'] = 'Y';
        }

        if((int)$this->request['event'] > 1 && (int)$this->arResult['ID'] < 1){
            $event = $this->getEventByID($this->request['event']);
            $this->arResult['EVENT_NAME'] = $event['UF_NAME'];
            $this->arResult['UF_EVENT_ID'] = $event['ID'];
            $this->arResult['PRODUCT_ID'] = $event['PRODUCT_ID'];
        }

        if((int)$this->arResult['ID'] > 0){
            $this->arResult['ORDERS_CNT'] = $this->getSales($this->arResult['ID'])['CNT'];
        }

        if($eventBlockChanges)
        {
            $this->arResult['DISABLED'] = "disabled";
        }

        $this->includeComponentTemplate();
    }

    public function getWidgetTypes()
    {
        return $this->getPropertiesEnum('Widgets', 'UF_TYPE');
    }

    private function addWidget()
    {
        try{
            global $APPLICATION;
            if (!$this->checkExistEvent($this->request['UF_EVENT_ID'])) throw new Exception('Мероприятие не найдено');
            $arFields = [
                'UF_NAME'              => $this->request['UF_NAME'],
                'UF_EVENT_ID'          => $this->request['UF_EVENT_ID'],
                'UF_TYPE'              => $this->request['UF_TYPE'],
                'UF_COMPANY_ID'        => $this->companyID,
                'UF_UUID'              => $this->request['UUID'],
                'UF_BG_COLOR'          => $this->request['UF_BG_COLOR'],
                'UF_CARDS_COLOR'       => $this->request['UF_CARDS_COLOR'],
                'UF_TEXT_COLOR'        => $this->request['UF_TEXT_COLOR'],
                'UF_TEXT_BUTTON_COLOR' => $this->request['UF_TEXT_BUTTON_COLOR'],
                'UF_ACCENT_COLOR'      => $this->request['UF_ACCENT_COLOR'],
                'UF_METRIC_COUNTER'    => $this->request['UF_METRIC_COUNTER'],
                'UF_MS_TOKEN'          => $this->request['UF_MS_TOKEN'],
            ];
            $widgetEntity    = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
            $widgetDataClass = $widgetEntity->getEntity()->getDataClass();
            $result          = $widgetDataClass::add($arFields);
            if (!$result->isSuccess()) throw new Exception(str_replace("<br>", "\n", implode(', ', $result->getErrors())));
            else{
                $APPLICATION->RestartBuffer();
                echo json_encode(['status' => 'success','id' => $result->getId()], JSON_UNESCAPED_UNICODE);
                die;
            }
        }catch (\Exception $e) {
            $APPLICATION->RestartBuffer();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            die;
        }

    }

    private function updateWidget() {
        try{
            global $APPLICATION;
            if(!$this->checkExistWidget($this->arParams['ELEMENT_ID'])) throw new Exception('Виджет не найден');
            if(!$this->checkExistEvent($this->request['UF_EVENT_ID'])) throw new Exception('Мероприятие не найдено');

            $arFields = [
                'UF_NAME'              => $this->request['UF_NAME'],
                'UF_EVENT_ID'          => $this->request['UF_EVENT_ID'],
                'UF_TYPE'              => $this->request['UF_TYPE'],
                'UF_COMPANY_ID'        => $this->companyID,
                'UF_BG_COLOR'          => $this->request['UF_BG_COLOR'],
                'UF_CARDS_COLOR'       => $this->request['UF_CARDS_COLOR'],
                'UF_TEXT_COLOR'        => $this->request['UF_TEXT_COLOR'],
                'UF_TEXT_BUTTON_COLOR' => $this->request['UF_TEXT_BUTTON_COLOR'],
                'UF_ACCENT_COLOR'      => $this->request['UF_ACCENT_COLOR'],
                'UF_METRIC_COUNTER'    => $this->request['UF_METRIC_COUNTER'],
                'UF_MS_TOKEN'          => $this->request['UF_MS_TOKEN'],
            ];

            $widgetEntity    = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
            $widgetDataClass = $widgetEntity->getEntity()->getDataClass();
            $result          = $widgetDataClass::update($this->arParams['ELEMENT_ID'],$arFields);
            if (!$result->isSuccess()) throw new Exception(str_replace("<br>", "\n", implode(', ', $result->getErrors())));
            else{
                $APPLICATION->RestartBuffer();
                echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
                die;
            }
        }catch (\Exception $e) {
            $APPLICATION->RestartBuffer();
            // header("Content-type: application/json; charset=utf-8");
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            die;
        }
    }

    private function checkExistEvent(int $id): bool
    {
        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $query       = $eventEntity
            ->setSelect(['ID'])
            ->setFilter(['UF_COMPANY_ID' => $this->companyID, 'ID' => $id])
            ->setLimit(1)
            ->countTotal(true)
            ->exec();

        return $query->getCount();
    }

    private function checkExistWidget(int $id): bool
    {
        $widgetEntity = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
        $query        = $widgetEntity
            ->setSelect(['ID'])
            ->setFilter(
                [
                    'UF_COMPANY_ID' => $this->companyID,
                    'ID'            => $id
                ]
            )
            ->exec();
        $res          = $query->fetch();
        return (int)$res['ID'] > 0;
    }

    private function getEventId(int $id): int
    {
        $widgetEntity = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
        $query        = $widgetEntity
            ->setSelect(['UF_EVENT_ID'])
            ->setFilter(
                [
                    'ID' => $id
                ]
            )
            ->exec();
        $res          = $query->fetch();
        return (int)$res['UF_EVENT_ID'];
    }

    private function execAction(string $action): void
    {
        switch ($action) {
            case 'setWidget':
                (int)$this->arParams['ELEMENT_ID'] > 0 ? $this->updateWidget() : $this->addWidget();
                break;
            case 'searchEvent':
                $this->searchEvents();
                break;
            case 'del':
                $this->delete($this->arParams['ELEMENT_ID']);
                break;
        }
    }

    public function searchEvents()
    {
        global $APPLICATION;

        $productEntity         = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $propFieldEventID      = $productEntity->getField('EVENT_ID');
        $propEventIDEntity     = $propFieldEventID->getRefEntity();

        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $eventClass  = $eventEntity->getEntity()->getDataClass();
        $query       = $eventEntity
            ->setSelect(['ID', 'UF_NAME','*','PRODUCT_ID' => 'PRODUCT.IBLOCK_ELEMENT_ID'])
            ->setFilter(['%UF_NAME' => $this->request['q'], 'UF_COMPANY_ID'=> $this->companyID, '!UF_STATUS' => EVENT_STATUS_COMPLETED])
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PRODUCT',
                    $propEventIDEntity,
                    ['this.ID' => 'ref.VALUE'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->exec();

        $result = [];
        while ($event = $query->fetch()) {
            $result[] = ['id' => $event['ID'],'name' => $event['UF_NAME'], 'event' => $event];
        }

        $APPLICATION->RestartBuffer();
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        die;
    }

    public function getEventByID($id)
    {
        $productEntity         = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $propFieldEventID      = $productEntity->getField('EVENT_ID');
        $propEventIDEntity     = $propFieldEventID->getRefEntity();

        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $eventClass  = $eventEntity->getEntity()->getDataClass();
        $query       = $eventEntity
            ->setSelect(['ID', 'UF_NAME','*','PRODUCT_ID' => 'PRODUCT.IBLOCK_ELEMENT_ID'])
            ->setFilter(['ID' => $id, 'UF_COMPANY_ID'=> $this->companyID, '!UF_STATUS' => EVENT_STATUS_COMPLETED])
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PRODUCT',
                    $propEventIDEntity,
                    ['this.ID' => 'ref.VALUE'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->exec();

        return $event = $query->fetch();
    }

    public function checkOrderExist($id): bool
    {
        $dbRes    = \Bitrix\Sale\Order::getList(
            [
                'select'      => [
                    'ID',
                ],
                'filter'      => [
                    "PAYED"                    => "Y",
                    "PROPERTY_WIDGET_ID.CODE"  => 'WIDGET_ID',
                    "PROPERTY_WIDGET_ID.VALUE" => $id,
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID',
                    "PROPERTY_ORGANIZER.VALUE" => $this->companyID,
                ],
                'runtime'     => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_WIDGET_ID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                ],
                'limit' => 1
            ]
        );
        return $dbRes->fetch()['ID'] > 0;
    }

    private function delete(int $id): void
    {
        try{
            global $APPLICATION;
            if(!$this->checkExistWidget($id)) throw new Exception('Виджет не найден');
            if($this->checkOrderExist($id)) throw new Exception('Ошибка удаления');
            $widgetEntity    = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
            $widgetDataClass = $widgetEntity->getEntity()->getDataClass();
            $result          = $widgetDataClass::delete($id);
            if (!$result->isSuccess()) throw new Exception(str_replace("<br>", "\n", implode(', ', $result->getErrors())));
            else{
                $APPLICATION->RestartBuffer();
                echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
                die;
            }
        }catch (\Exception $e) {
            $APPLICATION->RestartBuffer();
            // header("Content-type: application/json; charset=utf-8");
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            die;
        }
    }

    private function getSales($widgetID): array
    {
        $dbRes  = \Bitrix\Sale\Order::getList(
            [
                'select'  => [
                    'ID',
                    'TICKET_PRICE_SUM',
                    'PRICE_REFUND_SUM',
                ],
                'filter'  => [
                    "PAYED"                    => "Y",
                    "PROPERTY_WIDGET_ID.CODE"  => 'WIDGET_ID',
                    "PROPERTY_WIDGET_ID.VALUE" => $widgetID,
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID',
                    "PROPERTY_ORGANIZER.VALUE" => $this->companyID,
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_WIDGET_ID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_REFS',
                        'Bitrix\Sale\Internals\BasketTable',
                        ['this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),
                    (new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_PROPS_IS_REFUNDED',
                        'Bitrix\Sale\Internals\BasketPropertyTable',
                        \Bitrix\Main\ORM\Query\Join::on('ref.BASKET_ID', 'this.BASKET_REFS.ID')
                            ->where("ref.CODE", "=", "IS_REFUNDED")
                    ))->configureJoinType(
                        \Bitrix\Main\ORM\Query\Join::TYPE_LEFT,
                    ),
                    (new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_PROPS_REFUNDED_PRICE',
                        'Bitrix\Sale\Internals\BasketPropertyTable',
                        \Bitrix\Main\ORM\Query\Join::on('ref.BASKET_ID', 'this.BASKET_REFS.ID')
                            ->where("ref.CODE", "=", "REFUNDED_PRICE")
                    ))->configureJoinType(
                        \Bitrix\Main\ORM\Query\Join::TYPE_LEFT,
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'TICKET_PRICE_SUM', 'SUM(%s)', ['BASKET_REFS.PRICE']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'PRICE_REFUND_SUM', 'SUM(%s)', ['BASKET_PROPS_REFUNDED_PRICE.VALUE']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'CNT', 'COUNT(%s)', ['ID']
                    ),
                ],
                'group'   => ['ID']
            ]
        );
        $result = [
            'CNT' => 0,
            'SUM' => 0
        ];
        while ($order = $dbRes->fetch()) {
            $result['CNT'] += 1;
            $result['SUM'] += ((int)$order['TICKET_PRICE_SUM'] - (int)$order['PRICE_REFUND_SUM']);
        }
        return $result;
    }
}