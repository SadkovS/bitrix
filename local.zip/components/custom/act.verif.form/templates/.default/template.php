<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>


<div class="popup__content">
    <button data-close="" type="button" class="popup__close profile__popup-close"><i class="_icon-plus"></i></button>
    <div class="popup__name h1 text-center wrap-balance">
        Вы точно хотите подписать
        акт за <?=$arResult["RU_M_Y"]?>?
    </div>
    <div class="row d-flex justify-content-center">
        <div class="col-auto">
            <button type="button" class="btn btn__blue btn__big btn_act_verif"  data-href="<?=$arParams["SEF_FOLDER"]?>/?action=verif&id=<?=$arResult["ID"]?>&<?=bitrix_sessid_get()?>">Подтвердить</button>
        </div>
        <div class="col-auto">
            <button type="button" class="btn btn__clean btn__big" data-close="">Отмена</button>
        </div>
    </div>
</div>