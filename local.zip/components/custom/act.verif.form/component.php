<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Custom\Core\Products;
use Custom\Core\PriceRules;
use \Bitrix\Main\Localization\Loc;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest()->toArray();;
$files = $context->getRequest()->getFileList()->toArray();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
$actId = $request['id'];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core')
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    if($companyID && $actId)
    {
        $query = new ORM\Query\Query('\Custom\Core\Users\ActsTable');
        $resAct   = $query
            ->setFilter(['ID' => $actId, 'UF_COMPANY' => $companyID])
            ->setSelect([
                'ID', 'UF_DATE'
            ])
            ->setLimit(1)
            ->exec();
        if($act = $resAct->fetch()){
            if($act["UF_DATE"])
            {
                $act["RU_M_Y"] = FormatDate("f Y", MakeTimeStamp($act["UF_DATE"]));
            }

            $this->arResult = $act;
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => "Акт не найден"], JSON_UNESCAPED_UNICODE);
            die;
        }


    }
    else
    {
        echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_NO_COMPANY_FOR_USER")], JSON_UNESCAPED_UNICODE);
        die;
    }



    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}

?>