<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
    die();

use Bitrix\Catalog;
use Bitrix\Iblock;
use Bitrix\Main;
use Bitrix\Main\Error;
use Bitrix\Main\ErrorCollection;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use \Bitrix\Main\Application;
use \Bitrix\Main\Context;
use \Bitrix\Main\Request;
use \Custom\Core\UUID;
use \Custom\Core\Events;
use \Bitrix\Main\ORM;
use Bitrix\Highloadblock as HL;

class SmartBubbles extends CBitrixComponent
{
    public function convertUrlToCheck($url)
    {
        $result = array();
        $smartParts = explode("/", $url);
        foreach ($smartParts as $smartPart)
        {
            $item = false;
            $smartPart = preg_split("/-(from|to|is|or)-/", $smartPart, -1, PREG_SPLIT_DELIM_CAPTURE);

            foreach ($smartPart as $i => $smartElement)
            {
                if ($i == 0)
                {
                    $filterCode = "";

                    if (preg_match("/^price-(.+)$/", $smartElement, $match))
                    {
                        $filterCode = "price";
                    }
                    elseif (preg_match("/^date-(.+)$/", $smartElement, $match))
                    {
                        $filterCode = "date";
                    }
                    else
                    {
                        $filterCode = $smartElement;
                    }
                }
                elseif ($smartElement === "from")
                {
                    $result[$filterCode][$smartElement] = $smartPart[$i+1];
                }
                elseif ($smartElement === "to")
                {
                    $result[$filterCode][$smartElement] = $smartPart[$i+1];
                }
                elseif ($smartElement === "is" || $smartElement === "or")
                {
                    $result[$filterCode][] = $smartPart[$i+1];
                }
            }
            unset($item);
        }
        return $result;
    }

    public function onPrepareComponentParams($arParams)
    {
        return $arParams;
    }

    public function getDefUrl()
    {
        $url = $GLOBALS["APPLICATION"]->GetCurPage();
        $clear = substr($url, 0, strpos($url, "filter/"));

        if($clear)
            return $clear;
        else
            return $url;
    }

    public function makeBubbles($check)
    {
        $result = [];

        foreach ($check as $key => $item)
        {
            if(in_array($key, ["price", "date"]) && $item)
            {
                if($key == "price")
                {
                    if(count($item) > 1)
                    {
                        if($item["from"] == 0 && $item["to"] == 0)
                        {
                            $result[] = [
                                "CODE" => $key,
                                "VALUE" => "Бесплатно"
                            ];
                        }
                        else
                        {
                            $value = "от {$item["from"]} до {$item["to"]} ₽";
                            $value = str_replace(["от 0 ", "до 0 "], "", $value);

                            $result[] = [
                                "CODE" => $key,
                                "VALUE" => $value
                            ];
                        }
                    }
                    else
                    {
                        if($item["from"] != null)
                        {
                            $result[] = [
                                "CODE" => $key,
                                "VALUE" => "от {$item["from"]} ₽"
                            ];
                        }
                        elseif($item["to"] != null)
                        {
                            $result[] = [
                                "CODE" => $key,
                                "VALUE" => "до {$item["to"]} ₽"
                            ];
                        }
                    }
                }
                if($key == "date")
                {
                    $bufDate = [];
                    foreach ($item as $val)
                    {
                        $bufDate[] = \Custom\Core\Helper::rus_date('j F Y', strtotime($val));
                    }

                    $result[] = [
                        "CODE" => $key,
                        "VALUE" => implode(" - ", $bufDate)
                    ];
                }
            }
            elseif($item)
            {
                $categoryName = $this->getEventCategory($item);

                foreach ($item as $val)
                {
                    $result[] = [
                        "CODE" => $key,
                        "XML_ID" => $val,
                        "VALUE" => $categoryName[$val]
                    ];
                }
            }
        }

        return $result;
    }

    public function getEventCategory($code)
    {
        $result = [];

        $eventEntity  = new ORM\Query\Query('Custom\Core\Events\EventsCategoryTable');
        $resEntity    = $eventEntity
            ->setFilter(["UF_CODE" => $code])
            ->setOrder(["UF_SORT" => "ASC"])
            ->setSelect([
                'UF_CODE', 'UF_NAME'
            ])
            ->exec()
            ->fetchAll();

        foreach ($resEntity as $item)
        {
            $result[$item["UF_CODE"]] = $item["UF_NAME"];
        }

        return $result;
    }

    public function executeComponent()
    {
        if($_REQUEST["SMART_FILTER_PATH"])
        {
            $check = $this->convertUrlToCheck($_REQUEST["SMART_FILTER_PATH"]);
            $this->arResult["ITEMS"] = $this->makeBubbles($check);

            $this->arResult["DEF_URL"] = \Custom\Core\Helper::getDefFilterUrl();;
        }

        $this->includeComponentTemplate();
    }

    protected static function getSession(): ?Session
    {
        /** @var Session $session */
        $session = Application::getInstance()->getSession();
        if (!$session->isAccessible())
        {
            return null;
        }

        return $session;
    }

}
