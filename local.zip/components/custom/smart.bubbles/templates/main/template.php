<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>

<?if($arResult["ITEMS"]):?>
    <div class="mb-[35px] mb-c_sm inline-flex w-full flex-col gap-2.5 px-c_narrow md:px-5 lg:px-0">
        <form action="<?=$arResult["DEF_URL"]?>" class="filter__selected-tags flex flex-wrap gap-c_sm">
            <?foreach($arResult["ITEMS"] as $item):?>
                <label class="filter__item-tag">
                    <input type="checkbox" class="hidden" checked data-code="<?=$item["CODE"]?>" value="<?=$item["XML_ID"]?>"/>
                    <span class="tag"><?=$item["VALUE"]?></span>
                </label>
            <?endforeach;?>
            <button class="filter__item-tag" type="submit">
                <span class="tag clear-all">Сбросить все фильтры</span>
            </button>
        </form>
    </div>
<?endif;?>