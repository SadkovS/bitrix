document.addEventListener("DOMContentLoaded", () => {

    $(document).on("change", ".filter__item-tag input",  function (e) {
        e.preventDefault();

        if(!this.checked)
        {
            if($(this).data("code") == "price")
            {
                $("[data-filter-block-reset]").closest('.filter__item').find('input').each(function (e) {
                    if (this.type === "checkbox" || this.type === "radio") {
                        this.checked = false;
                    } else {
                        this.value = '';
                    }
                });

                $("input[name='price_from']").val("");
                $("input[name='price_to']").val("");
            }
            if($(this).data("code") == "date")
            {
                $("[data-calendar-reset]").closest('.filter__item').find('input').each(function (e) {
                    if (this.type === "checkbox" || this.type === "radio") {
                        this.checked = false;
                    } else {
                        this.value = '';
                    }
                });

                document.dispatchEvent(new CustomEvent('calendar-reset', { bubbles: true }));
            }
            if($(this).data("code") == "category")
            {
                $("input[name='"+$(this).data("code")+"'][value='"+$(this).val()+"']").prop('checked', false);
            }

            $("#filter-form").submit();
        }


    });

    $(document).on("submit", "form.filter__selected-tags",  function (e) {
        e.preventDefault();

        const filter = document.querySelector('#filter-form');
        filter.reset();

        let url = $(this).attr("action");

        getHtml(url);
    });
});