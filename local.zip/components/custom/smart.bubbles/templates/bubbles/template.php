<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>


<div class="mb-[35px] mb-c_sm inline-flex w-full flex-col gap-2.5 px-c_narrow md:px-5 lg:px-0 lg:hidden">
    <div class="inline-flex flex-auto gap-c_sm self-stretch xl:justify-between">
        <div class="js-xl-search flex-auto xl:relative xl:inline-flex xl:justify-between xl:gap-[50px]">
            <div class="form__item-wrapper h-fit" data-popup="#search-popup" data-popup-focus="#search">
                <input type="text" class="input search__input" placeholder="Поиск по сайту" autocapitalize="off" autocomplete="off" autocorrect="off" spellcheck="false" />
                <button type="submit" class="search__input-icon">
                    <i class="svg_icon-search"></i>
                </button>
            </div>
        </div>
        <button class="btn__filter" data-popup="#filter">
            <i class="svg_icon-filter"></i>
        </button>
    </div>
    <?if($arResult["ITEMS"]):?>
        <form action="<?=$arResult["DEF_URL"]?>" class="filter__selected-tags flex flex-wrap gap-c_sm">
            <?foreach($arResult["ITEMS"] as $item):?>
                <label class="filter__item-tag">
                    <input type="checkbox" class="hidden" checked data-code="<?=$item["CODE"]?>" value="<?=$item["XML_ID"]?>"/>
                    <span class="tag"><?=$item["VALUE"]?></span>
                </label>
            <?endforeach;?>
            <button class="filter__item-tag" type="submit">
                <span class="tag clear-all">Сбросить все фильтры</span>
            </button>
        </form>
    <?endif;?>
</div>