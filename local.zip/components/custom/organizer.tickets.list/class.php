<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\ORM;
use \Custom\Core\Traits\PropertyEnumTrait;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();

Loader::includeModule('custom.core');
Loader::includeModule('sale');
Loader::includeModule("catalog");


Loc::loadMessages(__FILE__);

class OrganizerTicketsListComponent extends \CBitrixComponent {
    protected int $companyID;
    private array $filter;
    private int $limit;
    private int $offset;
    private int $curPage;
    use PropertyEnumTrait;

    public function __construct($component = null)
    {
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        if ($this->companyID <= 0) return false;

        parent::__construct($component);

        $this->filter = $this->makeFilter();

    }

    public function executeComponent()
    {

        $barcodeStatuses = $this->getPropertiesEnum('Barcodes', 'UF_STATUS');
        $this->setLimit($this->request['action'] == 'export' ? -1 : 0);
        $this->setCurPage();
        $this->setOffset();

        $dbRes = \Bitrix\Sale\Order::getList(
            [
                'select'      => [
                    'ID',
                    'ACCOUNT_NUMBER',
                    'PRICE',
                    'DATE_INSERT',
                    'BUYER'            => 'QUESTIONNAIRE_REF.UF_FULL_NAME',
                    'EMAIL'            => 'QUESTIONNAIRE_REF.UF_EMAIL',
                    'PHONE'            => 'QUESTIONNAIRE_REF.UF_PHONE',
                    'EVENT_ID'         => 'PROPERTY_EVENT_ID.VALUE',
                    'EVENT_NAME'       => 'EVENT.UF_NAME',
                    'TICKET_NUM',
                    'BARCODE'          => 'BARCODE_REF.UF_BARCODE',
                    'BARCODE_STATUS'   => 'BARCODE_REF.UF_STATUS',
                    'ORDER_SUM',
                    'TICKET_TYPE_NAME' => 'BASKET_REFS.NAME',
                    'ROW'              => 'BASKET_PROPS_ROW_REF.VALUE',
                    'SEAT'             => 'BASKET_PROPS_PLACE_REF.VALUE',
                ],
                'filter'      => $this->filter,
                'runtime'     => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    /*new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_BUYER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_EMAIL',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_PHONE',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),*/
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_EVENT_ID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'EVENT',
                        'Custom\Core\Events\EventsTable',
                        ['=this.EVENT_ID' => 'ref.ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_REFS',
                        'Bitrix\Sale\Internals\BasketTable',
                        ['this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_PROPS_ROW_REF',
                        '\Bitrix\Sale\Internals\BasketPropertyTable',
                        [
                            '=this.BASKET_REFS.ID' => 'ref.BASKET_ID',
                            '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?', 'ROW')
                        ],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_PROPS_PLACE_REF',
                        '\Bitrix\Sale\Internals\BasketPropertyTable',
                        [
                            '=this.BASKET_REFS.ID' => 'ref.BASKET_ID',
                            '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?', 'PLACE')
                        ],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_PROPS_BARCODE_REF',
                        '\Bitrix\Sale\Internals\BasketPropertyTable',
                        ['=this.BASKET_REFS.ID' => 'ref.BASKET_ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BARCODE_REF',
                        'Custom\Core\Tickets\BarcodesTable',
                        ['this.BASKET_PROPS_BARCODE_REF.VALUE' => 'ref.ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'QUESTIONNAIRE_TICKET_REF',
                        'Custom\Core\Events\EventsQuestionnaireUfTicketTable',
                        ['=this.BASKET_REFS.ID' => 'ref.VALUE'],
                        ['join_type' => 'LEFT']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'QUESTIONNAIRE_REF',
                        'Custom\Core\Events\EventsQuestionnaireTable',
                        ['=this.QUESTIONNAIRE_TICKET_REF.ID' => 'ref.ID'],
                        ['join_type' => 'LEFT']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'ORDER_SUM', 'SUM(%s)', ['BASKET_REFS.PRICE']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'TICKET_NUM', "CONCAT(%s,'-',%s)", ['BARCODE_REF.UF_SERIES', 'BARCODE_REF.UF_TICKET_NUM']
                    ),
                ],
                'limit'       => $this->limit,
                'group'       => ['ID'],
                'offset'      => $this->offset,
                'order'       => ['DATE_INSERT' => 'DESC'],
                'count_total' => true,
            ]
        );
        while ($order = $dbRes->fetch()) {
            $order['STATUS_NAME'] = $barcodeStatuses[$order['BARCODE_STATUS']]['ENUM_NAME'];

            if ($order['ORDER_SUM'] == 0 && $barcodeStatuses[$order['BARCODE_STATUS']]["ENUM_XML_ID"] == "sold")
                $order['STATUS_NAME'] = "Зарегистрированный";
            $order['TICKET_TYPE_NAME'] = $this->extractTextFromBrackets($order['TICKET_TYPE_NAME']);

            $this->arResult['ITEMS'][] = $order;
        }

        if (isset($this->request['action']) && $this->request['action'] == 'export') {
            require_once 'export_excel.php';
        }

        $this->arResult['ALL_COUNT'] = $dbRes->getCount();
        $this->nav                   = new \CDBResult();
        $this->nav->NavStart($this->limit);
        $this->nav->NavPageCount      = ceil((int)$this->arResult['ALL_COUNT'] / $this->limit);
        $this->nav->NavPageNomer      = $this->curPage;
        $this->nav->NavRecordCount    = $this->arResult['ALL_COUNT'];
        $this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');

        $this->includeComponentTemplate();
    }

    public function onPrepareComponentParams($arParams)
    {
        if ((int)$arParams['TICKETS_PER_PAGE'] < 1) $arParams['TICKETS_PER_PAGE'] = 10;
        return $arParams;
    }

    private function makeFilter(): array
    {
        $filter = [
            "PROPERTY_ORGANIZER.CODE"       => 'ORGANIZER_ID', //по свойству
            "PROPERTY_ORGANIZER.VALUE"      => $this->companyID, //и по его значению
            /*"PROPERTY_BUYER.CODE"           => 'FIO', //по свойству
            "PROPERTY_EMAIL.CODE"           => 'EMAIL', //по свойству
            "PROPERTY_PHONE.CODE"           => 'PHONE', //по свойству*/
            "PROPERTY_EVENT_ID.CODE"        => "EVENT_ID", //и по его значению
            "BASKET_PROPS_BARCODE_REF.CODE" => "BARCODE",
        ];

        if (isset($this->request['n']) && $this->request['n'] != '') {
            $filter['%ACCOUNT_NUMBER'] = $this->request['n'];
        }
        if (isset($this->request['bc']) && $this->request['bc'] != '') {
            $filter['%BARCODE'] = $this->request['bc'];
        }
        if (isset($this->request['b']) && $this->request['b'] != '') {
            $filter['%BUYER'] = $this->request['b'];
        }
        if (isset($this->request['e']) && $this->request['e'] != '') {
            $filter['%EMAIL'] = $this->request['e'];
        }
        if (isset($this->request['p']) && $this->request['p'] != '') {
            $filter['%PHONE'] = $this->request['p'];
        }
        if (isset($this->request['ev']) && $this->request['ev'] != '') {
            $filter['%EVENT_NAME'] = $this->request['ev'];
        }
        if (isset($this->request['sn']) && $this->request['sn'] != '') {
            $filter['%TICKET_NUM'] = $this->request['sn'];
        }
        if (isset($this->request['tp']) && $this->request['tp'] != '') {
            $filter['%TICKET_TYPE_NAME'] = $this->request['tp'];
        }
        if (isset($this->request['r']) && $this->request['r'] != '') {
            $filter['%ROW'] = $this->request['r'];
        }
        if (isset($this->request['s']) && $this->request['s'] != '') {
            $filter['%SEAT'] = $this->request['s'];
        }
        if (isset($this->request['d']) && !empty($this->request['d'])) {
            $date = explode('-', $this->request['d']);
            if (count($date) > 1) {
                $filter[] = [
                    "LOGIC" => 'AND',
                    [">=DATE_INSERT" => $date[0] . ' 00:00:00'],
                    ["<=DATE_INSERT" => $date[1] . ' 23:59:59'],
                ];
            } else {
                $filter[] = [
                    "LOGIC" => 'AND',
                    [">=DATE_INSERT" => $date[0] . ' 00:00:00'],
                    ["<=DATE_INSERT" => $date[0] . ' 23:59:59'],
                ];
            }
        }
        return $filter;
    }

    private function setLimit($limit = 0): void
    {
        if ($limit == 0)
            $this->limit = $this->arParams['TICKETS_PER_PAGE'];
        elseif ($limit < 0)
            $this->limit = 0;
        else
            $this->limit = $limit;
    }

    private function setCurPage()
    {
        $this->curPage = (int)$this->request['PAGEN_1'] > 0 ? (int)$this->request['PAGEN_1'] : 1;
    }

    private function setOffset()
    {
        if (!isset($this->request['PAGEN_1']) || (int)$this->request['PAGEN_1'] <= 1)
            $this->offset = 0;
        else
            $this->offset = ((int)$this->request['PAGEN_1'] - 1) * $this->limit;
    }

    private function extractTextFromBrackets(string $text): string
    {
        if (preg_match('/\[([^\]]+)\]/', $text, $matches)) {
            return trim($matches[1]);
        }
        return '';
    }
}