<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Custom\Core\ExportExcel;

$arDefColumns = [
    '_number'      => ['name' => 'Номер заказа'],
    '_series'      => ['name' => 'Серия и номер'],
    '_barcode'     => ['name' => 'Штрих-код'],
    '_ticket_type' => ['name' => 'Тип билета'],
    '_ticket_row'  => ['name' => 'Ряд'],
    '_ticket_seat' => ['name' => 'Место'],
    '_email'       => ['name' => 'Email'],
    '_phone'       => ['name' => 'Телефон'],
    '_name'        => ['name' => 'ФИО'],
    '_status'      => ['name' => 'Статус'],
    '_sum'         => ['name' => 'Стоимость билета'],
    '_date'        => ['name' => 'Дата заказа'],
    '_event_name'  => ['name' => 'Мероприятие'],
];

if (!is_array($this->arResult['ITEMS']) || count($this->arResult['ITEMS']) < 1) throw new Exception('Заказы не найдены');

$obExport = new ExportExcel();
$obExport->setFileName("tickets.xlsx");
$date = new DateTime();
$date = $date->format('d.m.Y');
$obExport->setFilePath($_SERVER['DOCUMENT_ROOT'] . '/upload/tmp');
$xls = $obExport->createFile();
$xls->getProperties()->setTitle("Тестовый файл");
$xls->getProperties()->setCreated($date);
$xls->setActiveSheetIndex(0);
$sheet = $xls->getActiveSheet();
$sheet->setTitle('Отчет');
$sheet->getRowDimension("1")->setRowHeight(50);
$sheet->getRowDimension("2")->setRowHeight(30);
$sheet->getRowDimension("3")->setRowHeight(40);
$sheet->setCellValue("A1", "Билеты покупателей");
$sheet->mergeCells("A1:H1");
$sheet->getStyle("A1")->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$sheet->getStyle("A1")->getFont()->setSize(22);
$sheet->getStyle("A1")->getFont()->setBold(true);

$i            = 0;
$rowNum       = 4;
$columnsCount = 0;
$arTable      = [];

foreach ($this->arResult['ITEMS'] as $row) {

    if ($i == 0) {
        $arTable['HEAD'] = array_values($arDefColumns);
    }
    $arrColumns = $arDefColumns;
    foreach ($arrColumns as $key => &$col) {

        if ($key == '_event_name') $col['value'] = $row['EVENT_NAME'];
        elseif ($key == '_number') $col['value'] = $row['ACCOUNT_NUMBER'];
        elseif ($key == '_date') $col['value'] = $row['DATE_INSERT'];
        elseif ($key == '_series') $col['value'] = $row['TICKET_NUM'];
        elseif ($key == '_barcode') $col['value'] = $row['BARCODE'];
        elseif ($key == '_ticket_type') $col['value'] = $row['TICKET_TYPE_NAME'];
        elseif ($key == '_ticket_row') $col['value'] = $row['ROW'];
        elseif ($key == '_ticket_seat') $col['value'] = $row['SEAT'];
        elseif ($key == '_email') $col['value'] = $row['EMAIL'];
        elseif ($key == '_phone') $col['value'] = $row['PHONE'];
        elseif ($key == '_name') $col['value'] = $row['BUYER'];
        elseif ($key == '_sum') $col['value'] = $row['ORDER_SUM'];
        elseif ($key == '_status') $col['value'] = $row['STATUS_NAME'];
    }

    $arTable['BODY'][] = $arrColumns;
}

foreach ($arTable['HEAD'] as $key => $headItem) {
    $colLetter = $obExport->getColumnLetter($key + 1);
    $sheet->setCellValue($colLetter . '3', $headItem['name'] ?? '');
    $sheet->getStyle($colLetter . '3')->getFont()->setSize(14);
    $sheet->getStyle($colLetter . '3')->getFont()->setBold(true);
    $sheet->getStyle($colLetter . '3')->getFont()->setItalic(true);
    $sheet->getStyle($colLetter . '3')->applyFromArray(
        [
            'fill' => [
                'type'  => PHPExcel_Style_Fill::FILL_SOLID,
                'color' => ['rgb' => 'e4efdc']
            ]
        ]
    );
    $sheet->getStyle($colLetter . '3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle($colLetter . '3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
unset($key, $row, $i);
foreach ($arTable['BODY'] as $key => $row) {
    $i = 0;
    foreach ($row as $keyCol => $colID) {
        $indexCol  = $i + 1;
        $colLetter = $obExport->getColumnLetter($indexCol);
        if (strlen(strip_tags(is_string($colID['value']) ? $colID['value'] : '')) > 300) {
            $sheet->getColumnDimension($colLetter)->setAutoSize(false);
            $sheet->getColumnDimension($colLetter)->setWidth(150);
        }
        $cellValue = strip_tags(is_array($colID['value']) ? implode(', ', $colID['value']) : $colID['value']);
        if ($keyCol === '_barcode') {
            // Явно устанавливаем тип ячейки как текст, чтобы Excel не интерпретировал длинные числа и не терял точность
            $sheet->setCellValueExplicit($colLetter . $rowNum, (string)$cellValue, PHPExcel_Cell_DataType::TYPE_STRING);
        } else {
            $sheet->setCellValue($colLetter . $rowNum, $cellValue);
        }
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setWrapText(true);
        $sheet->getStyle($colLetter . $rowNum)->getFont()->setSize(14);
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        if ($keyCol == '_status') {
            $styleStatus = $obExport->getStatusStyle(strip_tags($colID['value']));
            $sheet->getStyle($colLetter . $rowNum)->applyFromArray(
                [
                    'fill' => [
                        'type'  => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => ['rgb' => $styleStatus['background']]
                    ]
                ]
            );
            $sheet->getStyle($colLetter . $rowNum)->getFont()->getColor()->setRGB($styleStatus['color']);
            $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
        }
        if ($keyCol == '_barcode') {
            $sheet->getStyle($colLetter . $rowNum)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);
        }
        $i++;
    }
    $rowNum++;
}
$endColLetter = $obExport->getColumnLetter(count($arTable['HEAD']));
$sheet->getStyle("A3:" . $endColLetter . ($rowNum - 1))->applyFromArray($obExport->getBorderStyle());
$obExport->downloadFile($xls);

exit;