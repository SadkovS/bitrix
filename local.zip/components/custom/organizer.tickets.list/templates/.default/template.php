<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Bitrix\Main\Localization\Loc;

use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\ORM;


use Bitrix\Main\Page\Asset;
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
?>
<div class="admin-body__item wide events">
    <div class="admin-body__item-header">

        <div class="admin-body__item-header__left">
            <h1>Билеты</h1>

            <div class="chart-head-date">
                <label class="range-two-date">
                    <div class="range-two-date__val"></div>
                    <div class="range-two-date__sep">—</div>
                    <div class="range-two-date__val"></div>
                    <input class="js-range-two-date js-reload-chart" data-date="range" name="d" type="text" data-url-search="change" value="<?= $request['d'] ?? ''?>">
                </label>
            </div>
        </div>

        <a class="btn btn__fix-width js-downloadLink" data-change-href href="<?=$APPLICATION->GetCurPageParam("action=export", array("action"))?>">Выгрузка</a>

    </div>
    <table class="events__table js-check-table-before-download">
        <thead>
        <tr>

            <td>
                <div class="events__table-item">
                    <label class="events__table-btn" data-table-sort=""><span>Номер заказа</span> <input class="d-none"
                                                                                                         type="checkbox"
                                                                                                         value="1"
                                                                                                         checked>
                        <i class="_icon-vector"></i>
                    </label>
                    <div class="events__form-item">
                        <input name="n" value="<?=$request['n']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input"> <i class="_icon-search"></i>
                    </div>
                </div>
            </td>

            <td>
                <div class="events__table-item">
                    <p>Серия и номер</p>
                    <div class="events__form-item">
                        <input name="sn" value="<?=$request['sn']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input">
                        <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Штрих-код</p>
                    <div class="events__form-item">
                        <input name="bc" value="<?=$request['bc']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input"> <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Тип билета</p>
                    <div class="events__form-item">
                        <input name="tp" value="<?=$request['tp']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input"> <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Ряд</p>
                    <div class="events__form-item">
                        <input name="r" value="<?=$request['r']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input"> <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Место</p>
                    <div class="events__form-item">
                        <input name="s" value="<?=$request['s']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input"> <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>E-mail</p>
                    <div class="events__form-item">
                        <input name="e" value="<?=$request['e']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input"> <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Телефон</p>
                    <div class="events__form-item">
                        <input name="p" value="<?=$request['p']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input"> <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>ФИО</p>
                    <div class="events__form-item">
                        <input name="b" value="<?=$request['b']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input"> <i class="_icon-search"></i>
                    </div>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Статус</p>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Стоимость<br> билета</p>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Дата заказа</p>
                </div>
            </td>
            <td>
                <div class="events__table-item">
                    <p>Мероприятие</p>
                    <div class="events__form-item">
                        <input name="ev" value="<?=$request['ev']?>" class="events__form-input" placeholder="Найти" type="text" data-url-search="input">
                        <i class="_icon-search"></i>
                    </div>
                </div>
            </td>

        </tr>
        </thead>
        <tbody>
        <? foreach ($arResult['ITEMS'] as $item): ?>
            <tr>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['ACCOUNT_NUMBER']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['TICKET_NUM']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['BARCODE']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?= $item['TICKET_TYPE_NAME'] ?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?= $item['ROW'] ?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?= $item['SEAT'] ?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name ">
                            <p><?=$item['EMAIL']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['PHONE']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['BUYER']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <?
                        $statusColor = '';
                        if($item['STATUS_NAME'] == 'Принят' || $item['STATUS_NAME'] == 'Выполнен' || $item['STATUS_NAME'] == 'Проданный' || $item['STATUS_NAME'] == 'Зарегистрированный')
                            $statusColor = 'c-green';
                        elseif($item['STATUS_NAME'] == 'Оплачен' || $item['STATUS_NAME'] == 'Забронирован')
                            $statusColor = 'c-yellow';
                        elseif($item['STATUS_NAME'] == 'Отменен' || $item['STATUS_NAME'] == 'Отменён' || $item['STATUS_NAME'] == 'Возвращенный')
                            $statusColor = 'c-error';
                        elseif($item['STATUS_NAME'] == 'Частичный возврат')
                            $statusColor = 'c-blue';
                        else
                            $statusColor = 'c-dark';
                        ?>
                        <span class="events__table-item-status <?=$statusColor?>"><?= $item['STATUS_NAME'] ?></span>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name no-wrap">
                            <p><?=floatval($item['ORDER_SUM'])?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['DATE_INSERT']?></p>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <div class="events__table-item-name">
                            <p><?=$item['EVENT_NAME']?></p>
                        </div>
                    </div>
                </td>

            </tr>
        <? endforeach; ?>
        </tbody>
    </table>
    <?=$arResult['NAV_STRING']?>

</div>