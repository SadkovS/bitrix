$(document).ready(function () {
    function printFromData(data, pushState = 'page', url) {
        const doc = new DOMParser().parseFromString(data, "text/html");
        const tbody = doc.querySelector('tbody');
        const pagination = doc.querySelector('.pagination.events__pagination');
        const h = doc.querySelector('[data-change-href]');

        window.history.pushState(pushState, "", url.toString());
        const pageTableBody = document.querySelector('.events__table tbody');
        if (pageTableBody && tbody) {
            pageTableBody.replaceWith(tbody);
        }
        const pagePagination = document.querySelector('.events__pagination');
        if (pagePagination && pagination) {
            pagePagination.replaceWith(pagination);
        }

        const hBody = document.querySelector('[data-change-href]');
        if (h && hBody) {
            hBody.replaceWith(h);
        }
    }

    let promise
    // Изменение фильтра
    async function pageTableSortFromUrl() {
        let reject, resolve;
         promise = new Promise((res, rej) => {
            resolve = res;
            reject = rej;
        });
        let url = new Url(window.location.href);
        url.search = '';
        url.query.ajax = 'Y';
        const inputs = [...document.querySelectorAll('input[data-url-search]')];
        for (let i = 0; i < inputs.length; i++) {
            const item = inputs[i];
            if (item.type === 'checkbox') {
                if (item.checked) {
                    url.query[item.name] = item.value
                } else {
                    delete url.query[item.name];
                }
            } else {
                item.value !== '' ? url.query[item.name] = item.value : delete url.query[item.name];
            }
        }
        url.query.PAGEN_1 = 1;

        const response = await fetch(url);
        if (!response.ok) {
            console.error(response.statusText);
            return
        }
        const data = await response.text();
        printFromData(data, "event search", url);

        resolve();
        return promise;
    }

   async function  multypleSearch(e) {
        const target = e.target;
        const input = target.closest('[data-multyple-search-select] input[data-multyple-search-select-input]');
        if (!input) return;
        const url = new URL( window.location.href);
        url.search = 'ACTION=eSearch&es_q=' + input.value;
        const request = await fetch(url.href);
        if (!request.ok) {
            console.error(request)
            return;
        }
        const data = await request.json();
        const parent = target.closest('[data-multyple-search-select]');
        const container = parent.querySelector('[data-multyple-search-select-options] .form-select-options');
        const childrens = [...container.children];
        childrens.filter(item => {
            if (!item.querySelector('input[type="checkbox"]').checked === true) {
                item.remove();
            }
        });
       printElements:  for(let i in data) {
            for(let j = 0; j < childrens.length; j++) {
                const el = childrens[j].querySelector('[data-multyple-search-select-item]');
                if (el.getAttribute('data-multyple-search-select-item') === data[i].ID && el.querySelector('input[type="checkbox"]').checked) {
                    continue printElements;
                }
            }
            const item = searchItemCreate(data[i]);
            container.insertAdjacentHTML('beforeend', item);
        }
    }

    function searchItemCreate({ID, TITLE, SUB_TITLE} = data) {
       const item = `<li><label class="form-select-options__item multyple-select__option" data-multyple-search-select-item="${ID}">
                                <span class="checkbox">
                                    <input type="checkbox" value="${ID}" name="events[${ID}]" data-promo-filter="${TITLE}">
                                    <span class="_icon-checkbox"></span>
                                </span>
                                <div class="multyple-select__option-content">
                                    <p>${TITLE}</p>
                                    <p class="color__grey">${SUB_TITLE}</p>
                                </div>
                            </label></li>`
        return item;
    }

    function createPromoFilterItem(NAME, ID, TITLE) {
        const wrapper = document.createElement('div');
        wrapper.classList.add('promo__item', 'filter__item');
        const input = document.createElement('input')
        input.name = NAME;
        input.value = ID;
        input.type = 'checkbox';
        input.checked = true;
        input.dataset.urlSearch = 'change';
        input.dataset.promoItem = TITLE;
        input.classList.add('d-none');

        const title = document.createElement('span')
        title.textContent = TITLE
        const icon = document.createElement('i')
        icon.classList.add('_icon-plus');
        wrapper.append(input, title, icon);
        return wrapper
    }

    function deleteFilter(e) {
        const target = e.target;
        const btn = target.closest('.promo__item.filter__item i');
        if (!btn) return;
        const wrapper = target.closest('.promo__item.filter__item')
        const input = wrapper.querySelector('input[data-promo-item]');
        const ID = input.value;
        const TITLE = input.dataset.promoItem;
        const filterEl =   document.querySelector('[data-promo-filter="' + TITLE + '"][value="' + ID + '"]')
        if (filterEl) {
            filterEl.checked = false;
            filterEl.dispatchEvent(new Event('change', {bubbles: true}));
        } else {
            input.checked = false;
            input.dispatchEvent(new Event('change', {bubbles: true}));
            pageTableSortFromUrl();
            wrapper.remove();
        }
    }

    async function promoFilterEvent(e) {
        const target = e.target;
        const checkbox = target.closest('[data-promo-filter]');
        if (!checkbox) return;
        if (checkbox.checked) {
            const teamplate = createPromoFilterItem(checkbox.name, checkbox.value, checkbox.dataset.promoFilter);
            const container = document.querySelector('[data-promo-filters]');
            container.insertAdjacentElement('afterbegin', teamplate);
           pageTableSortFromUrl();
        } else if (!checkbox.checked) {
            const element = document.querySelector(`input[data-promo-item="${checkbox.dataset.promoFilter}"][value="${checkbox.value}"]`)
            element.checked = false;
            pageTableSortFromUrl();
            element.closest('.promo__item').remove();
        }
    }

    async function clearPromoFilter(e) {
        const target = e.target;
        const btn = target.closest("[data-promo-filters-reset]");
        if (!btn) return;
        const elements = [...document.querySelectorAll('input[data-promo-filter]')];
        const promoItems = [...document.querySelectorAll('[data-promo-filters] .promo__item.filter__item')];
        elements.forEach(el => {
            el.checked = false;
        });
        promoItems.forEach(item => {
            item.remove();
        });
        const url = new URL(window.location.href);
        const clearPromoFilters = url.search.split('&').filter(item => {
            if (!item.includes('events')) {
                return item;
            }
        })
        url.search = clearPromoFilters.join('&');
        window.history.pushState("promo search", "", url.toString());
        pageTableSortFromUrl()
    }

// Эвент фильтрации по инпуту
    function inputFilter(e) {
        const target = e.target;
        if (!target.closest('[data-url-search="input"]')) return;
        pageTableSortFromUrl();
    }
// Эвент фильтрации по селекту
    function changeFilter(e) {
        const target = e.target;
        if (!target.closest('[data-url-search="change"]')) return;
        pageTableSortFromUrl();
    }
// Выгрузка статистики
    function getStatistic(e) {
        const target = e.target;
        const btn = target.closest('[data-promo-statistic]');
        if (!btn) return;
        const url = new URL(window.location.href);
        const link = document.createElement('a');
        link.href = url.toString() + (url.search === '' ? '?' : '&') + btn.getAttribute('data-promo-statistic');
        link.click();
        link.remove();
    }

    async function setPriceRuleActivity(e) {
        const target = e.target;
        if (!target.getAttribute('data-price-rule-activity')) return;
        e.preventDefault();

        const url = target.getAttribute('data-price-rule-activity');
        const tr = target.closest('tr');
        const container = tr.querySelector('.js-price-rule-activity');

        const response = await fetch(url, {
            method: 'PUTCH',
        });

        if (!response.ok) {
            return
            // throw new Error(response.statusText);
        }

        const data = await response.json();
        showToast(data);

        if (data.status === 'success' && container) {
            container.innerHTML = data.payload ? "<div class='status__active'>Активен</div>" : "<div class='status__inactive'>Не активен</div>";
            target.innerHTML = data.payload ? "Деактивировать" : "Активировать";
        }
    }

async function customNavigation(e) {
    const target = e.target;
    const link = target.closest('[data-custom-navigation] .pagination .pagination__list  a');
    if (!link) return;
    e.preventDefault();
    const linkHref = new URL(link.href);
    const page = linkHref.searchParams.get('PAGEN_1');
    const url = new URL(window.location.href);
    url.searchParams.delete('PAGEN_1');
    url.searchParams.append('PAGEN_1', page);

    const response = await fetch(url);
    if (!response.ok) {
        console.error(response.statusText);
        return
    }
    const data = await response.text()
    printFromData(data, 'page', url);
}

// Бинд всех эвентов на страницу
    [
        ['change', changeFilter],
        ['input', debounce(inputFilter, 500)],
        ['input', debounce(multypleSearch, 500)],
        ['change', promiseWaitDebounce(promoFilterEvent, promise)],
        ['click', deleteFilter],
        ['click', clearPromoFilter],
        ['click', getStatistic],
        //['click', setPriceRuleActivity],
        ['click', customNavigation],
    ].forEach(([event, fn]) => {
        document.addEventListener(event, fn);
    });

// Функция дебаунса
    function debounce(func, wait, immediate) {
        let timeout;
        return function() {
            const context = this;
            const args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }
    function promiseWaitDebounce(func, pr) {
        async function wrapper(){
            await pr
            func.apply(this, arguments);
        }
        return wrapper;
    }
});




