<?
$MESS ['C_HLDB_EVENT_LIST'] = "Список событий";
$MESS ['C_HLDB_CAT_EVENTS'] = "События";
$MESS ['C_HLDB_EVENT_LIST_DESC'] = "Выводит список событий";
$MESS ['C_HLDB_COMPONENTS'] = "FunStore";
?>