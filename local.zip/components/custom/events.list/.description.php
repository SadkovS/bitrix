<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("C_HLDB_EVENT_LIST"),
	"DESCRIPTION" => GetMessage("C_HLDB_EVENT_LIST_DESC"),
	"CACHE_PATH" => "Y",
	"SORT" => 40,
	"PATH" => array(
		"ID" => "custom",
        "NAME" => GetMessage("C_HLDB_COMPONENTS"),
		"CHILD" => array(
			"ID" => "events",
			"NAME" => GetMessage("C_HLDB_CAT_EVENTS"),
			"SORT" => 20,
            "CHILD" => array(
                "ID" => "events_list",
            ),
		)
	),
);

?>