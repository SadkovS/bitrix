<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Page\Asset;
use Bitrix\Main\Application;

//Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/quill/quill.snow.css");
//Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
//Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/picker/picker.min.css");
//Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");
//Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/quill/quill.js");
//Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/picker/picker.min.js");

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
?>
<div class="adminpanel__header-item-head">
    <div class="adminpanel__header-item-title">
        <h3>Мои мероприятия</h3>
        <a class="btn btn__medium" href="/admin_panel/events/">К полному списку</a>
    </div>
    <button class="btn btn__medium btn__red btn__fix-width" data-popup-src="/admin_panel/events/0/?action=getForm" data-popup="#create-event" type="button"><i class="_icon-plus"></i>Добавить
    </button>
</div>
<div class="scrolltable__wrapper">
    <div class="scrolltable">
        <table class="adminpanel__table">
            <thead>
            <tr>
                <th>
                    <div class="adminpanel__item">
                        <p>Название</p>
                    </div>
                </th>
                <th>
                    <div class="adminpanel__item">
                        <p>Дата</p>
                    </div>
                </th>
                <th>
                    <div class="adminpanel__item">
                        <p>Статус</p>
                    </div>
                </th>
            </tr>
            </thead>
            <tbody>
            <?foreach ($arResult['ITEMS'] as $key => $item):?>
            <tr>
                <td>
                    <div class="adminpanel__item text-break">
                        <p><?=$item['UF_NAME']?></p>
                    </div>
                </td>
                <td>
                    <div class="adminpanel__item">
                        <p><?=$item['DATE_TIME']?></p>
                    </div>
                </td>
                <td>
                    <div class="adminpanel__item">
                        <?
                        $cssClass = '';
                        switch ($item['UF_STATUS']['UF_NAME']) {
                            case 'Отклонено':
                                $cssClass = 'error';
                                break;
                            case 'Отменено':
                                $cssClass = 'error';
                                break;
                            case 'Подтверждено':
                                $cssClass = 'confirmed';
                                break;
                            case 'Опубликовано':
                                $cssClass = 'success';
                                break;
                            case 'Черновик':
                                $cssClass = 'draft';
                                break;
                        }
                        ?>
                        <p class="<?=$cssClass?>"><?=$item['UF_STATUS']['UF_NAME']?></p>
                    </div>
                </td>
            </tr>
            <?endforeach;?>
            </tbody>
        </table>
    </div>
</div>


<?/*
<div class="row">
    <div class="col">
        <div class="adminpanel__header-item-title">
            <h3>Мои мероприятия</h3><a href="<?=$arParams['SEF_FOLDER']?>" class="btn">К полному списку</a>
        </div>
        <div class="adminpanel__header-item-desc">
            <small>Упорядочено по последнему изменению статуса</small>
        </div>
    </div>
    <div class="col-auto">
        <button type="button" class="events__create-btn" data-popup-src="/admin_panel/events/0/?action=getForm" data-popup="#create-event">
            <i class="_icon-plus"></i>Создать мероприятие
        </button>
    </div>
</div>
<div class="scrolltable__wrapper">
    <div class="scrolltable">
        <table class="adminpanel__table">
            <thead>
            <tr>
                <th>
                    <div class="adminpanel__item">
                        <p>Название</p>
                    </div>
                </th>

                <th>
                    <div class="adminpanel__item" data-event-controls>
                        <button class="btn__sort" data-event-controls-btn>Статус <i class="_icon-vector"></i></button>
                        <div class="events__table-controls-body" data-event-controls-body>
                            <ul>
                                <li>
                                    <a href="<?=$APPLICATION->GetCurPageParam('',['s'])?>">Все</a>
                                </li>
                                <?foreach ($arResult['STATUS_LIST'] as $key => $status):?>
                                    <li>
                                        <a href="<?=$APPLICATION->GetCurPageParam('s='.$status['ID'],['s'])?>"><?=$status['UF_NAME']?></a>
                                    </li>
                                <?endforeach;?>
                            </ul>
                        </div>
                    </div>
                </th>
            </tr>
            </thead>
            <tbody>
            <?foreach ($arResult['ITEMS'] as $key => $item):?>
                <tr>
                    <td>
                        <div class="adminpanel__item">
                            <p><?=$item['UF_NAME']?></p>
                        </div>
                    </td>
                    <td>
                        <div class="adminpanel__item">
                            <?
                            $cssClass = '';
                            switch ($item['UF_STATUS']['UF_NAME']) {
                                case 'Отклонено':
                                    $cssClass = 'error';
                                    break;
                                case 'Подтверждено':
                                    $cssClass = 'confirmed';
                                    break;
                                case 'Опубликовано':
                                    $cssClass = 'success';
                                    break;
                                case 'Черновик':
                                    $cssClass = 'draft';
                                    break;
                            }
                            ?>
                            <p class="check <?=$cssClass?>"><?=($item['IS_CLOSED'] && $cssClass === 'success')?$item['UF_STATUS']['UF_NAME']. ' по ссылке':$item['UF_STATUS']['UF_NAME'];?></p>
                            <small><?=$item['STATUS_DATE']?'c '.$item['STATUS_DATE']:''?></small>
                        </div>
                    </td>
                </tr>
            <?endforeach;?>
            </tbody>
        </table>
    </div>
</div>
*/?>
