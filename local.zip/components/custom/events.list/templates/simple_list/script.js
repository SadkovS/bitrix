// $(document).ready(function () {
//     $(document).on('click', '.btn__event-next', function (e) {
//         let container = $(this).parents('.popup__content').find('.create-event__body:visible');
//         let form = container.find('form');
//         let url = form.attr('action');
//         let index;
//         const parent = this.closest('.popup__content');
//         [...parent.querySelectorAll('.create-event__body')].forEach((item, i) => {
//              if (!item.hasAttribute('hidden') && i === 0) index = i;
//          })
//         let formData = new FormData(form.get(0));
//         if (container.find('.ql-editor')) {
//             formData.append('UF_DESCRIPTION', container.find('.ql-editor').html());
//         }
//        // formData.append('action','set');
//         $.ajax({
//             method: 'post',
//             url: url,
//             data: formData,
//             processData: false,
//             contentType: false,
//             cache: false,
//         }).done(function (data) {
//             const formattedData = JSON.parse(data);
//            if (index === 0 && formattedData.id) {
//              const hiddenInp = [...parent.querySelectorAll('input[name="EVENT"]')];
//                hiddenInp.forEach((input) => {
//                    input.value = formattedData.id;
//                });
//                const firstForm = parent.querySelector('.poster__form');
//                const regex = /0/g;
//                console.log(firstForm)
//                firstForm.action = firstForm.action.replace(regex, formattedData.id);
//            }
//            console.log(data)
//             const completedTabs = Number(formattedData.step) - 1;
//             const parentTab = document.querySelector('[data-tabs].create-event');
//             const navigation = parentTab.querySelector('[data-tabs-titles].create-event__navigation');
//             const navBtns = [...navigation.querySelectorAll('button[type="button"]')]
//             for(let i = 0; i < navBtns.length; i++) {
//                 const btn = navBtns[i]
//
//                 if (i < completedTabs) {
//                     btn.classList.add('complete');
//                     btn.removeAttribute('disabled', '');
//                 }
//                  if (i === completedTabs) {
//                      btn.removeAttribute('disabled', '');
//                     btn.click();
//
//                 }
//                 if (i > completedTabs) {
//                     btn.setAttribute('disabled', '');
//                 }
//             }
//         });
//     });
// // Класс инициализации функционала попапа создания или редактирования эвента
//     class EventsList {
//         constructor(parent) {
//             this.parent = parent;
//             this.nav = [...parent.querySelectorAll('[data-tabs-titles].create-event__navigation button')];
//             this.forms = parent.querySelectorAll('.create-event__content .create-event__body  form');
//             this.dateInput = parent.querySelector('[data-static-date]');
//             this.eventTypeInput = parent.querySelector('[name="UF_TYPE"]');
//             this.dateNextElement = this.dateInput.parentElement.nextElementSibling;
//             if (this.dateInput && this.dateInput.value === '') {
//                 this.haveDate = false;
//             } else {
//                 this.haveDate = true;
//             }
//             this.active = null
//             for(let i = 0; i < this.nav.length; i++) {
//                 const el = this.nav[i]
//                 if (el.classList.contains('tab-active')) {
//                     this.active = i + 1;
//                     continue
//                 }
//                 if (!this.active || i < this.active) continue;
//                 el.setAttribute('disabled', '');
//             }
//
//             if (this.eventTypeInput && this.eventTypeInput.value !== '') {
//                 this.eventType = this.eventTypeInput.value;
//             } else {
//                 this.initType();
//             }
//
//             this.dateInit();
//             // this.request();
//             this.initEvevnts();
//         }
//
//         counter = 0;
//         events = [];
//         haveDate = false;
//         eventType = null;
//         // place = this.html.dateDefault;
//         request() {
//             for (let i = 0; i < this.forms.length; i++) {
//                 let form = this.forms[i];
//                 let url = form.action;
//                 let formData = new FormData();
//                 const inputs = form.querySelectorAll('input');
//
//
//                 switch (i) {
//                     case 0:
//                         inputs.forEach((input) => {
//                             if (input.name === 'UF_AGE_LIMIT' && !input.checked) return;
//                             formData.append(input.name, input.value);
//                         })
//                     break;
//
//                     case 1:
//
//                     break;
//
//                     case 2:
//
//                     break;
//
//                     default:
//
//                 }
//
//                 formData.append('action', 'get');
//                 $.ajax({
//                     method: 'post',
//                     url: url,
//                     data: formData,
//                     processData: false,
//                     contentType: false,
//                     cache: false,
//                 }).done(function (data) {
//                     if (data) {
//                         // let event = JSON.parse(data);
//                         if (event) {
//                             this.events.push(event);
//                         }
//                     }
//                 }.bind(this));
//             }
//         }
//
//         initType() {
//
//             if (this.eventTypeInput.value === '') {
//                 this.dateNextElement.classList.remove('grey__body')
//                 this.dateNextElement.classList.add('p-5')
//             } else {
//                 this.dateNextElement.classList.remove('p-5')
//                 this.dateNextElement.classList.add('grey__body')
//             }
//             this.eventType = this.eventTypeInput.value;
//             let result;
//             switch (this.eventType) {
//                 case '6':
//                     result = this.html.dateSelect(this.searchEventDate(this.dateInput.value)) + this.html.timeSelect + this.html.dateOnline;
//                     break;
//                 case '7':
//                     result = this.html.dateSelect(this.searchEventDate(this.dateInput.value)) + this.html.timeSelect + this.html.dateOffline;
//                     break;
//                 case '8':
//                     result = this.html.dateSelect(this.searchEventDate(this.dateInput.value)) + this.html.timeSelect + this.html.dateMixed;
//                     break;
//                 default:
//                     result = this.html.dateDefault;
//                     break;}
//             while (this.dateNextElement.firstChild) {
//                 this.dateNextElement.removeChild(this.dateNextElement.firstChild);
//             }
//             this.dateNextElement.insertAdjacentHTML('beforeend', result);
//         }
//
//         searchEventDate(eventDate) {
//             const months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
//             const d  = eventDate.split('.');
//              let res = months[d[1] - 1] + ' ' + Number(d[0]);
//             return res;
//         }
//
//         dateInit() {
//             if (this.haveDate && this.eventType) {
//                 this.dateNextElement.querySelector('.h4').textContent = this.searchEventDate(this.dateInput.value);
//             } else {
//                 this.initType();
//                 this.haveDate = true;
//             }
//         }
//
//         initEvevnts() {
//             this.eventTypeInput.addEventListener('change', ()=> this.initType());
//             this.dateInput.addEventListener('change', ()=> this.dateInit());
//         }
//         static init(parent) {
//             return new EventsList(parent);
//         }
//
//         html = {
//             dateDefault: `<h4 class="h4 mb-1">Выберите дату события в календаре, или несколько</h4><small class="mb-3 d-block">Серыми кружками отмечены даты, на которые вы <br> уже назначили другие события</small>`,
//             dateSelect: (data)=> { return `<h4 class="h4 mb-3">${ data ? data : 'Выберите дату события в календаре'}</h4>` },
//             timeSelect: `<div class="row mb-3" data-event-time-row>
//                             <div class="col-5">
//                             <div class="events__select-block">
//                             <div class="events__form-item required">
//                             <label class="form-item__label">Начало</label>
//                             <div class="form-select js-form-select time__select" data-event-start>
//                             <div class="form-select__selected-option js-form-select-option js-option-change" data-placeholder="Выберите из списка">Выбрать</div>
//                             <i class="form-select__icon js-form-select-icon _icon-chev"></i>
//                             <div class="form-select-options-wrap js-form-select-options-wrap">
//                             <ul class="form-select-options form-select__options">
//                             </ul>
//                             </div>
//                             <input type="hidden" value="" data-event-time="start">
//                             </div>
//                             </div>
//                             <div class="events__form-item required">
//                             <label class="form-item__label">Окончание</label>
//                             <div class="form-select js-form-select time__select"  data-event-start>
//                             <div class="form-select__selected-option js-form-select-option js-option-change" data-placeholder="Выберите из списка">Выбрать</div>
//                             <i class="form-select__icon js-form-select-icon _icon-chev"></i>
//                             <div class="form-select-options-wrap js-form-select-options-wrap">
//                             <ul class="form-select-options form-select__options">
//                             </ul>
//                             </div>
//                             <input type="hidden" value="" data-event-time="end">
//                             </div>
//                             </div>
//                             </div>
//                             </div>
//                             <div class="col-5">
//                             <div class="form-item required">
//                             <label class="form-item__label">Длительность, мин.</label>
//                             <input type="number"  class="form__underline-input" name="UF_DURATION" data-event-duration>
//                             </div>
//                             </div>
//                             </div>`,
//             dateOffline: `<div class="row gy-4">
//                                 <div class="col-5">
//                                     <div class="form-item required">
//                                         <label class="form-item__label">Локация</label>
//                                         <!-- <span class="form__error"></span> -->
//                                        <div class="form-select js-form-select borderless">
//                                             <input class="form-select__selected-option js-form-select-option js-option-change" data-da-search >
//                                             <div class="form-select-options-wrap js-form-select-options-wrap">
//                                                 <ul class="form-select-options form-select__options">
//                                                     <li class="form-select-options__item js-form-select-options-item" data-option="">
//                                                         <p>Введите название</p>
//                                                     </li>
//                                                 </ul>
//                                             </div>
//                                             <input type="hidden" value="" name="UF_ADDRESS">
//                                             <input type="hidden" value="" data-coords name="UF_COORDINATES">
//                                         </div>
//                                     </div>
//                                 </div>
//                                 <div class="col-5">
//                                     <div class="form-item">
//                                         <label class="form-item__label">Помещение</label>
//                                         <!-- <span class="form__error"></span> -->
//                                       <input type="text" class="form__underline-input" name="UF_ROOM" value="">
//                                     </div>
//                                 </div>
//
//
//                             </div>`,
//             dateOnline: `<div class="row gy-4">
//                         <div class="col-12" data-input-link="">
//                             <div class="row">
//                                 <div class="col-12"><label class="form-item__label">Ссылка <span class="star-required color__red me-1">*</span></label></div>
//                                 <div class="col-5">
//                                     <div class="form-item">
//                                         <!-- <span class="form__error"></span> -->
//                                         <input type="text" class="form__underline-input" value="">
//                                     </div>
//                                 </div>
//                                 <div class="col-5 ">
//                                     <div class="form-item">
//                                         <!-- <span class="form__error"></span> -->
//                                         <input type="text" class="form__underline-input" value="">
//                                     </div>
//                                 </div>
//                                 <div class="col-2 control__links">
//                                     <button type="button" class="btn__icon" data-input-link-to=""><i class="_icon-link"></i></button>
//                                     <button type="button" class="btn__icon delete" data-input-link-delete=""><i class="_icon-plus"></i></button>
//                                 </div>
//                             </div>
//                         </div>
//                         <div class="col-12" data-input-link="">
//                             <div class="row">
//                                 <div class="col-5">
//                                     <div class="form-item">
//                                         <!-- <span class="form__error"></span> -->
//                                         <input type="text" class="form__underline-input" value="">
//                                         <small>Название ссылки, например «Трансляция»</small>
//                                     </div>
//                                 </div>
//                                 <div class="col-5 ">
//                                     <div class="form-item">
//                                         <!-- <span class="form__error"></span> -->
//                                         <input type="text" class="form__underline-input" value="">
//                                         <small>http://..., https://...</small>
//                                     </div>
//
//                                 </div>
//                                 <div class="col-2 control__links">
//                                     <button type="button" class="btn__icon" data-input-link-to=""><i class="_icon-link"></i></button>
//                                     <button type="button" class="btn__icon delete" data-input-link-delete=""><i class="_icon-plus"></i></button>
//                                 </div>
//                             </div>
//                         </div>
//
//                     </div>`,
//             dateMixed: `<div class="row gy-4">
//                             <div class="col-5">
//                                 <div class="form-item required">
//                                     <label class="form-item__label">Локация</label>
//                                     <!-- <span class="form__error"></span> -->
//                                     <div class="form-select js-form-select borderless">
//                                             <input class="form-select__selected-option js-form-select-option js-option-change" data-da-search >
//                                             <div class="form-select-options-wrap js-form-select-options-wrap">
//                                                 <ul class="form-select-options form-select__options">
//                                                     <li class="form-select-options__item js-form-select-options-item" data-option="">
//                                                         <p>Введите название</p>
//                                                     </li>
//                                                 </ul>
//                                             </div>
//                                             <input type="hidden" value="" name="UF_ADDRESS">
//                                             <input type="hidden" value="" data-coords name="UF_COORDINATES">
//                                         </div>
//                                 </div>
//                             </div>
//                             <div class="col-5">
//                                 <div class="form-item">
//                                     <label class="form-item__label">Помещение</label>
//                                     <!-- <span class="form__error"></span> -->
//                                    <input type="text" class="form__underline-input" name="UF_ROOM" value="">
//                                 </div>
//                             </div>
//                             <div class="col-12" data-input-link="">
//                                 <div class="row required">
//                                     <div class="col-12"><label class="form-item__label">Ссылка <span class="star-required color__red me-1">*</span></label></div>
//                                     <div class="col-5">
//                                         <div class="form-item">
//                                             <!-- <span class="form__error"></span> -->
//                                             <input type="text" class="form__underline-input" value="">
//                                         </div>
//                                     </div>
//                                     <div class="col-5 ">
//                                         <div class="form-item">
//                                             <!-- <span class="form__error"></span> -->
//                                             <input type="text" class="form__underline-input" value="">
//                                         </div>
//
//                                     </div>
//                                     <div class="col-2 control__links">
//                                         <button type="button" class="btn__icon" data-input-link-to=""><i class="_icon-link"></i></button>
//                                         <button type="button" class="btn__icon delete" data-input-link-delete=""><i class="_icon-plus"></i></button>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div class="col-12" data-input-link="">
//                                 <div class="row">
//                                     <div class="col-5">
//                                         <div class="form-item">
//                                             <!-- <span class="form__error"></span> -->
//                                             <input type="text" class="form__underline-input" value="">
//                                             <small>Название ссылки, например «Трансляция»</small>
//                                         </div>
//                                     </div>
//                                     <div class="col-5 ">
//                                         <div class="form-item">
//                                             <!-- <span class="form__error"></span> -->
//                                             <input type="text" class="form__underline-input" value="">
//                                             <small>http://..., https://...</small>
//                                         </div>
//
//                                     </div>
//                                     <div class="col-2 control__links">
//                                         <button type="button" class="btn__icon" data-input-link-to=""><i class="_icon-link"></i></button>
//                                         <button type="button" class="btn__icon delete" data-input-link-delete=""><i class="_icon-plus"></i></button>
//                                     </div>
//                                 </div>
//                             </div>
//
//                         </div>`
//     }
// }
// // Биндим события попапа
//     document.addEventListener('popupContentReady', (e) => {
//         const popupContent = e.detail.popup;
//         if (!popupContent.closest('#create-event') ) return;
//         EventsList.init(popupContent);
//     })
// // Удаление поля с ценами
//     function deletePirceField(e) {
//         const target = e.target;
//
//         if (!target.closest('.price__table-item-delete')) return;
//         e.preventDefault();
//         const btn = target.closest('.price__table-item-delete');
//         const parent = btn.closest('[data-tabs-body]');
//         const tbody = parent.querySelector('tbody');
//         const parentTr = btn.closest('tr');
//
//         const [a, b, counter] = findAllFields(tbody);
//         if (b.length <= 1 && a.length === 1 || !parentTr.querySelector('input[name^="tickets[n_"]')) return;
//         tbody.removeChild(parentTr)
//         const [fields, filtered] = findAllFields(tbody);
//         filtered.forEach((tr, i) => {
//             const inputs = tr.querySelectorAll('input[name^="tickets[n_"]');
//             inputs.forEach((input, j) => {
//                 const secondPart = input.getAttribute('name').split('][')[1];
//                 input.setAttribute('name', `tickets[n_${i}][${secondPart}`)
//             })
//         })
//     }
// // Функция поиска всех полей с ценами
//     function findAllFields(element) {
//         let fields = [...element.querySelectorAll('tbody tr')], filtered = null, counter = 0;
//
//         if (fields.length) {
//             filtered = fields.filter(tr => {
//                 return tr.querySelector('input[name^="tickets[n_"]')
//             })
//
//             if (filtered.length) {
//                 counter = filtered.length
//             }
//         }
//         return  [fields, filtered, counter]
//     }
// // Добавление поля с ценами
//     function addPriceField(e) {
//         const target = e.target;
//         if (!target.closest('[data-add-ticket-type]')) return;
//         const addBtn = target.closest('[data-add-ticket-type]');
//         const parent = addBtn.closest('[data-tabs-body]');
//         const tbody = parent.querySelector('tbody');
//
//         const [fields, filtered, counter] = findAllFields(tbody);
//
//         const tableRow = document.createElement('tr');
//
//         const data = `
//         <td>
//             <div class="price__table-item">
//                 <input type="text" value="" placeholder="Введите тип" name="tickets[n_${counter}][TYPE]">
//             </div>
//         </td>
//         <td>
//             <div class="price__table-item">
//                 <input type="text" value="" placeholder="Введите количество" name="tickets[n_${counter}][TOTAL_QUANTITY]">
//             </div>
//         </td>
//         <td>
//             <div class="price__table-item">
//                 <input type="text" value="" placeholder="Макс. в заказе" name="tickets[n_${counter}][MAX_QUANTITY]">
//             </div>
//         </td>
//         <!-- //todo временно скрыто
//         <td>
//             <div class="price__table-item">
//                 <input type="text" value="" placeholder="Время резерва" name="tickets[n_${counter}][RESERVE_TIME]">
//             </div>
//         </td> --?>
//         <td>
//             <div class="price__table-item">
//                 <input type="text" value="" placeholder="Цена" name="tickets[n_${counter}][PRICE]">
//             </div>
//         </td>
//         <td>
//             <div class="price__table-item">
//                 <div class="promo__list">
//
//                 </div>
//             </div>
//         </td>`;
//
//         tableRow.insertAdjacentHTML('beforeend', data);
//         tbody.insertAdjacentElement('beforeend', tableRow);
//
//         const td = document.createElement('td');
//         const priceTableItem = document.createElement('div');
//
//         priceTableItem.classList.add('price__table-item');
//         td.appendChild(priceTableItem);
//         const delBtn = document.createElement('button');
//         delBtn.type = 'button';
//         delBtn.classList.add('price__table-item-delete');
//         delBtn.innerHTML = '<i class="_icon-plus"></i>';
//         priceTableItem.appendChild(delBtn);
//         tableRow.insertAdjacentElement('beforeend', td)
//     }
// // Поиск в Яндексе или Дадате в зависимости от выбранного сервиса
//     async function dadataSearch() {
//         let data = [], response = null, resolve, reject, promise = new Promise((res, rej) => {
//              resolve = res;
//              reject = rej;
//         });
//         const yandex = true;
//         const token = yandex ? 'c83498df-bf38-427b-8adf-a09d82aca174': "a1350a1a780eecf5a1b812ecbb5e75e51476970b";
//         const query = this.value;
//         // "https://search-maps.yandex.ru/v1/?text=Россия " + query + "&type=geo&lang=ru_RU&apikey=" + token, "https://search-maps.yandex.ru/v1/?text=" + query + "&type=biz&lang=ru_RU&apikey=" + token
//         //  https://suggest-maps.yandex.ru/v1/suggest?apikey=YOUR_API_KEY&text=бурдж
//         const url = yandex ? [ "https://search-maps.yandex.ru/v1/?text=Россия " + query + "&type=geo&lang=ru_RU&apikey=" + token, "https://search-maps.yandex.ru/v1/?text=" + query + "&type=biz&lang=ru_RU&apikey=" + token] : "https://suggestions.dadata.ru/suggestions/api/4_1/rs/suggest/party";
//         const options = {
//             method: "POST",
//             mode: "cors",
//             headers: {
//                 "Content-Type": "application/json",
//                 "Accept": "application/json",
//                 "Authorization": "Token " + token
//             },
//             body: JSON.stringify({query: query})
//         }
//
//         if (query === '') return;
//         if ( !yandex ) {
//              response =  await fetch(url, options);
//             resolve()
//         } else {
//
//              response =  await Promise.all(url.map(u => fetch(u)))
//                  .then(responses => responses.forEach(async (res, i) => {
//                      if (!res.ok) {
//                          throw new Error(res.statusText);
//                      }
//                      await res.json()
//                          .then((res) => {
//                          data.push(res)
//                          if (i ===  (url.length-1)) {
//                              resolve()
//                          }
//                      })
//                  }))
//         }
//
//         if (!yandex && !response.ok) {
//             throw new Error(response.statusText);
//         }
//
//         await promise;
//
//         data = !yandex ? await response.json() : data;
//
//         const parent = this.closest('.js-form-select');
//         const wrapper = parent.querySelector('.js-form-select-options-wrap');
//         while (wrapper.firstChild) {
//             wrapper.removeChild(wrapper.firstChild);
//         }
//         const list = document.createElement('ul');
//         list.classList.add('form-form-select-options', 'form-select__options');
//         wrapper.appendChild(list);
//
//         let c = 0;
//         if (yandex) {
//             data.forEach(d=> {
//                 c += d.features.length
//             });
//         }
//
//         if ( yandex && c === 0 || !yandex && !data.suggestions.length) {
//             const option = document.createElement('li');
//             option.classList.add('form-select-options__item', 'js-form-select-options-item');
//             const paragraph = document.createElement('p');
//             paragraph.textContent = 'Ничего не найдено';
//             option.appendChild(paragraph);
//             option.setAttribute('data-option', '');
//             list.appendChild(option);
//             return;
//         }
//
//         parent.classList.add('active');
//
//         switch (yandex) {
//             case true:
//                 data.forEach((item) => {
//                     item.features.forEach((feature) => {
//                         const [name, address, geo] = [feature.properties.name, feature.properties.description, feature.geometry.coordinates];
//                         if (!name || !address || !geo) return;
//                         const option = dataItemCreate(name, address, geo);
//                         list.appendChild(option);
//                     })
//                 })
//                 break;
//             case false:
//                 data.suggestions.forEach((item) => {
//                     const [name, address, geo] = [item.value, item.data.address.value, item.data.address.data.geo_lat + ',' + item.data.address.data.geo_lon];
//                     const option = dataItemCreate(name, address, geo);
//                     list.appendChild(option);
//                 })
//         }
//     }
// // Создание элемента в выпадающем списке
//     function dataItemCreate(name, address, geo) {
//         const option = document.createElement('li');
//         option.classList.add('form-select-options__item', 'js-form-select-options-item');
//         option.setAttribute('data-option', name);
//         option.setAttribute('data-option-coords', geo);
//         const content = `<p>${name}</p><small>${address}</small>`;
//         option.insertAdjacentHTML('beforeend', content);
//         return option;
//     }
// // Эвент поиска в инпуте
//     function dadataSearchEvent(e) {
//         const target = e.target;
//         if (!target.closest('[data-da-search]')) return;
//         const input = target.closest('[data-da-search]');
//         dadataSearch.call(input);
//     }
// // Удаление поля цены
//     async function deletePriceField(e) {
//         const target = e.target;
//         if (!target.closest('[data-price-serv-delete]')) return;
//         e.preventDefault();
//         const btn = target.closest('[data-price-serv-delete]');
//         const url = btn.closest('form').action.replace('action=setTickets', 'action=deleteTicket');
//         const formData = new FormData();
//         formData.append('ID', btn.getAttribute('data-price-serv-delete'));
//
//         const response = await fetch(url, {
//             method: 'POST',
//             body: formData
//         })
//         if (!response.ok) {
//             return
//             // throw new Error(response.statusText);
//         }
//         const data = await response.json();
//         if (data.status === 'success') {
//             btn.closest('tr').remove();
//         }
//     }
// // Изменение фильтра
//     async function getUrlVars() {
//         let url = new Url(window.location.href);
//         const [name, date, category, type, status] = [
//             document.querySelector('[name="q"]').value,
//             document.querySelector('[name="d"]').value.trim().replace(/ /g, ''),
//             document.querySelector('[name="c"]').value,
//             document.querySelector('[name="t"]').value,
//             document.querySelector('[name="s"]').value
//         ];
//
//         url.query.ajax = 'Y';
//         name === ''     ?   delete url.query.q  :   url.query.q = name;
//         date === ''     ?   delete url.query.d  :   url.query.d = date;
//         category === '' ?   delete url.query.c  :   url.query.c = category;
//         type === ''     ?   delete url.query.t  :   url.query.t = type;
//         status === ''   ?   delete url.query.s  :   url.query.s = status;
//
// 	    delete url.query.PAGEN_1;
//
// 	    const address = url.toString();
//
//         const response = await fetch(address);
//         if (!response.ok) {
//             return
//         }
//         const data = await response.text()
//         let doc = new DOMParser().parseFromString(data, "text/html");
//         const tbody = doc.querySelector('tbody');
//         const pagination = doc.querySelector('.pagination.events__pagination');
//         delete url.query.ajax;
//
//         window.history.pushState("event search", "", url.toString());
//         document.querySelector('.events__table tbody').replaceWith(tbody);
//         document.querySelector('.events__pagination').replaceWith(pagination);
//     }
// // Эвент фильтрации по инпуту
//     function inputFilter(e) {
//         const target = e.target;
//         if (!target.closest('[name="q"]')) return;
//         getUrlVars();
//     }
// // Эвент фильтрации по селекту
//     function changeFilter(e) {
//         const target = e.target;
//         if (!target.closest('[name="d"]') && !target.closest('[name="c"]') && !target.closest('[name="t"]') && !target.closest('[name="s"]')) return;
//         getUrlVars();
//     }
// // Добавление и удалени квестового поля
//     function addQuestionItem(e) {
//         const target = e.target;
//         if (!target.closest('[data-add-question-item]')) return;
//         const addBtn = target.closest('[data-add-question-item]');
//
//         const body = document.createElement('div');
//         body.classList.add('form-item', 'grey__body');
//         const delBtn = document.createElement('button');
//         delBtn.classList.add('btn__icon', 'form-item__delete');
//         delBtn.setAttribute('type', 'button');
//         delBtn.setAttribute('data-form-item-delete', '');
//         const delIcon = document.createElement('i');
//         delIcon.classList.add('_icon-plus');
//         delBtn.appendChild(delIcon);
//
//
//
//         const guid = createGuid();
//         const data = `<div class="row" >
//                         <div class="col-7">
//                             <div class="form-item">
//                                 <label class="form-item__label">Вопрос</label>
//                                 <input type="text" class="form__underline-input" name="Q_FIELDS[${guid}][name]" value="" placeholder="Введите вопрос">
//                             </div>
//                         </div>
//                         <div class="col-5 ">
//                             <div class="form-item">
//                                 <label class="form-item__label">Ответ</label>
//                                 <div class="form-select js-form-select borderless">
//                                     <div class="form-select__selected-option js-form-select-option js-option-change" data-placeholder="Выберите из списка">Произвольный текст</div>
//                                     <i class="form-select__icon js-form-select-icon _icon-chev"></i>
//                                     <div class="form-select-options-wrap js-form-select-options-wrap">
//                                         <ul class="form-select-options form-select__options">
//                                             <li class="form-select-options__item js-form-select-options-item" data-option="text">Произвольный текст</li>
//                                             <li class="form-select-options__item js-form-select-options-item" data-option="boolean">Да / Нет</li>
//                                         </ul>
//                                     </div>
//                                     <input type="hidden" name="Q_FIELDS[${guid}][type]" value="text">
//                                 </div>
//                             </div>
//                         </div>
//                     </div>`
//         body.appendChild(delBtn);
//         body.insertAdjacentHTML('beforeend', data);
//
//         addBtn.insertAdjacentElement('beforebegin', body);
//     }
//
//     function questionItemDelete(e) {
//         const target = e.target;
//         if (!target.closest('[data-form-item-delete]')) return;
//         const deleteBtn = target.closest('[data-form-item-delete]');
//         const parent = deleteBtn.closest('.form-item');
//         parent.remove();
//     }
// // Валидация полей расценки
//     function validateNumberFields(e) {
//         const target = e.target;
//
//         if (!target.closest('[name*="[TOTAL_QUANTITY]"]') && !target.closest('[name*="[MAX_QUANTITY]"]') && !target.closest('[name*="[RESERVE_TIME]"]') && !target.closest('[name*="[PRICE]"]')) return;
//         const input = target.closest('[name*="[TOTAL_QUANTITY]"]') || target.closest('[name*="[MAX_QUANTITY]"]') || target.closest('[name*="[RESERVE_TIME]"]') || target.closest('[name*="[PRICE]"]');
//         const regex = /[^0-9]/g;
//         input.value = input.value.replace(regex, '');
//     }
//
// // Бинд всех эвентов на страницу
//     [
//         ['click', addPriceField],
//         ['click', deletePirceField],
//         ['input', debounce(dadataSearchEvent, 1000)],
//         ['click', debounce(deletePriceField, 200)],
//         ['change', changeFilter],
//         ['input', debounce(inputFilter, 500)],
//         ['click', addQuestionItem],
//         ['click', questionItemDelete],
//         ['input', validateNumberFields],
//         ['click', deleteAttachedFileEvent]
//     ].forEach(([event, fn]) => {
//         document.addEventListener(event, fn)
//     });
//
// });
//
// // Удаление прикрепленного файла
// async  function deleteAttachedFile() {
// 	let formAction = this.closest('form').action;
// 	const id = this.getAttribute('data-attached-delete');
// 	formAction = formAction.replace('setEvent', 'delAttachment');
// 	const formData = new FormData();
// 	formData.append('ID', id);
//
// 	const response = await fetch(formAction, {
// 		method: 'POST',
// 		body: formData
// 	})
//
// 	if (!response.ok) {
// 		throw new Error(response.statusText);
// 	}
//
// 	const container = this.closest('[data-attached-item]');
// 	if(container) {
// 		container.remove();
// 	}
// }
//
// function deleteAttachedFileEvent(e) {
// 	const target = e.target;
// 	const delBtn = target.closest('[data-attached-delete]');
// 	if (!delBtn) return;
// 	deleteAttachedFile.call(delBtn);
// }
//
// // Функция дебаунса
// function debounce(func, wait, immediate) {
//     let timeout;
//     return function() {
//         const context = this;
//         const args = arguments;
//         const later = function() {
//             timeout = null;
//             if (!immediate) func.apply(context, args);
//         };
//         const callNow = immediate && !timeout;
//         clearTimeout(timeout);
//         timeout = setTimeout(later, wait);
//         if (callNow) func.apply(context, args);
//     };
// }
//
// function createGuid() {
//     return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
//         var r = Math.random() * 16 | 0,
//             v = c == 'x' ? r : (r & 0x3 | 0x8);
//         return v.toString(16);
//     });
// }
//
