async function getUrlVars(event = null, sort = true) {
    let url = new Url(window.location.href);

    const [name, date, category, type, status, d_sort, q_sort] = [
        document.querySelector('input[name="q"]').value,
        document.querySelector('input[name="d"]').value.trim().replace(/ /g, ''),
        document.querySelector('input[name="c"]').value,
        document.querySelector('input[name="t"]').value,
        document.querySelector('input[name="s"]').value,
        document.querySelector('input[name="d_sort"]'),
        document.querySelector('input[name="q_sort"]')
    ];

    url.query.ajax = 'Y';
    if('PAGEN_1' in url.query  && url.query.PAGEN_1 !== '') {
        url.query.PAGEN_1 = '1';
    }
    name === '' ? delete url.query.q : url.query.q = name;
    date === '' ? delete url.query.d : url.query.d = date;
    category === '' ? delete url.query.c : url.query.c = category;
    type === '' ? delete url.query.t : url.query.t = type;
    status === '' ? delete url.query.s : url.query.s = status;
    if (sort) {
        d_sort.checked === true ? url.query.d_sort = '1' : url.query.d_sort = '0';
        q_sort.checked === true ? url.query.q_sort = '1' : url.query.q_sort = '0';
    } else {
        delete url.query.d_sort;
        delete url.query.q_sort;
        delete url.query.PAGEN_1;
    }
    if (event) {
        switch (event.target) {
            case d_sort:
                delete url.query.q_sort;
                q_sort.checked = false;
                break;
            case q_sort:
                delete url.query.d_sort;
                d_sort.checked = false;
                break;
            default:
                break;
        }
    }

    const address = url.toString();

    const response = await fetch(address);
    if (!response.ok) {
        return
    }
    const data = await response.text()
    let doc = new DOMParser().parseFromString(data, "text/html");
    const tbody = doc.querySelector('tbody');
    const pagination = doc.querySelector('.pagination.events__pagination');
    delete url.query.ajax;

    window.history.pushState("event search", "", url.toString());
    document.querySelector('.events__table tbody').replaceWith(tbody);
    document.querySelector('.events__pagination').replaceWith(pagination);
}

// Эвент фильтрации по инпуту
function inputFilter(e) {
    const target = e.target;
    if (!target.closest('[name="q"]')) return;
    getUrlVars(null, false);
}

// Эвент фильтрации по селекту
function changeFilter(e) {
    const target = e.target;
    if (!target.closest('[name="d"]') && !target.closest('[name="c"]') && !target.closest('[name="t"]') && !target.closest('[name="s"]') && !target.closest('[name="d_sort"]') && !target.closest('[name="q_sort"]')) return;
    if (target.closest('[name="d_sort"]') || target.closest('[name="q_sort"]')) {
        getUrlVars(e, true);
    } else {
        getUrlVars(e, false);
    }
}

// Поворот сортировки
function sortStatus() {
    let url = new Url(window.location.href);
    const [d_sort, q_sort] = [document.querySelector('input[name="d_sort"]'), document.querySelector('input[name="q_sort"]')];
    url.query.d_sort === '1' ? d_sort.checked = true : d_sort.checked = false;
    url.query.q_sort === '1' ? q_sort.checked = true : q_sort.checked = false;
}

// Отправка эвента на проверку
function examSendFromTooltipEv(e) {
    const target = e.target;
    const btn = target.closest('[data-ajax]');
    if (!btn) return;
    e.preventDefault();
    examSendFromTooltip.call(btn, btn.dataset.ajax !== '' ? btn.dataset.ajax : "POST");
}

// Отправка эвента на проверку
async function examSendFromTooltip(method) {
    const url = this.href;
    addLoader();
    const response = await fetch(url, {
        method: method
    })
    removeLoader();
    if (!response.ok) {
        console.error(response.statusText);
        return
        // throw new Error(response.statusText);
    }

    const header = response.headers.get('content-type')

    if (method === "get") {
        if (header.includes('application/json')) {
            const msg = await response.json();
            window.showToast(msg);
        } else {
            const l = document.createElement("a");
            const reader = response.body.getReader();
            const chunks = [];
            while (true) {
                const {done, value} = await reader.read();
                if (done) {
                    window.showToast({status: "success", message: "Файл готов для скачивания", title: "Успех"});
                    break
                }
                chunks.push(value);
            }
            const blob = new Blob(chunks);
            const urlDownload = window.URL.createObjectURL(blob);
            l.href = urlDownload;
            l.download = this.download || 'анкета.xlsx';
            l.click();
            l.remove();
            window.URL.revokeObjectURL(url);
        }
    } else {
        const msg = await response.json();

        showToast(msg);
        const pageRespone = await fetch(window.location.href, {
            method: 'GET'
        })
        if (!pageRespone.ok) {
            console.error(pageRespone.statusText);
            return;
            // throw new Error(pageRespone.statusText);
        }
        const table = document.querySelector('.admin-body');
        const pageEvents = table.querySelector('.events__table');
        if (table && pageEvents) {
            const html = await pageRespone.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const responseTable = doc.querySelector('.admin-body');
            table.replaceWith(responseTable);
            sortStatus();
        }
        if (this.hasAttribute('data-popup-after') && msg.id) {
            document.dispatchEvent(new CustomEvent('openPopup', {
                detail: {
                    dataSrc: '/admin_panel/events/' + msg.id + '/?action=getForm',
                    popup: this.getAttribute('data-popup-after')
                },
                bubbles: true
            }))
        }
    }
}

$(document).ready(function () {

    sortStatus();

    [   ['change', changeFilter],
        ['click', examSendFromTooltipEv],
        ['input', debounce(inputFilter, 500)],].forEach(([event, fn]) => {
        document.addEventListener(event, fn)
    });
});
