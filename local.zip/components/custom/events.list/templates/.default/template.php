<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Page\Asset;
use Bitrix\Main\Application;

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/quill/quill.snow.css");
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/picker/picker.min.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/quill/quill.js");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/picker/picker.min.js");

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();
?>
<? if (isset($request['file']) && strlen($request['file']) == 32): ?>
    <? include_once 'download.php'; ?>
<? else: ?>
    <div class="admin-body__item wide events">
        <div class="admin-body__item-header">
            <h1>Список мероприятий</h1>
            <div class="events__create">
                <button type="button" class="events__create-btn"
                        data-popup-src="<?= $arParams['SEF_FOLDER'] ?>0/?action=getForm" data-popup="#create-event"><i
                            class="_icon-plus"></i>Создать мероприятие
                </button>
            </div>
        </div>
        <div class="admin-body__item-sort">
            <button type="button" class="promo__item reset" data-filters-reset>
                <span>Сбросить фильтры</span>
                <i class="_icon-plus"></i>
            </button>
        </div>
        <? if (isset($request['ajax']) && $request['ajax'] == 'Y') $APPLICATION->RestartBuffer(); ?>
        <table class="events__table">
            <thead>
            <tr>
                <td></td>
                <td>
                    <div class="events__table-item">
                        <label class="events__table-btn" data-table-sort=""><span>Название</span>
                            <input type="checkbox" class="d-none" name="q_sort" value="1"> <i class="_icon-vector"></i>
                        </label>
                        <div class="events__form-item">
                            <input type="text" class="events__form-input " placeholder="Найти" name="q">
                            <i class="_icon-search"></i>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <label class="events__table-btn" data-table-sort=""><span>Дата</span><input type="checkbox"
                                                                                                    class="d-none"
                                                                                                    name="d_sort"
                                                                                                    value="1"> <i
                                    class="_icon-vector"></i></label>
                        <div class="events__form-item">
                            <input type="text" class="events__form-input" data-date="range" name="d">
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Категория</p>
                        <div class="events__form-item">
                            <div class="form-select js-form-select">
                                <div class="form-select__selected-option js-form-select-option js-option-change"
                                     data-placeholder="Выберите из списка">Все
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="">Все
                                        </li>
                                        <? foreach ($arResult['CATEGORY_LIST'] as $category): ?>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="<?= $category['ID'] ?>"><?= $category['UF_NAME'] ?></li>
                                        <? endforeach; ?>
                                    </ul>
                                </div>
                                <input type="hidden" value="" name="c">
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Тип</p>
                        <div class="events__form-item">
                            <div class="form-select js-form-select">
                                <div class="form-select__selected-option js-form-select-option js-option-change"
                                     data-placeholder="Выберите из списка">Все
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="">Все
                                        </li>
                                        <? foreach ($arResult['TYPE_LIST'] as $status): ?>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="<?= $status['ID'] ?>"><?= $status['UF_NAME'] ?></li>
                                        <? endforeach; ?>
                                    </ul>
                                </div>
                                <input type="hidden" value="" name="t">
                            </div>
                        </div>

                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p class="text-nowrap">Билеты, шт.</p>
                        <p class="tikets__total">Всего</p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p class="tikets__sold">Продано</p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Статус</p>
                        <div class="events__form-item">
                            <div class="form-select js-form-select">
                                <div class="form-select__selected-option js-form-select-option js-option-change"
                                     data-placeholder="Выберите из списка">Все
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="">Все
                                        </li>
                                        <? foreach ($arResult['STATUS_LIST'] as $status): ?>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="<?= $status['ID'] ?>"><?= $status['UF_NAME'] ?></li>
                                        <? endforeach; ?>
                                    </ul>
                                </div>
                                <input type="hidden" value="" name="s">
                            </div>
                        </div>

                    </div>
                </td>
                <td></td>
            </tr>
            </thead>
            <tbody>

            <? foreach ($arResult['ITEMS'] as $event): ?>
                <tr <?= $event['UF_STATUS']['UF_NAME'] == 'Опубликовано' || $event['UF_STATUS']['UF_NAME'] == 'Подтверждено' ?: 'class="inactive"' ?>
                    <?= ($event['UF_STATUS']['UF_NAME'] != 'Отменено') ? 'data-popup-src="' . $arParams['SEF_FOLDER'] . $event['ID'] . '/?action=getForm" data-popup-dblclick="#create-event"' : '' ?>
                >
                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-pic -ibg">
                                <? if (!empty($event['IMG_SRC'])): ?>
                                    <img src="<?= $event['IMG_SRC'] ?>" alt="<?= $event['UF_NAME'] ?>">
                                <? endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p class="text-break">
                                  <a data-popup-src="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=getForm"
                                     data-popup="#create-event"
                                     href="javascript:void(0)"><?= $event['UF_NAME'] ?></a>
                                </p>
                                <? if (!empty($event['UF_CODE'])): ?>
                                    <small><?= $event['UF_CODE'] ?></small>
                                <? endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p class="text-center"><?= $event['DATE_TIME'] ?></p>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p><?= $event['UF_CATEGORY']['UF_NAME'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p><?= $event['UF_TYPE']['UF_NAME'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p><?= (int)$event['TOTAL_QUANTITY'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p><?= (int)$event['SOLD_QUANTITY'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <?
                            $cssClass = '';
                            switch ($event['UF_STATUS']['UF_NAME']) {
                                case 'Отклонено':
                                    $cssClass = 'error';
                                    break;
                                case 'Подтверждено':
                                    $cssClass = 'confirmed';
                                    break;
                                case 'Опубликовано':
                                    $cssClass = 'success';
                                    break;
                                case 'Черновик':
                                    $cssClass = 'draft';
                                    break;
                            }
                            ?>
                            <span class="events__table-item-status <?= $cssClass ?>">
                            <?= ($event['IS_CLOSED'] && $cssClass === 'success') ? $event['UF_STATUS']['UF_NAME'] . ' по ссылке' : $event['UF_STATUS']['UF_NAME']; ?>
                        </span>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-controls" data-event-controls>
                            <button type="button" class="btn__icon" data-event-controls-btn>
                                <i class="_icon-rounds"></i>
                            </button>
                            <div class="events__table-controls-body" data-event-controls-body>
                                <ul>
                                    <? if ($event['UF_STATUS']['UF_NAME'] != 'Отменено' && $event['UF_STATUS']['UF_NAME'] != 'Завершено'): ?>
                                        <li>
                                            <a data-popup-src="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=getForm"
                                               data-popup="#create-event" href="javascript:void(0)">Редактировать</a>
                                        </li>
                                    <? endif; ?>
                                    <? if (($event['UF_STATUS']['UF_NAME'] == 'Черновик' || $event['UF_STATUS']['UF_NAME'] == 'Отклонено') && !$event['IS_CLOSED']): ?>
                                        <li>
                                            <a href="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=sendToModeration"
                                               data-ajax>Отправить на проверку</a>
                                        </li>
                                    <? endif; ?>
                                    <? if ($event['UF_STATUS']['UF_NAME'] == 'Подтверждено' || ($event['IS_CLOSED'] && $event['UF_STATUS']['UF_NAME'] != 'Опубликовано') && $event['UF_STATUS']['UF_NAME'] != 'Отменено'): ?>
                                        <li>
                                            <a href="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=publish"
                                               data-ajax>Опубликовать</a>
                                        </li>
                                    <? endif; ?>
                                    <? if ($event['UF_STATUS']['UF_NAME'] == 'Опубликовано'): ?>
                                        <li>
                                            <a href="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=unpublish"
                                               data-ajax>Снять с публикации</a>
                                        </li>
                                    <? endif; ?>
                                    <? if ($event['UF_STATUS']['UF_NAME'] == 'Черновик'): ?>
                                        <li>
                                            <a href="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=delEvent"
                                               data-ajax>Удалить</a>
                                        </li>
                                    <? endif; ?>
                                    <? if ($event['UF_STATUS']['UF_NAME'] == 'На проверке'): ?>
                                        <li>
                                            <a href="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=sendToUnModeration"
                                               data-ajax>Отозвать с проверки</a>
                                        </li>
                                    <? endif; ?>
                                    <? if ($event['QUESTIONNAIRE_COUNT'] > 0): ?>
                                        <li>
                                            <a href="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=getQuestionnaires"
                                               download="Анкеты. [<?= $event['UF_NAME'] ?>].xlsx" data-ajax="get">Скачать
                                                анкеты</a>
                                        </li>
                                    <? endif; ?>
                                    <li>
                                        <a href="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=copyEvent"
                                           data-ajax="post" data-popup-after="#create-event">Копировать</a>
                                    </li>
                                    <? if ($event['UF_STATUS']['UF_NAME'] != 'Отменено' && (int)$event['SOLD_QUANTITY'] > 0): ?>
                                        <li>
                                            <a href="#"
                                               data-popup-src="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=cancellationForm"
                                               data-popup="#submit-act">Отменить</a>
                                        </li>
                                    <? endif; ?>
                                </ul>
                            </div>
                        </div>
                    </td>
                </tr>
            <? endforeach; ?>
            </tbody>
        </table>
        <?= $arResult['NAV_STRING'] ?>
        <? if (isset($request['ajax']) && $request['ajax'] == 'Y') die(); ?>
    </div>
<? endif; ?>
