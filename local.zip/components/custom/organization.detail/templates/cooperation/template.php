<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>
<div class="admin-body row">
    <form action="<?= $arParams['SEF_FOLDER']?>/?action=setRequsites" method="POST" class="col-6 company-profile__form">
        <h1 class="">Условия сотрудничества</h1>
        <?if(!$arResult["CONTRACT_STATUS"] || $arResult["CONTRACT_STATUS"] == "no"):?>
            <div class="form-item company-profile__form-item">
                <p class="text__large color__blue-three mb-1">Необходимо заключить договор</p>
                <p class="mb-3">Нет возможности использовать функционал для заведения <br> мероприятий с платными билетами</p>
                <a data-popup-src="/admin_panel/organization/contract/add_contract.php" data-popup="#contract_form" class="btn btn__big btn__blue">Заключить договор</a>
            </div>
        <?elseif($arResult["CONTRACT_STATUS"] && $arResult["CONTRACT_STATUS"] == "verif"):?>
            <div class="col-12">
                <div class="company-profile__form-item">
                    <p class="text__large mb-3">
                        Данные на проверке
                    </p>
                    <?if($arResult["CONTRACT_TYPE_CONFIRM_XML_ID"] == "docs"):?>
                        <div class="requisit__item">
                            <a href="<?=$arResult["CONTRACT_DOCS"]?>" target="_blank"  class="color__blue">
                                Шаблон документа
                            </a>
                            <div>
                                <small><?=$arResult["CONTRACT_ADDRESS"]?></small>
                            </div>
                        </div>
                    <?endif;?>
                    <?if($arResult["CONTRACT_TYPE_CONFIRM_XML_ID"] == "scet"):?>
                        <div class="requisit__item">
                            <a class="color__blue" href="<?=$arResult["SCET_SRC"]?>" target="_blank">
                                Ссылка на счёт
                            </a>
                            <div>
                                <small>
                                    Необходимо оплатить счёт с РС организации.<br>
                                    При оплате счета обязательно укажите назначение платежа: <b>Подтверждение договора</b>
                                </small>
                            </div>
                        </div>
                    <?endif;?>
                </div>
            </div>
        <?elseif($arResult["CONTRACT_STATUS"] && $arResult["CONTRACT_STATUS"] == "signed"):?>
            <div class="form-item company-profile__form-item">
                <p class="text__large color__blue-three mb-3">Лицензионный договор заключен! Вам доступна возможность заведения мероприятия с платными билетами.</p>
                <div class="mb-1 requisit__item">
                    <span class="color__blue-t">
                        Процент вознаграждения
                    </span>
                    <p><?=$arResult["UF_COOPERATION_PERCENT"]?> %</p>
                </div>
                <div class="mb-1 requisit__item">
                    <span class="color__blue-t">
                        Сервисный сбор
                    </span>
                    <p><?=$arResult["UF_COOPERATION_SERVICE_FEE"]?> %</p>
                </div>
            </div>
        <?endif;?>
    </form>





</div>