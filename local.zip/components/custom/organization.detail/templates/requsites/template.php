<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>
<div class="admin-body row">
    <form action="<?= $arParams['SEF_FOLDER']?>/?action=setRequsites" method="POST" class="row company-profile__form col-12">
        <h1 class="">Реквизиты</h1>
        <?if(!$arResult["CONTRACT_STATUS"] || $arResult["CONTRACT_STATUS"] == "no"):?>
            <div class="col-6">
                <div class="form-item company-profile__form-item">
                    <p class="text__large color__blue-three mb-1">Необходимо заключить договор</p>
                    <p class="mb-3">Нет возможности использовать функционал для заведения <br> мероприятий с платными билетами</p>
                    <a data-popup-src="/admin_panel/organization/contract/add_contract.php" data-popup="#contract_form" class="btn btn__big btn__blue">Заключить договор</a>
                </div>
            </div>
        <?elseif($arResult["CONTRACT_STATUS"] && $arResult["CONTRACT_STATUS"] == "verif"):?>
            <div class="col-6">
                <div class="company-profile__form-item">
                    <p class="text__large mb-3">
                        Данные на проверке
                    </p>
                    <?if($arResult["CONTRACT_TYPE_CONFIRM_XML_ID"] == "docs"):?>
                        <div class="requisit__item">
                            <a href="<?=$arResult["CONTRACT_DOCS"]?>" target="_blank"  class="color__blue">
                                Шаблон документа
                            </a>
                            <div>
                                <small><?=$arResult["CONTRACT_ADDRESS"]?></small>
                            </div>
                        </div>
                    <?endif;?>
                    <?if($arResult["CONTRACT_TYPE_CONFIRM_XML_ID"] == "scet"):?>
                        <div class="requisit__item">
                            <a class="color__blue" href="<?=$arResult["SCET_SRC"]?>" target="_blank">
                                Ссылка на счёт
                            </a>
                            <div>
                                <small>
                                    Необходимо оплатить счёт с РС организации.<br>
                                    При оплате счета обязательно укажите назначение платежа: <b>Подтверждение договора</b>
                                </small>
                            </div>
                        </div>
                    <?endif;?>
                </div>
            </div>
        <?elseif($arResult["CONTRACT_STATUS"] && $arResult["CONTRACT_STATUS"] == "signed"):?>
            <?if($arResult["COMPANY_TYPE"] && $arResult["COMPANY_TYPE"] == "person"):?>
                <div class="col-12">
                    <div class="form-item company-profile__form-item">
                        <p class="text__large color__blue-three mb-3">Реквизиты (Самозанятый)</p>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                ФИО
                            </span>
                            <p><?=$arResult["UF_FIO"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Ваш e-mail
                            </span>
                            <p><?=$arResult["UF_EMAIL"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Контактный номер телефона
                            </span>
                            <p><?=$arResult["UF_PHONE"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                ИНН
                            </span>
                            <p><?=$arResult["UF_INN"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Серия и номер паспорта
                            </span>
                            <p><?=$arResult["UF_PASSPORT_SERIES"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Дата выдачи
                            </span>
                            <p><?=$arResult["UF_PASSPORT_DATE"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Кем выдан паспорт
                            </span>
                            <p><?=$arResult["UF_PASSPORT_ISSUED"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue">
                                <a href="<?=$arResult["UF_FILE_PASPORT_1"]?>" target="_blank">Скан-копия разворота паспорта с фотографией</a>
                            </span>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue">
                                <a href="<?=$arResult["UF_FILE_PASPORT_2"]?>" target="_blank">Скан-копия разворота паспорта с регистрацией</a>
                            </span>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Адрес регистрации
                            </span>
                            <p><?=$arResult["UF_REGISTRATION_ADDRESS"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Номер СНИЛС
                            </span>
                            <p><?=$arResult["UF_SNILS"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue">
                                <a href="<?=$arResult["UF_FILE_SNILS"]?>" target="_blank">Скан-копия СНИЛС</a>
                            </span>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue">
                                <a href="<?=$arResult["UF_FILE_SELF_EMPLOYED"]?>" target="_blank">Скан-копия заявления о регистрации Самозанятого</a>
                            </span>
                        </div>
                    </div>
                </div>
                <?elseif($arResult["COMPANY_TYPE"] && $arResult["COMPANY_TYPE"] == "ip"):?>
                    <div class="col-12">
                        <div class="form-item company-profile__form-item">
                            <p class="text__large color__blue-three mb-3">Реквизиты (ИП)</p>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                ФИО
                            </span>
                                <p><?=$arResult["UF_FIO"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Ваш e-mail
                            </span>
                                <p><?=$arResult["UF_EMAIL"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Контактный номер телефона
                            </span>
                                <p><?=$arResult["UF_PHONE"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                ИНН
                            </span>
                                <p><?=$arResult["UF_INN"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Номер СНИЛС
                            </span>
                                <p><?=$arResult["UF_SNILS"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Номер ОГРНИП
                            </span>
                                <p><?=$arResult["UF_OGRNIP"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Серия и номер паспорта
                            </span>
                                <p><?=$arResult["UF_PASSPORT_SERIES"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Дата выдачи
                            </span>
                                <p><?=$arResult["UF_PASSPORT_DATE"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Кем выдан паспорт
                            </span>
                                <p><?=$arResult["UF_PASSPORT_ISSUED"]?></p>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue">
                                <a href="<?=$arResult["UF_FILE_PASPORT_1"]?>" target="_blank">Скан-копия разворота паспорта с фотографией</a>
                            </span>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue">
                                <a href="<?=$arResult["UF_FILE_PASPORT_2"]?>" target="_blank">Скан-копия разворота паспорта с регистрацией</a>
                            </span>
                            </div>
                            <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Адрес регистрации
                            </span>
                                <p><?=$arResult["UF_REGISTRATION_ADDRESS"]?></p>
                            </div>


                        </div>
                    </div>
            <?elseif($arResult["COMPANY_TYPE"] && $arResult["COMPANY_TYPE"] == "legal"):?>
                <div class="col-12">
                    <div class="form-item company-profile__form-item">
                        <p class="text__large color__blue-three mb-3">Реквизиты (ЮЛ)</p>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                ФИО
                            </span>
                            <p><?=$arResult["UF_FIO"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Ваш e-mail
                            </span>
                            <p><?=$arResult["UF_EMAIL"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Контактный номер телефона
                            </span>
                            <p><?=$arResult["UF_PHONE"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Название компании
                            </span>
                            <p><?=$arResult["UF_NAME"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                ИНН
                            </span>
                            <p><?=$arResult["UF_INN"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                КПП
                            </span>
                            <p><?=$arResult["UF_KPP"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                ОГРН
                            </span>
                            <p><?=$arResult["UF_OGRN"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                ФИО подписывающего лица
                            </span>
                            <p><?=$arResult["UF_SIGNATORE_FIO"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Должность подписанта
                            </span>
                            <p><?=$arResult["UF_SIGNATORE_POSITION"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Система налогообложения
                            </span>
                            <p><?=$arResult["TAX_SYSTEM_MANE"]?></p>
                        </div>
                        <div class="mb-1 requisit__item">
                            <span class="color__blue-t">
                                Юридический адрес
                            </span>
                            <p><?=$arResult["UF_REGISTRATION_ADDRESS"]?></p>
                        </div>
                    </div>
                </div>
            <?endif;?>
            <div class="col-12">
                <div class="form-item company-profile__form-item">
                    <p class="text__large color__blue-three mb-3">Банковские реквизиты</p>
                    <div class="mb-1 requisit__item">
                        <span class="color__blue-t">
                            Полное наименование банка включая отделение
                        </span>
                        <p><?=$arResult["UF_BANK_NAME"]?></p>
                    </div>
                    <div class="mb-1 requisit__item">
                        <span class="color__blue-t">
                            БИК
                        </span>
                        <p><?=$arResult["UF_BANK_BIK"]?></p>
                    </div>
                    <div class="mb-1 requisit__item">
                        <span class="color__blue-t">
                            Корреспондентский счёт
                        </span>
                        <p><?=$arResult["UF_BANK_KORR"]?></p>
                    </div>
                    <div class="mb-1 requisit__item">
                        <span class="color__blue-t">
                            Расчётный счёт
                        </span>
                        <p><?=$arResult["UF_BANK_RS"]?></p>
                    </div>
                    <div class="mb-1 requisit__item">
                        <span class="color__blue-t">
                            Комментарий для перевода денежных средств
                        </span>
                        <p><?=$arResult["UF_BANK_COMMENT"]?></p>
                    </div>
                </div>
            </div>
        <!--<div class="col-auto mt-5">
            <button class="btn btn__big btn__blue" type="submit">Внести изменения</button>
        </div>-->
        <?endif;?>
    </form>





</div>