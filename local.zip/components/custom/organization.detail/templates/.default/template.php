<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>
<div class="admin-body row">
    <form action="<?= $arParams['SEF_FOLDER']?>/?action=setOrganization" method="POST" class="col-6 company-profile__form js-form-validate">
        <h1 class="">Профиль компании</h1>
        <div class="form-item company-profile__form-item required js-input">
            <span class="clue__box">
                <span class="form-item__label-big">Название организатора <span class="color__red me-1">*</span></span>
	              <small>Не более 50 символов</small>
                <span class="clue" data-clue="">
                    <i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
                    <span class="clue-body" data-clue-body="" data-popper-placement="bottom" style="position: absolute; inset: 0px auto auto 0px; margin: 0px; transform: translate(-107px, 22px);">
                        Данное название будет отображаться на афише
                        <span data-popper-arrow=""></span>
                    </span>
                </span>
            </span>
            <input
                    type="text"
                    data-max-length="50"
                    class="form__underline-input"
                    name="data[UF_NAME]"
                    value='<?=$arResult["UF_NAME"]?>'>
        </div>
        <div class="form-item company-profile__form-item js-input">
            <span class="form-item__label-big">Краткое описание организатора</span>
	          <small>Не более 500 символов</small>
            <textarea name="data[UF_DESCRIPTION]" class="form__underline-textarea" data-max-length="500"  placeholder="" data-textarea-dummy><?=$arResult["UF_DESCRIPTION"]?></textarea>
        </div>
        <div class="upload" data-img-upload="" data-no-delete="">
            <input name="UF_LOGO" type="file" class="upload__input" accept=".jpg, .jpeg, .png" data-file-size="3">
            <div class="upload__icon upload-ibg_contain">
                <?if($arResult["LOGO_SRC"]):?>
                    <input name="logo_set" value="Y" hidden>
                    <img src="<?=$arResult["LOGO_SRC"]?>">
                <?endif;?>
                <button class="upload__delete" type="button" del-org-img>
                    <i class="_icon-trash2"></i>
                </button>
                <i class="_icon-upload"></i>
            </div>
            <div class="upload__info">
                <span class="form-item__label-big">Логотип </span>
               <small>Рекомендуемое соотношение сторон изображения — 16:9<br>
                   Поддерживаются JPEG, JPG и PNG <br>
                   Перетащите файл на рамку или нажмите для обзора
               </small>
            </div>
        </div>
        <div class="form-item company-profile__form-item">
            <span class="form-item__label-big">Страница организатора в Voroh</span>
            <div class="row flex justify-content-between align-items-center">
                <div class="col-auto color__blue h5" data-copy-item="https://<?=SITE_SERVER_NAME?>/org/<?=$arResult["ID"]?>">
                    https://<?=SITE_SERVER_NAME?>/organizer_event/<?=$arResult["ID"]?>/
                </div>
                <div class="col-auto">
                    <button class="btn" type="button" data-copy="[data-copy-item]">Копировать</button>
                </div>
            </div>
        </div>
        <div class="form-item company-profile__form-item">
            <span class="form-item__label-big">Контакты <span class="color__red">*</span></span>
            <small>E-mail и номер телефона, которые будут в контактах oрганизатора в билетах и на странице мероприятия</small>
            <div class="row mn-2">
                <div class="col-6 required">
	                <div class="form-item__label" hidden="hidden">E-mail</div>
                    <input
                            name="data[UF_CONTACT_EMAIL]"
                            type="email"
                            class="form__underline-input"
                            placeholder="E-mail"
                            value="<?=$arResult["UF_CONTACT_EMAIL"]?>">
                </div>
                <div class="col-6 required">
	                <div class="form-item__label" hidden="hidden">Телефон</div>
                    <input
                            name="data[UF_CONTACT_PHONE]"
                            type="tel"
                            class="form__underline-input col-6"
                            placeholder="Номер телефона"
                            value="<?=$arResult["UF_CONTACT_PHONE"]?>">
                </div>
            </div>
        </div>
        <div class="form-item">
            <span class="form-item__label-big mb-4"> <span class="color__red">*</span> — обязательное поле</span>
            <button type="button" class="btn btn__big btn__blue" id="save-profile">Сохранить</button>
        </div>
    </form>

</div>