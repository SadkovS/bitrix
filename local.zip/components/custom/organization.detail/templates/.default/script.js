$(document).ready(function () {
    function addLoader() {
        document.body.classList.add('loading')
    }

    function removeLoader() {
        document.body.classList.remove('loading')
    }
    function saveCompanyProfile(btn) {
        let form = btn.parents('form');
        let url = form.attr('action');
        let formData = new FormData(form.get(0));

        addLoader();

        $.ajax({
            method: 'post',
            url: url,
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
        }).done(async function (data) {
            removeLoader();
            const formattedData = JSON.parse(data);
            console.log(formattedData)
            showToast(formattedData);
            await renewElement('.aside__top');
        })
    }


    $(document).on('click', '#save-profile', (e)=>{
	    let $btn = $(e.currentTarget),
		    $form = $btn.closest('.js-form-validate')

	    if (formValidate($form[0], true) === false) {
		    e.preventDefault()
		    return false;
	    }


	    saveCompanyProfile($btn)
	});

	$(document).on('click', '[del-org-img]', function (event) {
		let form = $(this).parents('form');
		let img = $(form).find('.upload__icon img');
		let input = $(form).find('[name="UF_LOGO"]');
		let logo_set = $(form).find('[name="logo_set"]');

		$(input).val("");
		$(img).remove();
		$(logo_set).remove();
	});

});


