<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;

$isOwner = isset($_SESSION['CURRENT_USER_PROFILE']['UF_IS_OWNER']) && $_SESSION['CURRENT_USER_PROFILE']['UF_IS_OWNER'];
?>

<div class="admin-body promo">
    <div class="admin-body__item wide events">
        <div class="admin-body__item-header">
            <h1>Команда</h1>
	        <? if (!$isOwner): ?>
	            <div class="events__create">
	                <button type="button" class="btn btn__clear"><i class="_icon-plus"></i>Добавить
	                    сотрудника</button>
	                <!-- <button type="button" class="events__create-menu btn__icon"><i class="_icon-rounds"></i></button> -->
	            </div>
	        <? endif; ?>
        </div>
        <table class="events__table ">
            <thead>
            <tr>

                <td>
                    <div class="events__table-item">
                        <p class="color__main">ФИО</p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p class="color__main">E-mail</p>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <p class="color__main">Роль</p>
                    </div>
                </td>
                <td></td>
            </tr>
            </thead>
            <tbody>
            <?foreach ($arResult["TEAM"] as $user):?>
            <tr>

                <td>
                    <div class="events__table-item">
                        <p><p><?=$user["NAME"]?></p></p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p><?=$user["USER_EMAIL"]?></p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Какая-то роль</p>
                    </div>
                </td>
	            
	            <? if (!$isOwner): ?>
	                <td>
	                    <div class="events__table-controls" data-event-controls="">
	                        <button type="button" class="btn__icon" data-event-controls-btn="">
	                            <i class="_icon-rounds"></i>
	                        </button>
	                        <div class="events__table-controls-body" data-event-controls-body="">
	                            <ul>
	                                <li>
	                                    <a href="#">Редактировать</a>
	                                </li>
	                                <!--<li>
	                                    <a href="#">Отправить на проверку</a>
	                                </li>-->
	                                <li>
	                                    <a href="#">Удалить</a>
	                                </li>
	                            </ul>
	                        </div>
	                    </div>
	                </td>
	            <? endif; ?>
            </tr>
            <?endforeach;?>
            </tbody>
        </table>
        <?= $arResult['NAV_STRING'] ?>
    </div>
</div>