<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Custom\Core\Products;
use Custom\Core\PriceRules;
use \Bitrix\Main\Localization\Loc;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest()->toArray();;
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('catalog') ||
    !Loader::IncludeModule("iblock")
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    if($companyID)
    {
        $query = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany   = $query
            ->setFilter(['ID' => $companyID])
            ->setSelect([
                '*',
                'CONTRACT_STATUS' => 'CONTRACT.XML_ID',
                'COMPANY_TYPE' => 'COMPANY.XML_ID',
                'TAX_SYSTEM_MANE' => 'TAX_SYSTEM.VALUE',
                'LOGO_SRC',
                'SCET_SRC',
                'CONTRACT_TYPE_CONFIRM_VALUE' => 'CONTRACT_TYPE_CONFIRM.VALUE',
                'CONTRACT_TYPE_CONFIRM_XML_ID' => 'CONTRACT_TYPE_CONFIRM.XML_ID'
            ])
            ->setLimit(1)
            ->registerRuntimeField(
                'PICTURE',
                array(
                    'data_type' => '\Bitrix\Main\FileTable',
                    'reference' => array('=this.UF_LOGO' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'LOGO_SRC',
                new \Bitrix\Main\Entity\ExpressionField('LOGO_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['PICTURE.SUBDIR', 'PICTURE.FILE_NAME'])
            )
            ->registerRuntimeField(
                'SCET_FILE',
                array(
                    'data_type' => '\Bitrix\Main\FileTable',
                    'reference' => array('=this.UF_CONTRACT_PAY_FILE' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'SCET_SRC',
                new \Bitrix\Main\Entity\ExpressionField('SCET_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['SCET_FILE.SUBDIR', 'SCET_FILE.FILE_NAME'])
            )
            ->registerRuntimeField(
                'CONTRACT',
                array(
                    'data_type' => '\Custom\Core\FieldEnumTable',
                    'reference' => array('=this.UF_CONTRACT' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'CONTRACT_TYPE_CONFIRM',
                array(
                    'data_type' => '\Custom\Core\FieldEnumTable',
                    'reference' => array('=this.UF_CONTRACT_TYPE_CONFIRM' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'COMPANY',
                array(
                    'data_type' => '\Custom\Core\FieldEnumTable',
                    'reference' => array('=this.UF_TYPE' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->registerRuntimeField(
                'TAX_SYSTEM',
                array(
                    'data_type' => '\Custom\Core\FieldEnumTable',
                    'reference' => array('=this.UF_TAX_SYSTEM' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->exec();
        if($company = $resCompany->fetch()){
            foreach ($company as $propKey => &$value)
            {
                if($value && strpos($propKey, "FILE") !== false)
                {
                    $buf = json_decode($value, true);

                    if($buf["path"])
                        $value = str_replace($_SERVER["DOCUMENT_ROOT"], "", $buf["path"]);
                }
            }

            $company["CONTRACT_ADDRESS"] = Loc::GetMessage("CONTRACT_ADDRESS");
            $company["CONTRACT_DOCS"] = Loc::GetMessage("CONTRACT_DOCS");

            $this->arResult = $company;

            $curPage = (int)$request['PAGEN_1'] > 0 ? (int)$request['PAGEN_1'] : 1;
            if (!isset($_REQUEST['PAGEN_1']) || (int)$_REQUEST['PAGEN_1'] <= 1)
                $offset = 0;
            else
                $offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $arParams["PROFILE_COUNT"];

            $queryProfile = new ORM\Query\Query('\Custom\Core\Users\UserProfilesTable');

            $resProfileOb   = $queryProfile
                ->setFilter([
                    'UF_COMPANY_ID' => $companyID,
                    '!UF_USER_ID' => false,
                    '!USER_ID' => false
                ])
                ->setLimit($arParams["PROFILE_COUNT"])
                ->setOffset($offset)
                ->setSelect([
                    '*',
                    'USER_ID' => 'USER.ID',
                    'USER_EMAIL' => 'USER.EMAIL',
                    'USER_LAST_NAME' => 'USER.LAST_NAME',
                    'USER_NAME' => 'USER.NAME',
                    'USER_SECOND_NAME' => 'USER.SECOND_NAME',
                ])
                ->countTotal(1)
                ->registerRuntimeField(
                    'USER',
                    array(
                        'data_type' => '\Bitrix\Main\UserTable',
                        'reference' => array('=this.UF_USER_ID' => 'ref.ID'),
                        'join_type' => 'LEFT'
                    )
                )
                ->exec();

            $resProfile = $resProfileOb->fetchAll();
            foreach ($resProfile as $keyProfile => &$profile)
            {
                $profile["NAME"] = implode(" ", [$profile["USER_LAST_NAME"], $profile["USER_NAME"], $profile["USER_SECOND_NAME"]]);
            }

            if($resProfile)
            {
                $this->arResult["TEAM"] = $resProfile;

                if($arParams["PROFILE_COUNT"]) {
                    $this->arResult['ALL_COUNT'] = $resProfileOb->getCount();
                    $this->nav = new \CDBResult();
                    $this->nav->NavStart($arParams["PROFILE_COUNT"]);
                    $this->nav->NavPageCount = ceil((int)$arResult['ALL_COUNT'] / $arParams["PROFILE_COUNT"]);
                    $this->nav->NavPageNomer = $curPage;
                    $this->nav->NavRecordCount = $arResult['ALL_COUNT'];
                    $this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');
                }
            }
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_COMPANY_NOT_FOUND")], JSON_UNESCAPED_UNICODE);
            die;
        }


    }
    else
    {
        echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_NO_COMPANY_FOR_USER")], JSON_UNESCAPED_UNICODE);
        die;
    }

    if (
        isset($request['action']) &&
        $request['action'] == 'setOrganization'
    )
    {
        $APPLICATION->RestartBuffer();

        if($companyID)
        {
            $arData = $request['data'];

            foreach ($arData as $key => $val)
            {
				$notRequiredKeys = ['UF_DESCRIPTION'];

                if(!$val && !in_array($key, $notRequiredKeys))
                {
                    throw new Exception('Заполните обязательные поля');
                }

            }

            $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_ORGANIZATION_ID"])->fetch();
            $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
            $hlbClass = $entity->getDataClass();

            if (isset($_FILES['UF_LOGO']['tmp_name']) && !empty($_FILES['UF_LOGO']['tmp_name'])) {
                checkFileSize($_FILES['UF_LOGO']);

                $arData['UF_LOGO'] = $_FILES['UF_LOGO'];
            }
            elseif($request['logo_set'] == "Y")
            {
                unset($arData['UF_LOGO']);
            }
            else
            {
                $arData['UF_LOGO'] = null;
            }

            $resUpdate = $hlbClass::update($companyID, $arData);
            if (!$resUpdate->isSuccess())
            {
                echo json_encode(['status' => 'error', 'message' => str_replace("<br>", "\n", implode(', ', $resUpdate->getErrors()))], JSON_UNESCAPED_UNICODE); die();
            }

            $_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_NAME'] = $arData['UF_NAME'];
            foreach ($_SESSION['SESS_AUTH']['UF_USER_PROFILES'] as &$profile){
                if($profile['UF_COMPANY_ID'] == $companyID) $profile['UF_COMPANY_NAME'] = $arData['UF_NAME'];
            }

            echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
            die();
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_NO_COMPANY_FOR_USER")], JSON_UNESCAPED_UNICODE);
            die;
        }
    }

    if (
        isset($request['action']) &&
        $request['action'] == 'delLogo'
    )
    {
        $APPLICATION->RestartBuffer();

        if($companyID)
        {
            $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_ORGANIZATION_ID"])->fetch();
            $entity   = HL\HighloadBlockTable::compileEntity($hlblock);

            $objOrg = $entity->wakeUpObject($companyID);

            \CFile::Delete($objOrg->fillUfLogo());
            $objOrg->fillUfLogo('');

            $objOrg->save();
        }

        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die();
    }

    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}

function checkFileSize($file = null)
{
    $Questionnaires = new \Custom\Core\Questionnaires();
    $maxSize = $Questionnaires->fileSize;
    $maxSizeMB = $maxSize/1024/1024;

    if($file['size'] > $maxSize)
    {
        throw new Exception('Размер файла для поля "Афиша мероприятия" не должен быть больше '.$maxSizeMB.' МБ');
    }
}



?>