<?
$MESS ['ERROR_NO_COMPANY_FOR_USER'] = "У пользователя нет основной организации";
$MESS ['ERROR_COMPANY_NOT_FOUND'] = "Не найдена организация";

$MESS ['CONTRACT_ADDRESS'] = "Необходимо распечатать, подписать и принести по адресу: \r\n г. Москва, улица Верейская, дом 29, строение 33";
$MESS ['CONTRACT_DOCS'] = "/documents/statement_of_acceptance_org_license_agreement.docx?v=1";

?>