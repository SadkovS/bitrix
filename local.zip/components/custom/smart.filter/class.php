<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
    die();

use Bitrix\Catalog;
use Bitrix\Iblock;
use Bitrix\Main;
use Bitrix\Main\Error;
use Bitrix\Main\ErrorCollection;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use \Bitrix\Main\Application;
use \Bitrix\Main\Context;
use \Bitrix\Main\Request;
use \Custom\Core\UUID;
use \Custom\Core\Events;
use \Bitrix\Main\ORM;
use Bitrix\Highloadblock as HL;

class SmartFilter extends CBitrixComponent
{
    public function getEventCategory()
    {
        $eventEntity  = new ORM\Query\Query('Custom\Core\Events\EventsCategoryTable');
        $resEntity    = $eventEntity
            ->setFilter([])
            ->setOrder(["UF_SORT" => "ASC"])
            ->setSelect([
                '*',
                'ICON_CLASS' => 'ICON.XML_ID'
            ])
            ->registerRuntimeField(
                'ICON',
                array(
                    'data_type' => '\Custom\Core\FieldEnumTable',
                    'reference' => array('=this.UF_ICON' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->exec()
            ->fetchAll();

        foreach ($resEntity as &$item)
        {

        } unset($item);

        $this->arResult["FILTERS"]["EVENT_CATEGORY"] = $resEntity;
    }

    public function getEventsByFilter($check)
    {
        $filter = [];

        foreach ($check as $key => $item)
        {
            if($key == "category" && $item)
            {
                $filter["CATEGORY.UF_CODE"] = $item;
            }

            if($key == "price" && $item)
            {
                $filterItem = ["LOGIC" => 'AND'];
                $filterItem[] = [">PRODUCT.QUANTITY" => 0];

                if($item["from"] != null)
                {
                    $filterItem[] = [">=PRICE.PRICE" => $item["from"]];
                }

                if($item["to"] != null)
                {
                    $filterItem[] = ["<=PRICE.PRICE" => $item["to"]];
                }

                $filter[] = $filterItem;
            }

            if($key == "date" && $item)
            {
                if(count($item) > 1)
                {
                    $filter[] = [
                        "LOGIC" => 'AND',
                        [">=UF_LOCATION_REF.DATE_TIME.VALUE" => $item["from"] . ' 00:00:00'],
                        ["<=UF_LOCATION_REF.DATE_TIME.VALUE" => $item["to"] . ' 23:59:59'],
                    ];
                }
                else
                {
                    $filter[] = [
                        "LOGIC" => 'AND',
                        [">=UF_LOCATION_REF.DATE_TIME.VALUE" => $item["from"] . ' 00:00:00'],
                        ["<=UF_LOCATION_REF.DATE_TIME.VALUE" => $item["from"] . ' 23:59:59'],
                    ];
                }
            }

        }

        if($GLOBALS[$this->arParams["FILTER_NAME"]] && array_key_exists("PROPERTY_EVENT_ID", $GLOBALS[$this->arParams["FILTER_NAME"]]))
        {
            $filter["=ID"] = $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"];
        }

        if($filter)
        {
            $offerEntity       = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
            $productEntity     = \Bitrix\Iblock\IblockTable::compileEntity('tickets');

            $productPropField  = $productEntity->getField('EVENT_ID');
            $productPropEntity = $productPropField->getRefEntity();

            $offerPropField  = $offerEntity->getField('CML2_LINK');
            $offerPropEntity = $offerPropField->getRefEntity();

            $propFieldClosed       = $productEntity->getField('IS_CLOSED_EVENT');
            $propFieldClosedEntity = $propFieldClosed->getRefEntity();

            $propFieldModeration       = $productEntity->getField('MODERATION');
            $propFieldModerationEntity = $propFieldModeration->getRefEntity();

            $filter = array_merge(
                $filter,
                [
                    "=STATUS_REF.UF_XML_ID" => ["published"],
                    "=ELEMENT.ACTIVE" => "Y",
                    "=PROP_CLOSED_REF.VALUE" => null,
                    "=PROP_MODERATION_REF.VALUE" => null,
                    [
                        'LOGIC' => 'OR',
                        ['ELEMENT.ACTIVE_FROM' => false],
                        ['<=ELEMENT.ACTIVE_FROM' => date('d.m.Y H:i:s')]
                    ],
                    [
                        'LOGIC' => 'OR',
                        ['ELEMENT.ACTIVE_TO' => false],
                        ['>=ELEMENT.ACTIVE_TO' => date('d.m.Y H:i:s')]
                    ],
                    "=OFFER.ACTIVE" => "Y",
                    [
                        'LOGIC' => 'OR',
                        ['OFFER.ACTIVE_FROM' => false],
                        ['<=OFFER.ACTIVE_FROM' => date('d.m.Y H:i:s')]
                    ],
                    [
                        'LOGIC' => 'OR',
                        ['OFFER.ACTIVE_TO' => false],
                        ['>=OFFER.ACTIVE_TO' => date('d.m.Y H:i:s')]
                    ],
                ]
            );

            $dbRes = \Custom\Core\Events\EventsTable::getList(
                [
                    'select'      => [
                        'ID',
                    ],
                    'filter'      => $filter,
                    'runtime'     => [
                        new \Bitrix\Main\Entity\ReferenceField(
                            'CATEGORY',
                            '\Custom\Core\Events\EventsCategoryTable',
                            ['=this.UF_CATEGORY' => 'ref.ID'],
                            ['join_type' => 'inner']
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'STATUS_REF',
                            '\Custom\Core\Events\EventsStatusTable',
                            ['=this.UF_STATUS' => 'ref.ID'],
                            ['join_type' => 'inner']
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'EVENT_REF',
                            $productPropEntity,
                            ['=this.ID' => 'ref.VALUE'],
                            ['join_type' => 'inner']
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'ELEMENT',
                            $productEntity,
                            ['=this.EVENT_REF.IBLOCK_ELEMENT_ID' => 'ref.ID'],
                            ['join_type' => 'left']
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'CML2_LINK',
                            $offerPropEntity,
                            ['=this.EVENT_REF.IBLOCK_ELEMENT_ID' => 'ref.VALUE'],
                            ['join_type' => 'inner']
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'OFFER',
                            $offerEntity,
                            ['=this.CML2_LINK.IBLOCK_ELEMENT_ID' => 'ref.ID'],
                            ['join_type' => 'inner']
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'PRICE',
                            '\Bitrix\Catalog\PriceTable',
                            ['=this.OFFER.ID' => 'ref.PRODUCT_ID'],
                            ['join_type' => 'inner']
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'PRODUCT',
                            '\Bitrix\Catalog\ProductTable',
                            ['=this.OFFER.ID' => 'ref.ID'],
                            ['join_type' => 'inner']
                        ),
                        new  \Bitrix\Main\Entity\ReferenceField(
                            'UF_LOCATION_REF',
                            '\Custom\Core\Events\EventsDateAndLocationTable',
                            ['this.ID' => 'ref.UF_EVENT_ID'],
                            ['join_type' => 'LEFT']
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'PROP_CLOSED_REF',
                            $propFieldClosedEntity,
                            ['this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'],
                            ['join_type' => 'LEFT'],
                        ),
                        new \Bitrix\Main\Entity\ReferenceField(
                            'PROP_MODERATION_REF',
                            $propFieldModerationEntity,
                            ['this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'],
                            ['join_type' => 'LEFT'],
                        ),
                    ],
                ]
            );

            while($obEvents = $dbRes->fetch())
            {
                $eventIds[$obEvents["ID"]] = $obEvents["ID"];
            }

            if($eventIds)
            {
                $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"] = $eventIds;
            }
            else
            {
                $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"] = false;
            }
        }
    }

    public function convertUrlToCheck($url)
    {
        $result = array();
        $smartParts = explode("/", $url);
        foreach ($smartParts as $smartPart)
        {
            $item = false;
            $smartPart = preg_split("/-(from|to|is|or)-/", $smartPart, -1, PREG_SPLIT_DELIM_CAPTURE);

            foreach ($smartPart as $i => $smartElement)
            {
                if ($i == 0)
                {
                    $filterCode = "";

                    if (preg_match("/^price-(.+)$/", $smartElement, $match))
                    {
                        $filterCode = "price";
                    }
                    elseif (preg_match("/^date-(.+)$/", $smartElement, $match))
                    {
                        $filterCode = "date";
                    }
                    else
                    {
                        $filterCode = $smartElement;
                    }
                }
                elseif ($smartElement === "from")
                {
                    $result[$filterCode][$smartElement] = $smartPart[$i+1];
                }
                elseif ($smartElement === "to")
                {
                    $result[$filterCode][$smartElement] = $smartPart[$i+1];
                }
                elseif ($smartElement === "is" || $smartElement === "or")
                {
                    $result[$filterCode][] = $smartPart[$i+1];
                }
            }
            unset($item);
        }
        return $result;
    }

    public function onPrepareComponentParams($arParams)
    {
        return $arParams;
    }

    public function executeComponent()
    {
        if($_REQUEST["SMART_FILTER_PATH"])
        {
            $check = $this->convertUrlToCheck($_REQUEST["SMART_FILTER_PATH"]);

            $this->getEventsByFilter($check);

            $this->arResult["CHECK"] = $check;
        }

        $this->arResult["DAYS"] = [
            [
                "name" => "Все даты",
                "date" => "",
            ],
            [
                "name" => "Сегодня",
                "date" => date("d.m.Y"),
            ],
            [
                "name" => "Завтра",
                "date" => date('d.m.Y', time() + 86400),
            ],
            [
                "name" => "Выходные",
                "date" => date('d.m.Y', strtotime('saturday'))." - ".date('d.m.Y', strtotime('sunday')),
            ],
            [
                "name" => "На этой неделе",
                "date" => date('d.m.Y')." - ".date('d.m.Y', strtotime('sunday')),
            ],
            [
                "name" => "В этом месяце",
                "date" => date('d.m.Y')." - ".date('d.m.Y', strtotime('last day of this month')),
            ],
            [
                "name" => "В этом году",
                "date" => date('d.m.Y')." - ".date('31.12.Y'),
            ],
        ];

        $this->arResult["DEF_URL"] = \Custom\Core\Helper::getDefFilterUrl();

        $this->getEventCategory();

        $this->includeComponentTemplate();
    }

    protected static function getSession(): ?Session
    {
        /** @var Session $session */
        $session = Application::getInstance()->getSession();
        if (!$session->isAccessible())
        {
            return null;
        }

        return $session;
    }

}
