<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

?>
<script>
    localStorage.def_url = '<?=$arResult["DEF_URL"]?>';
</script>
<div id="filter" aria-hidden="false" class="popup bg-icons-1 dark:bg-background-1 lg:!bg-transparent filter__popup">
    <div class="popup__wrapper">

        <form action="" class="popup__content" id="filter-form" method="get">
            <input type="checkbox" class="hidden js-calendar-toggle peer/filter" id="calendar-toggle">
            <div
                class="filter inline-flex flex-col w-full  bg-t-1 dark:bg-primary p-c_narrow lg:p-c_lg lg:peer-checked/filter:hidden">
                <div class="inline-flex justify-between gap-5 mb-c_lg w-full ">
                    <div class="text-xl dark:text-white font-gothic leading-[110%] lg:text-[22px]">Фильтры</div>
                    <button class="link__red" type="button" data-close>
	                    <i class="svg_icon-cross-s normal"></i>
                    </button>
                </div>
                <div class="filter__items">

	                  <div class="filter__item">
		                <div class="filter__label">
			                <span class="filter__label-name">Категории</span>
			                <button class="filter__label-reset" type="button" data-filter-block-reset>Сбросить</button>
		                </div>

		                <div class="filter__item-list">

		                <?foreach ($arResult["FILTERS"]["EVENT_CATEGORY"] as $item):?>

					                <label class="filter__item-tag">
						                <input
				                <?if($arResult["CHECK"]["category"] && in_array($item["UF_CODE"], $arResult["CHECK"]["category"])):?>checked<?endif;?>
								                name="category"
								                type="checkbox"
								                class="hidden"
								                value="<?=$item["UF_CODE"]?>">
						                <span class="tag">
                                        <?=$item["UF_NAME"]?>
                                    </span>
					                </label>

		                <?endforeach;?>

		                </div>
	                </div>

                    <div class="filter__item">
                        <div class="filter__label">
                            <span class="filter__label-name">Дата</span>
                            <button class="filter__label-reset" type="button" data-filter-block-reset
                                    data-calendar-reset>Сбросить</button>
                        </div>
                        <div class="filter__item-body" data-selected-dates>
                            <label for="calendar-toggle" class="input cursor-pointer <?if($arResult["CHECK"]["date"]):?>!hidden<?endif;?>" data-popup-exeption>
                                <span class="text-t-2">Когда</span>
                                <i class="svg_icon-calendar text-lg text-icons-1"></i>
                            </label>
                            <?foreach($arResult["CHECK"]["date"] as $date):?>
                                <button class="input time__btn" data-popup-exeption="" type="button"><span><?=\Custom\Core\Helper::rus_date('j F, D', strtotime($date))?></span><i class="svg_icon-cross"></i></button>
                            <?endforeach;?>
                        </div>
                        <?if($arResult["DAYS"]):?>
                            <div class="filter__item-list">
                                <?foreach($arResult["DAYS"] as $item):?>
                                    <label class="filter__item-tag">
                                        <input type="radio" name="f-1" class="hidden" value="<?=$item["date"]?>">
                                        <span class="tag">
                                                    <?=$item["name"]?>
                                                </span>
                                    </label>
                                <?endforeach;?>
                            </div>
                        <?endif;?>
                    </div>
                    <div class="filter__item">
                        <div class="filter__label">
                            <span class="filter__label-name">Цена</span>
                            <button class="filter__label-reset" type="button" data-filter-block-reset>Сбросить</button>
                        </div>
                        <div class="filter__item-body">
                            <div class="grid grid-cols-2 gap-c_sm w-full">
                                <div class="price__input from">
                                    <input type="text" class="input" data-num-mask name="price_from" value="<?=$arResult["CHECK"]["price"]["from"]?>">
                                </div>
                                <div class="price__input to">
                                    <input type="text" class="input" data-num-mask name="price_to" value="<?=$arResult["CHECK"]["price"]["to"]?>">
                                </div>
                            </div>
                        </div>
                        <div class="filter__item-list">
                            <label class="filter__item-tag">
                                <input type="radio" name="f-2" class="hidden" data-price-from="0" data-price-to="0">
                                <span class="tag">
                                            Бесплатно
                                        </span>
                            </label>
                            <label class="filter__item-tag">
                                <input type="radio" name="f-2" class="hidden" data-price-from="0" data-price-to="500">
                                <span class="tag">
                                            до 500 ₽
                                        </span>
                            </label>
                            <label class="filter__item-tag">
                                <input type="radio" name="f-2" class="hidden" data-price-from="500" data-price-to="1000">
                                <span class="tag">
                                            от 500 до 1000 ₽
                                        </span>
                            </label>
                            <label class="filter__item-tag">
                                <input type="radio" name="f-2" class="hidden" data-price-from="1000" data-price-to="3000">
                                <span class="tag">
                                            от 1000 до 3000 ₽
                                        </span>
                            </label>
                            <label class="filter__item-tag">
                                <input type="radio" name="f-2" class="hidden" data-price-from="3000" data-price-to="5000">
                                <span class="tag">
                                            от 3000 до 5000 ₽
                                        </span>
                            </label>
                            <label class="filter__item-tag">
                                <input type="radio" name="f-2" class="hidden" data-price-from="5000" data-price-to="">
                                <span class="tag">
                                            от 5000 ₽
                                        </span>
                            </label>
                        </div>
                    </div>

                </div>
                <div class=" lg:mt-c_lg  py-c_narrow inline-flex flex-col gap-c_md w-full mt-auto lg:p-0">
                    <button type="reset" class="inline-flex justify-center items-center gap-2 text-warning"
                            type="reset">
                        <span class="text-xs lg:text-sm">Сбросить все фильтры</span>
                        <i class="svg_icon-cross text-[7px]"></i>
                    </button>
                    <button type="submit" class="btn__red font-gothic">Применить</button>
                </div>
            </div>
            <div class="calendar hidden peer-checked/filter:flex">
                <input
                        type="text"
                        id="calendar"
                        class="hidden"
                        data-datepicker="period"
                        <?if($arResult["CHECK"]["date"]):?>
                            value="<?=implode(" - ", $arResult["CHECK"]["date"])?>"
                        <?endif;?>
                >
            </div>
        </form>

    </div>
</div>