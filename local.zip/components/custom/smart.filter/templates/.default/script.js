
window.addEventListener('load', () => {
    const s = document.getElementById('calendar');
    s.dispatchEvent(new Event('change', { bubbles: true }));
})
document.addEventListener("DOMContentLoaded", () => {
    function setCalendarDate({ target }) {
        const btn = target.closest('input[name=\"f-1\"]');
        if (!btn) return;
        const inp = document.getElementById('calendar');
        inp.value = btn.value;

        inp.dispatchEvent(new Event('change', { bubbles: true }));
    }

    document.addEventListener('click', setCalendarDate);

    $(document).on("click", "input[name=\"f-2\"]",  function (e) {
        if ($(this).is(':checked')){
            $("input[name='price_from']").val($(this).data("price-from"));
            $("input[name='price_to']").val($(this).data("price-to"));
        } else {
            $("input[name='price_from']").val($(this).data());
            $("input[name='price_to']").val($(this).data());
        }
    });

    $(document).on("submit", "#filter-form",  function (e) {
        e.preventDefault();

        var filter = [];
        var url = "";
        var category = [];

        $('#filter-form input:checkbox:checked').each(function(){
            category.push($(this).val());
        });

        if(category.length)
        {
            if(category.length > 1)
            {
                let join = category.join('-or-');
                filter.push("category-is-"+join);

            }
            else
            {
                filter.push("category-is-"+category[0]);
            }
        }

        var price = "";
        if($("input[name='price_from']").val())
        {
            price = price + "-from-" + $("input[name='price_from']").val().replace(/\s/g, '');
        }
        if($("input[name='price_to']").val())
        {
            price = price + "-to-" + $("input[name='price_to']").val().replace(/\s/g, '');
        }

        if(price)
        {
            filter.push("price" + price);
        }

        if($("input[id='calendar']").val())
        {
            var calendar = $("input[id='calendar']").val();
            calendar = calendar.replace(" - ", "-to-");

            filter.push("date-from-" + calendar);
        }

        if(filter.length)
        {
            url = localStorage.def_url + "filter/" + filter.join('/') + '/';

            getHtml(url);
            //window.location.href = url;
        }
        else
        {
            getHtml(localStorage.def_url);
            //window.location.href = localStorage.def_url;
        }

        console.log(filter);
    });


});