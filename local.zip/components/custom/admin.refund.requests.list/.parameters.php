<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentParameters = [
    'PARAMETERS' => [
        "REFUNDS_COUNT" => [
            "PARENT"  => "BASE",
            "NAME"    => GetMessage("REFUNDS_COUNT"),
            "TYPE"    => "STRING",
            "DEFAULT" => '10',
        ],
    ]
];