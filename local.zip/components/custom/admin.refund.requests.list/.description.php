<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME"        => GetMessage("ADMIN_REFUND_LIST_NAME"),
    "DESCRIPTION" => GetMessage("ADMIN_REFUND_LIST_DESCRIPTION"),
    "COMPLEX"     => "N",
    "PATH"        => [
        "ID"    => "custom",
        "CHILD" => [
            "ID"    => "orders",
            "NAME"  => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT"  => 20,
            "CHILD" => [
                "ID" => 'admin_refund_requests_list',
            ]
        ]
    ],
];
?>