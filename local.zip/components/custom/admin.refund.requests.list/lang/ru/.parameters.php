<?php
$MESS['REFUNDS_COUNT'] = 'Количество заявок на страницу';