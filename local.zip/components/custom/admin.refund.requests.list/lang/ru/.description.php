<?php
$MESS["ADMIN_REFUND_LIST_NAME"]        = "Просмотр списка заявок на возврат";
$MESS["ADMIN_REFUND_LIST_DESCRIPTION"] = "Позволяет просмотреть список заявок на возврат";
