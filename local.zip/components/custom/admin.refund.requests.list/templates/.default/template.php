<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Application;
use Bitrix\Main\Page\Asset;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");
?>

<div class="admin-body">
    <div class="admin-body__item wide events">
        <div class="admin-body__item-header">
            <h1>Возвраты</h1>
        </div>

        <div class="event-head-filter">
            <div class="event-head-filter__left"></div>
            <div class="event-head-filter__right">

                <p class="event-head-filter__right__desc">Поиск возврата:</p>

                <div class="events__form-item">
                    <input class="events__form-input events__form-input--gray events__form-input--ico-right"
                           placeholder="По номеру телефона" type="text" name="ph" value="<?= $request['ph'] ?>">
                    <i class="_icon-search"></i>
                </div>


                <div class="events__form-item">
                    <input class="events__form-input events__form-input--gray events__form-input--ico-right"
                           placeholder="По e-mail" type="text" name="e" value="<?= $request['e'] ?>">
                    <i class="_icon-search"></i>
                </div>

            </div>
        </div>

	    <div class="scrolltable-x" aria-labelledby="caption" tabindex="0">
        <table class="events__table events__table--compact">
            <thead>
            <tr>
                <td>
                    <div class="events__table-select thead-checkbox">
                        <div class="checkbox blue checkbox--small">
                            <label>
                                <input type="checkbox" class="js-table-checkbox-all"> <span
                                        class="_icon-checkbox"></span>
                            </label>
                        </div>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">Меропритие</span>
                        <div class="events__form-item lg">
                            <input class="events__form-input" placeholder="Название" type="text" name="en"
                                   value="<?= $request['en'] ?>" data-url-search="input"> <i
                                    class="_icon-search"></i>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">№ заказа</span>
                        <div class="events__form-item lg">
                            <input class="events__form-input" placeholder="Название" type="text" name="on"
                                   value="<? $request['on'] ?>" data-url-search="input"> <i
                                    class="_icon-search"></i>
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">Объем</span>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
												<span class="events__table-btn">Кол-во
													билетов</span>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">Причина возврата</span>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">Сумма заявки</span>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">Сумма возврата</span>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">Тип оплаты</span>
                        <div class="events__form-item">
                            <div class="form-select js-form-select ">
                                <div class="form-select__selected-option js-form-select-option js-option-change"
                                     data-placeholder="Выберите из списка"><?
                                    if ($request['pt'] == 1) {
                                        echo 'Эквайринг';
                                    } elseif ($request['pt'] == 2) {
                                        echo 'ЮЛ по счету';
                                    } else {
                                        echo 'Все';
                                    }
                                    ?>
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="">Все
                                        </li>
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="1">
                                            Эквайринг
                                        </li>
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="2">
                                            ЮЛ по счету
                                        </li>
                                    </ul>
                                </div>
                                <input type="hidden" name="pt" value="<?= $request['pt'] ?>" data-url-search="change">
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <span class="events__table-btn">Документы</span>
                    </div>
                </td>


                <td>
                    <div class="events__table-item">
                        <p>Дата подачи заявки</p>
                        <div class="events__form-item">
                            <input type="text" class="events__form-input" data-date="range" name="d"
                                   value="<?= $request['d'] ?>" data-url-search="input">
                        </div>
                    </div>
                </td>

                <td>
                    <div class="events__table-item">
                        <p>Статус</p>
                        <div class="events__form-item">
                            <div class="form-select js-form-select ">
                                <div class="form-select__selected-option js-form-select-option js-option-change"
                                     data-placeholder="Выберите из списка">Все
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option=""><?= (int)$request['s'] > 0 ? $arResult['REVIEW_STATUS_LIST'][$request['s']]['ENUM_NAME'] : 'Все' ?>
                                        </li>
                                        <? foreach ($arResult['REVIEW_STATUS_LIST'] as $status): ?>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="<?= $status['ENUM_ID'] ?>"><?= $status['ENUM_NAME'] ?>
                                            </li>
                                        <? endforeach; ?>
                                    </ul>
                                </div>
                                <input type="hidden" name="s" value="<?= $request['s'] ?>" data-url-search="change">
                            </div>
                        </div>

                    </div>
                </td>

                <td></td>
            </tr>
            </thead>


            <tbody>
            <? foreach ($arResult['ITEMS'] as $item): ?>
                <tr>
                    <td>
                        <div class="events__table-select">
                            <div class="checkbox blue checkbox--small">
                                <label>
                                    <input type="checkbox" name="id[]" value="<?= $item['ID'] ?>"
                                           class="js-table-checkbox" <?= $item['UF_REVIEW_STATUS']['ENUM_XML_ID'] == 'pending' ? "" : "disabled" ?>>
                                    <span
                                            class="_icon-checkbox"></span>
                                </label>
                            </div>
                        </div>
                    </td>


                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p><?= $item['EVENT_NAME'] ?></p>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item" data-event-controls>
                            <div class="events__table-item-name">
                                <button class="table-link" data-event-controls-btn
                                        type="button"><?= $item['ORDER_NUM'] ?></button>

                                <div class="events__table-controls-body table-controls-notification"
                                     data-event-controls-body>
                                    <div class="table-controls-notification__close">
                                        <img alt="" class="svg" src="<?= SITE_TEMPLATE_PATH ?>/img/svg/cross.svg">
                                    </div>
                                    <div class="table-controls-notification__title">
                                        <p>Заказ №<?= $item['ORDER_NUM'] ?></p>
                                        <? foreach ($item['TICKETS_TYPES_REFUND'] as $typeName => $ticketQty): ?>
                                            <p><?= $typeName ?>, <?= (int)$ticketQty ?> шт.</p>
                                        <? endforeach; ?>
                                        <p><?= floatval($item['REFUND_SUM']) ?> ₽</p>
                                    </div>
                                    <div class="table-controls-notification__desc">
                                        <p><?= $item['UF_FULL_NAME'] ?></p>
                                        <p><?= $item['UF_EMAIL'] ?></p>
                                        <p><?= $item['UF_PHONE'] ?></p>
                                        <? if ($item['PERSON_TYPE'] == 2): ?>
                                            <p><?= $item['COMPANY'] ?></p>
                                            <p>ИНН <?= $item['INN'] ?></p>
                                        <? endif; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <? if ($item['REFUND_SUM'] == (int)$item['ORDER_SUM']): ?>
                                    <p>Полный возврат</p>
                                <? else: ?>
                                    <p>Неполный возврат</p>
                                <? endif; ?>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item" data-event-controls>
                            <div class="events__table-item-name">
                                <button class="table-link" data-event-controls-btn
                                        type="button"><?= is_array($item['UF_BASKET_ITEM_ID']) ? count($item['UF_BASKET_ITEM_ID']) : 0 ?></button>

                                <div class="events__table-controls-body table-controls-notification"
                                     data-event-controls-body>
                                    <div class="table-controls-notification__close">
                                        <img alt="" class="svg" src="<?= SITE_TEMPLATE_PATH ?>/img/svg/cross.svg">
                                    </div>
                                    <div>
	                                    <table class="table-controls-notification__table">
                                        <? foreach ($item['UF_BASKET_ITEM_ID'] as $ticket_num => $basketItem): ?>
	                                        <tr>
		                                        <td>Билет <?=$ticket_num + 1?></td>
                                                <?if($basketItem && is_array($basketItem)):?>
		                                        <td><?= $basketItem['TICKET_NAME'] ?>
			                                        №<?= $basketItem['SERIES'] ?> <?= $basketItem['NUMBER'] ?></td>
                                                <?endif;?>
	                                        </tr>
                                        <? endforeach; ?>
	                                    </table>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item" data-event-controls>
                            <div class="">
                                <p><?= $arResult['REASONS_LIST'][$item['UF_REASON_FOR_RETURN']]['ENUM_NAME'] ?></p>
                                <? if (!empty($item['UF_COMMENT'])): ?>
                                    <button class="table-link table-link--grey" data-event-controls-btn type="button">
                                        Комментарий
                                    </button>
                                <? endif; ?>
                                <div class="events__table-controls-body table-controls-notification"
                                     data-event-controls-body>
                                    <div class="table-controls-notification__close">
                                        <img alt="" class="svg" src="<?= SITE_TEMPLATE_PATH ?>/img/svg/cross.svg">
                                    </div>
                                    <div class="table-controls-notification__title">Причина возврата</div>
                                    <div class="table-controls-notification__desc">
                                        <?= $item['UF_COMMENT'] ?>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </td>


                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name no-wrap">
                                <?= floatval($item['REFUND_SUM']) ?> ₽
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name no-wrap">
                                <?= floatval($item['UF_ACTUAL_REFUND_SUM']) > 0 && !in_array($item['UF_REVIEW_STATUS']['ENUM_XML_ID'], ['reject', 'pending', 'independently']) ? floatval($item['UF_ACTUAL_REFUND_SUM']) . ' ₽' : '' ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name no-wrap">
                                <?= $item['PAYMENT_TYPE'] ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <? if (count($item['UF_DOCUMENTS'] ?? []) > 0): ?>
                            <div class="events__table-item">
                                <button class="table-icon-row" data-popup="#refund-attach-doc"
                                        data-popup-src="<?= $APPLICATION->GetCurPage() ?>?action=layoutFiles&id=<?= $item['ID'] ?>">
                                    <img alt="" class="table-icon-row__ico"
                                         src="<?= SITE_TEMPLATE_PATH ?>/img/svg/copy.svg">
                                    <span class="events__table-item__name"><?= count($item['UF_DOCUMENTS'] ?? []) ?></span>
                                </button>
                            </div>
                        <? endif; ?>
                    </td>


                    <td>
                        <div class="events__table-item">
                            <?= $item['UF_DATE_TIME'] ?>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item" data-event-controls>
                            <div class="status__active <?= $item['UF_REVIEW_STATUS']['CSS_CLASS'] ?>"><?= $item['UF_REVIEW_STATUS']['ENUM_NAME'] ?></div>
                            <? if ($item['UF_REVIEW_STATUS']['ENUM_XML_ID'] == 'reject'): ?>
                                <div>
                                    <button class="table-link table-link--grey" data-event-controls-btn type="button"
                                            style="padding-left: .875rem;">
                                        Причина отказа
                                    </button>
                                </div>
                                <div class="events__table-controls-body table-controls-notification"
                                     data-event-controls-body>
                                    <div class="table-controls-notification__close">
                                        <img alt="" class="svg" src="<?= SITE_TEMPLATE_PATH ?>/img/svg/cross.svg">
                                    </div>
                                    <div class="table-controls-notification__title"><?= $arResult['REASONS_FOR_REFUSAL_LIST'][$item['UF_REASON_FOR_REFUSAL']]['ENUM_NAME'] ?></div>
                                    <div class="table-controls-notification__desc">
                                        <?= $item['UF_COMMENT_ABOUT_REJECTION'] ?>
                                    </div>
                                </div>
                            <? endif; ?>
                        </div>
                    </td>
                    <td>
                        <? if ($item['UF_REVIEW_STATUS']['ENUM_XML_ID'] == 'pending') : ?>
                            <div class="events__table-controls controls__sticky" data-event-controls>
                                <button class="btn__icon" data-event-controls-btn type="button">
                                    <i class="_icon-rounds"></i>
                                </button>
                                <div class="events__table-controls-body" data-event-controls-body>
                                    <ul>
                                        <? foreach ($arResult['REFUNDS_TYPES_LIST'] as $type => $refundName): ?>
                                            <li>
                                                <? if (
                                                    (
                                                            $type != 'I' && $item['EVENT_STATUS'] != 'cancelled' &&
                                                            (empty($item['EVENT_DATE_CHANGES']) || $item['ORDER_DATE'] > $item['EVENT_DATE_CHANGES'])
                                                    ) ||
                                                    ($type == 'F' && $item['EVENT_STATUS'] == 'cancelled') ||
                                                    (
                                                        in_array($type, ['F', 'R']) &&
                                                        $item['EVENT_STATUS'] != 'cancelled' &&
                                                        !empty($item['EVENT_DATE_CHANGES']) &&
                                                        $item['ORDER_DATE'] <= $item['EVENT_DATE_CHANGES']
                                                    )
                                                ): ?>
                                                    <a href="#"
                                                       data-popup-src="<?= $APPLICATION->GetCurPage() ?>?action=getForm&type=<?= $type ?>&id=<?= $item['ID'] ?>"
                                                       data-popup="#refund"><?= $refundName ?></a>

                                                <? elseif ($type == 'I' && $item['PERSON_TYPE'] != 2): ?>
                                                    <a class="js-ajax-link" data-need-reload=".events__table"
                                                       href="<?= $APPLICATION->GetCurPage() ?>?action=refund&type=<?= $type ?>&id=<?= $item['ID'] ?>&<?= bitrix_sessid_get() ?>"><?= $refundName ?></a>
                                                <? endif; ?>
                                            </li>
                                        <? endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        <? endif; ?>
                    </td>
                </tr>
            <? endforeach; ?>
            </tbody>
        </table>
	    </div>

        <div class="event-foot">

            <div class="event-foot-btns disabled">
                <? foreach ($arResult['REFUNDS_TYPES_LIST'] as $type => $refundName): ?>
                    <? if ($type != 'P' && $type != 'I'): ?>
                        <div class="btn js-refund-get-data-btn">
                            <span><?= $refundName ?></span>
                            <a class="fake-btn" data-popup="#refund"
                               data-popup-src="<?= $APPLICATION->GetCurPage() ?>?action=getForm&type=<?= $type ?>"
                               href="<?= $APPLICATION->GetCurPage() ?>?action=getForm&type=<?= $type ?>"></a>
                        </div>
                    <? elseif ($type == 'I'): ?>
                        <div class="btn js-refund-get-data-btn">
                            <span><?= $refundName ?></span>
                            <a class="fake-btn js-ajax-link"
                               href="<?= $APPLICATION->GetCurPage() ?>?action=refund&type=<?= $type ?>&<?= bitrix_sessid_get() ?>"
                               data-need-reload=".events__table"></a>
                        </div>
                    <? endif; ?>
                <? endforeach; ?>
            </div>

            <div class="pagination events__pagination">

                <div class="form-select js-form-select pagination-show-to">
                    <div class="form-select__selected-option js-form-select-option js-option-change"
                         data-placeholder="Выберите из списка">Показывать по <?= $arParams['REFUNDS_COUNT'] ?>
                    </div>
                    <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                    <div class="form-select-options-wrap js-form-select-options-wrap">
                        <ul class="form-select-options form-select__options">
                            <li class="form-select-options__item js-form-select-options-item" data-option="10">
                                Показывать по 10
                            </li>
                            <li class="form-select-options__item js-form-select-options-item" data-option="20">
                                Показывать по 20
                            </li>
                            <li class="form-select-options__item js-form-select-options-item" data-option="50">
                                Показывать по 50
                            </li>
                            <li class="form-select-options__item js-form-select-options-item" data-option="100">
                                Показывать по 100
                            </li>
                        </ul>
                    </div>
                    <input type="hidden" name="show" value="<?= $arParams['REFUNDS_COUNT'] ?>">
                </div>

                <?= $arResult['NAV_STRING'] ?>

            </div>

        </div>

    </div>
</div>

<div aria-hidden="true" class="popup popup__small" id="refund">
    <div class="popup__wrapper">
        <div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            <div class="popup-transfer__name refund-title h1">Полный возврат</div>

            <table class="refund-static">
                <tr>
                    <td>Номер заказа</td>
                    <td>
                        <div class="refund-static__val no-wrap">
                            155457785
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Сумма заказа</td>
                    <td>
                        <div class="refund-static__val no-wrap">
                            25 000,00 ₽
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Сумма возврата</td>
                    <td>
                        <div class="refund-static__val no-wrap">
                            25 000,00 ₽
                        </div>
                    </td>
                </tr>
            </table>

            <div class="refund-modal-foot">
                <a class="btn btn__clean btn__big" data-close href="#" type="button">Отмена</a>
                <button class="btn btn__blue btn__big" href="" type="button">Подтвердить</button>
            </div>

        </div>
    </div>
</div>

<div aria-hidden="true" class="popup popup__small" id="refund-commission">
    <div class="popup__wrapper">
        <div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            <div class="popup-transfer__name refund-title h1">Возврат за вычетом комиссии</div>

            <table class="refund-static">
                <tr>
                    <td>Номер заказа</td>
                    <td>
                        <div class="refund-static__val no-wrap">
                            155457785
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Сумма заказа</td>
                    <td>
                        <div class="refund-static__val no-wrap">
                            25 000,00 ₽
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Лицензионное вознаграждение</td>
                    <td>
                        <div class="refund-static__val no-wrap">
                            500,00 ₽
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Сумма возврата</td>
                    <td>
                        <div class="refund-static__val no-wrap">
                            24 500,00 ₽
                        </div>
                    </td>
                </tr>
            </table>

            <div class="refund-modal-foot">
                <a class="btn btn__clean btn__big" data-close href="#" type="button">Отмена</a>
                <button class="btn btn__blue btn__big" href="" type="button">Подтвердить</button>
            </div>

        </div>
    </div>
</div>

<div aria-hidden="true" class="popup popup__small" id="refund-partial">
    <div class="popup__wrapper">
        <div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            <div class="popup-transfer__name refund-title h1">Частичный возврат</div>

            <form action="" class="js-form-validate">
                <input class="js-refund-order-sum" type="hidden" value="25000">
                <table class="refund-static">
                    <tr>
                        <td>Номер заказа</td>
                        <td>
                            <div class="refund-static__val no-wrap">
                                155457785
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Сумма заказа</td>
                        <td>
                            <div class="refund-static__val no-wrap">
                                25 000,00 ₽
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Лицензионное вознаграждение</td>
                        <td>
                            <div class="refund-static__val no-wrap">
                                500,00 ₽
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>Сумма возврата</p>
                            <div class="refund-static-type">
                                <label>
                                    <input checked name="refund-static-type" type="radio" value="percent"> <span
                                            class="refund-static-type__itm">%</span>
                                </label>
                                <label>
                                    <input name="refund-static-type" type="radio" value="ruble"> <span
                                            class="refund-static-type__itm">₽</span>
                                </label>
                            </div>
                        </td>
                        <td>
                            <div class="refund-static__val no-wrap required">
                                <div class="refund-static-val">
                                    <input class="js-refund-result-input" type="number">
                                    <div class="refund-static-val__ico">%</div>
                                    <div class="form-item__label" hidden="">Сумма возврата</div>
                                </div>
                            </div>
                        </td>
                    </tr>


                    <tr data-type-show="percent">
                        <td>Итого</td>
                        <td>
                            <div class="refund-static__val no-wrap js-percent-total-result">0,00 ₽</div>
                        </td>
                    </tr>
                </table>

                <div class="refund-modal-foot">
                    <a class="btn btn__clean btn__big" data-close href="#" type="button">Отмена</a>
                    <button class="btn btn__blue btn__big js-form-validate-btn" href="" type="submit">Подтвердить
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div aria-hidden="true" class="popup popup__small" id="refund-reject">
    <div class="popup__wrapper">
        <div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            <div class="popup-transfer__name refund-title h1">Отказ в возврате</div>

            <form action="" class="js-form-validate">
                <table class="refund-static">
                    <tr>
                        <td>Номер заказа</td>
                        <td>
                            <div class="refund-static__val no-wrap">
                                155457785
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Сумма заказа</td>
                        <td>
                            <div class="refund-static__val no-wrap">
                                25 000,00 ₽
                            </div>
                        </td>
                    </tr>
                </table>


                <div class="form-select js-form-select form-item-round form-item-margin required">
                    <label class="form-item__label" hidden="">Причина отказа</label>
                    <div class="form-select__selected-option js-form-select-option js-option-change"
                         data-placeholder="Выберите причину отказа">Выберите причину отказа
                    </div>
                    <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                    <div class="form-select-options-wrap js-form-select-options-wrap">
                        <ul class="form-select-options form-select__options">
                            <li class="form-select-options__item js-form-select-options-item" data-option="">Выберите
                                причину отказа
                            </li>
                            <li class="form-select-options__item js-form-select-options-item" data-option="1">Lorem
                                ipsum
                            </li>
                            <li class="form-select-options__item js-form-select-options-item" data-option="2">Другое
                            </li>
                        </ul>
                    </div>
                    <input type="hidden" value="">
                </div>

                <div class="form-item">
                    <label class="form-item__label" hidden="">Комментарий</label>
                    <span class="form__error"></span> <input class="form__round-input" placeholder="Комментарий"
                                                             type="text" value=""/>
                </div>

                <div class="refund-modal-foot">
                    <a class="btn btn__clean btn__big" data-close href="#" type="button">Отмена</a>
                    <button class="btn btn__blue btn__big js-form-validate-btn" href="" type="submit">Подтвердить
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div aria-hidden="true" class="popup popup__medium" id="refund-attach-doc">
    <div class="popup__wrapper"></div>
</div>



