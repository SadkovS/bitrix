$(document).ready(function () {

	$('.pagination-show-to input').on('change', (e) => {
		getUrlVars()
	})

// 	// Изменение фильтра
// 	async function getUrlVars() {
// 		let url = new Url(window.location.href);
// 		const [name, num, date, status, phone, email, show] = [
// 			document.querySelector('[name="en"]').value,
// 			document.querySelector('[name="on"]').value,
// 			document.querySelector('[name="d"]').value,
// 			document.querySelector('[name="s"]').value,
// 			document.querySelector('[name="ph"]').value,
// 			document.querySelector('[name="e"]').value,
// 			document.querySelector('[name="show"]').value
// 		];
//
// 		console.log(date)
//
// 		url.query.ajax = 'Y';
// 		name === '' ? delete url.query.en : url.query.en = name;
// 		num === '' ? delete url.query.on : url.query.on = num;
// 		date === '' ? delete url.query.d : url.query.d = date;
// 		status === '' ? delete url.query.s : url.query.s = status;
// 		phone === '' ? delete url.query.ph : url.query.ph = phone;
// 		email === '' ? delete url.query.e : url.query.e = email;
// 		show === '' ? delete url.query.show : url.query.show = show;
//
// 		const address = url.toString();
//
// 		const response = await fetch(address);
// 		if (!response.ok) {
// 			return
// 		}
// 		const data = await response.text()
// 		let doc = new DOMParser().parseFromString(data, "text/html");
// 		const tbody = doc.querySelector('tbody');
// 		const pagination = doc.querySelector('.pagination.events__pagination');
// 		delete url.query.ajax;
//
// 		window.history.pushState("event search", "", url.toString());
// 		document.querySelector('.events__table tbody').replaceWith(tbody);
// 		document.querySelector('.events__pagination').replaceWith(pagination);
// 	}
//
// // Эвент фильтрации по инпуту
// 	function inputFilter(e) {
// 		const target = e.target;
// 		console.log(target);
// 		if (!target.closest('[name="en"]') && !target.closest('[name="on"]') && !target.closest('[name="e"]') && !target.closest('[name="ph"]')) return;
// 		getUrlVars();
// 	}
//
// // Эвент фильтрации по селекту
// 	function changeFilter(e) {
// 		const target = e.target;
// 		if (!target.closest('[name="s"]') && !target.closest('[name="d"]')) return;
// 		getUrlVars();
// 	}

	function printFromData(data, pushState = 'page', url) {
		const doc = new DOMParser().parseFromString(data, "text/html");
		const tbody = doc.querySelector('tbody');
		const pagination = doc.querySelector('.pagination.events__pagination');

		window.history.pushState(pushState, "", url.toString());
		const pageTableBody = document.querySelector('.events__table tbody');
		if (pageTableBody && tbody) {
			pageTableBody.replaceWith(tbody);
		}
		const pagePagination = document.querySelector('.events__pagination');
		if (pagePagination && pagination) {
			pagePagination.replaceWith(pagination);
		}
	}

	let promise
	// Изменение фильтра
	async function pageTableSortFromUrl() {
		let reject, resolve;
		promise = new Promise((res, rej) => {
			resolve = res;
			reject = rej;
		});
		try {
			let url = new Url(window.location.href);
			url.search = '';
			url.query.ajax = 'Y';
			const inputs = [...document.querySelectorAll('input[data-url-search]')];
			for (let i = 0; i < inputs.length; i++) {
				const item = inputs[i];
				if (item.type === 'checkbox') {
					if (item.checked) {
						url.query[item.name] = item.value
					} else {
						delete url.query[item.name];
					}
				} else {
					item.value !== '' ? url.query[item.name] = item.value : delete url.query[item.name];
				}
			}
			url.query.PAGEN_1 = 1;

			const response = await fetch(url);
			if (!response.ok) {
				console.error(response.statusText);
				reject(response.statusText);
			}
			const data = await response.text();
			printFromData(data, "event search", url);

			resolve();
		} catch (error) {
			console.error(error);
			reject(error);
		}
		return promise;
	}

// Эвент фильтрации по инпуту
	function inputFilter(e) {
		const target = e.target;
		if (!target.closest('[data-url-search="input"]')) return;
		pageTableSortFromUrl();
	}
// Эвент фильтрации по селекту
	function changeFilter(e) {
		const target = e.target;
		if (!target.closest('[data-url-search="change"]')) return;
		pageTableSortFromUrl();
	}

// Req на отказе в возврате
	function toggleReq({target}) {
		if(!('closest' in target)) return;
		const select = target.closest('input[name="reason"]');
		if (!select) return;
		const parent = select.closest('form');
		if (!parent) return;
		const inp = parent.querySelector('input[name="reason_comment"]');
		if (!inp) return;
		inp.closest('.form-item').classList.toggle('required', select.value === '110')
	}
// Бинд всех эвентов на страницу
	[
		['change', changeFilter],
		['input', debounce(inputFilter, 500)],
		['change', toggleReq]
	].forEach(([event, fn]) => {
		document.addEventListener(event, fn)
	});

// Функция дебаунса
	function debounce(func, wait, immediate) {
		let timeout;
		return function () {
			const context = this;
			const args = arguments;
			const later = function () {
				timeout = null;
				if (!immediate) func.apply(context, args);
			};
			const callNow = immediate && !timeout;
			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
			if (callNow) func.apply(context, args);
		};
	}
});

