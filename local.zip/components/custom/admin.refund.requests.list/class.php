<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
require_once($_SERVER["DOCUMENT_ROOT"] . '/local/crest/crest.php');

use Bitrix\Highloadblock as HL;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM;

Loader::includeModule('iblock');
Loader::includeModule('sale');
Loc::loadMessages(__FILE__);

class AdminRefundRequestsList extends \CBitrixComponent {

    private $filter;
    protected $offset = 0;
    protected $showLimits = [10, 20, 50, 100];
    protected $companyID;
    protected const LEGAL_PERSON_TYPE_ID = 2;

    protected $statusCssClasses = [
        'pending'       => 'status__active--waiting',
        'independently' => 'status__active--approved',
        'fully'         => 'status__active--approved',
        'partial'       => 'status__active--approved',
        'refunded'      => 'status__active--success',
        'reject'        => 'status__active--error'
    ];
    protected $refundsTypes = [
        'F' => 'Полный возврат',
        'P' => 'Частичный возврат',
        'I' => 'Самостоятельный возврат',
        'C' => 'Возврат за вычетом комиссии',
        'R' => 'Отказ в возврате'
    ];

    public function __construct($component = null)
    {
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        if ($this->companyID <= 0) return false;

        parent::__construct($component);
        $this->filter                               = $this->makeFilter();
        $this->arResult['REASONS_LIST']             = self::getReasonsForRefund();
        $this->arResult['REASONS_FOR_REFUSAL_LIST'] = self::getReasonsForRefusal();
        $this->arResult['REVIEW_STATUS_LIST']       = self::getReviewStatuses();
        $this->arResult['REFUNDS_TYPES_LIST']       = $this->refundsTypes;

        if (isset($this->request['action']) && $this->request['action'] != '') $this->execAction($this->request['action']);

    }

    public function onPrepareComponentParams($arParams)
    {
        if (isset($this->request['show']) && in_array($this->request['show'], $this->showLimits))
            $arParams['REFUNDS_COUNT'] = $this->request['show'];
        else
            $arParams['REFUNDS_COUNT'] = 10;

        return $arParams;
    }

    private function makeFilter()
    {
        $filter = [
            'UF_COMPANY_ID'          => $this->companyID,
            "PROPERTY_EVENT_ID.CODE" => "EVENT_ID",
        ];

        if (isset($this->request['ph']) && !empty($this->request['ph']))
            $filter['%UF_PHONE'] = $this->request['ph'];
        if (isset($this->request['e']) && !empty($this->request['e']))
            $filter['%UF_EMAIL'] = $this->request['e'];
        if (isset($this->request['s']) && !empty($this->request['s']))
            $filter['UF_REVIEW_STATUS'] = $this->request['s'];
        if (isset($this->request['en']) && !empty($this->request['en']))
            $filter['%EVENT_NAME'] = $this->request['en'];
        if (isset($this->request['d']) && !empty($this->request['d'])) {
            $date = explode('-', $this->request['d']);
            if (count($date) > 1) {
                $filter[] = [
                    "LOGIC" => 'AND',
                    [">=UF_DATE_TIME" => $date[0] . ' 00:00:00'],
                    ["<=UF_DATE_TIME" => $date[1] . ' 23:59:59'],
                ];
            } else {
                $filter[] = [
                    "LOGIC" => 'AND',
                    [">=UF_DATE_TIME" => $date[0] . ' 00:00:00'],
                    ["<=UF_DATE_TIME" => $date[0] . ' 23:59:59'],
                ];
            }
        }
        if (isset($this->request['on']) && !empty($this->request['on']))
            $filter['%ORDER_NUM'] = $this->request['on'];
        if (isset($this->request['pt']) && !empty($this->request['pt']))
            $filter['PERSON_TYPE'] = $this->request['pt'];

        return $filter;
    }

    private function getReasonsForRefund()
    {
        return $this->getPropertiesEnum('TicketRefundRequests', 'UF_REASON_FOR_RETURN');
    }

    private function getReviewStatuses()
    {
        return $this->getPropertiesEnum('TicketRefundRequests', 'UF_REVIEW_STATUS');
    }

    private function getReasonsForRefusal()
    {
        return $this->getPropertiesEnum('TicketRefundRequests', 'UF_REASON_FOR_REFUSAL');
    }

    private function getPropertiesEnum(string $hlName, string $fieldName, string $xmlID = '')
    {
        $filter = [
            "HL.NAME"    => $hlName,
            "FIELD_NAME" => $fieldName,
        ];

        if (!empty($xmlID)) $filter["ENUM.XML_ID"] = $xmlID;

        $query = \Bitrix\Main\UserFieldTable::getList(
            [
                "filter"  => $filter,
                "select"  => [
                    "ENUM_ID"     => "ENUM.ID",
                    "ENUM_XML_ID" => "ENUM.XML_ID",
                    "ENUM_NAME"   => "ENUM.VALUE",
                ],
                "runtime" => [
                    new \Bitrix\Main\Entity\ExpressionField(
                        'HL_ID',
                        'REPLACE(%s, "HLBLOCK_", "")',
                        ['ENTITY_ID']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'HL',
                        '\Bitrix\Highloadblock\HighloadBlockTable',
                        ['this.HL_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'ENUM',
                        '\Custom\Core\FieldEnumTable',
                        ['this.ID' => 'ref.USER_FIELD_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ],
                'order'   => ['ENUM_ID' => 'ASC'],
                'cache'   => ['ttl' => 3600],
            ]
        );
        $res   = [];
        while ($item = $query->fetch()) {
            if (!empty($xmlID)) $res = $item['ENUM_ID'];
            else $res[$item['ENUM_ID']] = $item;
        }
        return $res;
    }

    private function getStatusIDByXmlID($xmlID): int
    {
        return (int)$this->getPropertiesEnum('TicketRefundRequests', 'UF_REVIEW_STATUS', $xmlID);
    }

    private function getRefundInfo(int|array $requestID, bool $totalAmount = false): array
    {

        $reviewStatusID = $this->getStatusIDByXmlID('pending');
        $query          = new ORM\Query\Query('Custom\Core\Tickets\TicketRefundRequestsTable');
        $resRequest     = $query
            ->setSelect(
                [
                    'ID',
                    'ORDER_NUM'           => 'ORDER_REF.ACCOUNT_NUMBER',
                    'ORDER_ID'            => 'ORDER_REF.ID',
                    'COOPERATION_PERCENT' => 'PROPERTY_COOPERATION_PERCENT.VALUE',
                    'REQUEST_SUM',
                    'COMMISSION',
                    'REFUND_SUM',
                    'TICKETS_QTY',
                    'BARCODES',
                ]
            )
            ->setFilter(
                [
                    'ID'                                => $requestID,
                    'UF_COMPANY_ID'                     => $this->companyID,
                    'UF_REVIEW_STATUS'                  => $reviewStatusID,
                    "PROPERTY_COOPERATION_PERCENT.CODE" => 'COOPERATION_PERCENT',
                    "BASKET_PROPS_BARCODE_REF.CODE"     => "BARCODE"
                ]
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'ORDER_REF',
                    '\Bitrix\Sale\Order',
                    ['this.UF_ORDER_ID' => 'ref.ID'],
                    ['join_type' => 'left']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PROPERTY_COOPERATION_PERCENT',
                    'Bitrix\Sale\Internals\OrderPropsValueTable',
                    ['=this.UF_ORDER_ID' => 'ref.ORDER_ID'],
                    ['join_type' => 'left']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'REFUND_TICKETS_REF',
                    'Bitrix\Sale\Internals\BasketTable',
                    ['this.BASKET_ITEM_ID.VALUE' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'TICKET_TYPE_REFUND_REF',
                    $this->getTicketTypeEntity(),
                    ['this.REFUND_TICKETS_REF.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'BASKET_PROPS_BARCODE_REF',
                    '\Bitrix\Sale\Internals\BasketPropertyTable',
                    ['=this.BASKET_ITEM_ID.VALUE' => 'ref.BASKET_ID'],
                    ['join_type' => 'left']
                ),
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'REQUEST_SUM',
                    "SUM( %s)",
                    ['REFUND_TICKETS_REF.PRICE']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'COMMISSION',
                    "ROUND( %s * %s / 100 ,2)",
                    ['REQUEST_SUM', 'PROPERTY_COOPERATION_PERCENT.VALUE']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'REFUND_SUM',
                    "%s - %s",
                    ['REQUEST_SUM', 'COMMISSION']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'TICKETS_QTY',
                    "COUNT( %s)",
                    ['BASKET_ITEM_ID.ID']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'BARCODES',
                    'GROUP_CONCAT(%s)',
                    ['BASKET_PROPS_BARCODE_REF.VALUE']
                )
            )
            ->countTotal(true)
            ->exec();
        $result         = $resRequest->fetchAll();
        if (!$totalAmount) return $result;

        $arResult = [];
        foreach ($result as $item) {
            $arResult['REQUEST_SUM']         += $item['REQUEST_SUM'];
            $arResult['COOPERATION_PERCENT'] = $item['COOPERATION_PERCENT'];
            $arResult['COMMISSION']          += $item['COMMISSION'];
            $arResult['REFUND_SUM']          += $item['REFUND_SUM'];
            $arResult['TICKETS_QTY']         += $item['TICKETS_QTY'];
        }
        return $arResult;

    }

    public function executeComponent()
    {

        $curPage = (int)$this->request['PAGEN_1'] > 0 ? (int)$this->request['PAGEN_1'] : 1;

        if (isset($this->request['PAGEN_1']) && (int)$this->request['PAGEN_1'] > 1)
            $this->offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $this->arParams["REFUNDS_COUNT"];

        $query      = new ORM\Query\Query('Custom\Core\Tickets\TicketRefundRequestsTable');
        $resRefunds = $query
            ->setSelect(
                [
                    'ID',
                    'UF_FULL_NAME',
                    'UF_EMAIL',
                    'UF_PHONE',
                    'UF_COMMENT',
                    'UF_REASON_FOR_RETURN',
                    'UF_DOCUMENTS',
                    'UF_DATE_TIME',
                    'UF_REVIEW_STATUS',
                    'ORDER_NUM'    => 'ORDER_REF.ACCOUNT_NUMBER',
                    'ORDER_DATE'   => 'ORDER_REF.DATE_INSERT',
                    'ORDER_SUM',
                    'EVENT_ID'     => 'PROPERTY_EVENT_ID.VALUE',
                    'EVENT_NAME'   => 'EVENT.UF_NAME',
                    'EVENT_STATUS' => 'EVENT_STATUS_REF.UF_XML_ID',
                    'EVENT_DATE_CHANGES' => 'EVENT.UF_DATE_OF_SIGNIFICANT_CHANGES',
                    'TICKETS_TYPES_REFUND',
                    'REFUND_SUM',
                    'UF_BASKET_ITEM_ID',
                    'UF_ACTUAL_REFUND_SUM',
                    'UF_COMMENT_ABOUT_REJECTION',
                    'PERSON_TYPE' => 'ORDER_REF.PERSON_TYPE_ID',
                    'INN'         => 'PROPERTY_INN.VALUE',
                    'COMPANY'     => 'PROPERTY_COMPANY.VALUE',
                ]
            )
            ->setFilter($this->filter)
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'ORDER_REF',
                    '\Bitrix\Sale\Order',
                    ['this.UF_ORDER_ID' => 'ref.ID'],
                    ['join_type' => 'left']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PROPERTY_INN',
                    'Bitrix\Sale\Internals\OrderPropsValueTable',
                    [
                        '=this.UF_ORDER_ID' => 'ref.ORDER_ID',
                        '=ref.CODE'         => new \Bitrix\Main\DB\SqlExpression('?s', 'INN')
                    ],
                    ['join_type' => 'left']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PROPERTY_COMPANY',
                    'Bitrix\Sale\Internals\OrderPropsValueTable',
                    [
                        '=this.UF_ORDER_ID' => 'ref.ORDER_ID',
                        '=ref.CODE'         => new \Bitrix\Main\DB\SqlExpression('?s', 'COMPANY')
                    ],
                    ['join_type' => 'left']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PROPERTY_EVENT_ID',
                    'Bitrix\Sale\Internals\OrderPropsValueTable',
                    ['=this.UF_ORDER_ID' => 'ref.ORDER_ID'],
                    ['join_type' => 'inner']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'EVENT',
                    'Custom\Core\Events\EventsTable',
                    ['=this.EVENT_ID' => 'ref.ID'],
                    ['join_type' => 'inner']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'EVENT_STATUS_REF',
                    'Custom\Core\Events\EventsStatusTable',
                    ['=this.EVENT.UF_STATUS' => 'ref.ID'],
                    ['join_type' => 'inner']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PROPERTY_EVENT_ID',
                    'Bitrix\Sale\Internals\OrderPropsValueTable',
                    ['=this.UF_ORDER_ID' => 'ref.ORDER_ID'],
                    ['join_type' => 'inner']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'REFUND_TICKETS_REF',
                    'Bitrix\Sale\Internals\BasketTable',
                    ['this.BASKET_ITEM_ID.VALUE' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'TICKET_TYPE_REFUND_REF',
                    $this->getTicketTypeEntity(),
                    ['this.REFUND_TICKETS_REF.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'TICKETS_TYPES_REFUND',
                    "GROUP_CONCAT( %s SEPARATOR ';')",
                    ['TICKET_TYPE_REFUND_REF.VALUE']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'REFUND_SUM',
                    "SUM( %s)",
                    ['REFUND_TICKETS_REF.PRICE']
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'ORDER_SUM',
                    "%s - %s",
                    ['ORDER_REF.PRICE', 'ORDER_REF.PRICE_DELIVERY']
                )
            )
            ->setGroup(['ID'])
            ->setOrder(['UF_DATE_TIME' => 'DESC'])
            ->setLimit($this->arParams["REFUNDS_COUNT"])
            ->setOffset($this->offset)
            ->countTotal(true)
            ->exec();

        $this->arResult['ALL_COUNT'] = $resRefunds->getCount();
        $basketItemsIds = [];
        while ($refundRequest = $resRefunds->fetch()) {
            if (is_object($refundRequest['EVENT_DATE_CHANGES'])) $refundRequest['EVENT_DATE_CHANGES'] = $refundRequest['EVENT_DATE_CHANGES']->getTimestamp();
            if (is_object($refundRequest['ORDER_DATE'])) $refundRequest['ORDER_DATE'] = $refundRequest['ORDER_DATE']->getTimestamp();

            $refundRequest['TICKETS_TYPES_REFUND'] = explode(';', $refundRequest['TICKETS_TYPES_REFUND']) ?? [];
            $refundRequest['TICKETS_TYPES_REFUND'] = array_count_values($refundRequest['TICKETS_TYPES_REFUND']);

            if (is_object($refundRequest['UF_DATE_TIME'])) $refundRequest['UF_DATE_TIME'] = $refundRequest['UF_DATE_TIME']->format('d.m.Y H:i');

            $refundRequest['UF_REVIEW_STATUS']              = $this->arResult['REVIEW_STATUS_LIST'][$refundRequest['UF_REVIEW_STATUS']];
            $refundRequest['UF_REVIEW_STATUS']['CSS_CLASS'] = $this->statusCssClasses[$refundRequest['UF_REVIEW_STATUS']['ENUM_XML_ID']];

            if($refundRequest['UF_BASKET_ITEM_ID'])
                $refundRequest['UF_BASKET_ITEM_ID'] = array_diff($refundRequest['UF_BASKET_ITEM_ID'], [0]);

            $basketItemsIds = array_merge($basketItemsIds, $refundRequest['UF_BASKET_ITEM_ID']);
            $refundRequest['PAYMENT_TYPE'] = $refundRequest['PERSON_TYPE'] != 2 ? 'Эквайринг' : 'ЮЛ по счету';

            $this->arResult['ITEMS'][] = $refundRequest;

        }
        if (count($basketItemsIds) > 0) {
            $resBarcodes = [];
            $query       = new ORM\Query\Query('Bitrix\Sale\Internals\BasketPropertyTable');
            $response    = $query
                ->setSelect(['BASKET_ID', 'SERIES' => 'BARCODE_REF.UF_SERIES', 'NUMBER' => 'BARCODE_REF.UF_TICKET_NUM', 'TICKET_NAME' => 'TICKET_TYPE_REFUND_REF.VALUE'])
                ->setFilter(['BASKET_ID' => $basketItemsIds, 'CODE' => 'BARCODE'])
                ->registerRuntimeField(
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BARCODE_REF',
                        'Custom\Core\Tickets\BarcodesTable',
                        ['=this.VALUE' => 'ref.ID'],
                        ['join_type' => 'inner']
                    )
                )
                ->registerRuntimeField(
                    new \Bitrix\Main\Entity\ReferenceField(
                        'REFUND_TICKETS_REF',
                        'Bitrix\Sale\Internals\BasketTable',
                        ['this.BASKET_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    )
                )
                ->registerRuntimeField(
                    new \Bitrix\Main\Entity\ReferenceField(
                        'TICKET_TYPE_REFUND_REF',
                        $this->getTicketTypeEntity(),
                        ['this.REFUND_TICKETS_REF.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                        ['join_type' => 'LEFT'],
                    )
                )
                ->exec();
            while ($barcode = $response->fetch()) {
                $resBarcodes[$barcode['BASKET_ID']] = $barcode;
            }

            foreach ($this->arResult['ITEMS'] as &$item) {
                foreach ($item['UF_BASKET_ITEM_ID'] as &$basketItemId) {
                    if (isset($resBarcodes[$basketItemId])) {
                        $basketItemId = $resBarcodes[$basketItemId];
                    }
                }
            }
        }


        $this->nav = new \CDBResult();
        $this->nav->NavStart($this->arParams["REFUNDS_COUNT"]);
        $this->nav->NavPageCount      = ceil((int)$this->arResult['ALL_COUNT'] / $this->arParams["REFUNDS_COUNT"]);
        $this->nav->NavPageNomer      = $curPage;
        $this->nav->NavRecordCount    = $this->arResult['ALL_COUNT'];
        $this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');

        $this->includeComponentTemplate();
    }

    public function getFilesList(int $requestID): array
    {
        $query      = new ORM\Query\Query('Custom\Core\Tickets\TicketRefundRequestsTable');
        $resRefunds = $query
            ->setSelect(
                [
                    'NAME'        => 'FILE.ORIGINAL_NAME',
                    'SIZE'        => 'FILE.FILE_SIZE',
                    'EXTERNAL_ID' => 'FILE.EXTERNAL_ID',
                    'FILE_PATH'
                ]
            )
            ->setFilter(['ID' => $requestID, 'UF_COMPANY_ID' => $this->companyID,])
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'FILE',
                    '\Bitrix\Main\FileTable',
                    ['this.DOCUMENT_ID.VALUE' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'FILE_PATH', 'CONCAT("/upload/",%s, "/", %s)', ['FILE.SUBDIR', 'FILE.FILE_NAME']
                )
            )
            ->exec();
        return $resRefunds->fetchAll() ?? [];
    }

    public function downloadFile(string $externalID): void
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        $query      = new ORM\Query\Query('\Bitrix\Main\FileTable');
        $resRefunds = $query
            ->setFilter(['EXTERNAL_ID' => $externalID,])
            ->setSelect(['FILE_PATH', 'FILE_NAME'])
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ExpressionField(
                    'FILE_PATH', 'CONCAT("/upload/",%s, "/", %s)', ['SUBDIR', 'FILE_NAME']
                )
            )
            ->setLimit(1)
            ->CountTotal(true)
            ->exec();

        if (!$resRefunds->getCount()) $this->showError('Файл не найден');

        $file = $resRefunds->fetch();

        header('X-Accel-Redirect: ' . $file['FILE_PATH']);
        header("Content-Type: application/x-force-download");
        header('Content-Disposition: attachment; filename="' . $file['FILE_NAME'] . '"');

        die;
    }

    public function downloadAllFiles(int $requestID): void
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        $arFiles = $this->getFilesList($requestID) ?? [];
        if (count($arFiles) < 1) $this->showError('Файлы не найдены');

        $zip_name = '/upload/tmp/' . time() . ".zip"; // имя файла
        $zip      = new \ZipArchive;

        $zip->open($_SERVER["DOCUMENT_ROOT"] . $zip_name, ZipArchive::CREATE | ZipArchive::OVERWRITE);

        foreach ($arFiles as $file) {
            $zip->addFile($_SERVER["DOCUMENT_ROOT"] . $file['FILE_PATH'], $file['NAME']);
        }

        $zip->close();

        if (file_exists($_SERVER["DOCUMENT_ROOT"] . $zip_name)) {

            $APPLICATION->RestartBuffer();
            // отдаём файл на скачивание
            header("Content-Type: application/zip");
            header('Content-Disposition: attachment; filename="archive.zip"');

            readfile($_SERVER["DOCUMENT_ROOT"] . $zip_name);

            // удаляем zip файл если он существует
            unlink($_SERVER["DOCUMENT_ROOT"] . $zip_name);
            die;
        }

    }

    private function showError($message): string
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        echo json_encode(['status' => 'error', 'message' => $message], JSON_UNESCAPED_UNICODE);
        die;
    }

    private function showSuccess($message = '', $title = ''): string
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        echo json_encode(['status' => 'success', 'message' => $message, 'title' => $title], JSON_UNESCAPED_UNICODE);
        die;
    }

    private function execAction(mixed $action)
    {
        switch ($action) {
            case 'download':
                $this->downloadFile($this->request['id']);
                break;
            case 'downloadAll':
                $this->downloadAllFiles($this->request['id']);
                break;
            case 'layoutFiles':
                $this->getLayoutFilesList($this->request['id']);
                break;
            case 'getForm':
                $this->getForm($this->request['type']);
                break;
            case 'refund':
                $this->approveRefund($this->request['id']);
                break;
        }
    }

    private function getLayoutFilesList(int $requestID): void
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();

        $list = $this->getFilesList($requestID) ?? [];

        if (count($list) < 1) $this->showError('Файлы не найдены');

        $html = '<div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            <div class="popup-transfer__name refund-title h1">Приложенные документы</div>

            <table class="refund-static">';
        foreach ($list as $file) {
            $html .= '<tr>
                    <td class="no-wrap refund-file-row">
                        <a class="refund-file-link" download="" href="?action=download&id=' . $file['EXTERNAL_ID'] . '">' . $file["NAME"] . '</a>
                        <span class="refund-file-size">' . CFile::FormatSize($file["SIZE"]) . '</span>
                    </td>
                    <td>
                        <div class="refund-static__val no-wrap">
                            <a class="refund-download-link" download="" href="?action=download&id=' . $file['EXTERNAL_ID'] . '">
                                <img src="' . SITE_TEMPLATE_PATH . '/img/svg/download-ico.svg" alt="">
                                <span class="refund-download-link__text">Скачать</span>
                            </a>
                        </div>
                    </td>
                </tr>';
        }

        $html .= '</table>

            <div class="refund-modal-foot refund-modal-foot--left">
                <a class="btn btn__blue btn__big" href="?action=downloadAll&id=' . $requestID . '" download="">Скачать все файлы</a>
            </div>

        </div>';
        echo $html;
        die;
    }

    private function getLayoutFullyRefund(int|array $requestID): void
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();

        if (is_array($requestID)) {
            $refundRequest = $this->getRefundInfo($requestID, true) ?? [];
            $paramIdString = '';
            foreach ($requestID as $id) {
                if (strlen($paramIdString) < 1) $paramIdString .= '?id[]=' . $id;
                else $paramIdString .= '&id[]=' . $id;
            }
        } else {
            $refundRequest = $this->getRefundInfo($requestID)[0] ?? [];
            $paramIdString = '?id=' . $requestID;
        }
        if (count($refundRequest) < 1) $this->showError('Заявка не найдена');

        $html = '<div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            <form action="' . $APPLICATION->GetCurPage() . $paramIdString . '" method="post" class="">
                ' . bitrix_sessid_post() . '
                <input type="hidden" name="type" value="F">
                <input type="hidden" name="action" value="refund">
                <div class="popup-transfer__name refund-title h1">Полный возврат</div>

                <table class="refund-static">';
        if (is_array($requestID) && count($requestID) > 1) $sumTitle = 'Сумма заказов';
        else $sumTitle = 'Сумма заказа';

        if (!is_array($requestID)) {
            $html .= '<tr>
                    <td>Номер заказа</td>
                    <td>
                        <div class="refund-static__val no-wrap">' . $refundRequest['ORDER_NUM'] . '</div>
                    </td>
                    </tr>';
        }

        $html .= '<tr>
                    <td>' . $sumTitle . '</td>
                    <td>
                        <div class="refund-static__val no-wrap">' . floatval($refundRequest['REQUEST_SUM']) . ' ₽</div>
                    </td>
                </tr>
                <tr>
                    <td>Сумма возврата</td>
                    <td>
                        <div class="refund-static__val no-wrap">' . floatval($refundRequest['REQUEST_SUM']) . ' ₽</div>
                    </td>
                </tr>
            </table>

                <div class="refund-modal-foot">
                <a class="btn btn__clean btn__big" data-close href="#" type="button">Отмена</a>
                <button class="btn btn__blue btn__big js-ajax-form-submit-btn" data-need-reload=".events__table" type="button">Подтвердить</button>
                </div>
            </form>
        </div>';

        echo $html;
        die;
    }

    private function getLayoutPartialRefund(int|array $requestID): void
    {

        global $APPLICATION;
        $APPLICATION->RestartBuffer();

        $refundRequest = $this->getRefundInfo($requestID)[0] ?? [];

        if (count($refundRequest) < 1) $this->showError('Заявка не найдена');

        $html = '<div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            
            <div class="popup-transfer__name refund-title h1">Частичный возврат</div>

            <form action="' . $APPLICATION->GetCurPage() . '?id=' . $requestID . '" method="post" class="js-form-validate">
                ' . bitrix_sessid_post() . '
                <input type="hidden" name="type" value="P">
                <input type="hidden" name="action" value="refund">
                <input class="js-refund-order-sum" type="hidden" value="' . floatval($refundRequest['REQUEST_SUM']) . '">
                <table class="refund-static">
                    <tr>
                        <td>Номер заказа</td>
                        <td>
                            <div class="refund-static__val no-wrap">' . $refundRequest['ORDER_NUM'] . '</div>
                        </td>
                    </tr>
                    <tr>
                        <td>Сумма заказа</td>
                        <td>
                            <div class="refund-static__val no-wrap">' . floatval($refundRequest['REQUEST_SUM']) . ' ₽</div>
                        </td>
                    </tr>
                    <tr>
                        <td>Лицензионное вознаграждение</td>
                        <td>
                            <div class="refund-static__val no-wrap">' . floatval($refundRequest['COMMISSION']) . ' ₽</div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>Сумма возврата</p>
                            <div class="refund-static-type">
                                <label>
                                    <input checked name="refund-static-type" type="radio" value="percent"> <span
                                            class="refund-static-type__itm">%</span>
                                </label>
                                <label>
                                    <input name="refund-static-type" type="radio" value="ruble"> <span
                                            class="refund-static-type__itm">₽</span>
                                </label>
                            </div>
                        </td>
                        <td>
                            <div class="refund-static__val no-wrap required">
                                <div class="refund-static-val">
                                    <input class="js-refund-result-input" name="amount" type="number">
                                    <div class="refund-static-val__ico">%</div>
                                    <div class="form-item__label" hidden="">Сумма возврата</div>
                                </div>
                            </div>
                        </td>
                    </tr>


                    <tr data-type-show="percent">
                        <td>Итого</td>
                        <td>
                            <div class="refund-static__val no-wrap js-percent-total-result">0,00 ₽</div>
                        </td>
                    </tr>
                </table>

                <div class="refund-modal-foot">
                    <a class="btn btn__clean btn__big" data-close href="#" type="button">Отмена</a>
                    <button class="btn btn__blue btn__big js-form-validate-btn js-ajax-form-submit-btn" data-need-reload=".events__table" type="button">Подтвердить
                    </button>
                </div>
            </form>
        </div>';
        echo $html;
        die;
    }

    private function getLayoutCommissionRefund(int|array $requestID): void
    {

        global $APPLICATION;
        $APPLICATION->RestartBuffer();

        if (is_array($requestID)) {
            $refundRequest = $this->getRefundInfo($requestID, true) ?? [];
            $paramIdString = '';
            foreach ($requestID as $id) {
                if (strlen($paramIdString) < 1) $paramIdString .= '?id[]=' . $id;
                else $paramIdString .= '&id[]=' . $id;
            }
        } else {
            $refundRequest = $this->getRefundInfo($requestID)[0] ?? [];
            $paramIdString = '?id=' . $requestID;
        }

        if (count($refundRequest) < 1) $this->showError('Заявка не найдена');

        $html = '<div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            <form action="' . $APPLICATION->GetCurPage() . $paramIdString . '" method="post" class="">
            ' . bitrix_sessid_post() . '
            <input type="hidden" name="type" value="C">
                <input type="hidden" name="action" value="refund">
            <div class="popup-transfer__name refund-title h1">Возврат за вычетом комиссии</div>

            <table class="refund-static">';
        if (is_array($requestID) && count($requestID) > 1) $sumTitle = 'Сумма заказов';
        else $sumTitle = 'Сумма заказа';

        if (!is_array($requestID)) {
            $html .= '<tr>
                    <td>Номер заказа</td>
                    <td>
                        <div class="refund-static__val no-wrap">' . $refundRequest['ORDER_NUM'] . '</div>
                    </td>
                    </tr>';
        }

        $html .= '<tr>
                    <td>' . $sumTitle . '</td>
                    <td>
                        <div class="refund-static__val no-wrap">' . floatval($refundRequest['REQUEST_SUM']) . ' ₽</div>
                    </td>
                </tr>
                <tr>
                    <td>Лицензионное вознаграждение</td>
                    <td>
                        <div class="refund-static__val no-wrap">' . floatval($refundRequest['COMMISSION']) . ' ₽</div>
                    </td>
                </tr>
                <tr>
                    <td>Сумма возврата</td>
                    <td>
                        <div class="refund-static__val no-wrap">' . (floatval($refundRequest['REQUEST_SUM']) - floatval($refundRequest['COMMISSION'])) . ' ₽</div>
                    </td>
                </tr>
            </table>

            <div class="refund-modal-foot">
                <a class="btn btn__clean btn__big" data-close href="#" type="button">Отмена</a>
                <button class="btn btn__blue btn__big js-ajax-form-submit-btn" data-need-reload=".events__table" type="button">Подтвердить</button>
            </div>
            </form>
        </div>';

        echo $html;
        die;
    }

    private function getLayoutRejectRefund(int|array $requestID): void
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        if (is_array($requestID)) {
            $refundRequest = $this->getRefundInfo($requestID, true) ?? [];
            $paramIdString = '';
            foreach ($requestID as $id) {
                if (strlen($paramIdString) < 1) $paramIdString .= '?id[]=' . $id;
                else $paramIdString .= '&id[]=' . $id;
            }
        } else {
            $refundRequest = $this->getRefundInfo($requestID)[0] ?? [];
            $paramIdString = '?id=' . $requestID;
        }

        $reasons = $this->getReasonsForRefusal();

        if (count($refundRequest) < 1) $this->showError('Заявка не найдена');
        $html = '<div class="popup__content gap-0 popup-transfer js-form-validate refund-popup">
            <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i>
            </button>
            <form action="' . $APPLICATION->GetCurPage() . $paramIdString . '" method="post" class="js-form-validate">
            ' . bitrix_sessid_post() . '
            <input type="hidden" name="type" value="R">
            <input type="hidden" name="action" value="refund">
            <div class="popup-transfer__name refund-title h1">Отказ в возврате</div>

            
                <table class="refund-static">';
        if (is_array($requestID) && count($requestID) > 1) $sumTitle = 'Сумма заказов';
        else $sumTitle = 'Сумма заказа';

        if (!is_array($requestID)) {
            $html .= '<tr>
                    <td>Номер заказа</td>
                    <td>
                        <div class="refund-static__val no-wrap">' . $refundRequest['ORDER_NUM'] . '</div>
                    </td>
                    </tr>';
        }

        $html .= '<tr>
                    <td>' . $sumTitle . '</td>
                        <td>
                            <div class="refund-static__val no-wrap">' . floatval($refundRequest['REQUEST_SUM']) . ' ₽</div>
                        </td>
                    </tr>
                </table>


                <div class="form-select js-form-select form-item-round form-item-margin required">
					<label class="form-item__label" hidden="">Причина отказа</label>
                    <div class="form-select__selected-option js-form-select-option js-option-change"
                         data-placeholder="Выберите причину отказа">Выберите причину отказа
                    </div>
                    <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                    <div class="form-select-options-wrap js-form-select-options-wrap">
                        <ul class="form-select-options form-select__options">';

        foreach ($reasons as $item) {
            $html .= '<li class="form-select-options__item js-form-select-options-item" data-option="' . $item['ENUM_ID'] . '">' . $item['ENUM_NAME'] . '</li>';
        }


        $html .= '</ul>
                    </div>
                    <input type="hidden" name="reason" value="">
                </div>

                <div class="form-item">
                    <label class="form-item__label" hidden="">Комментарий</label>
                    <span class="form__error"></span> <input class="form__round-input" name="reason_comment" placeholder="Комментарий"
                                                             type="text" value=""/>
                </div>

                <div class="refund-modal-foot">
                    <a class="btn btn__clean btn__big" data-close href="#" type="button">Отмена</a>
                    <button class="btn btn__blue btn__big js-form-validate-btn js-ajax-form-submit-btn" data-need-reload=".events__table" href="" type="button">Подтвердить
                    </button>
                </div>
            </form>
        </div>';
        echo $html;
        die;
    }

    private function getTicketTypeEntity()
    {
        $offerEntity         = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $propFieldType       = $offerEntity->getField('TYPE');
        $propFieldTypeEntity = $propFieldType->getRefEntity();

        return $propFieldTypeEntity;
    }

    private function getB24CompanyInfo(int $companyID): array
    {
        $query = new ORM\Query\Query('Custom\Core\Users\CompaniesTable');
        $res   = $query
            ->setSelect(['UF_XML_ID', 'UF_B24_DEAL_ID'])
            ->setFilter(['ID' => $companyID])
            ->exec();
        return $res->fetch();
    }

    private function sendB24Refund(array $refund, float $sum, string $refundType): int
    {
        $arTypes      = [
            'F' => 'full',
            'P' => 'partial',
            'C' => 'commission',
        ];

        $arCompany = $this->getB24CompanyInfo($this->companyID);
        $refundFields = self::getRefund($refund['ID']);
        $ticketsInfo  = self::getTicketNumbersByBarcodeIds($refund['BARCODES']);
        $eventName    = self::getEventNameById($ticketsInfo['EVENT_ID']);

        $order = \Bitrix\Sale\Order::load($refund['ORDER_ID']);

        $b24Fields = [
            "client_id"                  => $arCompany['UF_XML_ID'], // ID компании клиента
            "order_number"               => $refund['ORDER_NUM'], // Номер заказа
            "number_of_tickets"          => $refund['TICKETS_QTY'], // Количество билетов к возврату
            "refunded_amount"            => $sum, // Сумма к возврату
            "event_name"                 => $eventName, // Наименование мероприятия
            "tickets_series_and_numbers" => $ticketsInfo['TICKET_NUMBERS'], // Серия и номер билетов на возврат
            "client_FIO"                 => $refundFields['UF_FULL_NAME'], // ФИО клиента
            "client_phone"               => $refundFields['UF_PHONE'], // Телефон клиента
            "client_email"               => $refundFields['UF_EMAIL'], // Почта клиента
            "refund_reason"              => $refundFields['UF_REASON_FOR_RETURN'], // Причина возврата
            "refund_type"                => $arTypes[$refundType] // Тип одобренного возврата 693-Полный, 694-Частичный
        ];

        $personTypeId = $order->getField('PERSON_TYPE_ID');

        //Если возврат для ЮР оплат
        if ($personTypeId == self::LEGAL_PERSON_TYPE_ID) {
            $propCollection = $order->getPropertyCollection();

            $b24Fields["payment_type"]   = "по счету"; //Тип оплаты
            $b24Fields["org_name"]       = $propCollection->getItemByOrderPropertyCode('COMPANY')->getValue(); //Наименование покупателя
            $b24Fields["inn"]            = $propCollection->getItemByOrderPropertyCode('INN')->getValue(); //ИНН Покупателя
            $b24Fields["invoice_number"] = $refund['ORDER_NUM']; // Номер счета-договора
            $b24Fields["invoice_date"]   = $order->getField('DATE_INSERT'); //Дата счета-договора
        }

        $res       = CRest::call(
            'crm.vozvrat.add',
            $b24Fields,
        );

        return (int)$res['result']['item']['id'];
    }

    /*
     * F - Полный возврат
     * P - Частичный возврат
     * I - Самостоятельный возврат
     * С - Возврат за вычетом комиссии
     * R - Отказ в возврате
     * */
    private function getForm(string $formXmlID): void
    {
        switch ($formXmlID) {
            case 'F':
                $this->getLayoutFullyRefund($this->request['id']);
                break;
            case 'P':
                $this->getLayoutPartialRefund($this->request['id']);
                break;
            case 'I':
                //$this->getLayoutFilesList($this->request['id']);
                break;
            case 'C':
                $this->getLayoutCommissionRefund($this->request['id']);
                break;
            case 'R':
                $this->getLayoutRejectRefund($this->request['id']);
                break;
        }
    }

    private function approveRefund(int|array $requestID): void
    {

        $arRefunds      = $this->getRefundInfo($requestID) ?? [];
        $successMessage = $this->getRefundSuccessMessage($requestID);
        $balance        = floatval(\Custom\Core\BalanceHistory::getBalanceForCompany($this->companyID));
        if (count($arRefunds) < 1) $this->showError('Заявки не найдены');
        if (!key_exists($this->request['type'], $this->refundsTypes)) $this->showError('Тип возврата не найден');
        if (!check_bitrix_sessid()) $this->showError('Сессия истекла');

        $statusID = $this->getStatusIDByRefundType($this->request['type']);

        foreach ($arRefunds as $refund) {
            !empty($refund['BARCODES']) ?
                $refund['BARCODES'] = explode(',', $refund['BARCODES']) :
                $refund['BARCODES'] = [];

            $refundID = $refund['ID'];

            if ($this->request['type'] == 'P' && $this->request['refund-static-type'] == 'ruble') {
                $refund['REQUEST_SUM'] = $this->request['amount'];
            }

            if ($this->request['type'] == 'P' && $this->request['refund-static-type'] == 'percent') {
                $refund['REQUEST_SUM'] = $refund['REQUEST_SUM'] * ($this->request['amount'] / 100);
            }

            $arData                     = [];
            $arData['UF_REVIEW_STATUS'] = $statusID;

            if (in_array($this->request['type'], ['F', 'C', 'P'])) {
                if ($this->request['type'] == 'F') $arData['UF_ACTUAL_REFUND_SUM'] = $refund['REQUEST_SUM'];
                if ($this->request['type'] == 'C') $arData['UF_ACTUAL_REFUND_SUM'] = $refund['REFUND_SUM'];
                if ($this->request['type'] == 'P') $arData['UF_ACTUAL_REFUND_SUM'] = $refund['REQUEST_SUM'];
                if ($balance < $arData['UF_ACTUAL_REFUND_SUM']) $this->showError('Недостаточно средств на балансе');
                $resUpdateBalance = $this->setBalanceHistory($arData['UF_ACTUAL_REFUND_SUM'], $balance, $refundID);
                if (!$resUpdateBalance) $this->showError('Ошибка обновления истории баланса');

                $balance -= $arData['UF_ACTUAL_REFUND_SUM'];

                $this->setReturnedBarcode($refund['BARCODES']);

                $arData['UF_XML_ID'] = $this->sendB24Refund(
                    $refund,
                    $arData['UF_ACTUAL_REFUND_SUM'],
                    $this->request['type']
                );
            }

            if ($this->request['type'] == 'R') {
                $otherProp = $this->getPropertiesEnum('TicketRefundRequests', 'UF_REASON_FOR_REFUSAL', 'other');
                if (empty($this->request['reason_comment']) && $otherProp == $this->request['reason']) $this->showError('Заполните поле "Комментарий"');

                $arData['UF_REASON_FOR_REFUSAL']      = $this->request['reason'];
                $arData['UF_COMMENT_ABOUT_REJECTION'] = $this->request['reason_comment'];
            }
            if ($this->request['type'] == 'I') {
                $arData['UF_ACTUAL_REFUND_SUM'] = $refund['REQUEST_SUM'];
            }

            $requestEntity   = HL\HighloadBlockTable::compileEntity('TicketRefundRequests');
            $hlbClassRequest = $requestEntity->getDataClass();
            $result          = $hlbClassRequest::update($refundID, $arData);

            if (!$result->isSuccess()) $this->showError($result->getErrorMessages());
        }

        $this->showSuccess($successMessage);
    }

    private function getStatusIDByRefundType(string $type): int
    {
        $statusID = 0;
        foreach ($this->arResult['REVIEW_STATUS_LIST'] as $status) {
            if (
                ($this->request['type'] == 'F') && $status['ENUM_XML_ID'] == 'fully'
            ) {
                return $statusID = (int)$status['ENUM_ID'];
            }
            if ($this->request['type'] == 'C' && $status['ENUM_XML_ID'] == 'commission') {
                return $statusID = (int)$status['ENUM_ID'];
            }
            if ($this->request['type'] == 'P' && $status['ENUM_XML_ID'] == 'partial') {
                return $statusID = (int)$status['ENUM_ID'];
            }
            if ($this->request['type'] == 'I' && $status['ENUM_XML_ID'] == 'independently') {
                return $statusID = (int)$status['ENUM_ID'];
            }
            if ($this->request['type'] == 'R' && $status['ENUM_XML_ID'] == 'reject') {
                return $statusID = (int)$status['ENUM_ID'];
            }
        }
        return $statusID;
    }

    private function getRefundSuccessMessage(int|array $requestID): string
    {
        if (is_array($requestID) && count($requestID) > 1) $successMessage = 'Заявки успешно обработаны';
        else $successMessage = 'Заявка успешно обработана';
        if ($this->request['type'] == 'R') $successMessage = 'Вся юридическая ответственность за отказ в возврате лежит на организаторе';
        if ($this->request['type'] == 'I') $successMessage = 'Просим руководствоваться действующим законодательством и связаться с покупателем в течение 10 дней';
        return $successMessage;
    }

    private function setBalanceHistory(float $refundSum, float $actualBalance, int $requestID)
    {
        $balanceEntity   = HL\HighloadBlockTable::compileEntity('BalanceHistory');
        $hlbClassBalance = $balanceEntity->getDataClass();

        $balance = $hlbClassBalance::getList(
            [
                'filter' => [
                    'UF_COMPANY_ID' => $this->companyID,
                    'UF_REFUND_ID'  => $requestID
                ],
                'limit'  => 1,
                'order'  => ['ID' => 'DESC'],
            ]
        )->fetch();

        if ($balance['ID'] > 0) return false;

        $type        = (int)$this->getPropertiesEnum('BalanceHistory', 'UF_TYPE', 'down');
        $description = (int)$this->getPropertiesEnum('BalanceHistory', 'UF_DESCRIPTION', 'refund');

        $resAdd = $hlbClassBalance::add(
            [
                'UF_COMPANY_ID'  => $this->companyID,
                'UF_TYPE'        => $type,
                'UF_VALUE'       => $refundSum,
                'UF_BALANCE'     => $actualBalance - $refundSum,
                'UF_REFUND_ID'   => $requestID,
                'UF_DESCRIPTION' => $description
            ]
        );

        return $resAdd->isSuccess();
    }

    private function setReturnedBarcode(array $barcodesIds): void
    {
        $statusID = $this->getPropertiesEnum('Barcodes', 'UF_STATUS', 'returned');

        $barcodesEntity   = HL\HighloadBlockTable::compileEntity('Barcodes');
        $hlbClassBarcodes = $barcodesEntity->getDataClass();

        $objBarcodes = $hlbClassBarcodes::getList(
            ['filter' => ['ID' => $barcodesIds], 'count_total' => true]
        );

        if ($objBarcodes->getCount() > 0) {
            while ($barcode = $objBarcodes->fetchObject()) {
                $barcode->set('UF_STATUS', $statusID);
                $resUpdate = $barcode->save();
            }
        }
    }

    private function getEventNameById(int $eventID): string
    {
        $eventEntity   = HL\HighloadBlockTable::compileEntity('Events');
        $hlbClassEvent = $eventEntity->getDataClass();

        $event = $hlbClassEvent::getList(

            ['select' => ['UF_NAME'], 'filter' => ['ID' => $eventID]]

        )->fetch();

        return $event['UF_NAME'];
    }

    private function getTicketNumbersByBarcodeIds(array $barcodesIds): array
    {

        $barcodesEntity   = HL\HighloadBlockTable::compileEntity('Barcodes');
        $hlbClassBarcodes = $barcodesEntity->getDataClass();
        $resBarcodes      = [];
        $objBarcodes      = $hlbClassBarcodes::getList(
            ['filter' => ['ID' => $barcodesIds]]
        );
        while ($row = $objBarcodes->fetch()) {
            $resBarcodes['EVENT_ID']         = $row['UF_EVENT_ID'];
            $resBarcodes['TICKET_NUMBERS'][] = $row['UF_SERIES'] . '-' . $row['UF_TICKET_NUM'];
        }
        return $resBarcodes;
    }

    private function getRefund($id)
    {

        $query = new ORM\Query\Query('Custom\Core\Tickets\TicketRefundRequestsTable');

        $resRequest = $query
            ->setSelect(
                [
                    'ID',
                    'UF_FULL_NAME',
                    'UF_EMAIL',
                    'UF_PHONE',
                    'UF_REASON_FOR_RETURN',
                ]
            )
            ->setFilter(
                [
                    'ID'            => $id,
                    'UF_COMPANY_ID' => $this->companyID,
                ]
            )
            ->countTotal(true)
            ->exec();
        $result     = $resRequest->fetch();
        if (!empty($result)) {
            $result['UF_REASON_FOR_RETURN'] = $this->arResult['REASONS_LIST'][$result['UF_REASON_FOR_RETURN']]['ENUM_NAME'];
        }
        return $result;
    }
}