<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Custom\Core\Products;
use Custom\Core\PriceRules;
use \Bitrix\Main\Localization\Loc;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest()->toArray();;
$files = $context->getRequest()->getFileList()->toArray();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
$actId = $request['id'];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core')
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    if (
        isset($request['action']) &&
        $request['action'] == 'send'
    )
    {
        $APPLICATION->RestartBuffer();

        $obAct = \Custom\Core\Users\ActsTable::getList([
            "filter" => ["UF_XML_ID" => $request['id']],
            "select" => ["ID", "UF_STATUS"]
        ]);

        if($act = $obAct->fetch())
        {
            if($files && $files["file"]["tmp_name"])
            {
                $Questionnaires = new \Custom\Core\Questionnaires();
                $includeSystem = $Questionnaires->extensions;
                $maxSize = $Questionnaires->fileSize;

                if (
                    !in_array(strtolower(pathinfo($files["file"]["name"], PATHINFO_EXTENSION)), $includeSystem)
                    || $files["file"]["size"] > $maxSize
                ) {
                    throw new \Exception("Загрузка файла {$files["file"]["name"]} запрещена.");
                }
            }

            $arData["UF_STATUS"] = \Custom\Core\Contract::getHLfileldEnumId(
                \Custom\Core\Act::HL_NAME,
                \Custom\Core\Act::ACT_STATUS_XMLID,
                "adjustment"
            );

            \Custom\Core\Act::sendActMessage([
                "id" => $request["id"],
                "fields" => [
                    "ufCrm6_1737023133875" => $request["user_xml_id"],
                    "ufCrm6_1732694922" => $request["message"],
                    "ufCrm6_1732868727" => \Custom\Core\Act::ACT_VERIF["N"],
                    'ufCrm6_1736770311803' => [
                        '0' => [
                            $files["file"]["name"],
                            base64_encode(file_get_contents($files["file"]["tmp_name"]))
                        ]
                    ]
                ]
            ]);

            $resUpdate = \Custom\Core\Users\ActsTable::update($act['ID'], $arData);

            if (!$resUpdate->isSuccess())
            {
                echo json_encode(['status' => 'error', 'message' => str_replace("<br>", "\n", implode(', ', $resUpdate->getErrors()))], JSON_UNESCAPED_UNICODE);
            }
        }

        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die();
    }

    if($companyID && $actId)
    {
        $query = new ORM\Query\Query('\Custom\Core\Users\ActsTable');
        $resAct   = $query
            ->setFilter(['ID' => $actId, 'UF_COMPANY' => $companyID])
            ->setSelect([
                'ID', 'UF_XML_ID', 'COMPANY_ID' => 'COMPANY.ID', 'COMPANY_XML_ID' => 'COMPANY.UF_XML_ID', 'UF_CONTRACT_NUMBER' => 'COMPANY.UF_CONTRACT_NUMBER'
            ])
            ->registerRuntimeField(
                'COMPANY',
                array(
                    'data_type' => '\Custom\Core\Users\CompaniesTable',
                    'reference' => array('=this.UF_COMPANY' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->setLimit(1)
            ->exec();
        if($act = $resAct->fetch()){
            $query = new ORM\Query\Query('\Bitrix\Main\UserTable');

            $resUser = $query
                ->setFilter(['ID' => \Bitrix\Main\Engine\CurrentUser::get()->getId()])
                ->setSelect([
                    'EMAIL',
                    'LAST_NAME',
                    'NAME',
                    'SECOND_NAME',
                    'PERSONAL_PHONE_AUTH' => 'PHONE_AUTH.PHONE_NUMBER',
                    'UF_B24_CONTACT_ID'
                ])
                ->registerRuntimeField(
                    'PHONE_AUTH',
                    array(
                        'data_type' => '\Bitrix\Main\UserPhoneAuthTable',
                        'reference' => array('=this.ID' => 'ref.USER_ID'),
                        'join_type' => 'LEFT'
                    )
                )
                ->setLimit(1)
                ->exec();
            if($user = $resUser->fetch())
            {
                $user["FULL_NAME"] = implode(" ", [$user["LAST_NAME"], $user["NAME"], $user["SECOND_NAME"]]);
                $act["USER"] = $user;
            }

            $this->arResult = $act;
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => "Акт не найден"], JSON_UNESCAPED_UNICODE);
            die;
        }


    }
    else
    {
        echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_NO_COMPANY_FOR_USER")], JSON_UNESCAPED_UNICODE);
        die;
    }



    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}

?>