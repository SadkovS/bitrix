<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>


<div class="popup__content">
    <button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i></button>
    <h2 class="h2 mb-3">Скорректировать</h2>
    <form action="<?=$arParams["SEF_FOLDER"]?>/act.message.form.php?action=send" class="">
        <input name="id" value="<?=$arResult["UF_XML_ID"]?>" style="display: none;">
        <input name="user_xml_id" value="<?=$arResult["USER"]["UF_B24_CONTACT_ID"]?>" style="display: none;">
        <div class="grey__body-small row gy-3">
            <div class="col-6">
                <div class="form-item disabled">
                    <label class="form-item__label">ФИО</label>
                    <span class="form__error"></span>
                    <input class="form__underline-input" placeholder="Имя" readonly type="text" value="<?=$arResult["USER"]["FULL_NAME"]?>" />
                </div>
            </div>
            <div class="col-6">
                <div class="form-item disabled">
                    <label class="form-item__label">E-mail</label>
                    <span class="form__error"></span>
                    <input class="form__underline-input" placeholder="E-mail" readonly type="email" value="<?=$arResult["USER"]["EMAIL"]?>" />
                </div>
            </div>
            <div class="col-6">
                <div class="form-item disabled">
                    <label class="form-item__label">Номер телефона</label>
                    <span class="form__error"></span>
                    <input class="form__underline-input" readonly type="tel" value="<?=$arResult["USER"]["PERSONAL_PHONE_AUTH"]?>" />
                </div>
            </div>
            <div class="col-6">
                <div class="form-item disabled">
                    <label class="form-item__label">Номер договора</label>
                    <span class="form__error"></span>
                    <input class="form__underline-input" readonly type="text" value="<?=$arResult["COMPANY_XML_ID"]?>" />
                </div>
            </div>

            <div class="col-12">
                <label class="form-item__label">Сообщение</label>

                <div class="form-item textarea-white">
                    <textarea name="message" class="" data-textarea-auto-height placeholder="" maxlength="1000"></textarea>
                </div>
            </div>

            <div class="col-12">
                <div class="form-item">
                    <label class="form-item__label">Прикрепить файл</label>
                    <div class="upload upload-border upload__clean" data-img-upload>
                        <input name="file" accept=".pdf, .xls, .xlsx, .xlsm, .csv, .jpg, .jpeg, .heic, .png" class="upload__input" data-file-size="5" type="file">
                        <div class="upload__icon upload-ibg_contain">
                            <button class="upload__delete" type="button">
                                <i class="_icon-trash2"></i>
                            </button>
                            <i class="_icon-upload"></i>
                        </div>
                        <div class="upload__info">
                            <small>Рекомендуемый размер — не более 5 Мб<br> Поддерживаются форматы PDF, XLS, XLSX, XLSM, CSV, JPG, JPEG, HEIC и PNG<br> Перетащите файл на рамку или нажмите для обзора
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="popup-action-foot">
            <button class="btn btn__blue btn__big btn__fix-width btn_act_add_message" type="button">Отправить</button>
        </div>

    </form>
</div>