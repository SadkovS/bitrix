<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentParameters = [
    'PARAMETERS' => [
        'VIEWER_ID' => [
            "NAME"    => GetMessage("FILEMAN_PDFVIEWER_PARAMETER_VIEWER_ID"),
            "DEFAULT" => "",
        ],
    ]
];