<?php

use Bitrix\Highloadblock as HL;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

Loader::includeModule('custom.core');
Loader::includeModule('highloadblock');
Loader::includeModule('sale');
Loader::includeModule('iblock');
Loader::includeModule("catalog");

Loc::loadMessages(__FILE__);

class RefundFormComponent extends \CBitrixComponent {

    public function __construct($component = null)
    {
        parent::__construct($component);
        $this->arResult['REASONS_LIST'] = self::getReasonsForRefund();
        if ($this->request->isPost() && $this->request['action'] == 'refund' && !check_bitrix_sessid())
            $this->showError(Loc::getMessage('REFUND_FORM_WRONG_SESSION'));
    }

    public function executeComponent()
    {
        if ($this->request['success'] == 'Y') {
            $this->includeComponentTemplate();
            return false;
        }

        // Сначала получаем базовые данные заказа
        $filter = [
            "PAYED"                     => "Y",
            "PROPERTY_ORDER_UUID.CODE"  => "UUID",
            "PROPERTY_ORDER_UUID.VALUE" => $this->arParams["ORDER_UUID"],
            "PROPERTY_ORGANIZER.CODE"   => 'ORGANIZER_ID',
            "PROPERTY_EVENT_ID.CODE"    => "EVENT_ID",
            "PROPERTY_ORDER_FIO.CODE"   => "FIO",
        ];

        $dbRes = \Bitrix\Sale\Order::getList(
            [
                'select'  => [
                    'ID',
                    'ACCOUNT_NUMBER',
                    'PRICE',
                    'PAYED',
                    'ORGANIZER_ID' => 'PROPERTY_ORGANIZER.VALUE',
                    'EVENT_ID'     => 'PROPERTY_EVENT_ID.VALUE',
                    'EVENT_NAME'   => 'EVENT.UF_NAME',
                    'IMG_SRC',
                    'FIO'          => 'PROPERTY_ORDER_FIO.VALUE'
                ],
                'filter'  => $filter,
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_EVENT_ID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORDER_UUID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORDER_FIO',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'EVENT',
                        'Custom\Core\Events\EventsTable',
                        ['=this.EVENT_ID' => 'ref.ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PICTURE',
                        '\Bitrix\Main\FileTable',
                        ['this.EVENT.UF_IMG' => 'ref.ID'],
                        ['join_type' => 'LEFT']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'IMG_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['PICTURE.SUBDIR', 'PICTURE.FILE_NAME']
                    )
                ]
            ]
        );

        if ($orderData = $dbRes->fetch()) {
            // Получаем товары из корзины
            $basketItems = $this->getBasketItems($orderData['ID']);

            // Получаем свойства корзины одним запросом
            $basketProperties = $this->getBasketProperties(array_keys($basketItems));

            // Получаем данные о возвратах
            $refundData = $this->getRefundData(array_keys($basketItems));

            // Собираем результат
            foreach ($basketItems as $basketId => $basketItem) {
                $item = array_merge(
                    $orderData, [
                                  'BASKET_ITEM_ID' => $basketId,
                                  'TICKET_PRICE'   => $basketItem['PRICE'],
                                  'OFFER_ID'       => $basketItem['PRODUCT_ID']
                              ]
                );

                // Добавляем свойства корзины
                if (isset($basketProperties[$basketId])) {
                    $props                     = $basketProperties[$basketId];
                    $item['TICKET_UUID']       = $props['UUID'] ?? '';
                    $item['TICKET_ROW']        = $props['ROW'] ?? '';
                    $item['TICKET_PLACE']      = $props['PLACE'] ?? '';
                    $item['TICKET_SECTOR']     = $props['SECTOR'] ?? '';
                    $item['TICKET_BARCODE_ID'] = $props['BARCODE'] ?? '';
                }

                // Добавляем данные о возврате
                $item['HAS_REFUND'] = isset($refundData[$basketId]);

                $this->arResult['ITEMS'][] = $item;
            }
        }

        if (empty($this->arResult['ITEMS'])) {
            \Bitrix\Iblock\Component\Tools::process404(
                  ""
                , false
                , true
                , true
            );
        }

        //TICKETS
        $offersIDs     = array_column($this->arResult['ITEMS'], 'OFFER_ID');
        $arTicketDates = $this->getTicketInfo($offersIDs);

        //LOCATIONS
        $eventID     = $this->arResult['ITEMS'][0]['EVENT_ID'];
        $arLocations = $this->getLocations($eventID);
        $arDates     = [];
        foreach ($arLocations as $location) {
            $arDates = array_merge($arDates, $location['UF_DATE_TIME']);
        }

        // Текущая дата и время
        $currentDateTime = new DateTime();

        //QUESTIONNAIRE
        $orderID        = $this->arResult['ITEMS'][0]['ID'];
        $questionnaires = $this->getQuestionnaires($orderID);

        $barcodeIds = array_column($this->arResult['ITEMS'], 'TICKET_BARCODE_ID') ?? [];
        if (!empty($barcodeIds)) {
            $barcodeIds = $this->checkSKDHistory($barcodeIds);
        }

        $allTicketsUsed              = true;
        $allTicketsDateExpired       = true;

        foreach ($this->arResult['ITEMS'] as $key => &$item) {
            // Определяем даты-времена для билета
            $ticketDateTimes = $arDates; // По умолчанию все даты события

            if (!empty($arTicketDates[$item['OFFER_ID']]['PROP_DATES'])) {
                // Если у билета есть ограничения по датам, фильтруем $arDates
                $propDates       = $arTicketDates[$item['OFFER_ID']]['PROP_DATES'];
                $ticketDateTimes = [];

                foreach ($arDates as $dateTime) {
                    $date = date('Y-m-d', strtotime($dateTime));

                    // Проверяем, есть ли эта дата в ограничениях билета
                    foreach ($propDates as $propDate) {
                        $propDateFormatted = date('Y-m-d', strtotime($propDate));
                        if ($date === $propDateFormatted) {
                            $ticketDateTimes[] = $dateTime;
                            break;
                        }
                    }
                }
            }

            // Находим минимальную дату-время билета
            $minTicketDateTime = null;
            if (!empty($ticketDateTimes)) {
                $minTicketDateTime = min($ticketDateTimes);
                $minTicketDateTime = new DateTime($minTicketDateTime);
            }

            // Определяем возможность возврата
            $refundExists            = $this->checkRefundsExist([$item['BASKET_ITEM_ID']]);
            $dateRestriction         = $minTicketDateTime && $minTicketDateTime < $currentDateTime;
            $ticketUsed              = in_array($item['TICKET_BARCODE_ID'], $barcodeIds);
            
            $item['REFUND_DESCRIPTION'] = '';
            $item['REFUND_DISABLED'] = $refundExists || $dateRestriction || $ticketUsed;

            // Проверяем для общих флагов
            if (!$ticketUsed) {
                $allTicketsUsed = false;
            }
            if (!$dateRestriction) {
                $allTicketsDateExpired = false;
            }

            $item['TICKET_TYPE'] = $arTicketDates[$item['OFFER_ID']]['PROP_TYPE'];
            $item['DATES']           = $this->getFormatedDates($ticketDateTimes);
            $item['ADDRESS']         = $arLocations[0]['UF_ADDRESS'];
            $item['ROOM']            = $arLocations[0]['ROOM'];

            if ($refundExists) $item['REFUND_DESCRIPTION'] = 'Возврат уже оформлен';
            elseif ($ticketUsed) $item['REFUND_DESCRIPTION'] = 'Данный билет уже был использован';
            elseif ($dateRestriction) $item['REFUND_DESCRIPTION'] = 'Мероприятие уже началось и данный билет не подлежит возврату';

            foreach ($questionnaires as $questionnaire) {
                if (in_array($item['BASKET_ITEM_ID'], $questionnaire['UF_TICKET'])) $item['FIO'] = $questionnaire['UF_FULL_NAME'];
            }
        }

        // Устанавливаем флаги для шаблона
        $this->arResult['ALL_TICKETS_USED']         = $allTicketsUsed;
        $this->arResult['ALL_TICKETS_DATE_EXPIRED'] = $allTicketsDateExpired && !$allTicketsUsed;

        if ($this->request->isPost() && $this->request['action'] == 'refund') self::saveRequest($this->arResult);
        $this->includeComponentTemplate();
    }

    private function checkSKDHistory(array $barcodeIds): array
    {
        $result = [];
        $query  = Custom\Core\Skd\HistorySKDTable::getList(
            [
                'filter' => ['UF_BARCODE_ID' => $barcodeIds],
                'select' => ['UF_BARCODE_ID'],
            ]
        );
        while ($row = $query->fetch()) {
            $result[] = $row['UF_BARCODE_ID'];
        }
        return array_unique($result);
    }

    private function getFormatedDates(array $arDates = []): array
    {
        $result    = [];
        $startDate = null;
        $prevDate  = null;

        foreach ($arDates as $date) {
            $currentDate = new DateTime($date);

            if ($startDate === null) {
                $startDate = $currentDate;
                $prevDate  = $currentDate;
            } else {
                $diff     = $currentDate->diff($prevDate);
                $sameTime = $currentDate->format('H:i:s') === $prevDate->format('H:i:s');

                if ($diff->days === 1 && $sameTime) {
                    $prevDate = $currentDate;
                } else {
                    if ($startDate === $prevDate) {
                        $result[] = FormatDate("d F Y", $startDate->getTimestamp()) . ' в ' . FormatDate("H:i", $startDate->getTimestamp());
                    } else {
                        $result[] = FormatDate("d F Y", $startDate->getTimestamp()) . " - " . FormatDate("d F Y", $prevDate->getTimestamp()) . ' в ' . FormatDate("H:i", $prevDate->getTimestamp());
                    }
                    $startDate = $currentDate;
                    $prevDate  = $currentDate;
                }
            }
        }

        // Добавляем последний диапазон или дату
        if ($startDate === $prevDate) {
            $result[] = FormatDate("d F Y", $startDate->getTimestamp()) . ' в ' . FormatDate("H:i", $startDate->getTimestamp());
        } else {
            $result[] = FormatDate("d F Y", $startDate->getTimestamp()) . " - " . FormatDate("d F Y", $prevDate->getTimestamp()) . ' в ' . FormatDate("H:i", $prevDate->getTimestamp());
        }

        return $result;
    }

    private function getTicketInfo($offersIDs): array
    {
        $offerEntity    = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $offerDataClass = $offerEntity->getDataClass();

        $offersRes = $offerDataClass::getList(
            [
                'select'  => [
                    'ID',
                    'PROP_TYPE'      => 'TYPE.VALUE',
                    'PROP_DATES',
                    'PROP_DATES_ALL' => 'DATES_ALL.VALUE',
                ],
                'filter'  => ['ID' => $offersIDs],
                'runtime' => [
                    new \Bitrix\Main\Entity\ExpressionField(
                        'PROP_DATES',
                        "GROUP_CONCAT(%s SEPARATOR ';')",
                        ['DATES.VALUE']
                    ),
                ]
            ]
        );
        $res       = [];
        while ($offer = $offersRes->fetch()) {
            $offer['PROP_DATES'] ? $offer['PROP_DATES'] = explode(';', $offer['PROP_DATES']) : $offer['PROP_DATES'] = [];
            $res[$offer['ID']] = $offer;
        }
        return $res;
    }

    private function getLocations($eventID): array
    {
        $locationEntity    = (new ORM\Query\Query('Custom\Core\Events\EventsDateAndLocationTable'))->getEntity();
        $locationDataClass = $locationEntity->getDataClass();
        $locationRes       = $locationDataClass::getList(
            [
                'select' => ['UF_DATE_TIME', 'UF_ADDRESS', 'UF_ROOM'],
                'filter' => ['UF_EVENT_ID' => $eventID]
            ]
        );
        $res               = [];
        while ($location = $locationRes->fetch()) {
            $location['UF_DATE_TIME'] = unserialize($location['UF_DATE_TIME']) ?? [];
            $res[]                    = $location;
        }

        return $res;
    }

    private function getQuestionnaires($orderID): array
    {
        $questionnaireEntity    = (new ORM\Query\Query('Custom\Core\Events\EventsQuestionnaireTable'))->getEntity();
        $questionnaireDataClass = $questionnaireEntity->getDataClass();
        $questionnaireRes       = $questionnaireDataClass::getList(
            [
                'select' => ['ID', 'UF_FULL_NAME', 'UF_TICKET'],
                'filter' => ['UF_ORDER_ID' => $orderID]
            ]
        );
        $res                    = [];
        while ($questionnaire = $questionnaireRes->fetch()) {
            $res[] = $questionnaire;
        }
        return $res;
    }

    private function getReasonsForRefund($id = null)
    {
        $filter = [
            "HL.NAME"    => "TicketRefundRequests",
            "FIELD_NAME" => "UF_REASON_FOR_RETURN",
        ];
        if ((int)$id > 0) $filter['ENUM_ID'] = $id;
        $query = \Bitrix\Main\UserFieldTable::getList(
            [
                "filter"  => $filter,
                "select"  => [
                    "ENUM_ID"     => "ENUM.ID",
                    "ENUM_XML_ID" => "ENUM.XML_ID",
                    "ENUM_NAME"   => "ENUM.VALUE",
                ],
                "runtime" => [
                    new \Bitrix\Main\Entity\ExpressionField(
                        'HL_ID',
                        'REPLACE(%s, "HLBLOCK_", "")',
                        ['ENTITY_ID']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'HL',
                        '\Bitrix\Highloadblock\HighloadBlockTable',
                        ['this.HL_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'ENUM',
                        '\Custom\Core\FieldEnumTable',
                        ['this.ID' => 'ref.USER_FIELD_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ],
                'order'   => ['ENUM_ID' => 'ASC'],
                'cache'   => ['ttl' => 3600],
            ]
        );
        $res   = [];
        while ($item = $query->fetch()) {
            $res[$item['ENUM_ID']] = $item;
        }
        return $res;
    }

    private function saveRequest($arResult = [])
    {
        if (count($arResult['ITEMS']) == 0) $this->showError(Loc::getMessage('REFUND_FORM_ERROR_NO_TICKETS'));
        if ($this->eventIsCompleted($arResult['ITEMS'][0]['ID'])) $this->showError(Loc::getMessage('REFUND_FORM_ERROR_EVENT_COMPLETED'));

        // Получаем данные для дополнительных проверок
        $offersIDs     = array_column($arResult['ITEMS'], 'OFFER_ID');
        $arTicketDates = $this->getTicketInfo($offersIDs);

        $eventID     = $arResult['ITEMS'][0]['EVENT_ID'];
        $arLocations = $this->getLocations($eventID);
        $arDates     = [];
        foreach ($arLocations as $location) {
            $arDates = array_merge($arDates, $location['UF_DATE_TIME']);
        }

        $barcodeIds = array_column($arResult['ITEMS'], 'TICKET_BARCODE_ID') ?? [];
        if (!empty($barcodeIds)) {
            $barcodeIds = $this->checkSKDHistory($barcodeIds);
        }

        $currentDateTime = new DateTime();

        $requestEntity   = HL\HighloadBlockTable::compileEntity('TicketRefundRequests');
        $hlbClassRequest = $requestEntity->getDataClass();
        $reasonForReturn = $this->getReasonsForRefund($this->request['REASON_FOR_RETURN']);

        $arData = [
            'UF_FULL_NAME'         => $this->request['FULL_NAME'],
            'UF_EMAIL'             => $this->request['EMAIL'],
            'UF_PHONE'             => preg_replace('~\D+~', '', $this->request['PHONE']),
            'UF_COMMENT'           => $this->request['COMMENT'],
            'UF_REASON_FOR_RETURN' => $this->request['REASON_FOR_RETURN'],
            'UF_DATE_TIME'         => (new DateTime())->format('d.m.Y H:i:s'),
            'UF_COMPANY_ID'        => $arResult['ITEMS'][0]['ORGANIZER_ID'],
            'UF_ORDER_ID'          => $arResult['ITEMS'][0]['ID'],
        ];

        if (isset($_FILES['UF_DOCUMENT']['tmp_name']) && !empty($_FILES['UF_DOCUMENT']['tmp_name'][0])) {
            $arFiles = [];
            foreach ($_FILES['UF_DOCUMENT'] as $key => $values) {
                foreach ($values as $k => $value) {
                    $arFiles[$k][$key] = $value;
                }
            }
            $arData['UF_DOCUMENTS'] = $arFiles;
        }

        $currentTickets = $this->request['TICKET'] ?? [];
        $arTickets      = [];
        $selectedTickets = [];

        foreach ($arResult['ITEMS'] as $ticket) {
            if (in_array($ticket['TICKET_UUID'], $currentTickets)) {
                $arTickets[]       = $ticket['BASKET_ITEM_ID'];
                $selectedTickets[] = $ticket;
            }
        }

        if (count($arTickets) == 0) $this->showError(Loc::getMessage('REFUND_FORM_ERROR_NO_TICKETS'));

        if ($reasonForReturn[$this->request['REASON_FOR_RETURN']]['ENUM_XML_ID'] == 'other' && empty($this->request['COMMENT']))
            $this->showError(Loc::getMessage('REFUND_FORM_ERROR_NO_COMMENT'));

        if ($this->checkRefundsExist($arTickets)) $this->showError(Loc::getMessage('REFUND_FORM_ERROR_REFUND_EXISTS'));

        // Дополнительные проверки для выбранных билетов
        foreach ($selectedTickets as $ticket) {
            // Проверка истории прохода
            if (in_array($ticket['TICKET_BARCODE_ID'], $barcodeIds)) {
                $this->showError(Loc::getMessage('REFUND_FORM_ERROR_TICKET_ALREADY_USED'));
            }

            // Проверка по дате начала билета
            $ticketDateTimes = $arDates;
            if (!empty($arTicketDates[$ticket['OFFER_ID']]['PROP_DATES'])) {
                $propDates       = $arTicketDates[$ticket['OFFER_ID']]['PROP_DATES'];
                $ticketDateTimes = [];

                foreach ($arDates as $dateTime) {
                    $date = date('Y-m-d', strtotime($dateTime));

                    foreach ($propDates as $propDate) {
                        $propDateFormatted = date('Y-m-d', strtotime($propDate));
                        if ($date === $propDateFormatted) {
                            $ticketDateTimes[] = $dateTime;
                            break;
                        }
                    }
                }
            }

            if (!empty($ticketDateTimes)) {
                $minTicketDateTime = min($ticketDateTimes);
                $minTicketDateTime = new DateTime($minTicketDateTime);

                if ($minTicketDateTime < $currentDateTime) {
                    $this->showError(Loc::getMessage('REFUND_FORM_ERROR_EVENT_ALREADY_STARTED'));
                }
            }
        }

        $arData['UF_BASKET_ITEM_ID'] = $arTickets;

        $resAdd = $hlbClassRequest::add($arData);

        if (!$resAdd->isSuccess()) $this->showError(str_replace('<br>', ';', implode(', ', $resAdd->getErrors())));
        else $this->showSuccess('Заявка успешно отправлена');

    }

    private function showError($message)
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        echo json_encode(['status' => 'error', 'message' => $message], JSON_UNESCAPED_UNICODE);
        die;
    }

    private function showSuccess($message)
    {
        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        echo json_encode(['status' => 'success', 'message' => $message], JSON_UNESCAPED_UNICODE);
        die;
    }

    private function checkRefundsExist(array $basketItemsIDs): bool
    {
        $query = new ORM\Query\Query('Custom\Core\Tickets\TicketRefundRequestsUfBasketItemIdTable');
        $res   = $query
            ->setSelect(['ID'])
            ->setFilter(['VALUE' => $basketItemsIDs])
            ->countTotal(true)
            ->exec();
        return $res->getCount() > 0;
    }

    private function eventIsCompleted(int $orderID): bool
    {
        $query = \Bitrix\Sale\Order::getList(
            [
                'select'  => [
                    'ID',
                    'EVENT_ID' => 'PROPERTY_EVENT_ID.VALUE',
                    'EVENT_STATUS' => 'UF_STATUS_REF.UF_XML_ID'
                ],
                'filter'  => [
                    "PAYED"                  => "Y",
                    "PROPERTY_EVENT_ID.CODE" => 'EVENT_ID',
                    "ID"                     => $orderID
                ],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_EVENT_ID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'EVENT_REF',
                        'Custom\Core\Events\EventsTable',
                        ['this.EVENT_ID' => 'ref.ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'UF_STATUS_REF',
                        '\Custom\Core\Events\EventsStatusTable',
                        ['this.EVENT_REF.UF_STATUS' => 'ref.ID'],
                        ['join_type' => 'LEFT']
                    )

                ],
            ]
        );

        $status = $query->fetch()['EVENT_STATUS'];
        return $status == 'completed';
    }

    /**
     * Получает товары из корзины заказа
     */
    private function getBasketItems(int $orderId): array
    {
        $result = [];
        $dbRes  = \Bitrix\Sale\Internals\BasketTable::getList(
            [
                'select' => ['ID', 'PRICE', 'PRODUCT_ID'],
                'filter' => ['ORDER_ID' => $orderId]
            ]
        );

        while ($item = $dbRes->fetch()) {
            $result[$item['ID']] = $item;
        }

        return $result;
    }

    /**
     * Получает свойства корзины одним запросом
     */
    private function getBasketProperties(array $basketIds): array
    {
        if (empty($basketIds)) return [];

        $result = [];
        $dbRes  = \Bitrix\Sale\Internals\BasketPropertyTable::getList(
            [
                'select' => ['BASKET_ID', 'CODE', 'VALUE'],
                'filter' => [
                    'BASKET_ID' => $basketIds,
                    'CODE'      => ['UUID', 'ROW', 'PLACE', 'SECTOR', 'BARCODE']
                ]
            ]
        );

        while ($prop = $dbRes->fetch()) {
            $result[$prop['BASKET_ID']][$prop['CODE']] = $prop['VALUE'];
        }

        return $result;
    }

    /**
     * Получает данные о возвратах
     */
    private function getRefundData(array $basketIds): array
    {
        if (empty($basketIds)) return [];

        $result = [];
        $dbRes  = \Custom\Core\Tickets\TicketRefundRequestsUfBasketItemIdTable::getList(
            [
                'select' => ['VALUE'],
                'filter' => ['VALUE' => $basketIds]
            ]
        );

        while ($refund = $dbRes->fetch()) {
            $result[$refund['VALUE']] = true;
        }

        return $result;

    }
}