<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<main class="flex-auto">
    <section class="flex flex-col">
        <div class="lg:mb-14 mb-7 hidden md:flex flex-col items-center">
            <?
            $APPLICATION->IncludeComponent(
                "bitrix:breadcrumb",
                "main",
                Array(
                    "PATH" => "",
                    "SITE_ID" => "s1",
                    "START_FROM" => "0"
                )
            );
            ?>
        </div>
        <div class="container__wide flex items-center justify-center">
            <div class="inline-flex max-w-[860px] flex-col items-center justify-center gap-5 px-c_narrow py-20 text-center dark:text-white lg:gap-c_af">
                <h2>Ваша заявка принята</h2>
                <div class="text-xs font-medium leading-150 md:text-sm lg:text-lg">
                    Организатор рассмотрит её в течение 10 дней. Информация о результатах будет отправлена на
                    указанный
                    e-mail. Если возврат одобрен, деньги поступят на карту, с которой была произведена оплата.
                </div>
                <a href="/" class="btn__red btn__buy md:!px-[50px] lg:!px-[35px]">
                    <span class="font-gothic lg:text-xl">На главную</span>
                </a>
            </div>
        </div>
    </section>
</main>