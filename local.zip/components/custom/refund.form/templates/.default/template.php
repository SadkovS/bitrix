<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
global $APPLICATION;

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Custom\Core\Products;
use Custom\Core\PriceRules;
use Custom\Core\SeatMap as SeatMap;

$app       = Application::getInstance();
$context   = $app->getContext();
$request   = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
?>
<?if($request['success'] == 'Y'):?>
<?require_once 'success.php'?>
<? elseif ($arResult['ALL_TICKETS_USED']): ?>
    <section class="flex flex-col">
        <div class="lg:mb-14 mb-7 hidden md:flex flex-col items-center">
            <?
            $APPLICATION->IncludeComponent(
                "bitrix:breadcrumb",
                "main",
                Array(
                    "PATH" => "",
                    "SITE_ID" => "s1",
                    "START_FROM" => "0"
                )
            );
            ?>
        </div>
        <div class="container__wide flex items-center justify-center">
            <div class="inline-flex max-w-[860px] flex-col items-center justify-center gap-5 px-c_narrow py-20 text-center dark:text-white lg:gap-c_af">
                <h2 class="text-balance">Все билеты в этом заказе
                    уже были использованы</h2>
                <a href="/" class="btn__red btn__buy md:!px-[50px] lg:!px-[35px]">
                    <span class="font-gothic lg:text-xl">На главную</span>
                </a>
            </div>
        </div>
    </section>
<? elseif ($arResult['ALL_TICKETS_DATE_EXPIRED']): ?>
    <section class="flex flex-col">
        <div class="lg:mb-14 mb-7 hidden md:flex flex-col items-center">
            <?
            $APPLICATION->IncludeComponent(
                "bitrix:breadcrumb",
                "main",
                Array(
                    "PATH" => "",
                    "SITE_ID" => "s1",
                    "START_FROM" => "0"
                )
            );
            ?>
        </div>
        <div class="container__wide flex items-center justify-center">
            <div class="inline-flex max-w-[860px] flex-col items-center justify-center gap-5 px-c_narrow py-20 text-center dark:text-white lg:gap-c_af">
                <h2 class="text-balance">Билеты в этом заказе уже не подлежат возврату, так как мероприятие уже
                    началось</h2>
                <a href="/" class="btn__red btn__buy md:!px-[50px] lg:!px-[35px]">
                    <span class="font-gothic lg:text-xl">На главную</span>
                </a>
            </div>
        </div>
    </section>
<?else:?>
<section class="flex flex-col">
    <div class="lg:mb-14 mb-7 hidden md:flex flex-col items-center">
        <?
        $APPLICATION->IncludeComponent(
            "bitrix:breadcrumb",
            "main",
            Array(
                "PATH" => "",
                "SITE_ID" => "s1",
                "START_FROM" => "0"
            )
        );
        ?>
    </div>
    <form class="flex js-form-validate" method="post" action="<?= $APPLICATION->GetCurPage() . "?action=refund" ?>" enctype="multipart/form-data">
        <?= bitrix_sessid_post(); ?>
        <div class="container__wide inline-flex flex-col gap-5 lg:gap-10">
            <div class="inline-flex items-baseline justify-between px-c_narrow lg:px-0">
                <h1 class="dark:text-white">Возврат билетов</h1>
            </div>
            <div class="inline-flex w-full flex-col gap-5 md:gap-c_af laptop:grid laptop:grid-cols-3 laptop:gap-10 xl:grid-cols-2">
                <div class="inline-flex flex-col gap-c_sm laptop:col-span-2 xl:col-span-1" data-refund-parent>

                    <div class="relative inline-flex items-center gap-5 rounded-c_lg bg-t-1 px-c_at py-c_narrow dark:bg-background-2 md:px-c_af md:py-5 lg:p-2.5">
                        <div class="inline-flex items-center gap-c_md">
                            <label class="checkbox red">
                                <input type="checkbox" name="" checked data-refund-all/>
                                <span class="checkbox__icon svg_icon-check"></span>
                            </label>
                            <span class="text-sm font-medium dark:text-white md:text-base">Выбрать все</span>
                        </div>
                        <div class="text-xs font-medium text-t-2 lg:text-sm">
                            Выбрано:
                            <span data-refund-counter>все</span>
                        </div>
                    </div>
                    <? foreach ($arResult['ITEMS'] as $item): ?>
                        <div
                                class="relative inline-flex flex-col gap-2.5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5  md:flex-row md:gap-5 lg:p-c_sm lg:gap-0 <?=$item['REFUND_DISABLED']?"refund-disabled":""?>">
                            <div class="relative h-[70px] w-[127px] rounded-c_sm bg-cover bg-center md:h-20 md:w-40 lg:w-[258px] lg:h-[144px] flex-shrink-0">
		                            <picture>
			                            <img src="<?=$item['IMG_SRC']?>" alt="" class="fill-img disable-blur rounded-c_sm">
		                            </picture>
                                <? if (!$item['REFUND_DISABLED']): ?>
                                <label class="checkbox red absolute left-c_sm top-c_sm">
                                    <input type="checkbox" value="<?= $item['TICKET_UUID'] ?>" name="TICKET[]" checked
                                           data-refund-part/>
                                    <span class="checkbox__icon svg_icon-check"></span>
                                </label>
                                <?else:?>
	                                <div class="checkbox disabled red absolute left-c_sm top-c_sm">
		                                <div class="checkbox__icon svg_icon-check">

																    <span class="checkbox-tooltip bg-t-1 dark:bg-primary dark:text-white text-primary rounded-c_lg text-base font-medium p-3">
																	    <?=$item['REFUND_DESCRIPTION']?>
																    </span>

		                                </div>

	                                </div>
                                <?endif;?>
                            </div>
                            <div class="inline-flex flex-col gap-2.5 flex-auto md:gap-1 lg:p-5 laptop:py-2.5 laptop:pl-5 laptop:pr-c_md disable-blur">
                                <div class="inline-flex flex-col gap-0.5 laptop:gap-[3px]">
                                    <div class="text-c_xs font-medium dark:text-white md:text-sm lg:text-lg laptop:!leading-none ">
                                        <?= $item['EVENT_NAME'] ?>
                                    </div>
                                    <div class="text-xs font-medium text-t-2 lg:text-base"><?= $item['ADDRESS'] ?>
                                    </div>
                                    <?foreach ($item['DATES'] as $date):?><div class="text-xs font-medium text-t-2 lg:text-base"><?= $date ?></div><?endforeach;?>
                                </div>
                                <div class="inline-flex items-center justify-between mt-auto">
                                     <div class="inline-flex flex-col">
                                        <div class="inline-flex flex-wrap items-baseline gap-2.5 text-xs font-medium dark:text-white sm:text-c_xs md:text-sm lg:text-base"><?=$item['FIO']?></div>
                                        <div
                                                class="inline-flex flex-wrap items-baseline gap-2.5 text-xs font-medium dark:text-white sm:text-c_xs  md:text-sm lg:text-base">
                                            <?=empty($item['TICKET_ROW'])?'':$item['TICKET_ROW'].' ряд, '?> <?=empty($item['TICKET_PLACE'])?'':$item['TICKET_PLACE'].' место'?>
                                            <span class="text-t-2 lg:text-sm"><?=empty($item['TICKET_SECTOR'])?'':$item['TICKET_SECTOR'].'/'?> <?=empty($item['TICKET_TYPE'])?'':$item['TICKET_TYPE']?></span>
                                        </div>
                                    </div>
                                    <div class="text-sm  md:text-base whitespace-nowrap font-semibold dark:text-white lg:text-lg">
                                        <?= floatval($item['TICKET_PRICE']) ?> ₽
                                    </div>
                                </div>
                            </div>
                        </div>
                    <? endforeach; ?>
                </div>
                <div class="inline-flex flex-col gap-c_sm">
                    <div class="relative inline-flex flex-col gap-5 rounded-c_lg bg-t-1 p-c_narrow dark:bg-background-2 md:p-5 laptop:p-c_lg">
                        <span class="text-xs font-medium dark:text-white md:text-sm lg:text-lg">Для возврата билетов заполните форму</span>
                        <div class="inline-flex flex-col gap-c_md md:gap-5 laptop:gap-c_af">
                            <div class="form__item required">
                      <span class="form__item-label">
                        Имя и фамилия
                        <b class="text-warning">*</b>
                      </span>
                                <input type="text" name="FULL_NAME" class="input input__bg"/>
                            </div>
                            <div class="form__item required">
                      <span class="form__item-label">
                        E-mail
                        <b class="text-warning">*</b>
                      </span>
                                <input type="email" name="EMAIL" class="input input__bg"/>
                            </div>
                            <div class="form__item required">
                      <span class="form__item-label">
                        Телефон
                        <b class="text-warning">*</b>
                      </span>
                                <div class="form__item-wrapper">
                                    <i class="input__icon">+</i>
                                    <input type="text" name="PHONE" class="input input__bg" data-mask="7 ( 000 ) 000-00-00"
                                           placeholder="7 ( ___ ) ___ - __ - __"/>
                                </div>
                            </div>
                            <div class="form__item required">
                      <span class="form__item-label">
                        Причина возврата
                        <b class="text-warning">*</b>
                      </span>
                                <div class="form-select js-comment-change" data-select="">
                                    <div class="form-select__selected-option" data-select-selected-option="change"
                                         data-placeholder="Выберите">Выберите
                                    </div>
                                    <i class="form-select__icon svg_icon-chevron" data-select-icon=""></i>
                                    <div class="form-select__options-wrap" data-select-wrapper="">
                                        <ul class="form-select__options custom-scroll">
                                            <? foreach ($arResult['REASONS_LIST'] as $reason): ?>
                                                <li class="form-select__options-item <?=($reason['ENUM_XML_ID'] == 'other')?'js-other-id':'' ?>"
                                                    data-select-option="<?= $reason['ENUM_ID'] ?>"><?= $reason['ENUM_NAME'] ?></li>
                                            <? endforeach; ?>
                                        </ul>
                                    </div>
                                    <input type="hidden" name="REASON_FOR_RETURN" value="" data-select-input="" data-show-more-change/>
                                </div>
                            </div>
                            <div class="form__item js-comment-field">
                                <span class="form__item-label">Комментарий <b class="text-warning hidden js-comment-field-star">*</b></span>
                                <textarea type="text" name="COMMENT" class="textarea xl:min-h-[150px]" value="5"
                                          data-textarea-auto-height></textarea>
                            </div>
                            <div class="form__upload">
                                <span class="form__item-label">Прикрепить документ</span>
                                <div class="form__item">
                                    <label class="upload-file svg_icon-clip" data-upload-file>
                                        <input type="file" accept=".pdf, .doc, .docs,.jpg, .jpeg, .png, .docx, .heic" data-name="UF_DOCUMENT[]"/>
                                        <span class="upload-file__label">До 3 МБ: PNG, JPG, HEIC, PDF, DOCX</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="inline-flex gap-2">
                            <span class="block text-warning">*</span>
                            <span class="form__item-label">— обязательное поле</span>
                        </div>
                        <span class="text-mic font-medium dark:text-icons-1">Нажимая на кнопку «Отправить», вы соглашаетесь с <a class="underline" target="_blank" href="/documents/policy_personal_data.pdf">Политикой в отношении обработки персональных данных</a> и  <a class="underline" target="_blank" href="/documents/consent_processing_personal_data.pdf">Обработкой персональных данных</a>.</span>
                    </div>
                    <button type="submit" class="btn__red js-ajax-form-submit-btn js-form-validate-btn" data-redirrect="?success=Y"><span class="font-gothic">Отправить</span>
                    </button>
                </div>
            </div>
        </div>
    </form>
</section>
<?endif;?>

<div class="-mb-10 mt-14 flex md:hidden flex-col items-center px-c_narrow">
	<?
	$APPLICATION->IncludeComponent(
		"bitrix:breadcrumb",
		"main",
		Array(
			"PATH" => "",
			"SITE_ID" => "s1",
			"START_FROM" => "0"
		)
	);
	?>
</div>