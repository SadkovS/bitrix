<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME"        => GetMessage("REFUND_FORM_COMPONENT_NAME"),
    "DESCRIPTION" => GetMessage("REFUND_FORM_COMPONENT_DESCRIPTION"),
    "COMPLEX"     => "N",
    "PATH"        => [
        "ID"    => "custom",
        "CHILD" => [
            "ID"    => "orders",
            "NAME"  => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT"  => 20,
            "CHILD" => [
                "ID" => 'refund_form',
            ]
        ]
    ],
];
?>