<?php
$MESS["REFUND_FORM_COMPONENT_NAME"] = "Форма оформления возврата";
$MESS["REFUND_FORM_COMPONENT_DESCRIPTION"] = "Выводит форму оформления возврата";
$MESS["C_HLDB_CAT_ORDERS"] = "Заказы";