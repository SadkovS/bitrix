<?php
$MESS["REFUND_FORM_WRONG_SESSION"]        = "Неверная сессия";
$MESS["REFUND_FORM_SUCCESS_SEND_REQUEST"] = "Запрос на возврат успешно отправлен";
$MESS["REFUND_FORM_ERROR_NO_TICKETS"] = "Нет билетов";
$MESS["REFUND_FORM_ERROR_REFUND_EXISTS"] = "Запрос на возврат уже отправлен";
$MESS["REFUND_FORM_ERROR_NO_COMMENT"] = "Комментарий обязателен для заполнения";
$MESS["REFUND_FORM_ERROR_EVENT_COMPLETED"] = "Мероприятие уже завершено. Для оформления возврата обратитесь в поддержку";
$MESS["REFUND_FORM_ERROR_TICKET_ALREADY_USED"] = "Билет уже был использован и не может быть возвращен";
$MESS["REFUND_FORM_ERROR_EVENT_ALREADY_STARTED"] = "Возврат билета невозможен - мероприятие уже началось";