<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => GetMessage("NAME"),
    "DESCRIPTION" => GetMessage("DESC"),
    "CACHE_PATH" => "Y",
    "SORT" => 40,
    "PATH" => array(
        "ID" => "custom",
        "CHILD" => array(
            "ID" => "organization.team",
            "NAME" => GetMessage("CATEGORY"),
            "SORT" => 20,
            "CHILD" => array(
                "ID" => 'organization_team.list'
            )
        )
    ),
);

?>