<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;

$isOwner = isset($_SESSION['CURRENT_USER_PROFILE']['UF_IS_OWNER']) && $_SESSION['CURRENT_USER_PROFILE']['UF_IS_OWNER'];
?>

<div class="admin-body promo js-admin-team-body">
	<div class="admin-body__item wide events">
		<div class="admin-body__item-header">
			<h1>Команда</h1>
			<? if ($isOwner): ?>
				<div class="events__create">
					<button type="button" class="btn btn__clear" data-popup="#team-add" data-popup-src="<?= $arParams['SEF_FOLDER']?>0/?action=getForm&ajax=y"><i class="_icon-plus"></i>Добавить сотрудника</button>
				</div>
			<? endif; ?>
		</div>
		<div class="team-table">
			<table class="events__table">
				<thead>
				<tr>

					<td>
						<div class="events__table-item">
							<p class="color__main">ФИО</p>
						</div>
					</td>
					<td>
						<div class="events__table-item">
							<p class="color__main">E-mail</p>
						</div>
					</td>
					<td>
						<div class="events__table-item">
							<p class="color__main">Телефон</p>
						</div>
					</td>
					<td>
						<div class="events__table-item">
							<p class="color__main">Роль</p>
						</div>
					</td>
					<td></td>
				</tr>
				</thead>
				<tbody>
				<?foreach ($arResult["TEAM"] as $user):?>
					<tr>

						<td>
							<div class="events__table-item">
								<p><?=$user["NAME"]?></p>
							</div>
						</td>
						<td>
							<div class="events__table-item">
								<p><?=$user["USER_EMAIL"]?></p>
							</div>
						</td>
						<td>
							<div class="events__table-item">
								<p><?=$user["USER_PHONE"]?></p>
							</div>
						</td>
						<td>
							<div class="events__table-item">
								<p><?= $user['UF_IS_OWNER'] ? 'Владелец' : 'Администратор'?></p>
							</div>
						</td>

						<? if ($isOwner && !$user['UF_IS_OWNER']): ?>
							<td>
								<div class="events__table-controls" data-event-controls="">
									<button type="button" class="btn__icon" data-event-controls-btn="">
										<i class="_icon-rounds"></i>
									</button>
									<div class="events__table-controls-body" data-event-controls-body="">
										<ul>
											<!--<li>
												<a data-popup-src="<?php /*=$arParams['SEF_FOLDER'].$user['ID']*/?>/?action=getForm&ajax=y" data-popup="#team-add" href="javascript:void(0)">Редактировать</a>
											</li>-->
											<li>
												<a href="javascript:void(0);" data-delete-confirm-title="Профиль пользователя <?= $user['NAME'] ?? ''; ?>" data-delete-user-link="<?=$arParams['SEF_FOLDER'] . $user['ID'] ?>/?action=del" data-delete-user-confirm="<?=$user['ID']?>">Удалить</a>
											</li>
										</ul>
									</div>
								</div>
							</td>
						<? endif; ?>
					</tr>
				<?endforeach;?>
				</tbody>
			</table>
			<?= $arResult['NAV_STRING'] ?>
		</div>
	</div>
</div>



<div aria-hidden="true" class="popup popup__small" id="team-add-complete">
	<div class="popup__wrapper">

		<div class="popup__content">
			<button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i></button>

			<div class="team-add-complete">
				<div class="h2 team-add-complete-title">Пользователь успешно добавлен в организацию</div>
				<div class="team-add-complete-text">
					<p>На его e-mail отправлено уведомление с приглашением войти в личный кабинет.</p>

					<p>Если письмо не пришло в течение нескольких минут, напомните пользователю проверить папку «Спам» или войти в кабинет вручную по ссылке:<br>
						<a href="https://voroh.ru/admin_panel/" target="_blank">https://voroh.ru/admin_panel/</a>
					</p>
				</div>
				<div class="team-add-complete__btn">
					<button class="btn btn__blue btn__big btn__fix-width" data-close>ОК</button>
				</div>
			</div>
		</div>
	</div>
</div>

<div aria-hidden="true" class="popup popup__small" id="team-add-complete-org">
	<div class="popup__wrapper">

		<div class="popup__content">
			<button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i></button>

			<div class="team-add-complete">
				<div class="h2 team-add-complete-title">Пользователь успешно добавлен</div>
				<div class="team-add-complete-text">
					<p>На указанный вами e-mail ему отправлено письмо с инструкциями для активации аккаунта.</p>
					<p>Если письмо не пришло в течение нескольких минут, попросите пользователя воспользоваться функцией восстановления пароля по указанному вами адресу электронной почты.</p>
				</div>
				<div class="team-add-complete__btn">
					<button class="btn btn__blue btn__big btn__fix-width" data-close>ОК</button>
				</div>
			</div>
		</div>
	</div>
</div>