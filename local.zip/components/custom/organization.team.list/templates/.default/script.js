$(document).ready(function () {

    // Бинд всех эвентов на страницу
    [
        ['click', openDeleteUserConfirmPopup],
        ['click', deleteUserConfirm],
    ].forEach(([event, fn]) => {
        document.addEventListener(event, fn)
    });

    function openDeleteUserConfirmPopup(e) {
        const target = e.target;
        const btn = target.closest('[data-delete-user-confirm]');
        if(!btn) return;

        const link = btn.getAttribute('data-delete-user-confirm');

        const url = target.getAttribute('data-delete-user-link');

        const title = btn.getAttribute('data-delete-confirm-title') || '';
        const content = `<div class="popup__content">
      <button data-close type="button" class="popup__close profile__popup-close"><i class="_icon-plus"></i></button>
      <div class="popup__name h1">Вы точно хотите <br>
        удалить ${title}</div>
        <div class="row d-flex justify-content-center">
          <div class="col-auto">
            <button type="button" class="btn btn__blue btn__big" data-close>Оставить</button>
          </div>
          <div class="col-auto">
            <button type="button" class="btn btn__clean btn__big" data-user-confirm-url="${url}" data-user-confirm-delete="${link}">Удалить</button>
          </div>
        </div>
        </div>`;
        document.dispatchEvent(new CustomEvent('openPopup', {detail: {popup: '#delete-item', content}}));
    }

    async function deleteUserConfirm(e) {
        const target = e.target;
        if (!target.closest('[data-user-confirm-delete]')) return;
        e.preventDefault();
        const btn = target.closest('[data-user-confirm-delete]');
        const url = btn.getAttribute('data-user-confirm-url');
        const formData = new FormData();
        formData.append('ID', btn.getAttribute('data-user-confirm-delete'));
        addLoader();
        const response = await fetch(url, {
            method: 'POST',
            body: formData
        })
        removeLoader();
        if (!response.ok) {
            return
            // throw new Error(response.statusText);
        }
        const data = await response.json();
        if (data.status === 'success') {
            document.dispatchEvent(new CustomEvent('closePopup', {detail: {popup: '#delete-item'}}));
	        partialReloadPage(".team-table");
        } else {
            showToast(data);
            document.dispatchEvent(new CustomEvent('closePopup', {detail: {popup: '#delete-item'}}));
        }
    }



    function addLoader() {
        document.body.classList.add('loading')
    }

    function removeLoader() {
        document.body.classList.remove('loading')
    }
});
