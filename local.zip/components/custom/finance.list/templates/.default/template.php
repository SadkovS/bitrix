<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");
?>

<div class="admin-body">
    <div class="row col-12">
        <h1>Финансы</h1>
    </div>
    <div class="finance-grid">

        <div class="widget-small finance-grid-itm">
            <h3 class="text__large">Сумма оборотных средств за текущий месяц</h3>
            <div class="finance-grid-itm__val"><?=$arResult["COMPANY"]["SUMM_MONTH"]?> ₽</div>
        </div>

        <div class="widget-small finance-grid-itm">
					<div class="finance-grid-itm__flex">
						<div>
							<h3 class="text__large">Сумма средств, доступных к выводу</h3>
							<div class="finance-grid-itm__val"><?= $arResult["COMPANY"]["UF_BALANCE"] ?> ₽</div>
						</div>
						<?php if ($arResult["COMPANY"]["UF_BALANCE"] === '0.00'): ?>
							<div class="finance-grid-itm__btn-wrap">
								<a class="btn btn__big btn__blue finance-grid-itm__btn disabled blocked" data-popup="#transfer" href="">Вывести</a>
								<div class="clue__box">
									<div class="" data-clue="">
										<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
										<span class="clue-body" data-clue-body="" data-popper-placement="top">
									Нет доступных средств для выводы
									<span data-popper-arrow=""></span>
									</span>
									</div>
								</div>
							</div>
			  		<?php else: ?>
							<a class="btn btn__big btn__blue finance-grid-itm__btn" data-popup="#transfer" href="">Вывести</a>
						<?php endif; ?>

					</div>
        </div>

    </div>

    <div class="admin-body__item wide events">
        <div class="admin-body__item-header">
            <h2 class="text__large">Заявки на вывод</h2>
        </div>
        <table class="events__table table-standard-th">
            <thead>
            <tr>
                <td>ФИО</td>
                <td>Дата запроса</td>
                <td>Сумма запроса, ₽</td>
                <td>Статус</td>
                <td>Дата выведения<br> денежных средств</td>
                <td>Комментарий</td>
            </tr>
            </thead>
            <tbody>

            <?foreach($arResult["ITEMS"] as $item):?>
                <tr class="">
                    <td>
                        <div class="events__table-item">
                            <?=$item["FULL_NAME"]?>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <?=$item["UF_DATE"]?>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <?=$item["UF_SUMM"]?> ₽
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <span class="events__table-item-status <?=$item["STATUS_CLASS"]?>"><?=$item["STATUS_VALUE"]?></span>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <?=$item["UF_DATE_SUCCESS"]?>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <?=$item["UF_COMMENT"]?>
                        </div>
                    </td>

                </tr>
            <?endforeach;?>



            </tbody>
        </table>

        <?= $arResult['NAV_STRING'] ?>

    </div>

</div>