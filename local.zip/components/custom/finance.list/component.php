<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Custom\Core\Products;
use Custom\Core\PriceRules;
use \Bitrix\Main\Localization\Loc;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest()->toArray();;
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('catalog') ||
    !Loader::IncludeModule("iblock")
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    if($companyID)
    {
        $query = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany   = $query
            ->setFilter(['ID' => $companyID])
            ->setSelect([
                'ID', 'UF_BANK_*', 'UF_BALANCE'
            ])
            ->setLimit(1)
            ->exec();
        if($company = $resCompany->fetch()){
            $curPage = (int)$request['PAGEN_1'] > 0 ? (int)$request['PAGEN_1'] : 1;
            if (!isset($_REQUEST['PAGEN_1']) || (int)$_REQUEST['PAGEN_1'] <= 1)
                $offset = 0;
            else
                $offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $arParams["ACTS_COUNT"];

            $queryActs = new ORM\Query\Query('\Custom\Core\Users\FinanceListTable');

            $resActsOb   = $queryActs
                ->setOrder([
                    "ID" => "DESC"
                ])
                ->setFilter([
                    'UF_COMPANY_ID' => $companyID,
                    //'!STATUS_XML_ID' => ["created"],
                ])
                ->setLimit($arParams["ACTS_COUNT"])
                ->setOffset($offset)
                ->setSelect([
                    '*',
                    'STATUS_' => 'STATUS',
                    'USER_LAST_NAME' => 'USER.LAST_NAME',
                    'USER_NAME' => 'USER.NAME',
                    'USER_SECOND_NAME' => 'USER.SECOND_NAME',
                ])
                ->registerRuntimeField(
                    'STATUS',
                    array(
                        'data_type' => '\Custom\Core\FieldEnumTable',
                        'reference' => array('=this.UF_STATUS' => 'ref.ID'),
                        'join_type' => 'LEFT'
                    )
                )
                ->registerRuntimeField(
                    'USER',
                    array(
                        'data_type' => '\Bitrix\Main\UserTable',
                        'reference' => array('=this.UF_USER_ID' => 'ref.ID'),
                        'join_type' => 'LEFT'
                    )
                )
                ->countTotal(1)
                ->exec();

            $resActs = $resActsOb->fetchAll();

            $statusClass = getActsStatusClass();

            foreach ($resActs as &$act)
            {
                $act["FULL_NAME"] = implode(" ", [$act["USER_LAST_NAME"], $act["USER_NAME"], $act["USER_SECOND_NAME"]]);

                if($act["UF_DATE"])
                {
                    $act["UF_DATE"] = $act["UF_DATE"]->format("d.m.Y, H:i");
                }

                if($act["UF_DATE_SUCCESS"])
                {
                    $act["UF_DATE_SUCCESS"] = $act["UF_DATE_SUCCESS"]->format("d.m.Y, H:i");
                }

                if($act["STATUS_XML_ID"])
                {
                    $act["STATUS_CLASS"] = $statusClass[$act["STATUS_XML_ID"]];
                }

                $act["UF_SUMM"] = number_format($act["UF_SUMM"],2,"."," ");
            }

            $date =  date('d.m.Y');
            $dateFrom = date('01.m.Y 00:00:00', strtotime($date));
            $dateTo = date('t.m.Y 23:59:59', strtotime($date));

            $company["SUMM_MONTH"] = \Custom\Core\Act::getOrdersSum($company["ID"], $dateFrom, $dateTo, true);
            $company["SUMM_MONTH"] = number_format($company["SUMM_MONTH"],2,"."," ");

            $company["UF_BALANCE"] = \Custom\Core\BalanceHistory::getBalanceForCompany($companyID);
            $company["UF_BALANCE"] = number_format($company["UF_BALANCE"],2,"."," ");

            $this->arResult['COMPANY'] = $company;

            $this->arResult['ITEMS'] = $resActs;

            if($arParams["ACTS_COUNT"]) {
                $this->arResult['ALL_COUNT'] = $resActsOb->getCount();
                $this->nav = new \CDBResult();
                $this->nav->NavStart($arParams["ACTS_COUNT"]);
                $this->nav->NavPageCount = ceil((int)$arResult['ALL_COUNT'] / $arParams["ACTS_COUNT"]);
                $this->nav->NavPageNomer = $curPage;
                $this->nav->NavRecordCount = $arResult['ALL_COUNT'];
                $this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');
            }
            //echo "<pre>"; print_r($arResult); echo "</pre>";
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_COMPANY_NOT_FOUND")], JSON_UNESCAPED_UNICODE);
            die;
        }


    }
    else
    {
        echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_NO_COMPANY_FOR_USER")], JSON_UNESCAPED_UNICODE);
        die;
    }



    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}

function getActsStatusClass()
{
    return $class = [
        "created" => "table-status--dark",
        "verif" => "table-status--gray",
        "adjustment" => "table-status--yellow",
        "success" => "table-status--green",
        "original" => "table-status--gray",
        "edo" => "table-status--blue",
        "cancel" => "table-status--red",
    ];
}

?>