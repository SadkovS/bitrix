<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Page\Asset;
use Bitrix\Main\Application;

Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/quill/quill.snow.css");
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.css");
Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/files/libs/picker/picker.min.css");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/air-datepicker/air-datepicker.js");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/quill/quill.js");
Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . "/files/libs/picker/picker.min.js");

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();

?>
<div class="admin-body">
    <div class="admin-body__item wide events">
        <div class="admin-body__item-header">
            <h1>Штрих-коды</h1>
        </div>
        <table class="events__table">
            <thead>
            <tr>
                <td>
                    <div class="events__table-item">
                        <label class="events__table-btn" data-table-sort=""><span>Название</span>
                            <input type="checkbox" class="d-none" name="q_sort" value="1" data-url-search="change"> <i class="_icon-vector"></i>
                        </label>
                        <div class="events__form-item">
                            <input type="text" class="events__form-input " placeholder="Найти" name="q" data-url-search="input">
                            <i class="_icon-search"></i>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <label class="events__table-btn" data-table-sort=""><span>Дата</span><input type="checkbox" data-url-search="change"
                                                                                                    class="d-none"
                                                                                                    name="d_sort"
                                                                                                    value="1"> <i
                                    class="_icon-vector"></i></label>
                        <div class="events__form-item">
                            <input type="text" class="events__form-input" data-date="range" name="d" data-url-search="change">
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Категория</p>
                        <div class="events__form-item">
                            <div class="form-select js-form-select">
                                <div class="form-select__selected-option js-form-select-option js-option-change"
                                     data-placeholder="Выберите из списка">Все
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="">Все
                                        </li>
                                        <? foreach ($arResult['CATEGORY_LIST'] as $category): ?>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="<?= $category['ID'] ?>"><?= $category['UF_NAME'] ?></li>
                                        <? endforeach; ?>
                                    </ul>
                                </div>
                                <input type="hidden" value="" name="c" data-url-search="change">
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Тип</p>
                        <div class="events__form-item">
                            <div class="form-select js-form-select">
                                <div class="form-select__selected-option js-form-select-option js-option-change"
                                     data-placeholder="Выберите из списка">Все
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="">Все
                                        </li>
                                        <? foreach ($arResult['TYPE_LIST'] as $status): ?>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="<?= $status['ID'] ?>"><?= $status['UF_NAME'] ?></li>
                                        <? endforeach; ?>
                                    </ul>
                                </div>
                                <input type="hidden" value="" name="t" data-url-search="change">
                            </div>
                        </div>

                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Билеты, шт.</p>
                        <p>Всего</p>
                    </div>
                </td>
                <td>
                    <div class="events__table-item">
                        <p>Статус</p>
                        <div class="events__form-item">
                            <div class="form-select js-form-select">
                                <div class="form-select__selected-option js-form-select-option js-option-change"
                                     data-placeholder="Выберите из списка">Все
                                </div>
                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                    <ul class="form-select-options form-select__options">
                                        <li class="form-select-options__item js-form-select-options-item"
                                            data-option="">Все
                                        </li>
                                        <? foreach ($arResult['STATUS_LIST'] as $status): ?>
                                            <li class="form-select-options__item js-form-select-options-item"
                                                data-option="<?= $status['ID'] ?>"><?= $status['UF_NAME'] ?></li>
                                        <? endforeach; ?>
                                    </ul>
                                </div>
                                <input type="hidden" value="" name="s" data-url-search="change">
                            </div>
                        </div>

                    </div>
                </td>
                <td></td>
            </tr>
            </thead>
            <tbody>
            <? foreach ($arResult['ITEMS'] as $event): ?>
                <tr <?=  $event['UF_STATUS']['UF_NAME'] == 'Опубликовано' || $event['UF_STATUS']['UF_NAME'] == 'Завершено' ?: 'class="inactive"' ?>
                        data-popup-src="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=getForm"
                        data-popup-dblclick="#create-event"
                >
                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p class="text-break"><a
                                            data-popup-src="<?= $arParams['SEF_FOLDER'] . $event['ID'] ?>/?action=getForm"
                                            data-popup="#create-event"
                                            href="javascript:void(0)"><?= $event['UF_NAME'] ?></a></p>
                                <? if (!empty($event['UF_CODE'])): ?>
                                    <small><?= $event['UF_CODE'] ?></small>
                                <? endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p class="text-center"><?= $event['DATE_TIME'] ?></p>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p><?= $event['UF_CATEGORY']['UF_NAME'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p><?= $event['UF_TYPE']['UF_NAME'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <p><?= (int)$event['TOTAL_QUANTITY'] ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <?
                            $cssClass = '';
                            switch ($event['UF_STATUS']['UF_NAME']) {
                                case 'Отклонено':
                                    $cssClass = 'error';
                                    break;
                                case 'Подтверждено':
                                    $cssClass = 'confirmed';
                                    break;
                                case 'Опубликовано':
                                    $cssClass = 'success';
                                    break;
                                case 'Черновик':
                                    $cssClass = 'draft';
                                    break;
                            }
                            ?>
                            <span class="events__table-item-status <?= $cssClass ?>">
                            <?= ($event['IS_CLOSED'] && $cssClass === 'success') ? $event['UF_STATUS']['UF_NAME'] . ' по ссылке' : $event['UF_STATUS']['UF_NAME']; ?>
                        </span>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-controls">
                            <button class="btn btn__blue btn__fix-width" data-event="<?=$event['ID']?>"  <?=  $event['UF_STATUS']['UF_NAME'] == 'Опубликовано' || $event['UF_STATUS']['UF_NAME'] == 'Завершено' ? 'data-popup="#barcode-add"': 'data-error-msg="Выгрузка штрих-кодов доступна только для опубликованных мероприятий"' ?>>Выгрузить</button>
                        </div>
                    </td>
                </tr>
            <? endforeach; ?>
            </tbody>
        </table>
        <?= $arResult['NAV_STRING'] ?>
    </div>
</div>
<div id="barcode-add" aria-hidden="true" class="popup popup__medium">
    <div class="popup__wrapper">
        <div class="popup__content">
            <button type="button" class="popup__close profile__popup-close" data-close><i class="_icon-plus"></i></button>
            <div class="popup__name text__large">Выгрузка штрих-кодов</div>
            <form class="row d-flex gy-3" action="<?=$APPLICATION->GetCurPage()?>?export=y" method="get" data-barcodes-load-form>
                <input type="hidden" name="EVENT_ID" value="">
                <div class="col-6">
                    <div class="form-item">
                        <label class="form-item__label">Статус</label>
                        <div class="form-select js-form-select ">
                            <div class="form-select__selected-option js-form-select-option js-option-change ps-0" data-placeholder="Выберите из списка">
                                Все
                            </div>
                            <i class="form-select__icon js-form-select-icon color__main _icon-chev"></i>
                            <div class="form-select-options-wrap js-form-select-options-wrap">
                                <ul class="form-select-options form-select__options">
                                    <li class="form-select-options__item js-form-select-options-item" data-option="">
                                       <b>Все</b>
                                    </li>
                                    <?foreach ($arResult['BARCODES_STATUS_LIST'] as $status):?>
                                    <li class="form-select-options__item js-form-select-options-item" data-option="<?=$status['VALUE_ID']?>">
                                        <?=$status['UF_NAME']?>
                                    </li>
                                    <?endforeach;?>
                                </ul>
                            </div>
                            <input type="hidden" name="status" value="">
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-item">
                        <label class="form-item__label">Кодировка</label>
                        <div class="form-select js-form-select ">
                            <div class="form-select__selected-option js-form-select-option js-option-change ps-0" data-placeholder="Выберите из списка">
                                UTF-8
                            </div>
                            <i class="form-select__icon js-form-select-icon color__main _icon-chev"></i>
                            <div class="form-select-options-wrap js-form-select-options-wrap">
                                <ul class="form-select-options form-select__options">
                                    <?foreach ($arResult['BARCODES_CHARSET_LIST'] as $key => $value):?>
                                    <li class="form-select-options__item js-form-select-options-item" data-option="<?=$key?>">
                                        <?=$value?>
                                    </li>
                                    <?endforeach;
                                    unset($key, $value);?>
                                </ul>
                            </div>
                            <input type="hidden" name="charset" value="">
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <p class="text__med fw-bold">Выгружаемые поля</p>
                </div>
                <div class="col-12 d-flex flex-column" data-draggable-container>
                    <?foreach ($arResult['BARCODES_FIELDS_LIST'] as $key => $value):?>
                        <div class="barcode__item draggable__item">
                            <i class="_icon-drag" data-draggable-handler=""></i>
                            <div class="barcode__item-text"><?=$value?></div>
                            <? if  ($key != "UF_BARCODE"): ?>
                                <button type="button" data-barcode-delete>
                                    <i class="_icon-cross"></i>
                                </button>
                            <? endif ?>
                            <input type="hidden" name="col[]" value="<?=$key?>">
                        </div>
                    <?endforeach;
                    unset($key, $value);?>
                </div>
                <div class="col-12">
                    <div class="form-static-select m-0" data-static-select="">
                        <div class="form-static-select__name _icon-plus" data-static-select-name="" data-placeholder="Выберите из списка"><span>Добавить поле</span><span>Добавить поле</span>
                        </div>
                        <i class="form-static-select__icon _icon-chev" data-static-select-icon=""></i>
                        <div class="form-static-select__wrapper" data-static-select-wrapper="">
                            <ul class="form-static-select__options">
                                 <?foreach ($arResult['BARCODES_FIELDS_LIST'] as $key => $value):?>
                                    <li class="form-select-options__item" data-option="<?=$key?>"><?=$value?></li>
                                <?endforeach;
                                unset($key, $value);?>
                            </ul>
                        </div>
                    </div>
                </div>
                 <div class="col-12">
                     <button type="submit" class="btn btn__blue btn__big mx-auto">Выгрузить</button>
                 </div>
            </form>
        </div>
    </div>
</div>