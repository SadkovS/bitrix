<?php
require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/modules/main/include/prolog_before.php");
use Bitrix\Main\Application,
    Bitrix\Main\Context,
    Bitrix\Main\Request,
    Bitrix\Main\Loader,
    Bitrix\Main\Server;
Loader::IncludeModule('iblock');
$request = Context::getCurrent()->getRequest();
$fileID = $request['file'];

if (!empty(trim($_REQUEST['file']))){
    $obFiles = CFile::GetList(array("FILE_SIZE"=>"desc"), array("EXTERNAL_ID"=>$fileID));
    $arFile = $obFiles->GetNext();
    if(count($arFile)>0){
        $filePath = $_SERVER["DOCUMENT_ROOT"].'/upload/'.$arFile["SUBDIR"]."/".$arFile["FILE_NAME"];
        if (file_exists($filePath)) {

            //Передаём отдачу файла NGINX
            header('X-Accel-Redirect: /upload/' . $arFile["SUBDIR"] . "/" . $arFile["FILE_NAME"]);
            header("Content-Type: application/x-force-download");
            header("Content-Disposition: attachment; filename=" . str_replace(',', '.', $arFile['FILE_NAME']));
            exit;
        }


        else{
            \Bitrix\Iblock\Component\Tools::process404(
                "404 Not Found",
                true,
                true,
                true,
                "/404.php"
            );
        }
    }else{
        \Bitrix\Iblock\Component\Tools::process404(
            "404 Not Found",
            true,
            true,
            true,
            "/404.php"
        );
    }
}
else{
    die("good bye!");
}