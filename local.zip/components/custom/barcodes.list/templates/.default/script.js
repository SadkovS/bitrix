$(document).ready(function () {
	let promise


	function printFromData(data, pushState = 'page', url) {
		const doc = new DOMParser().parseFromString(data, "text/html");
		const tbody = doc.querySelector('tbody');
		const pagination = doc.querySelector('.pagination.events__pagination');

		window.history.pushState(pushState, "", url.toString());
		const pageTableBody = document.querySelector('.events__table tbody');
		if (pageTableBody && tbody) {
			pageTableBody.replaceWith(tbody);
		}
		const pagePagination = document.querySelector('.events__pagination');
		if (pagePagination && pagination) {
			pagePagination.replaceWith(pagination);
		}
	}

// Изменение фильтра
	async function pageTableSortFromUrl(e) {
		let reject, resolve;
		promise = new Promise((res, rej) => {
			resolve = res;
			reject = rej;
		});
		let url = new Url(window.location.href);
		url.search = '';
		url.query.ajax = 'Y';
		const inputs = [...document.querySelectorAll('input[data-url-search]')];
		for (let i = 0; i < inputs.length; i++) {
			const item = inputs[i];
			if (item.type === 'checkbox') {
				if (e.target === item) {
					if (item.checked) {
						url.query[item.name] = item.value
					} else {
						url.query[item.name] = 0
					}
				}else{
					delete url.query[item.name];
				}
			} else {
				item.value !== '' ? url.query[item.name] = item.value : delete url.query[item.name];
			}
		}
		url.query.PAGEN_1 = 1;

		const response = await fetch(url);
		if (!response.ok) {
			console.error(response.statusText);
			return
		}
		const data = await response.text();
		printFromData(data, "event search", url);

		resolve();
		return promise;
	}

	// Эвент фильтрации по инпуту
	function inputFilter(e) {
		const target = e.target;
		if (!target.closest('[data-url-search="input"]')) return;
		pageTableSortFromUrl(e);
	}
// Эвент фильтрации по селекту
	function changeFilter(e) {
		const target = e.target;
		if (!target.closest('[data-url-search="change"]')) return;
		pageTableSortFromUrl(e);
	}


// Бинд всех эвентов на страницу
	[
		['change', changeFilter],
		['input', debounce(inputFilter, 500)],
	].forEach(([event, fn]) => {
		document.addEventListener(event, fn);
	});

// Функция дебаунса
	function debounce(func, wait, immediate) {
		let timeout;
		return function() {
			const context = this;
			const args = arguments;
			const later = function() {
				timeout = null;
				if (!immediate) func.apply(context, args);
			};
			const callNow = immediate && !timeout;
			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
			if (callNow) func.apply(context, args);
		};
	}
})


// // barcode load
    function barcodeInit() {
        const container = document.querySelector('#barcode-add');

        if (!container) return;
        const barcodeItems = Array.from(container.querySelectorAll('.barcode__item'));
        const selectorItems = Array.from(container.querySelectorAll('[data-static-select] [data-option]'));
        const select = container.querySelector('[data-static-select]');
        let counter = 0;
        for (let i = 0; i < barcodeItems.length; i++) {
            const barcodeItem = barcodeItems[i];
            const searchSame = selectorItems.filter(item => item.getAttribute('data-option') === barcodeItem.querySelector('input[type="hidden"]').value && !barcodeItem.hidden);
            if (searchSame.length) {
                searchSame[0].style.display = 'none';
                counter++;
            }
        }

        if (counter === barcodeItems.length) {
            select.style.display = 'none';
        } else {
            select.style.display = 'block';
        }
    }

    function barcodesDelete(e) {
        const target = e.target;
        if (!('closest' in target)) return;
        const btn = target.closest('#barcode-add [data-barcode-delete]');
        if (!btn) return;
        const parent = btn.closest('#barcode-add');
        const selectorItems = Array.from(parent.querySelectorAll('[data-static-select] [data-option]'));
        const block = btn.closest('.barcode__item');
        const input = block.querySelector('input[type="hidden"]');
        const select = parent.querySelector('[data-static-select]');
        block.setAttribute('hidden', '');
        input.setAttribute('disabled', '');

        const option = parent.querySelector(`[data-static-select] [data-option="${input.value}"]`);
        option.style.display = 'block';
        select.style.display = 'block';
    }

    function barcodeAdd(e) {
        const target = e.target;
        if (!('closest' in target)) return;
        const btn = target.closest('#barcode-add [data-static-select] [data-option]');
        if (!btn) return;
        const parent = btn.closest('#barcode-add');
        const btnValue = btn.getAttribute('data-option');
        const input = parent.querySelector(`input[value="${btnValue}"]`);
        const barcode = input.closest('.barcode__item');
        barcode.removeAttribute('hidden');
        input.removeAttribute('disabled');
        barcodeInit();
    }

    function openBarcodePopup(e) {
        const popup = e.detail.popup
        if (popup.targetOpen.selector !== "#barcode-add") return;
        const openBtn = popup.lastFocusEl
        const body = popup.targetOpen.element
        const input = body.querySelector('input[name="EVENT_ID"]');
        input.value = openBtn.getAttribute('data-event');
		barcodeInit();
    }

    async function barcodesFormSubmit(e) {
        const target = e.target;
        if (!('closest' in target)) return;
        const form = target.closest('[data-barcodes-load-form]');
        if (!form) return;
        e.preventDefault();
        const addr =  form.getAttribute('action');
        const data = new FormData(form);

        const response = await fetch(  addr, {
            method: 'POST',
            body: data
        });
        if (!response.ok) {
           console.error(response.statusText);
            return
        }

        const type = response.headers.get('content-type');
        if (type.includes('application/json')) {
            const data = await response.json();
            showToast(data)
            return
        }
        const reader = response.body.getReader();
        const nameHeader =  response.headers.get('content-disposition');

        const fileName = nameHeader?.split('filename=')[1] || 'file.csv';
        const chunks = [];
        while (true) {
            const {done, value} = await reader.read();
            if (done) {
                showToast({status: "success", message: "Файл готов для скачивания", title: "Успех"});
                break
            }
            chunks.push(value);
        }
        const blob = new Blob(chunks, { type: type});
        const urlDownload = window.URL.createObjectURL(blob);
        const l = document.createElement("a");
        l.href = urlDownload;
        l.download = fileName;
        l.click();
        l.remove();
        URL.revokeObjectURL(l.href);
    }

// Бинд всех эвентов на страницу
     [
        ['click', barcodesDelete],
        ['click', barcodeAdd],
		['afterPopupOpen', openBarcodePopup],
        ['submit', barcodesFormSubmit],
    ].forEach(([event, fn]) => {
        document.addEventListener(event, fn)
    });

