<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;

$app       = Application::getInstance();
$context   = $app->getContext();
$request   = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('iblock') ||
    !Loader::includeModule('sale')
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}
if ($companyID < 1) {
    ShowError(GetMessage("HLDB_COMPANY_ID_EMPTY"));
    return;
}

if (!isset($arParams["CACHE_TIME"]))
    $arParams["CACHE_TIME"] = 180;

$curPage = (int)$request['PAGEN_1'] > 0 ? (int)$request['PAGEN_1'] : 1;
if (!isset($_REQUEST['PAGEN_1']) || (int)$_REQUEST['PAGEN_1'] <= 1)
    $offset = 0;
else
    $offset = ((int)$_REQUEST['PAGEN_1'] - 1) * $arParams["EVENTS_COUNT"];

$arParams['HLDB_EVENTS_STATUS_ID'] = (int)$arParams['HLDB_EVENTS_STATUS_ID'];
if ($arParams['HLDB_EVENTS_STATUS_ID'] < 1) {
    ShowError(GetMessage("HLDB_EVENTS_STATUS_ID_EMPTY"));
    return;
}
$query                         = new ORM\Query\Query('\Custom\Core\Events\EventsStatusTable');
$this->arResult['STATUS_LIST'] = [];
$resStatus                     = $query
    ->setSelect(['ID', 'UF_NAME'])
    ->setOrder(['UF_SORT' => 'ASC'])
    ->setCacheTtl(3600)
    ->exec();
while ($status = $resStatus->fetch()) {
    $this->arResult['STATUS_LIST'][$status['ID']] = $status;
}
unset($query, $resStatus, $status);

$arParams['HLDB_EVENTS_CATEGORY_ID'] = (int)$arParams['HLDB_EVENTS_CATEGORY_ID'];
if ($arParams['HLDB_EVENTS_STATUS_ID'] < 1) {
    ShowError(GetMessage("HLDB_EVENTS_CATEGORY_ID_EMPTY"));
    return;
}

$query                           = new ORM\Query\Query('\Custom\Core\Events\EventsCategoryTable');
$this->arResult['CATEGORY_LIST'] = [];
$resCategory                     = $query
    ->setSelect(['ID', 'UF_NAME'])
    ->setOrder(['UF_SORT' => 'ASC'])
    ->setCacheTtl(3600)
    ->exec();
while ($category = $resCategory->fetch()) {
    $this->arResult['CATEGORY_LIST'][$category['ID']] = $category;
}
unset($query, $resCategory, $category);

$arParams['HLDB_EVENTS_ID'] = (int)$arParams['HLDB_EVENTS_ID'];
if ($arParams['HLDB_EVENTS_ID'] < 1) {
    ShowError(GetMessage("HLDB_EVENTS_ID_EMPTY"));
    return;
}

$query                       = new ORM\Query\Query('\Custom\Core\FieldEnumTable');
$this->arResult['TYPE_LIST'] = [];
$resType                     = $query
    ->setSelect(['ID', 'UF_NAME' => 'VALUE'])
    ->setOrder(['SORT' => 'ASC'])
    ->setFilter(['USER_FIELD_ID' => 48])
    ->setCacheTtl(3600)
    ->exec();
while ($type = $resType->fetch()) {
    $this->arResult['TYPE_LIST'][$type['ID']] = $type;
}
unset($query, $resType, $type);

$query = new ORM\Query\Query('\Custom\Core\FieldTable');
$this->arResult['BARCODES_STATUS_LIST'] = [];
$resBarcodeStatus = $query
    ->setSelect(
        [
            'ID',
            'ENTITY_ID',
            'FIELD_NAME',
            'UF_XML_ID' => 'UF_ENUM_VALUES_REF.XML_ID',
            'VALUE_ID' => 'UF_ENUM_VALUES_REF.ID',
            'UF_NAME' => 'UF_ENUM_VALUES_REF.VALUE',
        ]
    )
    ->setOrder(['SORT' => 'ASC'])
    ->setFilter(
        [
            'ENTITY_ID'  => 'HLBLOCK_'.HL_BARCODES_ID,
            'FIELD_NAME' => 'UF_STATUS'
        ]
    )
    ->registerRuntimeField(
        new \Bitrix\Main\Entity\ReferenceField(
            'UF_ENUM_VALUES_REF',
            '\Custom\Core\FieldEnumTable',
            ['this.ID' => 'ref.USER_FIELD_ID'],
            ['join_type' => 'LEFT']
        )
    )
    ->setCacheTtl(3600)
    ->exec();
while ($status = $resBarcodeStatus->fetch()) {
    $this->arResult['BARCODES_STATUS_LIST'][$status['VALUE_ID']] = $status;
}
unset($query, $resBarcodeStatus, $status);

$this->arResult['BARCODES_CHARSET_LIST'] = ['utf8' => 'UTF-8','cp1251' => 'Windows-1251'];
$this->arResult['BARCODES_FIELDS_LIST'] = [
    'UF_BARCODE' => 'Штрих-код',
    'UF_OFFER_TYPE' => 'Категория билета',
    'UF_ROW' => 'Номер ряда',
    'UF_SEAT' => 'Номер места',
    'UF_PRICE' => 'Цена билета',
    'STATUS_NAME' => 'Статус штрих-кода'
];

if(isset($request['export']) && $request['export'] == 'y') {
    $APPLICATION->RestartBuffer();
    require_once 'export.php';
    $exporter = new BarcodeExporter($this->arResult, $request);
    $exporter->export();
    die;
}

//Поиск и фильтрация
$filter = [];
if (isset($request['q']) && !empty($request['q'])) {
    $filter[] = [
        "LOGIC" => 'OR',
        ["%UF_NAME" => $request['q']],
    ];
}
if (isset($request['d']) && !empty($request['d'])) {
    $date = explode('-', $request['d']);
    if (count($date) > 1) {
        $filter[] = [
            "LOGIC" => 'AND',
            [">=UF_LOCATION_REF.DATE_TIME.VALUE" => $date[0] . ' 00:00:00'],
            ["<=UF_LOCATION_REF.DATE_TIME.VALUE" => $date[1] . ' 23:59:59'],
        ];
    } else {
        $filter[] = [
            "LOGIC" => 'AND',
            [">=UF_LOCATION_REF.DATE_TIME.VALUE" => $date[0] . ' 00:00:00'],
            ["<=UF_LOCATION_REF.DATE_TIME.VALUE" => $date[0] . ' 23:59:59'],
        ];
    }
}

if (isset($request['c']) && !empty($request['c'])) {
    $filter['=UF_CATEGORY'] = $request['c'];
}
if (isset($request['t']) && !empty($request['t'])) {
    $filter['=UF_TYPE'] = $request['t'];
}
if (isset($request['s']) && !empty($request['s'])) {
    $filter['=UF_STATUS'] = $request['s'];
}


$hlblock     = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
$entity      = HL\HighloadBlockTable::compileEntity($hlblock);
$entityClass = $entity->getDataClass();

$arParams['HLDB_EVENTS_ID'] = (int)$arParams['HLDB_EVENTS_ID'];
$filter['UF_COMPANY_ID']    = $companyID;

$select = [
    'ID',
    'UF_NAME',
    'MIN_DATE',
    'MAX_DATE',
    'UF_CATEGORY',
    'UF_TYPE',
    'UF_STATUS',
];

$order = ['ID' => 'DESC'];

if (isset($request['q_sort'])) {
    $order = ['UF_NAME' => (int)$request['q_sort'] ? 'ASC' : 'DESC'];
}

if (isset($request['d_sort'])) {
    $order = ['MIN_DATE' => (int)$request['d_sort'] ? 'ASC' : 'DESC'];
}

$runtime = [
    new \Bitrix\Main\Entity\ReferenceField(
        'PICTURE',
        '\Bitrix\Main\FileTable',
        ['this.UF_IMG' => 'ref.ID'],
        ['join_type' => 'LEFT'],
    ),
    new  \Bitrix\Main\Entity\ReferenceField(
        'UF_LOCATION_REF',
        '\Custom\Core\Events\EventsDateAndLocationTable',
        ['this.ID' => 'ref.UF_EVENT_ID'],
        ['join_type' => 'LEFT']
    ),
    new  \Bitrix\Main\Entity\ReferenceField(
        'UF_LOCATION_DATE_REF',
        '\Custom\Core\Events\EventsDateAndLocationTable',
        ['this.ID' => 'ref.UF_EVENT_ID'],
        ['join_type' => 'LEFT']
    ),
    new \Bitrix\Main\Entity\ExpressionField('MIN_DATE', "MIN(%s)", ['UF_LOCATION_DATE_REF.DATE_TIME.VALUE']),
    new \Bitrix\Main\Entity\ExpressionField('MAX_DATE', "MAX(%s)", ['UF_LOCATION_DATE_REF.DATE_TIME.VALUE'])
];

$productEntity         = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
$propFieldEventID      = $productEntity->getField('EVENT_ID');
$propEventIDEntity     = $propFieldEventID->getRefEntity();
$propFieldClosed       = $productEntity->getField('IS_CLOSED_EVENT');
$propFieldClosedEntity = $propFieldClosed->getRefEntity();

// Добавляем связь с продуктом через свойство EVENT_ID
$runtime[] = new \Bitrix\Main\Entity\ReferenceField(
    'PRODUCT',
    $propEventIDEntity,
    ['this.ID' => 'ref.VALUE'],
    ['join_type' => 'LEFT'],
);

// Добавляем поля в select после определения runtime
$select['PRODUCT_ID'] = 'PRODUCT.IBLOCK_ELEMENT_ID';

// Основной запрос
$resEvents = $entityClass::getList(
    [
        'select'      => $select,
        'filter'      => $filter,
        'order'       => $order,
        'group'       => 'ID',
        'offset'      => $offset,
        'limit'       => $arParams["EVENTS_COUNT"],
        'runtime'     => $runtime,
        'count_total' => true,
        //        'cache'       => [
        //            'ttl' => $arParams['CACHE_TIME']
        //        ]
    ]
);

$this->arResult['ITEMS']    = [];
$this->arResult['CATEGORY'] = $this->arResult['CATEGORY_LIST'];
$this->arResult['TYPE']     = $this->arResult['TYPE_LIST'];
$this->arResult['STATUS']   = $this->arResult['STATUS_LIST'];
$arEventsIDs                = [];
$arProductIDs = [];

while ($event = $resEvents->fetch()) {
    $event['IS_CLOSED'] = false; // Устанавливаем значение по умолчанию
    if (empty($event['MIN_DATE'])) $event['DATE_TIME'] = '';
    elseif ($event['MIN_DATE'] == $event['MAX_DATE']) $event['DATE_TIME'] = (new \DateTime($event['MIN_DATE']))->format('d.m.Y');
    else $event['DATE_TIME'] = (new \DateTime($event['MIN_DATE']))->format('d.m.Y') . ' - ' . (new \DateTime($event['MAX_DATE']))->format('d.m.Y');

    if (is_object($event['STATUS_DATE'])) {
        $event['STATUS_DATE'] = (new \DateTime($event['STATUS_DATE']))->format('d.m.Y H:i:s');
    }
    $event['UF_CATEGORY']                  = $this->arResult['CATEGORY_LIST'][$event['UF_CATEGORY']];
    $event['UF_STATUS']                    = $this->arResult['STATUS_LIST'][$event['UF_STATUS']];
    $event['UF_TYPE']                      = $this->arResult['TYPE_LIST'][$event['UF_TYPE']];

    // Инициализируем значения по умолчанию
    $event['TOTAL_QUANTITY'] = 0;
    $event['SOLD_QUANTITY']  = 0;
    
    $this->arResult['ITEMS'][$event['ID']] = $event;
    $arEventsIDs[]                         = $event['ID'];
    if ($event['PRODUCT_ID']) {
        $arProductIDs[] = $event['PRODUCT_ID'];
    }
}

// Получаем TOTAL_QUANTITY отдельным быстрым запросом
if (!empty($arProductIDs)) {
    $offerEntity        = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
    $totalQuantityQuery = new ORM\Query\Query($offerEntity);
    $totalQuantityRes   = $totalQuantityQuery
        ->setSelect(
            [
                'PRODUCT_ID'       => 'CML2_LINK.VALUE',
                'TICKETS_QUANTITY' => 'TOTAL_QUANTITY.VALUE'
            ]
        )
        ->setFilter(
            [
                'CML2_LINK.VALUE'       => $arProductIDs,
                '!TOTAL_QUANTITY.VALUE' => false
            ]
        )
        //->setCacheTtl(1800)
        ->exec();

    $totalQuantities = [];
    while ($totalQuantity = $totalQuantityRes->fetch()) {
        if (!isset($totalQuantities[$totalQuantity['PRODUCT_ID']])) {
            $totalQuantities[$totalQuantity['PRODUCT_ID']] = 0;
        }
        $totalQuantities[$totalQuantity['PRODUCT_ID']] += (int)$totalQuantity['TICKETS_QUANTITY'];
    }

    // Применяем данные к событиям
    foreach ($this->arResult['ITEMS'] as &$event) {
        if ($event['PRODUCT_ID'] && isset($totalQuantities[$event['PRODUCT_ID']])) {
            $event['TOTAL_QUANTITY'] = $totalQuantities[$event['PRODUCT_ID']];
        }
    }
    unset($event);
}

// Получаем SOLD_QUANTITY отдельным быстрым запросом
if (!empty($arEventsIDs)) {
    $soldQuantityQuery = new ORM\Query\Query('Bitrix\Sale\Order');
    $soldQuantityRes   = $soldQuantityQuery
        ->setSelect(
            [
                'EVENT_ID'      => 'PROPERTY_EVENT.VALUE',
                'SOLD_QUANTITY' => 'BASKET_REFS.QUANTITY'
            ]
        )
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY_EVENT',
                'Bitrix\Sale\Internals\OrderPropsValueTable',
                ['=this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'INNER']
            )
        )
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ReferenceField(
                'BASKET_REFS',
                'Bitrix\Sale\Internals\BasketTable',
                ['this.ID' => 'ref.ORDER_ID'],
                ['join_type' => 'INNER']
            )
        )
        ->setFilter(
            [
                'PAYED'                 => 'Y',
                'PROPERTY_EVENT.CODE'   => 'EVENT_ID',
                'PROPERTY_EVENT.VALUE'  => $arEventsIDs,
                '!BASKET_REFS.QUANTITY' => false
            ]
        )
        //->setCacheTtl(1800)
        ->exec();

    $soldQuantities = [];
    while ($soldQuantity = $soldQuantityRes->fetch()) {
        if (!isset($soldQuantities[$soldQuantity['EVENT_ID']])) {
            $soldQuantities[$soldQuantity['EVENT_ID']] = 0;
        }
        $soldQuantities[$soldQuantity['EVENT_ID']] += (int)$soldQuantity['SOLD_QUANTITY'];
    }

    // Применяем данные к событиям
    foreach ($this->arResult['ITEMS'] as &$event) {
        if (isset($soldQuantities[$event['ID']])) {
            $event['SOLD_QUANTITY'] = $soldQuantities[$event['ID']];
        }
    }
    unset($event);
}

$this->arResult['ALL_COUNT'] = $resEvents->getCount();
$this->nav                   = new \CDBResult();
$this->nav->NavStart($arParams["EVENTS_COUNT"]);
$this->nav->NavPageCount      = ceil((int)$arResult['ALL_COUNT'] / $arParams["EVENTS_COUNT"]);
$this->nav->NavPageNomer      = $curPage;
$this->nav->NavRecordCount    = $arResult['ALL_COUNT'];
$this->arResult['NAV_STRING'] = $this->nav->GetPageNavStringEx($navComponentObject, '', 'events_list_nav', 'Y');

//$this->SetResultCacheKeys([]);
$this->IncludeComponentTemplate();

//$this->AbortResultCache();
?>
