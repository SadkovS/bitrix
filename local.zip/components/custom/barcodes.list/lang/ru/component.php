<?
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Модуль Информационных блоков не установлен";
$MESS ['HLDB_COMPANY_ID_EMPTY'] = "Не удалось определить ID компании";
?>