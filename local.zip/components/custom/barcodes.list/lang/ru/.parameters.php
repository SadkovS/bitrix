<?
$MESS["HLDB_EVENTS_ID"] = "ID хайлоадблока событий";
$MESS["HLDB_EVENTS_STATUS_ID"] = "ID хайлоадблока статусов событий";
$MESS["HLDB_EVENTS_CATEGORY_ID"] = "ID хайлоадблока категорий событий";
$MESS["HLDB_EVENTS_LOCATION_ID"] = "ID хайлоадблока локаций";
$MESS["IBLOCK_ANY"] = "(любой)";
$MESS["CP_BPR_CACHE_GROUPS"] = "Учитывать права доступа";
?>