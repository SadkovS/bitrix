<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
{
	die();
}

$arComponentParameters = [
	"GROUPS" => [
	],
	"PARAMETERS" => [
        "HLDB_EVENTS_ID" => [
            "PARENT" => "BASE",
            "NAME" => GetMessage("HLDB_EVENTS_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => '',
        ],
        "HLDB_EVENTS_STATUS_ID" => [
            "PARENT" => "BASE",
            "NAME" => GetMessage("HLDB_EVENTS_STATUS_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => '',
        ],
        "HLDB_EVENTS_CATEGORY_ID" => [
            "PARENT" => "BASE",
            "NAME" => GetMessage("HLDB_EVENTS_CATEGORY_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => '',
        ],
		"CACHE_TIME"  =>  ["DEFAULT"=>180],
		"CACHE_GROUPS" => [
			"PARENT" => "CACHE_SETTINGS",
			"NAME" => GetMessage("CP_BPR_CACHE_GROUPS"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "Y",
		],
	],
];
