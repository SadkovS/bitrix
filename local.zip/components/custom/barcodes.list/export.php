<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\ORM;
use Bitrix\Main\Entity\ReferenceField;

class BarcodeExporter {
    private $arResult;
    private $request;
    private $companyID;
    private $charset;
    private const LIMIT = 1000;
    private $fileName;

    public function __construct($arResult, $request)
    {
        $this->arResult  = $arResult;
        $this->request   = $request;
        $this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
        $this->charset   = $this->getCharset();
        $this->fileName  = "Export_barcode_" . (new \DateTime())->format('d.m.Y_H:i') . ".csv";
    }

    private function getCharset()
    {
        return key_exists($this->request['charset'], $this->arResult['BARCODES_CHARSET_LIST'])
            ? $this->arResult['BARCODES_CHARSET_LIST'][$this->request['charset']]
            : 'UTF-8';
    }

    private function buildQuery()
    {
        $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $eventEntity   = new ORM\Query\Query('Custom\Core\Events\EventsTable');

        $filter = [
            'UF_COMPANY_ID' => $this->companyID,
            'ID'            => $this->request['EVENT_ID'],
        ];

        if (isset($this->request['status']) && (int)$this->request['status'] > 0) $filter['UF_BARCODES_REF.UF_STATUS'] = $this->request['status'];

        return $eventEntity
            ->setSelect(
                [
                    'UF_NAME',
                    'UF_BARCODE'    => 'UF_BARCODES_REF.UF_BARCODE',
                    'UF_OFFER_TYPE' => 'UF_OFFERS_REF.TYPE.VALUE',
                    'STATUS_NAME'   => 'BARCODE_STATUS_REF.VALUE',
                    'UF_PRICE'      => 'PRICE.PRICE',
                    'OFFER_ID'      => 'UF_BARCODES_REF.UF_OFFER_ID',
                    'UF_ROW'     => 'ROW_PROP.VALUE',
                    'UF_SEAT'   => 'PLACE_PROP.VALUE',
                ]
            )
            ->setFilter($filter)
            ->registerRuntimeField($this->getBarcodesReference())
            ->registerRuntimeField(new \Bitrix\Main\Entity\ExpressionField(
                'BARCODES_ID_STR',
                'CAST(%s AS CHAR)',
                ['UF_BARCODES_REF.ID']
            ))
            ->registerRuntimeField(new ReferenceField(
                'BARCODE_PROP',
                '\Bitrix\Sale\Internals\BasketPropertyTable',
                [
                    '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?', 'BARCODE'),
                    '=ref.VALUE' => 'this.BARCODES_ID_STR',
                ],
                ['join_type' => 'LEFT']
            ))
            ->registerRuntimeField(new \Bitrix\Main\Entity\ExpressionField(
                'BARCODE_BASKET_ID',
                'COALESCE(%s, 0)',
                ['BARCODE_PROP.BASKET_ID']
            ))
            ->registerRuntimeField(new ReferenceField(
                'ROW_PROP',
                '\Bitrix\Sale\Internals\BasketPropertyTable',
                [
                    '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?', 'ROW'),
                    '=ref.BASKET_ID' => 'this.BARCODE_BASKET_ID'
                ],
                ['join_type' => 'LEFT']
            ))
            ->registerRuntimeField(new ReferenceField(
                'PLACE_PROP',
                '\Bitrix\Sale\Internals\BasketPropertyTable',
                [
                    '=ref.CODE' => new \Bitrix\Main\DB\SqlExpression('?', 'PLACE'),
                    '=ref.BASKET_ID' => 'this.BARCODE_BASKET_ID'
                ],
                ['join_type' => 'LEFT']
            ))
            ->registerRuntimeField($this->getOffersReference($productEntity))
            ->registerRuntimeField($this->getPriceReference())
            ->registerRuntimeField($this->getStatusReference())
            ->countTotal(true);
    }

    private function getBarcodesReference()
    {
        return new ReferenceField(
            'UF_BARCODES_REF',
            '\Custom\Core\Tickets\BarcodesTable',
            ['this.ID' => 'ref.UF_EVENT_ID'],
            ['join_type' => 'LEFT']
        );
    }

    private function getOffersReference($productEntity)
    {
        return new ReferenceField(
            'UF_OFFERS_REF',
            $productEntity,
            ['this.OFFER_ID' => 'ref.ID'],
            ['join_type' => 'LEFT']
        );
    }

    private function getPriceReference()
    {
        return new ReferenceField(
            'PRICE',
            '\Bitrix\Catalog\PriceTable',
            ['this.OFFER_ID' => 'ref.PRODUCT_ID'],
            ['join_type' => 'LEFT']
        );
    }

    private function getStatusReference()
    {
        return new ReferenceField(
            'BARCODE_STATUS_REF',
            '\Custom\Core\FieldEnumTable',
            ['this.UF_BARCODES_REF.UF_STATUS' => 'ref.ID'],
            ['join_type' => 'LEFT']
        );
    }

    private function getFileFields()
    {
        if (!isset($this->request['col']) || !is_array($this->request['col'])) {
            return $this->arResult['BARCODES_FIELDS_LIST'];
        }

        $arFileFields = [];
        foreach ($this->request['col'] as $field) {
            if (key_exists($field, $this->arResult['BARCODES_FIELDS_LIST'])) {
                $arFileFields[$field] = $this->arResult['BARCODES_FIELDS_LIST'][$field];
            }
        }

        return $arFileFields;
    }

    private function setHeaders()
    {
        header('Content-Description: File Transfer');
        header('Content-Type: text/csv; charset=' . $this->charset);
        header("Content-Disposition: attachment; filename=" . $this->fileName);
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
    }

    private function writeRow($rowFields)
    {
        $text = implode(';', $rowFields);
        if ($this->charset == 'Windows-1251') {
            $text = iconv('utf-8//IGNORE', 'windows-1251//IGNORE', $text);
        }
        print $text . PHP_EOL;
    }

    public function export()
    {
        $query = $this->buildQuery()->exec();

        if ($query->getCount() === 0) {
            if (isset($this->request['status']) && (int)$this->request['status'] > 0){
                $name = $this->getStatusName((int)$this->request['status']);
                $message = 'Штрих-коды со статусом "'.$name.'" отсутствуют.';
            }else{
                $message = 'Штрих-коды не найдены';
            }
            //getStatus
            $this->showError($message);
            return false;
        }

        $arFileFields = $this->getFileFields();

        // Write BOM for UTF-8 and header row
        if ($this->getCharset() == 'UTF-8') print chr(0xEF) . chr(0xBB) . chr(0xBF);

        $this->writeRow($arFileFields);

        // Write data rows

        while ($row = $query->fetch()) {
            $rowFields = [];
            foreach ($arFileFields as $field => $value) {
                $rowFields[] = $row[$field];
            }
            $this->writeRow($rowFields);
        }

        $this->setHeaders();

        return true;
    }

    private function showError(string $message): void
    {
        header("Content-type: application/json; charset=utf-8");
        echo json_encode(['status' => 'error', 'message' => $message], JSON_UNESCAPED_UNICODE);
    }

    private function getStatusName(int $id): string
    {
        $query   = new ORM\Query\Query('\Custom\Core\FieldEnumTable');
        $resType = $query
            ->setSelect(['ID', 'VALUE'])
            ->setOrder(['SORT' => 'ASC'])
            ->setFilter(['ID' => $id])
            ->setCacheTtl(3600)
            ->exec();
        $status  = $resType->fetch();
        return $status['VALUE'];
    }
}