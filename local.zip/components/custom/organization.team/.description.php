<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("NAME"),
	"DESCRIPTION" => GetMessage("DESCRIPTION"),
	"COMPLEX" => "Y",
	"PATH" => array(
        "ID" => "custom",
		"CHILD" => array(
			"ID" => "organizations.team",
			"NAME" => GetMessage("DESC"),
			"SORT" => 10,
			"CHILD" => array(
				"ID" => "organizations_team_cmpx",
			),
		),
	),
);

?>