<?
$MESS ['NAME'] = "Команда";
$MESS ['DESCRIPTION'] = "Раздел Команда";
$MESS ['DESC'] = "Команда";
?>