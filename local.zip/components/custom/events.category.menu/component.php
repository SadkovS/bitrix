<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use \Bitrix\Main\Localization\Loc;

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('catalog') ||
    !Loader::IncludeModule("iblock")
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    $productEntity     = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
    $productPropField  = $productEntity->getField('EVENT_ID');
    $productPropEntity = $productPropField->getRefEntity();
    $propFieldClosed       = $productEntity->getField('IS_CLOSED_EVENT');
    $propFieldClosedEntity = $propFieldClosed->getRefEntity();
    $propFieldModeration       = $productEntity->getField('MODERATION');
    $propFieldModerationEntity = $propFieldModeration->getRefEntity();
    
    $filter = [
        "=STATUS_REF.UF_XML_ID" => ["published"],
        "=ELEMENT.ACTIVE" => "Y",
        "=PROP_CLOSED_REF.VALUE" => null,
        "=PROP_MODERATION_REF.VALUE" => null,
        [
            'LOGIC' => 'OR',
            ['ELEMENT.ACTIVE_FROM' => false],
            ['<=ELEMENT.ACTIVE_FROM' => date('d.m.Y H:i:s')]
        ],
        [
            'LOGIC' => 'OR',
            ['ELEMENT.ACTIVE_TO' => false],
            ['>=ELEMENT.ACTIVE_TO' => date('d.m.Y H:i:s')]
        ],
    ];

    if($GLOBALS[$this->arParams["FILTER_NAME"]] && array_key_exists("PROPERTY_EVENT_ID", $GLOBALS[$this->arParams["FILTER_NAME"]]))
    {
        $filter["=EVENT.ID"] = $GLOBALS[$this->arParams["FILTER_NAME"]]["PROPERTY_EVENT_ID"];
    }

    $eventEntity  = new ORM\Query\Query('Custom\Core\Events\EventsCategoryTable');
    $resEntity    = $eventEntity
        ->setFilter($filter)
        ->setOrder(["UF_SORT" => "ASC"])
        ->setSelect([
            'UF_NAME',
            'UF_CODE',
            'ICON_CLASS' => 'ICON.XML_ID',
        ])
        ->registerRuntimeField(
            'ICON',
            array(
                'data_type' => '\Custom\Core\FieldEnumTable',
                'reference' => array('=this.UF_ICON' => 'ref.ID'),
                'join_type' => 'LEFT'
            )
        )
        ->registerRuntimeField(
            'EVENT',
            array(
                'data_type' => '\Custom\Core\Events\EventsTable',
                'reference' => array('=this.ID' => 'ref.UF_CATEGORY'),
                'join_type' => 'LEFT'
            )
        )
        ->registerRuntimeField(
            'EVENT_REF',
            array(
                'data_type' => $productPropEntity,
                'reference' => array('=this.EVENT.ID' => 'ref.VALUE'),
                'join_type' => 'LEFT'
            )
        )
        ->registerRuntimeField(
            'ELEMENT',
            array(
                'data_type' => $productEntity,
                'reference' => array('=this.EVENT_REF.IBLOCK_ELEMENT_ID' => 'ref.ID'),
                'join_type' => 'LEFT'
            )
        )
        ->registerRuntimeField(
            'STATUS_REF',
            array(
                'data_type' => '\Custom\Core\Events\EventsStatusTable',
                'reference' => array('=this.EVENT.UF_STATUS' => 'ref.ID'),
                'join_type' => 'LEFT'
            )
        )
        ->registerRuntimeField(
            'PROP_CLOSED_REF',
            array(
                'data_type' => $propFieldClosedEntity,
                'reference' => array('this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'),
                'join_type' => 'LEFT'
            )
        )
        ->registerRuntimeField(
            'PROP_MODERATION_REF',
            array(
                'data_type' => $propFieldModerationEntity,
                'reference' => array('=this.ELEMENT.ID' => 'ref.IBLOCK_ELEMENT_ID'),
                'join_type' => 'LEFT'
            )
        )
        ->setDistinct()
        ->exec()
        ->fetchAll();

        foreach ($resEntity as &$item)
        {
            if($item["UF_CODE"])
                $item["DETAIL_PAGE"] = str_replace("#CODE#", $item["UF_CODE"], $this->arParams["DETAIL_PAGE"]);
        } unset($item);

        $this->arResult["ITEMS"] = $resEntity;

    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}

?>