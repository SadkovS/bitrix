<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
    die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>

<div class="group/list menu__block inline-flex flex-col gap-c_narrow items-start w-full xl:max-w-[47.9375rem] laptop:h-c_sxl laptop:flex-row-reverse laptop:gap-0"
    data-in=".js-xl-search, 1399, 1" data-menu-list>
    <input type="checkbox" id="categoryes-toggle" class="hidden categoryes-toggle">
    <?php if ($arResult["ITEMS"]): ?>
        <ul class="menu__list  laptop:overflow-hidden js-cat-list">
            <? foreach ($arResult["ITEMS"] as $item): ?>
                <li class="menu__item ">
                    <a href="<?= $item["DETAIL_PAGE"] ?>" class="menu__link">
                        <i class="<?= $item["ICON_CLASS"] ?>"></i>
                        <span><?= $item["UF_NAME"] ?></span>
                    </a>
                </li>
            <? endforeach; ?>
            <li class="menu__item hidden laptop:block categoryes-toggle__label group-[.hide-dots]/list:!hidden">
                <label class="menu__link" for="categoryes-toggle">
                    <span class="svg_icon-points"></span>
                </label>
            </li>
        </ul>
    <?php endif; ?>
    <button class="btn__filter lg:hidden" data-popup="#filter">
        <i class="svg_icon-filter"></i>
    </button>
</div>