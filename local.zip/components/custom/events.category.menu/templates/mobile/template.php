<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>

<div class="filter__item">
    <div class="filter__label">
        <span class="filter__label-name">Категории</span>
        <button class="filter__label-reset" type="button" data-filter-block-reset>Сбросить</button>
    </div>

    <div class="filter__item-list">

        <?foreach ($arResult["ITEMS"] as $item):?>

            <label class="filter__item-tag">
                <input type="checkbox" class="hidden">
                <span class="tag">
                    <?=$item["UF_NAME"]?>
                </span>
            </label>

        <?endforeach;?>

    </div>
</div>