<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Custom\Core\Products;
use Custom\Core\PriceRules;
use \Bitrix\Main\Localization\Loc;
use \Custom\Core\Contract as ContractCore;

$app     = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest()->toArray();;
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('catalog') ||
    !Loader::IncludeModule("iblock")
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {
    if (
        isset($request['action']) &&
        isset($request['summ']) &&
        $request['action'] == 'add'
    )
    {
        $APPLICATION->RestartBuffer();

        if(!check_bitrix_sessid())
        {
            echo json_encode(['status' => 'error', 'message' => 'Ошибка сессии'], JSON_UNESCAPED_UNICODE);
        }

        if($request['summ'] <= 0)
        {
            echo json_encode(['status' => 'error', 'message' => 'Операция не возможна'], JSON_UNESCAPED_UNICODE);
            die();
        }

        if($companyID)
        {
            $query = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
            $resCompany   = $query
                ->setFilter(['ID' => $companyID])
                ->setSelect([
                    'ID', 'UF_XML_ID', 'UF_B24_DEAL_ID'
                ])
                ->setLimit(1)
                ->exec();
            if($company = $resCompany->fetch()) {
                $balance = \Custom\Core\BalanceHistory::getBalanceForCompany($companyID);

                $request['summ'] = preg_replace('/[^0-9,.]/', '', $request['summ']);
                $request['summ'] = str_replace(',', '.', $request['summ']);
                
                if(!$balance || $balance < $request['summ'])
                {
                    echo json_encode(['status' => 'error', 'message' => 'Недостаточно средств'], JSON_UNESCAPED_UNICODE);
                    die();
                }

                $query = new ORM\Query\Query('Custom\Core\Tickets\TicketRefundRequestsTable');
                $resRefunds = $query
                    ->setSelect(
                        [
                            'ID',
                        ]
                    )
                    ->setFilter([
                        'UF_COMPANY_ID' => $companyID,
                        "STATUS.XML_ID" => ["pending"],
                    ])
                    ->registerRuntimeField(
                        'STATUS',
                        array(
                            'data_type' => '\Custom\Core\FieldEnumTable',
                            'reference' => array('=this.UF_REVIEW_STATUS' => 'ref.ID'),
                            'join_type' => 'LEFT'
                        )
                    )
                    ->exec();

                if ($refund = $resRefunds->fetch()) {
                    echo json_encode(['status' => 'error', 'message' => 'Есть незавершенные заявки на возврат'], JSON_UNESCAPED_UNICODE);
                    die();
                }

                if($request['summ'] < 5000)
                {
                    $date =  date('d.m.Y');
                    $dateFrom = date('01.m.Y 00:00:00', strtotime($date));
                    $dateTo = date('t.m.Y 23:59:59', strtotime($date));

                    $queryActs = new ORM\Query\Query('\Custom\Core\Users\FinanceListTable');

                    $resActsOb   = $queryActs
                        ->setOrder([
                            "ID" => "DESC"
                        ])
                        ->setFilter([
                            'UF_COMPANY_ID' => $companyID,
                            //'<UF_SUMM' => 5000,
                            '!STATUS_XML_ID' => ["cancel"],
                            [
                                'LOGIC' => 'AND',
                                '>=UF_DATE' => new \Bitrix\Main\Type\DateTime($dateFrom),
                                '<=UF_DATE' => new \Bitrix\Main\Type\DateTime($dateTo),
                            ]

                        ])
                        ->setSelect([
                            'ID', 'UF_SUMM', 'STATUS_' => 'STATUS'
                        ])
                        ->registerRuntimeField(
                            'STATUS',
                            array(
                                'data_type' => '\Custom\Core\FieldEnumTable',
                                'reference' => array('=this.UF_STATUS' => 'ref.ID'),
                                'join_type' => 'LEFT'
                            )
                        )
                        ->countTotal(1)
                        ->exec();

                    while($arAct = $resActsOb->fetch())
                    {
                        if($arAct['UF_SUMM'] < 5000) {

                            echo json_encode(['status' => 'error', 'message' => 'В течение календарного месяца можно выводить менее 5000 рублей только 1 раз '], JSON_UNESCAPED_UNICODE);
                            die();
                        }
                    }
                }

                $newBalance = $balance - $request['summ'];

                $arData = [];

                $arData["UF_COMPANY_ID"] = $company["ID"];
                $arData["UF_USER_ID"] = $_SESSION['CURRENT_USER_PROFILE']['UF_USER_ID'];
                $arData["UF_SUMM"] = $request['summ'];
                $arData["UF_DATE"] = new \Bitrix\Main\Type\DateTime();

                $arData["UF_STATUS"] = \Custom\Core\Contract::getHLfileldEnumId(
                    \Custom\Core\FinanceList::HL_NAME,
                    \Custom\Core\FinanceList::FL_STATUS_XMLID,
                    "created"
                );

                $resAdd = \Custom\Core\Users\FinanceListTable::add($arData);

                $enumType = ContractCore::getHLfileldEnumId(
                    \Custom\Core\BalanceHistory::HL_NAME,
                    \Custom\Core\BalanceHistory::BH_TYPE,
                    "down"
                );

                $enumDescription = ContractCore::getHLfileldEnumId(
                    \Custom\Core\BalanceHistory::HL_NAME,
                    \Custom\Core\BalanceHistory::BH_DESCRIPTION,
                    "withdrawal"
                );

                \Custom\Core\Users\BalanceHistoryTable::add(
                    [
                        "UF_COMPANY_ID" => $company["ID"],
                        "UF_VALUE" => $request['summ'],
                        "UF_BALANCE" => $newBalance,
                        "UF_DATE" => new \Bitrix\Main\Type\DateTime(),
                        "UF_TYPE" => $enumType,
                        "UF_DESCRIPTION" => $enumDescription,
                    ]
                );

                if (!$resAdd->isSuccess()) {
                    echo json_encode(['status' => 'error', 'message' => str_replace("<br>", "\n", implode(', ', $resUpdate->getErrors()))], JSON_UNESCAPED_UNICODE);
                    die();
                }

                \Custom\Core\FinanceList::addFL(
                    $resAdd->getId(),
                    [
                    'companyId' => $company["UF_XML_ID"],
                    'PARENT_ID_2' => $company["UF_B24_DEAL_ID"],
                    'ufCrm8_1736840694660' => strval($request['summ'])
                    ]
                );

                echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
                die();
            }
            else
            {
                echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_COMPANY_NOT_FOUND")], JSON_UNESCAPED_UNICODE);
                die;
            }
        }
        else
        {
            echo json_encode(['status' => 'error'], JSON_UNESCAPED_UNICODE);
            die();
        }

    }

    if($companyID)
    {
        $query = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany   = $query
            ->setFilter(['ID' => $companyID])
            ->setSelect([
                'ID', 'UF_BANK_*', 'UF_BALANCE'
            ])
            ->setLimit(1)
            ->exec();
        if($company = $resCompany->fetch()){
            $this->arResult['COMPANY'] = $company;
        }
        else
        {
            echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_COMPANY_NOT_FOUND")], JSON_UNESCAPED_UNICODE);
            die;
        }


    }
    else
    {
        echo json_encode(['status' => 'error', 'message' => Loc::GetMessage("ERROR_NO_COMPANY_FOR_USER")], JSON_UNESCAPED_UNICODE);
        die;
    }



    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}

?>