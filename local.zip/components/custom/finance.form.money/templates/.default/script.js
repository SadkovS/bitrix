$(document).ready(function () {
    function addLoader() {
        document.body.classList.add('loading')
    }

    function removeLoader() {
        document.body.classList.remove('loading')
    }
     function sendRequestForTransfer(resolve) {
        let url = "";
        let formData = [];

        if($(this).data('href'))
        {
            url = $(this).data('href');
        }
        else
        {
            let form = $(this).closest('form');

            url = form.attr('action');
            formData = new FormData(form.get(0));
        }

        addLoader();

        $.ajax({
            method: 'post',
            url: url,
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
        }).done(function (data) { 
            removeLoader();
			let formattedData = data

	        try {
		        formattedData = JSON.parse(data);

		        showToast(formattedData);

		        if(formattedData["status"] == "success")
		        {
			        location.reload();
		        }
	        } catch (e) {

	        }

        });
    }

	$(document).on('click', '.js-money-form-submit', function () {
		if ($(this).hasClass('js-ajax-form-submit-btn')) {
			return true;
		}
		sendRequestForTransfer.call(this, null)
	});

});


