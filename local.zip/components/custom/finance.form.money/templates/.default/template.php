<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;

?>

<div aria-hidden="true" class="popup popup__medium" id="transfer">
    <div class="popup__wrapper">
        <form action="<?=$arParams["SEF_FOLDER"]?>?action=add&<?=bitrix_sessid_get()?>" class="popup__content gap-0 popup-transfer js-form-validate js-no-submit">
            <button class="popup__close profile__popup-close" data-close="" type="button"><i class="_icon-plus"></i></button>
            <div class="popup-transfer__name h4 fw400">Указать сумму перевода</div>

            <div class="row">
                <div class="col-8">
                    <div class="grey__body modal-price-body">
                        <div class="form-item">
                            <input class="form__underline-input js-price-format-input" name="summ" placeholder="" type="text" value="">
                        </div>
                    </div>
                </div>
            </div>

            <div class="h4 fw400">Банковские реквизиты</div>

            <div class="modal-transfer-line-list">

                <div class="modal-transfer-line">
                    <div class="modal-transfer-line__desc">Полное наименование банка включая отделение</div>
                    <div class="modal-transfer-line__val"><?=$arResult["COMPANY"]["UF_BANK_NAME"]?></div>
                </div>

                <div class="modal-transfer-line">
                    <div class="modal-transfer-line__desc">БИК</div>
                    <div class="modal-transfer-line__val"><?=$arResult["COMPANY"]["UF_BANK_BIK"]?></div>
                </div>

                <div class="modal-transfer-line">
                    <div class="modal-transfer-line__desc">Корреспондентский счёт</div>
                    <div class="modal-transfer-line__val"><?=$arResult["COMPANY"]["UF_BANK_KORR"]?></div>
                </div>


                <div class="modal-transfer-line">
                    <div class="modal-transfer-line__desc">Расчётный счёт</div>
                    <div class="modal-transfer-line__val"><?=$arResult["COMPANY"]["UF_BANK_RS"]?></div>
                </div>


                <?if($arResult["COMPANY"]["UF_BANK_COMMENT"]):?>
                    <div class="modal-transfer-line">
                        <div class="modal-transfer-line__desc">Комментарий для перевода денежных средств</div>
                        <div class="modal-transfer-line__val"><?=$arResult["COMPANY"]["UF_BANK_COMMENT"]?></div>
                    </div>
                <?endif;?>

            </div>

            <div class="d-flex gap-3 justify-content-end">
                <button type="button" data-close="" class="btn btn__clean btn__big">Отменить</button>
                <button type="button" class="btn btn__blue btn__big js-form-validate-btn js-money-form-submit">Вывести</button>
            </div>

        </form>
    </div>
</div>