<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>
<div class="adminpanel-notification-line">
    <div class="adminpanel-notification-line__text">Для начала работы с платными событиями вам необходимо заключить договор</div>
    <a href="<?=$arResult["CONTRACT_PAGE"]?>" class="btn btn__fix-width btn__red btn__medium">Перейти</a>
    <div class="adminpanel-notification-line__sep"></div>
    <div class="adminpanel-notification-line__close js-close-adminpanel-notification-line">
        <img src="<?=SITE_TEMPLATE_PATH?>/img/svg/cross.svg" alt="" class="svg">
    </div>
</div>