<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use \Bitrix\Main\Localization\Loc;

$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

try {
    if($companyID)
    {
        $query = new \Bitrix\Main\ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
        $resCompany   = $query
            ->setFilter([
                'ID' => $companyID,
                [
                    "LOGIC" => "OR",
                    [
                        '!CONTRACT.XML_ID' => ["verif", "signed"],
                    ],
                        [
                        'UF_CONTRACT' => null,
                    ]
                ]

            ])
            ->setSelect([
                'ID',
            ])
            ->setLimit(1)
            ->registerRuntimeField(
                'CONTRACT',
                array(
                    'data_type' => '\Custom\Core\FieldEnumTable',
                    'reference' => array('=this.UF_CONTRACT' => 'ref.ID'),
                    'join_type' => 'LEFT'
                )
            )
            ->exec();
        if($company = $resCompany->fetch()){
            $this->arResult["CONTRACT_PAGE"] = Loc::GetMessage("CONTRACT_PAGE");

            $this->IncludeComponentTemplate();
        }
    }


} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}


?>