<?
$MESS["IBLOCK_ANY"]          = "(любой)";
$MESS["CP_BPR_CACHE_GROUPS"] = "Учитывать права доступа";
?>