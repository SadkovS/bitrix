<?

if ( ! defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
	die();
}
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Bitrix\Main\Entity\Query\Join;
use Custom\Core\Helper;

$app       = Application::getInstance();
$context   = $app->getContext();
$request   = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

if ( ! Loader::includeModule("highloadblock") || ! Loader::includeModule('custom.core') || ! Loader::IncludeModule(
		"iblock"
	)) {
	ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
	
	return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if ( ! isset($arParams["CACHE_TIME"])) {
	$arParams["CACHE_TIME"] = 180;
}

try {
	if (empty($arParams['ACTION'])) {
		throw new Exception('Не задан обязательный параметр action');
	}
	
	$itemId = (int)$arParams['ELEMENT_ID'];
	
	$additionalSuccessParams = [];
	
	if ($arParams['ACTION'] == 'getForm') {
		if ((int)$arParams['ELEMENT_ID'] > 0) {
			$arResult['ACTION'] = 'edit';
			
			/*if ($userProfile = findProfileById($itemId, $companyID)) {
				$arResult['PROFILE'] = $userProfile;
			} else {
				throw new Exception('Профиль пользователя не найден!');
			}*/
			throw new Exception('Обновление временно недоступно!');
		} else {
			$arResult['ACTION'] = 'add';
		}
		
		$this->IncludeComponentTemplate();
	}
	
	if ($arParams['ACTION'] == 'edit' || $arParams['ACTION'] == 'add') {
		$APPLICATION->RestartBuffer();
		
		if (!isset($request['FIRST_NAME']) || mb_strlen(trim($request['FIRST_NAME'])) < 1) {
			throw new Exception('Имя не заполнено!');
		}
		
		if (!isset($request['LAST_NAME']) || mb_strlen(trim($request['LAST_NAME'])) < 1) {
			throw new Exception('Фамилия не заполнено!');
		}
		
		if (!isset($request['EMAIL']) || empty(trim($request['EMAIL']))) {
			throw new Exception('E-mail не заполнен!');
		}
		
		if (!isset($request['PHONE']) || empty($request['PHONE'])) {
			throw new Exception('Телефон не заполнен!');
		}
		
		$phone = phoneClear($request['PHONE']);
		$email = trim($request['EMAIL']);
		
		if (!filter_var($request['EMAIL'], FILTER_VALIDATE_EMAIL)) {
			throw new Exception('E-mail содержит некорректное значение!');
		}
		
		if (!$phone || !preg_match('/^\+79/', $phone)) {
			throw new Exception('Телефон содержит некорректное значение!');
		}
		
		$searchUsers = searchUsers($email, $phone);
		
		if ($arParams['ACTION'] == 'edit' && $itemId > 0) { // update
			throw new Exception('Обновление временно недоступно!');
		} else {
			if (count($searchUsers) === 0) { // связка email и phone еще нет в базе
				
				$additionalSuccessParams['new_user'] = true;
				
				$password = \Custom\Core\Helper::genPass();
				$userAdd = new \CUser;
				$arFields = Array(
					'LAST_NAME'          => trim($request['LAST_NAME']),
					'NAME'               => trim($request['FIRST_NAME']),
					'SECOND_NAME'        => trim($request['SECOND_NAME'] ?? ''),
					'PHONE_NUMBER'       => $phone,
					"EMAIL"              => $email,
					"LOGIN"              => $email,
					"ACTIVE"             => "Y",
					"GROUP_ID"           => [2, 3, 4, 5, 9],
					"PASSWORD"           => $password,
					"CONFIRM_PASSWORD"   => $password,
					"CONFIRM_CODE"       => "",
					'_NO_CREATE_COMPANY' => true,
				);
				
				$userId = $userAdd->Add($arFields);
				if (intval($userId) > 0) {
					Helper::createProfile($userId, $companyID);
					
					$serverName = \COption::GetOptionString('main', 'server_name', '');
					$accountActivateLink  = 'https://' . $serverName . '/login/?forgot_password=yes#'.$email;
					
					\CEvent::Send('NEW_USER_TEAM_ADD', SITE_ID, [
						'EMAIL' => $email,
						'COMPANY_NAME' => $_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_NAME'] ?? '',
						'ACCOUNT_ACTIVATE_LINK' => $accountActivateLink,
					]);
				} else {
					throw new Exception($userAdd->LAST_ERROR);
				}
				
			} else {
				$additionalSuccessParams['new_user'] = false;
				
				foreach ($searchUsers as $user) {
					if ($user['EMAIL'] === $email && $user['USER_PHONE'] === $phone && (int)$user['USER_PROFILE_COMPANY_ID'] === $companyID) {
						throw new Exception('Профиль уже существует!');
					}
					
					if (($user['EMAIL'] === $email && $user['USER_PHONE'] !== $phone) || ($user['EMAIL'] !== $email && $user['USER_PHONE'] === $phone)) {
						throw new Exception('Связка email и телефон должны быть уникальными!');
					}
				}
				
				$firstUserKey = array_key_first($searchUsers);
				
				if (!is_null($firstUserKey)) {
					Helper::createProfile($searchUsers[$firstUserKey]['ID'], $companyID);
					
					\CEvent::Send('USER_TEAM_ADD', SITE_ID, [
						'EMAIL' => $email,
						'COMPANY_NAME' => $_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_NAME'] ?? '',
					]);
				}
			}
		}
		unset($searchUsers);
		
		$resArr = array_merge(['status' => 'success', 'message' => 'Профиль успешно создан!'], $additionalSuccessParams);
		echo json_encode($resArr, JSON_UNESCAPED_UNICODE);
		die;
	}
	
	if ($arParams['ACTION'] == 'del') {
		$APPLICATION->RestartBuffer();
		
		if ( ! (isset($request['ID']) && is_numeric($request['ID']))) {
			throw new Exception('Неверный параметр ID');
		}
		
		$profileEntity = new ORM\Query\Query('Custom\Core\Users\UserProfilesTable');
		$query         = $profileEntity->setSelect(['ID', 'UF_USER_ID'])->setFilter([
			                                                                            [
				                                                                            'ID' => $request['ID'],
				                                                                            'UF_COMPANY_ID' => $companyID,
			                                                                            ]
		                                                                            ])->setLimit(
			1
		)->exec();
		
		if ($objProfile = $query->fetchObject()) {
			if ($objProfile->get('UF_IS_OWNER')) {
				throw new Exception('Профиль владельца компании нельзя удалить!');
			}
			
			$objProfile->delete();
		} else {
			throw new Exception('Профиль не найден!');
		}
		
		echo json_encode(['status' => 'success', 'title' => 'Удаление', 'message' => 'Профиль успешно удален'],
		                 JSON_UNESCAPED_UNICODE);
		die;
	}
} catch (\Exception $e) {
	$APPLICATION->RestartBuffer();
	// header("Content-type: application/json; charset=utf-8");
	echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
	die;
}

/**
 * @param string $email
 * @param string $phone
 *
 * @return array
 */
function searchUsers(string $email, string $phone): array
{
	$query   = new ORM\Query\Query('\Bitrix\Main\UserTable');
	$resUser = $query->setFilter(
		[
			"LOGIC" => 'OR',
			['EMAIL' => $email],
			['USER_PHONE' => $phone],
		]
	)->setSelect([
		             'ID',
		             'EMAIL',
		             'USER_PROFILE_COMPANY_ID' => 'USER_PROFILE.UF_COMPANY_ID',
		             'USER_PHONE' => 'PHONE.PHONE_NUMBER',
	             ])
	                 ->registerRuntimeField(
		                 new \Bitrix\Main\Entity\ReferenceField(
			                 'USER_PROFILE',
			                 '\Custom\Core\Users\UserProfilesTable',
			                 Join::on('this.ID', 'ref.UF_USER_ID'),//->where('ref.UF_COMPANY_ID', $companyID),
			                 ['join_type' => 'LEFT'],
		                 )
	                 )
	                 ->registerRuntimeField(
		                 new \Bitrix\Main\Entity\ReferenceField(
			                 'PHONE',
			                 '\Bitrix\Main\UserPhoneAuthTable',
			                 Join::on('this.ID', 'ref.USER_ID'),
			                 ['join_type' => 'LEFT'],
		                 
		                 )
	                 )
	                 ->exec();
	
	return $resUser->fetchAll();
}

/**
 * @param int $profileId
 * @param int $companyID
 *
 * @return array|false
 */
function findProfileById(int $profileId, int $companyID): array|false
{
	$queryProfile = new ORM\Query\Query('\Custom\Core\Users\UserProfilesTable');
	$resProfileOb = $queryProfile->setFilter([
		                                         'UF_COMPANY_ID' => $companyID,
		                                         'ID'            => $profileId
	                                         ])
	                             ->setLimit(1)
	                             ->setSelect([
		                                                                    '*',
		                                                                    'USER_ID'          => 'USER.ID',
		                                                                    'USER_EMAIL'       => 'USER.EMAIL',
		                                                                    'USER_PHONE'       => 'PHONE.PHONE_NUMBER',
		                                                                    'USER_LAST_NAME'   => 'USER.LAST_NAME',
		                                                                    'USER_NAME'        => 'USER.NAME',
		                                                                    'USER_SECOND_NAME' => 'USER.SECOND_NAME',
	                                                                    ])
	                             ->registerRuntimeField(
									'USER',
									array(
										      'data_type' => '\Bitrix\Main\UserTable',
										      'reference' => array('=this.UF_USER_ID' => 'ref.ID'),
										      'join_type' => 'LEFT'
									      ))
								->registerRuntimeField(
									'PHONE',
									array(
										'data_type' => '\Bitrix\Main\UserPhoneAuthTable',
										'reference' => array('=this.USER_ID' => 'ref.USER_ID'),
										'join_type' => 'LEFT'
									))
	                             ->exec();
	
	return $resProfileOb->fetch();
}

/**
 * @param string $t
 *
 * @return string
 */
function phoneClear(string $t): string {
	$t = preg_replace("/[^0-9]/", '', $t);
	if (strlen($t) > 9) {
		$data = '+7' . substr($t, -10);
	} else {
		$data = '';
	}
	return $data;
}

?>
