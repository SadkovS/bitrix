<? if ( ! defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
	die();
}
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;

Loader::includeModule('custom.core');
$APPLICATION->RestartBuffer();

$isEdit = $arResult['ACTION'] === 'edit';
?>
	<div class="popup__content">
		<button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i></button>
		<div class="popup__name h2 wrap-balance">Личные данные</div>
		<form action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=<?= $arResult['ACTION'] ?>&ajax=y" class="js-form-validate" id="team-add-form" method="POST">
			<div class="form-item-margin form-item required">
				<label class="form-item__label">Имя</label>
				<span class="form__error"></span> <input class="form__underline-input" placeholder="Введите имя сотрудника" type="text" name="FIRST_NAME" value="<?= $arResult["PROFILE"]['USER_NAME'] ?? '' ?>" />
			</div>
			
			<div class="form-item-margin form-item required">
				<label class="form-item__label">Фамилия</label>
				<span class="form__error"></span> <input class="form__underline-input" placeholder="Введите фамилию сотрудника" type="text" name="LAST_NAME" value="<?= $arResult["PROFILE"]['USER_LAST_NAME'] ?? '' ?>" />
			</div>
			
			<div class="form-item-margin form-item">
				<label class="form-item__label">Отчество</label>
				<span class="form__error"></span> <input class="form__underline-input" placeholder="Введите отчество сотрудника" type="text" name="SECOND_NAME" value="<?= $arResult["PROFILE"]['USER_SECOND_NAME'] ?? '' ?>" />
			</div>
			
			<div class="form-item-margin form-item required">
				<label class="form-item__label">E-mail</label>
				<span class="form__error"></span> <input class="form__underline-input" placeholder="example@mail.ru" type="email" name="EMAIL" value="<?= $arResult["PROFILE"]['USER_EMAIL'] ?? '' ?>" />
			</div>
			
			<div class="form-item-margin form-item required">
				<label class="form-item__label">Телефон</label>
				<span class="form__error"></span> <input class="form__underline-input" placeholder="+7 (000) 000-00-00" type="tel" name="PHONE" value="<?= $arResult["PROFILE"]['USER_PHONE'] ?? '' ?>" />
			</div>
			
			<div class="row d-flex justify-content-center team-modal-btn">
				<div class="col-auto">
					<button class="btn btn__blue btn__big js-form-validate-btn js-ajax-form-submit-btn" type="button" data-need-reload=".team-table"><?= $isEdit ? 'Сохранить изменения' : 'Добавить пользователя' ?></button>
				</div>
			</div>
		
		</form>
	</div>

<? die(); ?>