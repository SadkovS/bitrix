<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME"        => GetMessage("NAME"),
    "DESCRIPTION" => GetMessage("DESC"),
    "CACHE_PATH"  => "Y",
    "SORT"        => 40,
    "PATH"        => [
        "ID"    => "custom",
        "CHILD" => [
            "ID"    => "organization.team",
            "NAME"  => GetMessage("CATEGORY"),
            "SORT"  => 20,
            "CHILD" => [
                "ID" => 'organization_team_detail',
            ]
        ]
    ],
];
?>