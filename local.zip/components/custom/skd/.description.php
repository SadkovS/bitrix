<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("SKD_NAME"),
	"DESCRIPTION" => GetMessage("SKD_DESCRIPTION"),
	"COMPLEX" => "Y",
	"PATH" => array(
        "ID" => "custom",
		"CHILD" => array(
			"ID" => "skd",
			"NAME" => GetMessage("SKD_DESC"),
			"SORT" => 10,
			"CHILD" => array(
				"ID" => "skd_cmpx",
			),
		),
	),
);

?>