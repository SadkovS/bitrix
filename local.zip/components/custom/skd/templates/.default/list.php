<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
{
	die();
}
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>

<? $APPLICATION->IncludeComponent(
	"custom:skd.list",
	"",
	[
		"HLB_SKD_ACCESS_ID" => $arParams['HLB_SKD_ACCESS_ID'],
		"HLB_SKD_HISTORY_ID" => $arParams['HLB_SKD_HISTORY_ID'],
		"SKD_COUNT" => $arParams['SKD_COUNT'],
		"CACHE_TYPE" => $arParams['CACHE_TYPE'],
		"CACHE_TIME" => $arParams['CACHE_TIME'],
		"CACHE_GROUPS" => $arParams['CACHE_GROUPS'],
		"SEF_FOLDER" => $arParams['SEF_FOLDER'],
	]
); ?>
