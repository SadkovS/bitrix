<?
$MESS ['SKD_NAME'] = "СКД";
$MESS ['SKD_DESCRIPTION'] = "Раздел СКД";
$MESS ['SKD_DESC'] = "СКД";
?>