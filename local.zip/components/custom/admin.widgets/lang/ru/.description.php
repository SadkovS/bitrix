<?
$MESS ['CMPX_ADMIN_WIDGETS_NAME'] = "Виджеты";
$MESS ['CMPX_REFUNDS_DESC'] = "Виджеты комплексный компонент";
$MESS ['C_HLDB_CAT_ORDERS'] = "Заказы";
?>