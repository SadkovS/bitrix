<?
$MESS["IBLOCK_CACHE_FILTER"]             = "Кешировать при установленном фильтре";
$MESS["T_IBLOCK_DESC_USE_PERMISSIONS"]   = "Использовать дополнительное ограничение доступа";
$MESS["T_IBLOCK_DESC_GROUP_PERMISSIONS"] = "Группы пользователей, имеющие доступ к детальной информации";
$MESS["CP_BP_CACHE_GROUPS"]              = "Учитывать права доступа";
?>