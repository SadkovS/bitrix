<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME"        => GetMessage("CMPX_ADMIN_WIDGETS_NAME"),
    "DESCRIPTION" => GetMessage("CMPX_ADMIN_WIDGETS_DESC"),
    "CACHE_PATH"  => "Y",
    "COMPLEX"     => "Y",
    "PATH"        => [
        "ID"    => "custom",
        "CHILD" => [
            "ID"    => "events",
            "NAME"  => GetMessage("C_HLDB_CAT_ORDERS"),
            "SORT"  => 20,
            "CHILD" => [
                "ID" => 'admin_widgets_cmpx',
            ]
        ]
    ],
];
?>