<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
	"NAME"        => GetMessage("ORDERS_DETAIL_NAME"),
	"DESCRIPTION" => GetMessage("ORDERS_DETAIL_DESC"),
	"CACHE_PATH"  => "Y",
	"SORT"        => 40,
	"PATH"        => [
		"ID"    => "custom",
		"CHILD" => [
			"ID"    => "orders",
			"NAME"  => GetMessage("C_HLDB_CAT_ORDERS"),
			"SORT"  => 20,
			"CHILD" => [
				"ID" => 'organizer.orders.detail',
			]
		]
	],
];
?>