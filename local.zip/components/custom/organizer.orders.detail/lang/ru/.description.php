<?
$MESS ['ORDERS_DETAIL_NAME'] = "Заказ";
$MESS ['ORDERS_DETAIL_DESC'] = "Показывает детальную заказа";
$MESS ['C_HLDB_CAT_ORDERS']  = "Заказы";
?>