<? if ( ! defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
	die();
}
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Local\Api\Controllers\V1\Enum\SkdSearchBy;

Loader::includeModule('custom.core');
$APPLICATION->RestartBuffer();
?>
	
	<form class="popup__content" action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=<?= $arResult['ACTION'] ?>&ajax=y"
	      id="ticket-repayment-form">
		<button class="popup__close profile__popup-close" data-close type="button"><i class="_icon-plus"></i></button>
		<div class="popup__name h2 wrap-balance">Погашение билетов заказа № <?= $arResult['TICKETS'][0]['ACCOUNT_NUMBER'] ?? '' ?></div>
		<div class="grey__body px-0">
			<table class="events__table table-standard-th">
				<thead>
				<tr>
					<td>
						<div class="thead-smallest">Тип билета</div>
					</td>
					<td>
						<div class="thead-smallest">Секция/ряд/место</div>
					</td>
					<td>
						<div class="thead-smallest">ФИО</div>
					</td>
					<td>
						<div class="thead-smallest">Почта</div>
					</td>
					<td>
						<div class="thead-smallest">Номер телефона</div>
					</td>
					<td>
						<div class="thead-smallest">Номер штрих-кода</div>
					</td>
					<td>
						<div class="thead-smallest">Статус билета/штрих-кода</div>
					</td>
				</tr>
				</thead>
				<tbody>
				<? foreach ($arResult['TICKETS'] as $ticket): ?>
					<tr class="">
						<td>
							<div class="events__table-item">
								<div class="events__table-item-name"><?= $ticket['TICKET_TYPE'] ?? ''?></div>
							</div>
						</td>
						<td>
							<div class="events__table-item">
								<div class="events__table-item-name"><?= implode('/', array_filter([$ticket['SECTOR'] ?? '', $ticket['ROW'] ?? '', $ticket['PLACE'] ?? ''], fn($value) => !is_null($value) && $value !== '')) ?></div>
							</div>
						</td>
						<td>
							<div class="events__table-item">
								<div class="events__table-item-name"><?= $ticket['USER_FIO'] ?? ''?></div>
							</div>
						</td>
						<td>
							<div class="events__table-item">
								<div class="events__table-item-name"><?= $ticket['USER_EMAIL'] ?? ''?></div>
							</div>
						</td>
						<td>
							<div class="events__table-item">
								<div class="events__table-item-name"><?= $ticket['USER_PHONE'] ?? ''?></div>
							</div>
						</td>
						<td>
							<div class="events__table-item">
								<div class="events__table-item-name">
									<div class="copy-buffer">
										<div class="copy-buffer__text opacity-25"><?= $ticket['BARCODE'] ?? ''?></div>
										<div class="copy-buffer__btn js-copy-to-buffer" data-copy-text="<?= $ticket['BARCODE'] ?? ''?>"></div>
									</div>
								</div>
							</div>
						</td>
						
						<td>
							<div class="events__table-item">
								<div class="events__table-item-name">
									<div class="repayment-status">
										
										<? if (isset($arResult['IS_TIME_HAS_COME']) && $arResult['IS_TIME_HAS_COME'] && in_array($arResult['PARTICIPATION_TYPE_LIST'][$ticket['TICKET_TYPE_PARTICIPATION']]['XML_ID'], ['offline', 'offline_online'])): ?>
											
											<? $statusColor = match ($arResult['BARCODE_STATUS_LIST'][$ticket['BARCODE_STATUS_ID']]['ENUM_XML_ID'] ?? null){
												'new' => 'table-status--dark',
												'sold' => 'table-status--yellow',
												'request_refund' => 'table-status--yellow',
												'used' => 'table-status--green',
												'returned' => 'table-status--red',
												'booked' => 'table-status--gray',
												default => '',
												
												
											};?>
											<p class="table-status <?= $statusColor;?>"><?= $arResult['BARCODE_STATUS_LIST'][$ticket['BARCODE_STATUS_ID']]['ENUM_NAME'] ?? ''?></p>
											
											<? if (!$ticket['LAST_HISTORY_STATUS_ID'] || isset($arResult['HISTORY_STATUS_LIST'][$ticket['LAST_HISTORY_STATUS_ID']]['ENUM_XML_ID']) && in_array($arResult['HISTORY_STATUS_LIST'][$ticket['LAST_HISTORY_STATUS_ID']]['ENUM_XML_ID'],['exit', 'no_entry', 'no_exit'])) : ?>
												<a href="javascript:void(0);" class="btn btn__blue btn__fix-width" data-action-type="entry" data-ticket-repayment="<?= $ticket['BARCODE_ID'] ?? 0?>">Подтвердить проход</a>
											<? elseif (isset($arResult['HISTORY_STATUS_LIST'][$ticket['LAST_HISTORY_STATUS_ID']]['ENUM_XML_ID']) && $arResult['HISTORY_STATUS_LIST'][$ticket['LAST_HISTORY_STATUS_ID']]['ENUM_XML_ID'] === 'allowed'): ?>
												<a href="javascript:void(0);" class="btn btn__fix-width" data-action-type="exit" data-ticket-repayment="<?= $ticket['BARCODE_ID'] ?? 0?>">Подтвердить выход</a>
											<?endif; ?>
										
										<? endif; ?>
									</div>
								</div>
							</div>
						</td>
					</tr>
				<? endforeach; ?>
				</tbody>
			</table>
		</div>
	
	</form>

<? die(); ?>