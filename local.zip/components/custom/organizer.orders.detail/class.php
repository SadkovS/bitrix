<?php
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Highloadblock as HL;
use Bitrix\Main\ORM;
use Bitrix\Main\Application;
use Bitrix\Main\HttpRequest;
use Custom\Core\Traits\PropertyEnumTrait;
use Custom\Core\Traits\TimeTrait;

if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

Loader::includeModule('custom.core');
Loader::includeModule('sale');
Loader::includeModule("catalog");

Loc::loadMessages(__FILE__);

class OrganizerOrdersDetailComponent extends \CBitrixComponent
{
	use TimeTrait;
	use PropertyEnumTrait;
	
	protected int $companyID;
	
	protected $request;
	
	private array $barcodeStatusList;
	private array $skdHistoryStatusList;
	private array $participationType;
	
	/**
	 * контроллер должен иметь возможность получать доступ до начала мероприятия за n часов
	 * @var int
	 */
	private int $timeReserveInHoursUntil;
	
	/**
	 * контроллер должен иметь возможность получать доступ после окончания мероприятия еще n часов
	 * @var int
	 */
	private int $timeReserveInHoursAfter;
	
	public function __construct($component = null)
	{
		parent::__construct($component);
		
		$this->companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
		if ($this->companyID <= 0) return false;
		
		$app       = Application::getInstance();
		$context   = $app->getContext();
		$this->request   = $context->getRequest();
		
		$this->timeReserveInHoursUntil = CHECK_TICKET_TIME_RESERVE_IN_HOURS_UNTIL;
		$this->timeReserveInHoursAfter = CHECK_TICKET_TIME_RESERVE_IN_HOURS_AFTER;
		
		$this->barcodeStatusList = $this->getPropertiesEnum('Barcodes', 'UF_STATUS','ENUM_XML_ID');
		$this->skdHistoryStatusList = $this->getPropertiesEnum('HistorySKD', 'UF_STATUS','ENUM_XML_ID');
		$this->participationType = $this->getParticipationType();
	}
	
	public function executeComponent()
	{
		global $APPLICATION;
		
		try {
			if (empty($this->arParams['ACTION'])) {
				throw new Exception('Не задан обязательный параметр action');
			}
			
			$currentDateTime = new \DateTime();
			$itemId = (int)$this->arParams['ELEMENT_ID'];
			
			if ($this->arParams['ACTION'] == 'getForm') {
				$this->arResult['ACTION'] = 'repayment';
				
				$this->arResult['BARCODE_STATUS_LIST'] = array_combine(array_column(array_values($this->barcodeStatusList), 'ENUM_ID'), array_values($this->barcodeStatusList));
				
				$this->arResult['HISTORY_STATUS_LIST'] = array_combine(array_column(array_values($this->skdHistoryStatusList), 'ENUM_ID'), array_values($this->skdHistoryStatusList));
				
				$this->arResult['PARTICIPATION_TYPE_LIST'] = $this->participationType;
				
				$tickets = $this->getTickets($this->companyID, $itemId);
				
				if (count($tickets) > 0) {
					$eventId = (int)($tickets[0]['EVENT_ID'] ?? 0);
					
					if (!$eventId) throw new Exception('Не удалось определить идентификатор мероприятия');
					
					// проверки по дате и времени мероприятия
					$eventLocationDates = $this->getEventLocationDates($eventId);
					$timeRangeEvent = $this->getTimeRangeEvent($currentDateTime, $eventLocationDates);
					if (is_null($timeRangeEvent))  {
						$this->arResult['IS_TIME_HAS_COME'] =  false;
					} else {
						$this->arResult['IS_TIME_HAS_COME'] =  true;
					}
					
					foreach ($tickets as &$ticket) {
						$ticket['LAST_HISTORY_STATUS_ID'] = $this->getLastItemHistoryId($ticket['BARCODE_ID'], $timeRangeEvent[0] ?? 0, $timeRangeEvent[1] ?? 0);
					}
					
					unset($eventLocationDates, $timeRangeEvent);
					
					$this->arResult['TICKETS'] = $tickets;
				} else {
					throw new Exception('Билеты заказа не найдены!');
				}
				
				$this->includeComponentTemplate();
			}
			
			if ($this->arParams['ACTION'] === 'repayment' && isset($this->request['ajax']) && $this->request['ajax'] === 'y' && isset($this->request['id']) && (int)$this->request['id'] > 0 && isset($this->request['type']) && in_array(
					$this->request['type'],
					['entry', 'exit']
				)) {
				$APPLICATION->RestartBuffer();
				
				$barcodeId = (int)$this->request['id'];
				$actionType = $this->request['type'];
				
				$ticket = $this->getTicket($this->companyID, $itemId, $barcodeId);
				
				if ($ticket === false) {
					throw new Exception('Билет не найден или не доступен!');
				}
				
				$eventId = (int)($ticket['EVENT_ID'] ?? 0);
				
				if (!$eventId) throw new Exception('Не удалось определить идентификатор мероприятия');
				
				$participationTypeId = (int)($ticket['TICKET_TYPE_PARTICIPATION'] ?? 0);
				
				if (isset($this->participationType[$participationTypeId]['XML_ID']) && $this->participationType[$participationTypeId]['XML_ID'] === 'online') throw new Exception('Данный билет нельзя обработать, так как тип участия - онлайн');
				
				// проверки по дате и времени мероприятия
				$eventLocationDates = $this->getEventLocationDates($eventId);
				$timeRangeEvent = $this->getTimeRangeEvent($currentDateTime, $eventLocationDates);
				if (is_null($timeRangeEvent)) throw new Exception('Погашение билета доступно лишь во время проведения мероприятия!');
				
				// проверка по типам билетов в данный день
				if (!$this->checkTicketOffer($eventId, $ticket['TICKET_TYPE_ID'], $currentDateTime, $eventLocationDates)) throw new Exception('Погашение билета доступно лишь во время проведения мероприятия в соответствии с установленным типом билета!');
				
				$historyStatusList = $this->getPropertiesEnum('HistorySKD', 'UF_STATUS', 'ENUM_XML_ID');
				$ticket['LAST_HISTORY_STATUS_ID'] = $this->getLastItemHistoryId($ticket['BARCODE_ID'], $timeRangeEvent[0], $timeRangeEvent[1]);
				
				switch ($actionType) {
					case 'entry': {
						if (!in_array($ticket['LAST_HISTORY_STATUS_ID'], [$historyStatusList['exit']['ENUM_ID'], $historyStatusList['no_entry']['ENUM_ID'], $historyStatusList['no_exit']['ENUM_ID'], 0])) {
							throw new Exception('Невозможно подтвердить выход, так как билет имеет неподходящий статус!');
						}
						$this->setBarcodeStatusUsed($eventId, $barcodeId);
						$this->addSkdHistoryItem($eventId, $historyStatusList['allowed']['ENUM_ID'], $currentDateTime, $barcodeId);
						break;
					}
					case 'exit': {
						if ($ticket['LAST_HISTORY_STATUS_ID'] !== $historyStatusList['allowed']['ENUM_ID']) {
							throw new Exception('Невозможно подтвердить выход, так как билет имеет неподходящий статус!');
						}
						
						$this->addSkdHistoryItem($eventId, $historyStatusList['exit']['ENUM_ID'], $currentDateTime, $barcodeId);
						break;
					}
					default: throw new Exception('Некорректное действие!');
				}
				
				unset($barcodeId, $actionType, $historyStatusList, $timeRangeEvent, $ticket, $eventLocationDates, $currentDateTime);
				
				echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
				die;
			}
		} catch (\Exception $e) {
			$APPLICATION->RestartBuffer();
			// header("Content-type: application/json; charset=utf-8");
			echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
			die;
		}
	}
	
	private function getParticipationType(): array {
		$query                                     = new ORM\Query\Query('\Bitrix\Iblock\PropertyEnumerationTable');
		$res = [];
		
		$resType                     = $query
			->setSelect(['ID', 'VALUE', 'XML_ID'])
			->setOrder(['SORT' => 'ASC'])
			->setFilter(['PROPERTY.CODE' => 'TYPE_PARTICIPATION'])
			->registerRuntimeField(
				new \Bitrix\Main\Entity\ReferenceField(
					'PROPERTY',
					'\Bitrix\Iblock\PropertyTable',
					['this.PROPERTY_ID' => 'ref.ID'],
					['join_type' => 'LEFT'],
				)
			)
			->setCacheTtl(3600)
			->exec();
		while ($type = $resType->fetch()) {
			$res[$type['ID']] = $type;
		}
		unset($query, $resType, $type);
		
		return $res;
	}
	
	
	/**
	 * @param int $barcodeId
	 * @param int $currentDayStartTs
	 * @param int $currentDayEndTs
	 *
	 * @return int
	 */
	private function getLastItemHistoryId(int $barcodeId, int $currentDayStartTs, int $currentDayEndTs): int {
		
		$queryHistoryStatus = new ORM\Query\Query('Custom\Core\Skd\HistorySKDTable');
		$queryHistoryStatus
			->setSelect(['UF_STATUS'])
			->setLimit(1)
			->setOrder(['ID' => 'DESC'])
			->setFilter([
				            'UF_BARCODE_ID'  => $barcodeId,
				            ">=UF_DATE_TIME" => date('d.m.Y H:i:s', $currentDayStartTs),
				            "<=UF_DATE_TIME" => date('d.m.Y H:i:s', $currentDayEndTs),
			            ]);
		return (int)($queryHistoryStatus->fetch()['UF_STATUS'] ?? 0);
	}
	
	
	/**
	 * @param int      $companyId
	 * @param int      $orderId
	 * @param int|null $barcodeId
	 *
	 * @return array|false
	 */
	private function getTicket(int $companyId, int $orderId, ?int $barcodeId = null): array|false {
		
		$offerEntity         = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
		
		$propFieldTypeParticipation       = $offerEntity->getField('TYPE_PARTICIPATION');
		$propFieldTypeParticipationEntity = $propFieldTypeParticipation->getRefEntity();
		
		$dbRes = \Bitrix\Sale\Order::getList(
			[
				'select'  => [
					'ID',
					'EVENT_ID'          => 'PROPERTY_EVENT_ID.VALUE',
					'BARCODE_ID'        => 'BARCODE_REF.ID',
					'TICKET_TYPE_ID'    => 'BASKET_REFS.PRODUCT_ID',
					'TICKET_TYPE_PARTICIPATION'       => 'TICKET_TYPE_PARTICIPATION_REF.VALUE',
				],
				'filter'  => [
					"PROPERTY_ORGANIZER.CODE"       => 'ORGANIZER_ID', //по свойству
					"PROPERTY_ORGANIZER.VALUE"      => $companyId, //и по его значению
					"BASKET_PROPS_BARCODE_REF.CODE" => "BARCODE",
					"PROPERTY_EVENT_ID.CODE"        => 'EVENT_ID',
					"ID"                            => $orderId,
					"PAYED"                         => "Y", //оплаченные
					'BARCODE_ID'                    => $barcodeId,
					'BARCODE_REF.UF_STATUS' => [$this->barcodeStatusList['sold']['ENUM_ID'] ?? 0, $this->barcodeStatusList['used']['ENUM_ID'] ?? 0, $this->barcodeStatusList['request_refund']['ENUM_ID'] ?? 0],
				],
				'runtime' => [
					new \Bitrix\Main\Entity\ReferenceField(
						'PROPERTY_ORGANIZER',
						'Bitrix\Sale\Internals\OrderPropsValueTable',
						['=this.ID' => 'ref.ORDER_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'PROPERTY_EVENT_ID',
						'Bitrix\Sale\Internals\OrderPropsValueTable',
						['=this.ID' => 'ref.ORDER_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BASKET_REFS',
						'Bitrix\Sale\Internals\BasketTable',
						['this.ID' => 'ref.ORDER_ID'],
						['join_type' => 'left']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BASKET_PROPS_BARCODE_REF',
						'\Bitrix\Sale\Internals\BasketPropertyTable',
						['=this.BASKET_REFS.ID' => 'ref.BASKET_ID'],
						['join_type' => 'left']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BARCODE_REF',
						'Custom\Core\Tickets\BarcodesTable',
						['this.BASKET_PROPS_BARCODE_REF.VALUE' => 'ref.ID'],
						['join_type' => 'left']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'TICKET_TYPE_PARTICIPATION_REF',
						$propFieldTypeParticipationEntity,
						['this.BASKET_REFS.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
						['join_type' => 'LEFT'],
					),
				],
				'limit' => 1,
			]
		);
		
		return $dbRes->fetch();
	}
	
	/**
	 * @param int      $eventId
	 * @param int      $ticketTypeId
	 * @param DateTime $currentDateTime
	 * @param array    $eventLocationDates
	 *
	 * @return bool
	 * @throws DateMalformedStringException
	 */
	private function checkTicketOffer(int $eventId, int $ticketTypeId, \DateTime $currentDateTime, array $eventLocationDates): bool
	{
		$ticketOffers = $this->getTicketsOffer($eventId);
		
		if (isset($ticketOffers[$ticketTypeId])) {
			if ($ticketOffers[$ticketTypeId]['SKU_DATES_ALL'] === 'all') {
				return true;
			} else {
				$skuDates = preg_split('@;@', $ticketOffers[$ticketTypeId]['SKU_DATES'], -1, PREG_SPLIT_NO_EMPTY);
				$skuDates = array_map(fn($date) => new \DateTime($date), $skuDates);
				
				foreach ($skuDates as $skuDate) {
					foreach ($eventLocationDates as $location) {
						if (is_array($location['UF_DATE_TIME']) &&
						    count($location['UF_DATE_TIME']) > 0 &&
						    (int)$location['UF_DURATION'] > 0) {
							
							foreach ($location['UF_DATE_TIME'] as $dateItem) {
								if ($skuDate->format('Y-m-d') === $dateItem->format('Y-m-d')) {
									$dateTimeStartTs     = $dateItem->getTimestamp();
									$dateTimeEndTs       = (new \DateTime($dateItem->format('Y-m-d H:i:s')))->modify(
										'+' . (int)$location['UF_DURATION'] . ' minutes'
									)->getTimestamp();
									if ($currentDateTime->getTimestamp() >= ($dateTimeStartTs - $this->hoursToSeconds($this->timeReserveInHoursUntil)) && $currentDateTime->getTimestamp() <= ($dateTimeEndTs + $this->hoursToSeconds($this->timeReserveInHoursAfter))) {
										return true;
									}
								}
							}
						}
					}
				}
			}
		}
		
		return false;
	}
	
	/**
	 * @param int $companyId
	 * @param int $orderId
	 *
	 * @return array
	 */
	private function getTickets(int $companyId, int $orderId): array {
		
		$offerEntity         = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
		$propFieldType       = $offerEntity->getField('TYPE');
		$propFieldTypeEntity = $propFieldType->getRefEntity();
		
		$propFieldTypeParticipation       = $offerEntity->getField('TYPE_PARTICIPATION');
		$propFieldTypeParticipationEntity = $propFieldTypeParticipation->getRefEntity();
		
		$dbRes = \Bitrix\Sale\Order::getList(
			[
				'select'  => [
					'ID',
					'ACCOUNT_NUMBER',
					'EVENT_ID'          => 'PROPERTY_EVENT_ID.VALUE',
					'BARCODE_STATUS_ID' => 'BARCODE_REF.UF_STATUS',
					'BARCODE'           => 'BARCODE_REF.UF_BARCODE',
					'BARCODE_ID'        => 'BARCODE_REF.ID',
					'PLACE'             => 'BASKET_PROPS_PLACE_REF.VALUE',
					'ROW'               => 'BASKET_PROPS_ROW_REF.VALUE',
					'SECTOR'            => 'BASKET_PROPS_SECTOR_REF.VALUE',
					'TICKET_TYPE_ID'    => 'BASKET_REFS.PRODUCT_ID',
					'TICKET_TYPE'       => 'TICKET_TYPE_REF.VALUE',
					'TICKET_TYPE_PARTICIPATION'       => 'TICKET_TYPE_PARTICIPATION_REF.VALUE',
					'USER_FIO'          => 'USER_REF.UF_FULL_NAME',
					'USER_EMAIL'        => 'USER_REF.UF_EMAIL',
					'USER_PHONE'        => 'USER_REF.UF_PHONE',
				],
				'filter'  => [
					"PROPERTY_ORGANIZER.CODE"       => 'ORGANIZER_ID', //по свойству
					"PROPERTY_ORGANIZER.VALUE"      => $companyId, //и по его значению
					"PROPERTY_EVENT_ID.CODE"        => 'EVENT_ID',
					"BASKET_PROPS_BARCODE_REF.CODE" => "BARCODE",
					"BASKET_PROPS_PLACE_REF.CODE"   => 'PLACE',
					"BASKET_PROPS_ROW_REF.CODE"     => 'ROW',
					"BASKET_PROPS_SECTOR_REF.CODE"  => 'SECTOR',
					"ID"                            => $orderId,
					"PAYED"                         => "Y", //оплаченные
					'BARCODE_STATUS_ID' => [$this->barcodeStatusList['sold']['ENUM_ID'] ?? 0, $this->barcodeStatusList['used']['ENUM_ID'] ?? 0,  $this->barcodeStatusList['request_refund']['ENUM_ID'] ?? 0],
				],
				'runtime' => [
					new \Bitrix\Main\Entity\ReferenceField(
						'PROPERTY_ORGANIZER',
						'Bitrix\Sale\Internals\OrderPropsValueTable',
						['=this.ID' => 'ref.ORDER_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'PROPERTY_EVENT_ID',
						'Bitrix\Sale\Internals\OrderPropsValueTable',
						['=this.ID' => 'ref.ORDER_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'PROPERTY_EMAIL',
						'Bitrix\Sale\Internals\OrderPropsValueTable',
						['=this.ID' => 'ref.ORDER_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'PROPERTY_PHONE',
						'Bitrix\Sale\Internals\OrderPropsValueTable',
						['=this.ID' => 'ref.ORDER_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BASKET_REFS',
						'Bitrix\Sale\Internals\BasketTable',
						['this.ID' => 'ref.ORDER_ID'],
						['join_type' => 'left']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'QUESTIONNAIRE_REF',
						'Custom\Core\Events\EventsQuestionnaireUfTicketTable',
						['=this.BASKET_REFS.ID' => 'ref.VALUE'],
						['join_type' => 'LEFT']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'USER_REF',
						'Custom\Core\Events\EventsQuestionnaireTable',
						['=this.QUESTIONNAIRE_REF.ID' => 'ref.ID'],
						['join_type' => 'LEFT']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BASKET_PROPS_ROW_REF',
						'\Bitrix\Sale\Internals\BasketPropertyTable',
						['=this.BASKET_REFS.ID' => 'ref.BASKET_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BASKET_PROPS_PLACE_REF',
						'\Bitrix\Sale\Internals\BasketPropertyTable',
						['=this.BASKET_REFS.ID' => 'ref.BASKET_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BASKET_PROPS_SECTOR_REF',
						'\Bitrix\Sale\Internals\BasketPropertyTable',
						['=this.BASKET_REFS.ID' => 'ref.BASKET_ID'],
						['join_type' => 'inner']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BASKET_PROPS_BARCODE_REF',
						'\Bitrix\Sale\Internals\BasketPropertyTable',
						['=this.BASKET_REFS.ID' => 'ref.BASKET_ID'],
						['join_type' => 'left']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'BARCODE_REF',
						'Custom\Core\Tickets\BarcodesTable',
						['this.BASKET_PROPS_BARCODE_REF.VALUE' => 'ref.ID'],
						['join_type' => 'left']
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'TICKET_TYPE_REF',
						$propFieldTypeEntity,
						['this.BASKET_REFS.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
						['join_type' => 'LEFT'],
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'TICKET_TYPE_PARTICIPATION_REF',
						$propFieldTypeParticipationEntity,
						['this.BASKET_REFS.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
						['join_type' => 'LEFT'],
					),
				],
				'group'   => ['ID'],
				'order'   => ['DATE_INSERT' => 'DESC'],
			]
		);
		
		return $dbRes->fetchAll();
	}
	
	
	/**
	 * @param int $eventId
	 *
	 * @return array
	 */
	private function getTicketsOffer(int $eventId): array {
		$elementEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
		$propField     = $elementEntity->getField('CML2_LINK');
		$propEntity    = $propField->getRefEntity();
		
		$dbRes = \Bitrix\Iblock\Elements\ElementTicketsTable::getList(
			[
				'select'  => [
					'SKU_ID'   => 'OFFER.ID',
					'SKU_DATES',
					'SKU_DATES_ALL'      => 'OFFER.DATES_ALL.VALUE',
				],
				'filter'  => ['EVENT_ID.VALUE' => $eventId],
				'runtime' => [
					new \Bitrix\Main\Entity\ReferenceField(
						'TICKETS',
						$propEntity,
						['this.ID' => 'ref.VALUE'],
						['join_type' => 'LEFT'],
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'OFFER',
						$elementEntity,
						['this.TICKETS.IBLOCK_ELEMENT_ID' => 'ref.ID'],
						['join_type' => 'LEFT'],
					),
					new \Bitrix\Main\Entity\ReferenceField(
						'PROPS',
						'\Bitrix\Catalog\ProductTable',
						['this.OFFER.ID' => 'ref.ID'],
						['join_type' => 'LEFT'],
					),
					new \Bitrix\Main\Entity\ExpressionField(
						'SKU_DATES',
						"GROUP_CONCAT(%s SEPARATOR ';')",
						['OFFER.DATES.VALUE']
					),
				]
			]
		);
		
		$res = [];
		while($sku = $dbRes->fetch()) {
			$res[$sku['SKU_ID']]   = $sku;
		}
		
		return $res;
	}
	
	/**
	 * @param int      $eventId
	 * @param int      $statusId
	 * @param DateTime $date
	 * @param int      $barcodeId
	 *
	 * @return int
	 * @throws Exception
	 */
	private function addSkdHistoryItem(int $eventId, int $statusId, \DateTime $date, int $barcodeId): int {
		
		$barcodeQuery = $this->getBarcodeQuery($eventId, $barcodeId);
		
		if ($barcode = $barcodeQuery->fetch()) {
			$entityHistory = \Custom\Core\Skd\HistorySKDTable::getEntity();
			$objHistory    = $entityHistory->createObject();
			$objHistory->set('UF_ACCESS_SKD_ID', '');
			$objHistory->set('UF_BARCODE_ID', $barcode['ID']);
			$objHistory->set('UF_STATUS', $statusId);
			$objHistory->set('UF_DATE_TIME', $date->format('d.m.Y H:i:s'));
			$objHistory->set('UF_CREATED_DATE', (new \DateTime())->format('d.m.Y H:i:s'));
			$resHistory = $objHistory->save();
			
			if(!$resHistory->isSuccess()) throw new \Exception(implode(', ', $resHistory->getErrors()));
			
			return $resHistory->getId();
		} else {
			throw new \Exception('Штрихкод не найден или недоступен!');
		}
	}
	
	/**
	 * @param int $eventId
	 * @param int $barcodeId
	 *
	 * @return bool
	 * @throws Exception
	 */
	private function setBarcodeStatusUsed(int $eventId, int $barcodeId): bool {
		$barcodeQuery = $this->getBarcodeQuery($eventId, $barcodeId);
		
		if ($obBarcode = $barcodeQuery->fetchObject()) {
			$obBarcode->set('UF_STATUS', $this->barcodeStatusList['used']['ENUM_ID'] ?? 0);
			$resUpdate = $obBarcode->save();
			
			if(!$resUpdate->isSuccess()) throw new \Exception(implode(', ', $resUpdate->getErrors()));
			
			return true;
		} else {
			throw new \Exception('Штрихкод не найден или недоступен!');
		}
	}
	
	/**
	 * @param int $eventId
	 * @param int $barcodeId
	 *
	 * @return ORM\Query\Result
	 */
	private function getBarcodeQuery(int $eventId, int $barcodeId): Bitrix\Main\ORM\Query\Result {
		$barcodesEntity = new ORM\Query\Query('Custom\Core\Tickets\BarcodesTable');
		
		return $barcodesEntity->setSelect(
			[
				'*',
			]
		)->setFilter(
			[
				'UF_EVENT_ID' => $eventId,
				'ID' => $barcodeId,
				'UF_STATUS' => [$this->barcodeStatusList['sold']['ENUM_ID'] ?? 0, $this->barcodeStatusList['used']['ENUM_ID'] ?? 0,  $this->barcodeStatusList['request_refund']['ENUM_ID'] ?? 0]
			]
		)->setLimit(1)->exec();
	}
	
	/**
	 * @param int $eventId
	 *
	 * @return array
	 */
	private function getEventLocationDates(int $eventId): array {
		
		$hlblLocation     = HL\HighloadBlockTable::getById(HL_EVENTS_LOCATION_ID)->fetch();
		$entityLocation   = HL\HighloadBlockTable::compileEntity($hlblLocation);
		$hlbClassLocation = $entityLocation->getDataClass();
		
		$obElement                        = $hlbClassLocation::getList(
			[
				'select' => [
					'UF_DATE_TIME',
					'UF_DURATION',
				],
				'filter' => ['UF_EVENT_ID' => $eventId],
			]
		);
		
		// получим даты проведения мероприятия и определим доступность для контроллера
		return $obElement->fetchAll();
	}
	
	/**
	 * Получить временные рамки мероприятия при условии что текущее время находится в них
	 *
	 * @param DateTime $currentDateTime
	 * @param array    $eventLocationDates
	 *
	 * @return array|null
	 * @throws Exception
	 */
	private function getTimeRangeEvent(DateTime $currentDateTime, array $eventLocationDates): ?array {
		
		// получим даты проведения мероприятия и определим доступность для контроллера
		foreach ($eventLocationDates as $location) {
			
			if (is_array($location['UF_DATE_TIME']) &&
			    count($location['UF_DATE_TIME']) > 0 &&
			    (int)$location['UF_DURATION'] > 0)
			{
				foreach ($location['UF_DATE_TIME'] as $dateItem) {
					
					// мероприятие может начаться в один день, а закончится в следующий.
					// Контроллер должен иметь возможность валидировать даже при указаннии даты лишь первого дня
					$dateTimeStartTs = $dateItem->getTimestamp();
					$dateTimeEndTs   = (new \DateTime($dateItem->format('Y-m-d H:i:s')))->modify('+' . (int)$location['UF_DURATION'] . ' minutes')->getTimestamp();
					
					$reserveDateTimeStartTs = $dateTimeStartTs - $this->hoursToSeconds(CHECK_TICKET_TIME_RESERVE_IN_HOURS_UNTIL);
					$reserveDateTimeEndTs = $dateTimeEndTs + $this->hoursToSeconds(CHECK_TICKET_TIME_RESERVE_IN_HOURS_AFTER);
					
					if ($currentDateTime->getTimestamp() >= $reserveDateTimeStartTs && $currentDateTime->getTimestamp() <= $reserveDateTimeEndTs) {
						return [
							$reserveDateTimeStartTs,
							$reserveDateTimeEndTs
						];
					}
				}
			}
		}
		
		return null;
	}
}