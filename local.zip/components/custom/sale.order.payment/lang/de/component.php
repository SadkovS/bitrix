<?
$MESS["SALE_MODULE_NOT_INSTALL"] = "Das Modul \"Onlineshop\" wurde nicht installiert.";
$MESS["SOA_TEMPL_ORDER_PS_ERROR"] = "Bei der ausgewählten Zahlungsoption ist ein Fehler aufgetreten. Kontaktieren Sie bitte Ihren Website-Administrator oder wählen Sie eine andere Zahlungsoption aus.";
$MESS["SOP_ORDER_NOT_FOUND"] = "Bestellung wurde nicht gefunden.";
?>