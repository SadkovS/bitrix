<?
$MESS["SALE_MODULE_NOT_INSTALL"] = "e-Store module is not installed";
$MESS["SOA_TEMPL_ORDER_PS_ERROR"] = "The selected payment method failed. Please contact the site administrator or select another method.";
$MESS["SOP_ORDER_NOT_FOUND"] = "Order was not found.";
?>