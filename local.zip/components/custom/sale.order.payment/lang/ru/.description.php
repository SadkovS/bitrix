<?
$MESS ['SOP_DEFAULT_TEMPLATE_NAME'] = "Подключение платежной системы";
$MESS ['SOP_DEFAULT_TEMPLATE_DESCRIPTION'] = "Подключение платежной системы";
$MESS ['SOP_NAME'] = "Процедура заказа";
?>