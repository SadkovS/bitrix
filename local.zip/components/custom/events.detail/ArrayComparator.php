<?php
class ArrayComparator
{
    /** @var string Формат вывода дат */
    private const DATE_FORMAT = 'd.m.Y H:i';

    /** @var array Кэш для форматированных дат */
    private $dateFormatCache = [];

    /** @var array Кэш для обработанных пар ссылок */
    private $processedLinkPairs = [];

    /** @var array Кэш для обработанных дат+ссылок */
    private $processedDateLinks = [];

    /** @var array Оригинальные массивы данных для получения информации о длительности */
    private $processedData = [];

    /**
     * Создает карту соответствия дат и ссылок
     *
     * @param array $data Исходный массив данных
     * @return array Карта даты => информация о ссылке и длительности
     */
    private function createDateLinkMap(array $data): array
    {
        $map = [];

        foreach ($data as $item) {
            if (isset($item['DATE_TIME']) && isset($item['LINK'][1])) {
                $link = $item['LINK'][1];
                $duration = isset($item['DURATION']) ? (int)$item['DURATION'] : 0;

                foreach ($item['DATE_TIME'] as $date) {
                    $map[$date] = [
                        'link' => $link,
                        'address' => $item['ADDRESS'] ?? '',
                        'duration' => $duration
                    ];
                }
            }
        }

        return $map;
    }

    /**
     * Создает карту соответствия ссылок и связанных с ними дат
     *
     * @param array $data Исходный массив данных
     * @return array Карта ссылка => массив дат и информации о событиях
     */
    private function createLinkDateMap(array $data): array
    {
        $map = [];

        foreach ($data as $item) {
            if (isset($item['DATE_TIME']) && isset($item['LINK'][1])) {
                $link = $item['LINK'][1];
                $duration = isset($item['DURATION']) ? (int)$item['DURATION'] : 0;

                if (!isset($map[$link])) {
                    $map[$link] = [
                        'dates' => [],
                        'duration' => $duration
                    ];
                }

                foreach ($item['DATE_TIME'] as $date) {
                    $map[$link]['dates'][] = $date;
                }
            }
        }

        // Сортируем даты для каждой ссылки
        foreach ($map as $link => $info) {
            sort($map[$link]['dates']);

            // Удаляем дубликаты дат
            $map[$link]['dates'] = array_unique($map[$link]['dates']);
        }

        return $map;
    }

    /**
     * Проверяет, похожи ли два набора дат
     * (достаточно, чтобы большинство дат совпадало)
     *
     * @param array $dates1 Первый набор дат
     * @param array $dates2 Второй набор дат
     * @return bool true, если наборы похожи
     */
    private function areDatesSetsSimilar(array $dates1, array $dates2): bool
    {
        // Если один из наборов пуст, то они не похожи
        if (empty($dates1) || empty($dates2)) {
            return false;
        }

        // Находим общие даты
        $common = array_intersect($dates1, $dates2);

        // Вычисляем коэффициент сходства (отношение количества общих дат к среднему количеству дат)
        $average = (count($dates1) + count($dates2)) / 2;
        $similarityRatio = count($common) / $average;

        // Если коэффициент сходства выше 0.7 (70%), считаем наборы похожими
        return $similarityRatio > 0.7;
    }

    /**
     * Сравнивает ссылки, привязанные к определенным датам
     *
     * @param array $beforeData Массив данных до изменений
     * @param array $afterData Массив данных после изменений
     * @return array Массив изменений ссылок по датам
     */
    private function compareDateLinks(array $beforeData, array $afterData): array
    {
        $changes = [];

        // Извлекаем уникальные пары дат и ссылок
        $beforeDateLinks = $this->createUniqueEventMap($beforeData);
        $afterDateLinks = $this->createUniqueEventMap($afterData);

        // Сравниваем события по ключам (дата-время)
        foreach ($beforeDateLinks as $dateTime => $beforeEvent) {
            if (isset($afterDateLinks[$dateTime])) {
                $afterEvent = $afterDateLinks[$dateTime];

                // Проверяем изменение ссылки для одного и того же события
                if ($beforeEvent['link'] !== $afterEvent['link']) {
                    $formattedDate = date('Y-m-d', strtotime($dateTime));
                    $linkPair = $beforeEvent['link'] . '|' . $afterEvent['link'];

                    if (!$this->isLinkPairProcessed($linkPair)) {
                        $changes[] = 'Ссылка: <br>' . $beforeEvent['link'] . '<br> на <br>' . $afterEvent['link'];
                        $this->markLinkPairProcessed($linkPair);
                    }
                }
            }
        }

        return $changes;
    }

    /**
     * Создает карту событий с уникальными ключами по дате и времени
     *
     * @param array $data Исходный массив данных
     * @return array Карта дата-время => информация о событии
     */
    private function createUniqueEventMap(array $data): array
    {
        $map = [];

        foreach ($data as $event) {
            if (isset($event['DATE_TIME']) && isset($event['LINK'][1])) {
                $link = $event['LINK'][1];
                $duration = isset($event['DURATION']) ? (int)$event['DURATION'] : 0;
                $address = $event['ADDRESS'] ?? '';

                foreach ($event['DATE_TIME'] as $dateTime) {
                    $map[$dateTime] = [
                        'link' => $link,
                        'address' => $address,
                        'duration' => $duration
                    ];
                }
            }
        }

        return $map;
    }

    /**
     * Сравнивает даты и возвращает строку с изменениями
     *
     * @param array $beforeData Массив данных до изменений
     * @param array $afterData Массив данных после изменений
     * @return string|null Строка с изменениями или null если изменений нет
     */
    private function compareDates(array $beforeData, array $afterData): ?string
    {
        // Собираем все даты и их длительности из массивов
        $beforeDatesInfo = $this->getAllDatesWithInfo($beforeData);
        $afterDatesInfo = $this->getAllDatesWithInfo($afterData);

        // Проверяем, есть ли изменения в существующих датах или их длительностях
        $hasChanges = false;
        $removedDates = [];
        $modifiedDates = [];

        // Проверяем изменения и удаления существующих дат
        foreach ($beforeDatesInfo as $date => $info) {
            if (!isset($afterDatesInfo[$date])) {
                // Дата была удалена
                $removedDates[] = $date;
                $hasChanges     = true;
            } elseif ($info['duration'] !== $afterDatesInfo[$date]['duration']) {
                // Длительность даты изменилась
                $modifiedDates[] = $date;
                $hasChanges      = true;
            }
        }

        // НЕ считаем добавление новых дат изменением
        // Добавленные даты можно найти так: array_diff(array_keys($afterDatesInfo), array_keys($beforeDatesInfo))
        // но мы их игнорируем

        if ($hasChanges) {
            $beforeDates = array_keys($beforeDatesInfo);
            $afterDates = array_keys($afterDatesInfo);

            $beforeFormatted = $this->formatDateRanges($beforeDates, $beforeDatesInfo);
            $afterFormatted = $this->formatDateRanges($afterDates, $afterDatesInfo);

            return 'Дата и время: <br>' . $beforeFormatted . '<br> на <br>' . $afterFormatted;
        }

        return null;
    }

    /**
     * Собирает все даты и их информацию из массива
     *
     * @param array $data Исходный массив данных
     * @return array Карта дата => информация
     */
    private function getAllDatesWithInfo(array $data): array
    {
        $map = [];

        foreach ($data as $item) {
            if (isset($item['DATE_TIME'])) {
                $duration = isset($item['DURATION']) ? (int)$item['DURATION'] : 0;
                $link = isset($item['LINK'][1]) ? $item['LINK'][1] : '';

                foreach ($item['DATE_TIME'] as $date) {
                    $map[$date] = [
                        'duration' => $duration,
                        'link' => $link
                    ];
                }
            }
        }

        return $map;
    }

    /**
     * Форматирует массив дат в строку с диапазонами
     *
     * @param array $dates Массив дат
     * @param array $datesInfo Информация о датах (длительность и т.д.)
     * @return string Отформатированная строка с диапазонами
     */
    private function formatDateRanges(array $dates, array $datesInfo): string
    {
        if (empty($dates)) {
            return '';
        }

        sort($dates);
        $ranges = [];
        $rangeStart = null;
        $rangeEnd = null;
        $prevDate = null;
        $prevTime = null;
        $prevDuration = null;

        foreach ($dates as $datetime) {
            list($date, $time) = explode(' ', $datetime);
            $duration = isset($datesInfo[$datetime]) ? $datesInfo[$datetime]['duration'] : 0;

            if ($prevDate === null) {
                $rangeStart = $datetime;
                $prevDate = $date;
                $prevTime = $time;
                $prevDuration = $duration;
                continue;
            }

            $nextDay = date('Y-m-d', strtotime("$prevDate +1 day"));

            // Если дата следующая по порядку, время и длительность совпадают
            if ($date === $nextDay && $time === $prevTime && $duration === $prevDuration) {
                $rangeEnd = $datetime;
            } else {
                // Завершаем текущий диапазон
                $this->addFormattedRangeWithDuration($ranges, $rangeStart, $rangeEnd, $prevDuration);

                // Начинаем новый диапазон
                $rangeStart = $datetime;
                $rangeEnd = null;
            }

            $prevDate = $date;
            $prevTime = $time;
            $prevDuration = $duration;
        }

        // Добавляем последний диапазон
        $this->addFormattedRangeWithDuration($ranges, $rangeStart, $rangeEnd, $prevDuration);

        return implode(', <br>', $ranges);
    }

    /**
     * Добавляет форматированный диапазон дат в массив с учетом длительности
     *
     * @param array &$ranges Массив диапазонов для пополнения
     * @param string|null $rangeStart Начало диапазона
     * @param string|null $rangeEnd Конец диапазона
     * @param int $duration Длительность в минутах
     */
    private function addFormattedRangeWithDuration(array &$ranges, ?string $rangeStart, ?string $rangeEnd, int $duration): void
    {
        if ($rangeStart === null) {
            return;
        }

        if ($rangeEnd) {
            // Получаем компоненты дат для форматирования
            list($startDate, $startTime) = explode(' ', $rangeStart);
            list($endDate, $endTime) = explode(' ', $rangeEnd);

            // Форматируем даты
            $formattedStart = date('d.m.Y', strtotime($startDate));
            $formattedEnd = date('d.m.Y', strtotime($endDate));

            // Получаем время начала и окончания с учетом длительности
            $formattedStartTime = date('H:i', strtotime($startTime));
            $formattedEndTime = $this->calculateEndTime($startTime, $duration);

            // Если время одинаковое, формируем диапазон дат с одним указанием времени
            $ranges[] = "$formattedStart - $formattedEnd $formattedStartTime - $formattedEndTime";
        } else {
            // Одна дата
            list($date, $time) = explode(' ', $rangeStart);
            $formattedDate = date('d.m.Y', strtotime($date));
            $formattedStartTime = date('H:i', strtotime($time));
            $formattedEndTime = $this->calculateEndTime($time, $duration);

            $ranges[] = "$formattedDate $formattedStartTime - $formattedEndTime";
        }
    }

    /**
     * Вычисляет время окончания события, добавляя длительность к времени начала
     *
     * @param string $startTime Время начала в формате H:i:s
     * @param int $durationMinutes Длительность в минутах
     * @return string Время окончания в формате H:i
     */
    private function calculateEndTime(string $startTime, int $durationMinutes): string
    {
        if ($durationMinutes <= 0) {
            return date('H:i', strtotime($startTime));
        }

        $timestamp = strtotime($startTime) + ($durationMinutes * 60);
        return date('H:i', $timestamp);
    }

    /**
     * Сравнивает индивидуальные элементы массивов (адреса и общие ссылки)
     *
     * @param array $beforeData Массив данных до изменений
     * @param array $afterData Массив данных после изменений
     * @return array Массив изменений
     */
    private function compareIndividualItems(array $beforeData, array $afterData): array
    {
        $changes = [];
        $processedAddresses = [];

        // Создаем карты соответствия блоков и их идентификаторов
        $beforeBlocks = $this->createBlockMap($beforeData);
        $afterBlocks = $this->createBlockMap($afterData);

        // Собираем уникальные пары адресов до/после изменений
        $addressChanges = [];

        foreach ($beforeData as $beforeItem) {
            $beforeAddress = $beforeItem['ADDRESS'] ?? '';

            foreach ($afterData as $afterItem) {
                $afterAddress = $afterItem['ADDRESS'] ?? '';

                // Если адреса различаются и пара ещё не обработана
                if ($beforeAddress !== $afterAddress && !empty($beforeAddress) && !empty($afterAddress)) {
                    $addressPair = $beforeAddress . '|' . $afterAddress;

                    if (!isset($processedAddresses[$addressPair])) {
                        $processedAddresses[$addressPair] = true;
                        $changes[] = 'Адрес: <br>' . $beforeAddress . '<br> на <br>' . $afterAddress;
                        break;
                    }
                }
            }
        }

        return $changes;
    }

    /**
     * Создает уникальные идентификаторы для блоков событий
     *
     * @param array $data Исходный массив данных
     * @return array Карта идентификатор => блок данных
     */
    private function createBlockMap(array $data): array
    {
        $map = [];

        foreach ($data as $index => $block) {
            // Создаем уникальный идентификатор блока на основе его дат и ссылки
            $dates = isset($block['DATE_TIME']) ? implode('|', $block['DATE_TIME']) : '';
            $link = isset($block['LINK'][1]) ? $block['LINK'][1] : '';
            $id = md5($dates . $link);

            $map[$id] = [
                'index' => $index,
                'address' => $block['ADDRESS'] ?? '',
                'link' => $link,
                'duration' => isset($block['DURATION']) ? (int)$block['DURATION'] : 0,
                'dates' => $block['DATE_TIME'] ?? []
            ];
        }

        return $map;
    }

    /**
     * Проверяет, была ли пара ссылок уже обработана
     *
     * @param string $linkPair Ключ пары ссылок (oldLink|newLink)
     * @return bool true, если пара уже обработана
     */
    private function isLinkPairProcessed(string $linkPair): bool
    {
        return in_array($linkPair, $this->processedLinkPairs);
    }

    /**
     * Отмечает пару ссылок как обработанную
     *
     * @param string $linkPair Ключ пары ссылок (oldLink|newLink)
     */
    private function markLinkPairProcessed(string $linkPair): void
    {
        $this->processedLinkPairs[] = $linkPair;
    }

    /**
     * Отмечает дату+ссылку как обработанную
     *
     * @param string $date Дата
     * @param string $link Ссылка
     */
    private function markDateLinkProcessed(string $date, string $link): void
    {
        $key = $date . '|' . $link;
        $this->processedDateLinks[$key] = true;
    }

    /**
     * Проверяет, была ли дата+ссылка уже обработана
     *
     * @param string $date Дата
     * @param string $link Ссылка
     * @return bool true, если дата+ссылка уже обработана
     */
    private function isDateLinkProcessed(string $date, string $link): bool
    {
        $key = $date . '|' . $link;
        return isset($this->processedDateLinks[$key]);
    }

    /**
     * Сравнивает два массива и возвращает массив изменений
     *
     * @param array $beforeData Массив данных до изменений
     * @param array $afterData Массив данных после изменений
     * @return array Массив с описанием изменений
     */
    public function compareArrays(array $beforeData, array $afterData): array
    {
        $changes = [];

        // Сохраняем оригинальные данные для использования при форматировании дат
        $this->processedData = array_merge($beforeData, $afterData);

        // Сбрасываем кэш обработанных пар ссылок перед новым сравнением
        $this->processedLinkPairs = [];
        $this->processedDateLinks = [];

        // Сравнение ссылок по датам (сначала, чтобы иметь приоритет)
        $dateLinkChanges = $this->compareDateLinks($beforeData, $afterData);
        if (!empty($dateLinkChanges)) {
            $changes = array_merge($changes, $dateLinkChanges);
        }

        // Сравнение адресов и общих ссылок
        $individualChanges = $this->compareIndividualItems($beforeData, $afterData);
        if (!empty($individualChanges)) {
            $changes = array_merge($changes, $individualChanges);
        }

        // Сравнение дат и времени (объединяем все даты)
        $dateChanges = $this->compareDates($beforeData, $afterData);

        // Объединяем изменения (даты добавляем в начало для более логичного порядка)
        if ($dateChanges) {
            array_unshift($changes, $dateChanges);
        }

        return $changes;
    }
}