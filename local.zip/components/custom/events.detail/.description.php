<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("HLB_EVENTS_DETAIL"),
	"DESCRIPTION" => GetMessage("HLB_EVENTS_DETAIL_DESC"),
	"CACHE_PATH" => "Y",
	"SORT" => 40,
	"PATH" => array(
        "ID" => "custom",
		"CHILD" => array(
            "ID" => "events",
			"NAME" => GetMessage("C_HLDB_CAT_EVENTS"),
			"SORT" => 20,
            "CHILD" => array(
                "ID" => 'events_detail'
            )
		)
	),
);
?>