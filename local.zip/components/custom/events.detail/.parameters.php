<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
{
	die();
}

/** @var array $arCurrentValues */

use Bitrix\Main\Loader;

if (!Loader::includeModule('iblock'))
{
	return;
}

$iblockExists = (!empty($arCurrentValues['IBLOCK_ID']) && (int)$arCurrentValues['IBLOCK_ID'] > 0);

$arIBlockType = CIBlockParameters::GetIBlockTypes();

$arIBlock=array(
	"-" => GetMessage("IBLOCK_ANY"),
);
$iblockFilter = [
	'ACTIVE' => 'Y',
];
if (!empty($arCurrentValues['IBLOCK_TYPE']))
{
	$iblockFilter['TYPE'] = $arCurrentValues['IBLOCK_TYPE'];
}
$rsIBlock = CIBlock::GetList(["SORT" => "ASC"], $iblockFilter);
while($arr=$rsIBlock->Fetch())
{
	$arIBlock[$arr["ID"]] = "[".$arr["ID"]."] ".$arr["NAME"];
}

$arComponentParameters = [
	"GROUPS" => [
	],
	"PARAMETERS" => [
        "HLDB_EVENTS_ID" => [
            "PARENT" => "BASE",
            "NAME" => GetMessage("HLDB_EVENTS_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => '',
        ],
        "HLDB_EVENTS_STATUS_ID" => [
            "PARENT" => "BASE",
            "NAME" => GetMessage("HLDB_EVENTS_STATUS_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => '',
        ],
        "HLDB_EVENTS_CATEGORY_ID" => [
            "PARENT" => "BASE",
            "NAME" => GetMessage("HLDB_EVENTS_CATEGORY_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => '',
        ],
        "HLDB_EVENTS_LOCATION_ID" => [
            "PARENT" => "BASE",
            "NAME" => GetMessage("HLDB_EVENTS_LOCATION_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => '',
        ],
		"CACHE_TIME"  =>  ["DEFAULT"=>180],
		"CACHE_GROUPS" => [
			"PARENT" => "CACHE_SETTINGS",
			"NAME" => GetMessage("CP_BPR_CACHE_GROUPS"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "Y",
		],
	],
];
