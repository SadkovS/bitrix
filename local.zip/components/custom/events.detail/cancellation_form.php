<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); ?>
<div class="popup__content">
    <button data-close="" type="button" class="popup__close profile__popup-close"><i class="_icon-plus"></i></button>
        <div class="popup__name h1 text-center wrap-balance">
            Вы точно хотите отменить мероприятие?
        </div>
				<div class="popup__desc ta-c">При отмене автоматически запускаются заявки на возврат</div>
        <form class="row d-flex justify-content-center"  method="post" action="<?=$arParams["SEF_FOLDER"].$arParams["ELEMENT_ID"]?>/?action=cancellationEvent&<?=bitrix_sessid_get()?>">
            <div class="col-auto">
                <button type="button" class="btn btn__blue btn__big btn_act_verif js-ajax-form-submit-btn" data-need-reload=".events__table">Подтвердить</button>
            </div>
            <div class="col-auto">
                <button type="button" class="btn btn__clean btn__big" data-close="">Отмена</button>
            </div>
        </form>
</div>

