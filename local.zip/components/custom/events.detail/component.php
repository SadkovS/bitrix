<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
require_once('ArrayComparator.php');
/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
/** @global CUser $USER */

/** @global CMain $APPLICATION */

use Bitrix\Highloadblock as HL;
use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Loader;
use Bitrix\Main\ORM;
use Custom\Core\PriceRules;
use Custom\Core\Products;
use Custom\Core\SeatMap as SeatMap;
use Custom\Core\Events as Events;

$app       = Application::getInstance();
$context   = $app->getContext();
$request   = $context->getRequest();
$companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

if (
    !Loader::includeModule("highloadblock") ||
    !Loader::includeModule('custom.core') ||
    !Loader::includeModule('catalog') ||
    !Loader::includeModule('sale') ||
    !Loader::includeModule('iblock')
) {
    ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    return;
}

/*************************************************************************
 * Processing of received parameters
 *************************************************************************/
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 180;
}

try {

    $query                           = new ORM\Query\Query('\Custom\Core\Events\EventsCategoryTable');
    $this->arResult['CATEGORY_LIST'] = [];
    $resCategory                     = $query
        ->setSelect(['ID', 'UF_NAME'])
        ->setOrder(['UF_SORT' => 'ASC'])
        ->setCacheTtl(3600)
        ->exec();
    while ($category = $resCategory->fetch()) {
        $this->arResult['CATEGORY_LIST'][$category['ID']] = $category;
    }
    unset($query, $resCategory, $category);

    $query                       = new ORM\Query\Query('\Custom\Core\FieldEnumTable');
    $this->arResult['TYPE_LIST'] = [];
    $resType                     = $query
        ->setSelect(['ID', 'UF_NAME' => 'VALUE'])
        ->setOrder(['SORT' => 'ASC'])
        ->setFilter(['USER_FIELD_ID' => 48])
        ->setCacheTtl(3600)
        ->exec();
    while ($type = $resType->fetch()) {
        $this->arResult['TYPE_LIST'][$type['ID']] = $type;
    }
    unset($query, $resType, $type);

    $query                                     = new ORM\Query\Query('\Bitrix\Iblock\PropertyEnumerationTable');
    $this->arResult['TYPE_PARTICIPATION_LIST'] = [];
    $resType                     = $query
        ->setSelect(['ID', 'VALUE', 'XML_ID'])
        ->setOrder(['SORT' => 'ASC'])
        ->setFilter(['PROPERTY.CODE' => 'TYPE_PARTICIPATION'])
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPERTY',
                '\Bitrix\Iblock\PropertyTable',
                ['this.PROPERTY_ID' => 'ref.ID'],
                ['join_type' => 'LEFT'],
            )
        )
        ->setCacheTtl(3600)
        ->exec();
    while ($type = $resType->fetch()) {
        $this->arResult['TYPE_PARTICIPATION_LIST'][$type['XML_ID']] = $type;
    }
    unset($query, $resType, $type);

    $query                            = new ORM\Query\Query('\Custom\Core\FieldEnumTable');
    $this->arResult['AGE_LIMIT_LIST'] = [];
    $resType                          = $query
        ->setSelect(['ID', 'UF_NAME' => 'VALUE'])
        ->setOrder(['SORT' => 'ASC'])
        ->setFilter(['USER_FIELD_ID' => 47])
        ->setCacheTtl(3600)
        ->exec();
    while ($type = $resType->fetch()) {
        $this->arResult['AGE_LIMIT_LIST'][$type['ID']] = $type;
    }
    unset($query, $resType, $type);

    if(
        isset($arParams['ACTION'])
        && (int)$arParams['ELEMENT_ID'] > 0
    )
    {
        if(Events::blockChanges($arParams['ELEMENT_ID']))
        {
            if(in_array($arParams['ACTION'], ['getForm', 'getQuestionnaires']))
            {
                $this->arResult['DISABLED'] =  "disabled";
            }
            else
            {
                $APPLICATION->RestartBuffer();
                echo json_encode(['status' => 'error', 'message' => 'Запрет на редактирование завершенных событий'], JSON_UNESCAPED_UNICODE);
                die();
            }
        }

    }

    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'getForm'
        && (int)$arParams['ELEMENT_ID'] > 0
    ) {
        //EVENT
        $filter = [
            'ID'            => $arParams['ELEMENT_ID'],
            'UF_COMPANY_ID' => $companyID,
            //'!UF_STATUS'    => [6, 7]
        ];

        $arGroups = $USER->GetUserGroupArray();
        if (is_array($arGroups) && (in_array('1', $arGroups) || in_array('8', $arGroups)))
            unset($filter['UF_COMPANY_ID']);

        $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
        $hlbClass = $entity->getDataClass();

        $productEntity         = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $propFieldEventID      = $productEntity->getField('EVENT_ID');
        $propEventIDEntity     = $propFieldEventID->getRefEntity();
        $propFieldClosed       = $productEntity->getField('IS_CLOSED_EVENT');
        $propFieldClosedEntity = $propFieldClosed->getRefEntity();

        $hlblStatus     = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_STATUS_ID"])->fetch();
        $entityStatus   = HL\HighloadBlockTable::compileEntity($hlblStatus);
        $hlbClassStatus = $entityStatus->getDataClass();

        $obElement                                   = $hlbClass::getList(
            [
                'select'  => [
                    'ID',
                    'UF_STATUS',
                    'UF_IMG',
                    'UF_NAME',
                    'UF_CATEGORY',
                    'UF_AGE_LIMIT',
                    'UF_TYPE',
                    'UF_TYPE_XML_ID' => 'TYPE_REF.XML_ID',
                    'UF_DESCRIPTION',
                    'UF_QUESTIONNAIRE_FIELDS',
                    'UF_QUESTIONNAIRE_DESCRIPTION',
                    'UF_QUESTIONNAIRE_ACTIVE',
                    'UF_QUESTIONNAIRE_FOREACH_TICKETS',
                    'UF_PAY_SYSTEM',
                    'UF_STEP',
                    'UF_FILES',
                    'UF_UUID',
                    'IMG_SRC',
                    'UF_SIT_MAP',
                    'PRODUCT_ID'    => 'PRODUCT.IBLOCK_ELEMENT_ID',
                    'PRODUCT_CODE'  => 'REF_PRODUCT.CODE',
                    'IS_CLOSED'     => 'EVENT_CLOSED.VALUE',
                    'STATUS_XML_ID' => 'STATUS.UF_XML_ID',
                    'UF_RESERVATION_VALIDITY_PERIOD',
                ],
                'filter'  => $filter,
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PICTURE',
                        '\Bitrix\Main\FileTable',
                        ['this.UF_IMG' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'IMG_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['PICTURE.SUBDIR', 'PICTURE.FILE_NAME']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PRODUCT',
                        $propEventIDEntity,
                        ['this.ID' => 'ref.VALUE'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'EVENT_CLOSED',
                        $propFieldClosedEntity,
                        ['this.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'REF_PRODUCT',
                        $productEntity,
                        ['this.PRODUCT_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'STATUS',
                        $hlbClassStatus,
                        ['this.UF_STATUS' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'TYPE_REF',
                        '\Custom\Core\FieldEnumTable',
                        ['this.UF_TYPE' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ]
            ]
        );
        $objQuestionnaire                            = new \Custom\Core\Questionnaires();
        $this->arResult['EVENT']                     = $obElement->fetch();
        $this->arResult['EVENT']['IS_CLOSED']        = (int)$this->arResult['EVENT']['IS_CLOSED'] > 0;
        $this->arResult['QUESTIONNAIRE_FIELDS']      = json_decode($this->arResult['EVENT']['UF_QUESTIONNAIRE_FIELDS'], true);
        $this->arResult['QUESTIONNAIRE_FIELD_TYPES'] = $objQuestionnaire->fieldsTypes;
        $this->arResult['QUESTIONNAIRE_FILE_TYPES']  = $objQuestionnaire->extensions;
        $this->arResult['IS_FILED']                  = $objQuestionnaire->isFilled((int)$arParams['ELEMENT_ID']);
        $this->arResult['ORDER_EXIST']               = checkExistsOrders((int)$arParams['ELEMENT_ID']);
        $checkedPaySystem                            = $this->arResult['EVENT']['UF_PAY_SYSTEM'] ?? [];
        unset($this->arResult['EVENT']['UF_QUESTIONNAIRE_FIELDS'], $this->arResult['EVENT']['UF_PAY_SYSTEM']);

        if (is_array($arResult['EVENT']['UF_FILES']) && count($arResult['EVENT']['UF_FILES']) > 0) {
            $query    = new ORM\Query\Query('\Bitrix\Main\FileTable');
            $resFiles = $query
                ->setSelect(['ID', 'ORIGINAL_NAME', 'EXTERNAL_ID', 'FILE_SIZE', 'FILE_PATH'])
                ->setFilter(['ID' => $arResult['EVENT']['UF_FILES']])
                ->registerRuntimeField(
                    new \Bitrix\Main\Entity\ExpressionField(
                        'FILE_PATH', 'CONCAT("/upload/",%s, "/", %s)', ['SUBDIR', 'FILE_NAME']
                    )
                )
                ->exec();

            while ($arFile = $resFiles->fetch()) {
                $arFile['SORT'] = 900;
                foreach ($arResult['EVENT']['UF_FILES'] as $key => $value) {
                    if ($value == $arFile['ID']) $arFile['SORT'] = $key + 1;
                }
                $arTemp[] = $arFile;
            }

            usort(
                $arTemp, function ($a, $b) {
                return ($a['SORT'] - $b['SORT']);
            }
            );

            $arResult['EVENT']['UF_FILES'] = $arTemp;
        }
        //EVENT_LOCATION
        $hlblLocation     = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_LOCATION_ID"])->fetch();
        $entityLocation   = HL\HighloadBlockTable::compileEntity($hlblLocation);
        $hlbClassLocation = $entityLocation->getDataClass();

        $obElement                        = $hlbClassLocation::getList(
            [
                'select' => [
                    'ID',
                    'UF_EVENT_ID',
                    'UF_DATE_TIME',
                    'UF_ADDRESS',
                    'UF_ROOM',
                    'UF_LINK',
                    'UF_DURATION',
                    'UF_COORDINATES'
                ],
                'filter' => ['UF_EVENT_ID' => $arParams['ELEMENT_ID']]
            ]
        );
        $this->arResult['EVENT_LOCATION'] = [];
        $arDatesAndLocations              = [];
        $arLocations                      = [];
        while ($location = $obElement->fetch()) {
            $duration = (int)$location['UF_DURATION'];

            foreach ($location['UF_LINK'] as &$link) {
                $link = json_decode($link, true);
            }
            unset($link);

            if (is_array($location['UF_DATE_TIME']) && count($location['UF_DATE_TIME']) > 0) {
                foreach ($location['UF_DATE_TIME'] as $key => &$dateItem) {
                    $dateTimeStart                   = ($dateItem)->format('d.m.Y H:i');
                    $currentDate                     = ($dateItem)->format('d.m.Y');
                    $currentDateShort                = ($dateItem)->format('d.m.y');
                    $timeStamp                       = strtotime($dateTimeStart);
                    $dateItem                        =
                        [
                            'DATE'              => $currentDate,
                            'DATE_SHORT'        => $currentDateShort,
                            'TIME'              => ($dateItem)->format('H:i'),
                            'TIME_END'          => (new DateTime($dateItem))->modify("+{$duration} minutes")->format('H:i'),
                            'DATE_PRESENTATION' => Custom\Core\Helper::getFormatDate($currentDate),
                            'TIMESTAMP'         => $timeStamp,
                        ];
                    $arDatesAndLocations[$timeStamp] = [
                        'LOCATION_ID' => $location['ID'],
                        'EVENT_DATE'  => $dateItem,
                    ];
                }
                unset($dateItem, $key);
            } else {
                $dateTimeStart                   = (new DateTime())->format('d.m.Y H:i');
                $currentDate                     = new DateTime();
                $currentDateShort                = $currentDate->format('d.m.y');
                $currentDate                     = $currentDate->format('d.m.Y');
                $timeStamp                       = strtotime($dateTimeStart);
                $dateItem                        =
                    [
                        'DATE'              => $currentDate,
                        'DATE_SHORT'        => $currentDateShort,
                        'TIME'              => (new DateTime())->format('H:i'),
                        'TIME_END'          => '',
                        'DATE_PRESENTATION' => Custom\Core\Helper::getFormatDate($currentDate),
                        'TIMESTAMP'         => strtotime($dateTimeStart),
                    ];
                $arDatesAndLocations[$timeStamp] = [
                    'LOCATION_ID' => $location['ID'],
                    'EVENT_DATE'  => $dateItem,
                ];
            }
            unset($location['UF_DATE_TIME']);
            $locationID                   = $location['ID'];
            $arLocations[$location['ID']] = $location;
        }
        ksort($arDatesAndLocations, SORT_NUMERIC);
        $arChecked = [];
        foreach ($arDatesAndLocations as &$dateItem) {
            $dateItem['CHECKED'] = in_array($dateItem['LOCATION_ID'], $arChecked);
            $arChecked[]         = $dateItem['LOCATION_ID'];

            if (!isset($inheritDate)) $inheritDate = $dateItem['EVENT_DATE']['DATE_PRESENTATION'];
            $dateItem['INHERIT_TEXT']  = 'Те же настройки, что для <span data-date-binding>' . $inheritDate . '</span>';
            $dateItem['LOCATION_INFO'] = $arLocations[$dateItem['LOCATION_ID']];
            $dateItem['SALES_EXISTS'] = 0;
        }

        if (count($arDatesAndLocations) > 0) {
            $stampStart = date('d.m.Y', array_key_first($arDatesAndLocations));
            $endStamp   = date('d.m.Y', array_key_last($arDatesAndLocations));

            $this->arResult['EVENT_LOCATION']['DATE'] = $stampStart == $endStamp ? $stampStart : $stampStart . ' - ' . $endStamp;
        } else {
            $this->arResult['EVENT_LOCATION']['DATE'] = (new DateTime())->format('d.m.Y');
        }

        $this->arResult['EVENT_LOCATION']['ITEMS'] = $arDatesAndLocations;

        // SeatMap
        if (
            USE_SEATMAP
            && isset($arResult['EVENT'])
            && isset($arResult['EVENT']['UF_TYPE'])
            && ($arResult['EVENT']['UF_TYPE'] === '7' || $arResult['EVENT']['UF_TYPE'] === '8')
            && $arResult['EVENT']['UF_SIT_MAP'] === '1'
            && !isset($this->arResult['SeatMap'])
        ) {
            if ($this->siteTemplateId === 'moderation') {
                $this->arResult['SeatMap'] = \Custom\Core\Events::getSeatMapData($arResult['EVENT']['ID']);
            } else {
                $this->arResult['SeatMap'] = getSeatMapData($this->arResult);
            }
        }

        //PRICES

        $this->arResult['TICKETS'] = \Custom\Core\Helper::getTicketsOffers((int)$arParams['ELEMENT_ID']);

        // Обработка продаж билетов для дат
        if (!empty($this->arResult['TICKETS']) && !empty($this->arResult['EVENT_LOCATION']['ITEMS'])) {
            foreach ($this->arResult['TICKETS'] as $ticket) {
                // Проверяем, что билет активен для продаж
                if (isset($ticket['SKU_SALES_EXISTS']) && $ticket['SKU_SALES_EXISTS'] == 1) {

                    // Если даты не заполнены - билет действует для всех дат
                    if (empty($ticket['SKU_DATES']) || $ticket['SKU_DATES_ALL'] === 'all') {
                        foreach ($this->arResult['EVENT_LOCATION']['ITEMS'] as $timestamp => $locationItem) {
                            $this->arResult['EVENT_LOCATION']['ITEMS'][$timestamp]['SALES_EXISTS'] = 1;
                        }
                        break; // Выходим из цикла
                    } // Если даты заполнены - ищем соответствующие элементы
                    elseif (!empty($ticket['SKU_DATES']) && is_array($ticket['SKU_DATES'])) {
                        foreach ($ticket['SKU_DATES'] as $ticketDate) {
                            foreach ($this->arResult['EVENT_LOCATION']['ITEMS'] as $timestamp => $locationItem) {
                                if (isset($locationItem['EVENT_DATE']['DATE']) &&
                                    $locationItem['EVENT_DATE']['DATE_SHORT'] === $ticketDate) {
                                    $this->arResult['EVENT_LOCATION']['ITEMS'][$timestamp]['SALES_EXISTS'] = 1;
                                }
                            }
                        }
                    }
                }
            }
        }
        $companyInfo = Custom\Core\Orders\InvoiceGenerator::getOrganizerInfo($companyID);

        $defPaySystem = ['b_cards', 'sbp'];
        if (
            in_array($companyInfo['COMPANY_TYPE'], ['legal', 'ip']) &&
            $companyInfo['CONTRACT_STATUS'] == 'signed'
        ) {
            $defPaySystem[] = 'invoice';
        }
        $paySystemResult = \Bitrix\Sale\PaySystem\Manager::getList(
            [
                'select' => ['ID', 'CODE', 'PAY_SYSTEM_ID', 'NAME', 'LOGO_SRC', 'DESCRIPTION'],
                'filter' => ['ACTIVE' => 'Y', 'CODE' => $defPaySystem],
                'order'   => ['SORT' => 'ASC'],
                'cache'   => ['ttl' => 3600],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PICTURE',
                        '\Bitrix\Main\FileTable',
                        ['this.LOGOTIP' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'LOGO_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['PICTURE.SUBDIR', 'PICTURE.FILE_NAME']
                    ),
                ]
            ]
        );
        while ($resPaySys = $paySystemResult->fetch()) {
            (in_array($resPaySys['ID'], $checkedPaySystem)) ? $resPaySys['CHECKED'] = 'Y' : $resPaySys['CHECKED'] = 'N';
            $this->arResult['PAY_SYSTEMS'][] = $resPaySys;
        }

        $query                            = new ORM\Query\Query('\Custom\Core\Events\EventsStatusHistoryTable');
        $this->arResult['STATUS_HISTORY'] = [];
        $resElement                       = $query
            ->setSelect(['ID', 'STATUS_NAME' => 'STATUS.UF_NAME', 'STATUS_ID' => 'STATUS.ID', 'UF_DATE_UPDATE', 'UF_COMMENT'])
            ->setOrder(['UF_DATE_UPDATE' => 'ASC'])
            ->setFilter(['UF_EVENT_ID' => $arParams['ELEMENT_ID']])
            //->setCacheTtl(3600)
            ->exec();
        while ($element = $resElement->fetch()) {
            $this->arResult['STATUS_HISTORY'][$element['ID']] = $element;
            if (is_object($element['UF_DATE_UPDATE'])) {
                $this->arResult['STATUS_HISTORY'][$element['ID']]['UF_DATE_UPDATE'] = ($element['UF_DATE_UPDATE'])->format('d.m.Y H:i:s');
            }
        }
        unset($element, $query, $resElement);
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'getForm'
        && (int)$arParams['ELEMENT_ID'] < 1) {
        $objQuestionnaire                            = new \Custom\Core\Questionnaires();
        $this->arResult['QUESTIONNAIRE_FIELD_TYPES'] = $objQuestionnaire->fieldsTypes;
        $this->arResult['QUESTIONNAIRE_FILE_TYPES']  = $objQuestionnaire->extensions;

        $companyInfo = Custom\Core\Orders\InvoiceGenerator::getOrganizerInfo($companyID);
        $defPaySystem = ['b_cards', 'sbp'];

        if (
            in_array($companyInfo['COMPANY_TYPE'], ['legal', 'ip']) &&
            $companyInfo['CONTRACT_STATUS'] == 'signed'
        ) {
            $defPaySystem[] = 'invoice';
        }

        $paySystemResult = \Bitrix\Sale\PaySystem\Manager::getList(
            [
                'select' => ['ID', 'CODE', 'PAY_SYSTEM_ID', 'NAME', 'LOGO_SRC', 'DESCRIPTION'],
                'filter' => ['ACTIVE' => 'Y', 'CODE' => $defPaySystem],
                'order'   => ['SORT' => 'ASC'],
                'cache'   => ['ttl' => 3600],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PICTURE',
                        '\Bitrix\Main\FileTable',
                        ['this.LOGOTIP' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'LOGO_SRC', 'CONCAT("/upload/",%s, "/", %s)', ['PICTURE.SUBDIR', 'PICTURE.FILE_NAME']
                    ),
                ]
            ]
        );
        while ($resPaySys = $paySystemResult->fetch()) {
            $resPaySys['CHECKED'] = 'N';
            $this->arResult['PAY_SYSTEMS'][] = $resPaySys;
            $this->arResult['ORDER_EXIST']   = false;
        }
    }
    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'setEvent'
    ) {
        $APPLICATION->RestartBuffer();
        $hlblock         = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entity          = HL\HighloadBlockTable::compileEntity($hlblock);
        $hlbClass        = $entity->getDataClass();
        $objEvent        = $entity->wakeUpObject($arParams['ELEMENT_ID']);
        $filePropsEntity = Custom\Core\Events\EventsUfFilesTable::getEntity();
        $text = strip_tags($request['UF_DESCRIPTION']);
        if ((int)$arParams['ELEMENT_ID'] > 0) {

            if ($objEvent->fillUfCompanyId() != $companyID) throw new Exception('Нельзя редактировать чужое событие!');

            if ($text && mb_strlen($text, 'UTF-8') > 10000) {
                throw new Exception("Максимальная длина поля «Описание» 10000 символов");
            }

            $arData = [
                'UF_NAME'        => $request['UF_NAME'],
                'UF_CATEGORY'    => $request['UF_CATEGORY'],
                'UF_TYPE'        => $request['UF_TYPE'],
                'UF_AGE_LIMIT'   => $request['UF_AGE_LIMIT'],
                'UF_DESCRIPTION' => $request['UF_DESCRIPTION'],
                'UF_SIT_MAP'     => $request['UF_SIT_MAP'],
                'UF_MODIFIED_BY' => $USER->GetID(),
                'UF_DATE_UPDATE' => (new DateTime())->format('d.m.Y H:i:s'),
            ];

            if (
                (isset($_FILES['UF_IMG']['tmp_name']) && !empty($_FILES['UF_IMG']['tmp_name'])) ||
                (isset($_FILES['UF_FILES']['tmp_name']) && !empty($_FILES['UF_FILES']['tmp_name'][0]))
            ) {
                $resFiles = $hlbClass::getList(
                    [
                        'filter' => ['ID' => $arParams['ELEMENT_ID']],
                        'select' => ['UF_FILES', 'UF_IMG']
                    ]
                )->fetch();
            }

            if (isset($_FILES['UF_IMG']['tmp_name']) && !empty($_FILES['UF_IMG']['tmp_name'])) {
                checkFileSize($_FILES['UF_IMG']);

                $arData['UF_IMG']             = $_FILES['UF_IMG'];
                $arData['UF_IMG']['del']      = 'Y';
                $arData['UF_IMG']['old_file'] = $resFiles['UF_IMG'];
            }
            if (isset($_FILES['UF_FILES']['tmp_name']) && !empty($_FILES['UF_FILES']['tmp_name'][0])) {
                $arFiles = [];
                foreach ($_FILES['UF_FILES'] as $key => $values) {
                    foreach ($values as $k => $value) {
                        $arFiles[$k][$key] = $value;
                    }
                }
                if (is_array($arFiles) && count($arFiles) > 0) {
                    $newFIds = [];
                    foreach ($arFiles as $file) {
                        $newFIds[] = CFile::saveFile($file, 'events');
                    }
                    if (count($newFIds) > 0) {

                        foreach ($newFIds as $fid) {
                            $objFileProps = $filePropsEntity->createObject();
                            $objFileProps->set('ID', $arParams['ELEMENT_ID']);
                            $objFileProps->set('VALUE', $fid);
                            $objFileProps->save();
                        }
                    }

                }
            }

            if (is_array($request['FILE_SORT']) && count($request['FILE_SORT']) > 0) {
                $query        = new ORM\Query\Query($filePropsEntity);
                $resFileProps = $query
                    ->setSelect(
                        [
                            'ID',
                            'VALUE',
                            'HASH',
                            'NAME' => 'FILE.ORIGINAL_NAME',
                            'TYPE' => 'FILE.CONTENT_TYPE',
                            'SIZE' => 'FILE.FILE_SIZE'
                        ]
                    )
                    ->setFilter(['ID' => $arParams['ELEMENT_ID']])
                    ->registerRuntimeField(
                        new \Bitrix\Main\Entity\ReferenceField(
                            'FILE',
                            '\Bitrix\Main\FileTable',
                            ['this.VALUE' => 'ref.ID'],
                            ['join_type' => 'LEFT'],
                        )
                    )
                    ->registerRuntimeField(
                        new \Bitrix\Main\Entity\ExpressionField(
                            'HASH', 'MD5(CONCAT(%s, %s, %s))', ['FILE.ORIGINAL_NAME', 'FILE.FILE_SIZE', 'FILE.CONTENT_TYPE']
                        )
                    )
                    ->exec();

                while ($resFiles = $resFileProps->fetch()) {
                    $resFiles['SORT'] = 900;
                    foreach ($request['FILE_SORT'] as $key => $value) {
                        if (((int)$value > 0 && $value == $resFiles['VALUE']) || $value == $resFiles['HASH']) $resFiles['SORT'] = $key + 1;
                    }
                    $existingFiles[] = $resFiles;
                }

                if (is_array($existingFiles) && count($existingFiles) > 0) {

                    usort(
                        $existingFiles, function ($a, $b) {
                        return ($a['SORT'] - $b['SORT']);
                    }
                    );


                    $eventEntity    = Custom\Core\Events\EventsTable::getEntity();
                    $dataClassEvent = $eventEntity->getDataClass();
                    $resEvent       = $dataClassEvent::getByPrimary($arParams['ELEMENT_ID']);


                    if ($objEvent = $resEvent->fetchObject()) {
                        $objEvent->set('UF_FILES', array_column($existingFiles, 'VALUE') ?? []);
                        //todo Временно отключнно
                        //if(is_array($newFIds) && count($newFIds) > 0) $objEvent->set('UF_STATUS', 4);
                        $objEvent->save();
                    }
                }

            }

            $resUpdate = $hlbClass::update($arParams['ELEMENT_ID'], $arData);
            if ($resUpdate->isSuccess()) {
                $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
                $query         = new ORM\Query\Query($productEntity);
                $resProduct    = $query
                    ->setSelect(['ID', 'EVENT_ID.VALUE'])
                    ->setFilter(['EVENT_ID.VALUE' => $arParams['ELEMENT_ID']])
                    ->setLimit(1)
                    ->exec();

                $objProduct = $resProduct->fetchObject();
                if (is_object($objProduct) && $objProduct->getId() && $objProduct->getId() > 0) {

                    $resProduct = Products::getInstance()->updateProduct(
                        $objProduct->getId(),
                        [
                            'NAME'        => $request['UF_NAME'],
                            'MODIFIED_BY' => $USER->GetID(),
                            'TIMESTAMP_X' => (new \DateTime())->format('d.m.Y H:i:s'),
                        ]
                    );

                    $offerEntity      = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
                    $query            = new ORM\Query\Query($offerEntity);
                    $resOffer         = $query
                        ->setSelect(['CML2_LINK', 'NAME', 'ID', 'TYPE'])
                        ->setFilter(['CML2_LINK.VALUE' => $objProduct->getId()])
                        ->exec();
                    $collectionOffers = $resOffer->fetchCollection();

                    foreach ($collectionOffers as $objOffer) {
                        $objOffer->setName($request['UF_NAME'] . ' [' . $objOffer->getType()->getValue() . ']');
                        $objOffer->save();
                    }
                }

                if (isset($resProduct['status']) && $resProduct['status'] == 'error') throw new Exception($resProduct['message']);

                echo json_encode(['status' => 'success', 'step' => 2, 'id' => $resUpdate->getId()], JSON_UNESCAPED_UNICODE);
            } else
                echo json_encode(['status' => 'error', 'message' => str_replace("<br>", "\n", implode(', ', $resUpdate->getErrors()))], JSON_UNESCAPED_UNICODE);
        } else {
            if ($text && mb_strlen($text, 'UTF-8') > 10000) {
                throw new Exception("Максимальная длина поля «Описание» 10000 символов");
            }
            $eventUUID = \Custom\Core\UUID::uuid8();
            $series    = Products::getInstance()->genTicketSeries();
            $arData    = [
                'UF_NAME'        => $request['UF_NAME'],
                'UF_CATEGORY'    => $request['UF_CATEGORY'],
                'UF_UUID'        => $eventUUID,
                'UF_TYPE'        => $request['UF_TYPE'],
                'UF_AGE_LIMIT'   => $request['UF_AGE_LIMIT'],
                'UF_DESCRIPTION' => $request['UF_DESCRIPTION'],
                'UF_SIT_MAP'     => $request['UF_SIT_MAP'],
                'UF_MODIFIED_BY' => $USER->GetID(),
                'UF_CREATED_BY'  => $USER->GetID(),
                'UF_COMPANY_ID'  => $companyID,
                'UF_SERIES'      => $series,
                'UF_STEP'        => 2,
                'UF_STATUS'      => 4
            ];

            if (isset($_FILES['UF_IMG']['tmp_name']) && !empty($_FILES['UF_IMG']['tmp_name'])) {
                checkFileSize($_FILES['UF_IMG']);

                $arData['UF_IMG'] = $_FILES['UF_IMG'];
            }

            if (isset($_FILES['UF_FILES']['tmp_name']) && !empty($_FILES['UF_FILES']['tmp_name'][0])) {
                $arFiles = [];
                foreach ($_FILES['UF_FILES'] as $key => $values) {
                    foreach ($values as $k => $value) {
                        $arFiles[$k][$key] = $value;
                    }
                }
                $arData['UF_FILES'] = $arFiles;
            }

            $resAdd = $hlbClass::add($arData);
            if ($resAdd->isSuccess()) {
                $resProduct = Products::getInstance()->createProduct(
                    [
                        'NAME'        => $request['UF_NAME'],
                        'MODIFIED_BY' => $USER->GetID(),
                        'DATE_CREATE' => (new \DateTime())->format('d.m.Y H:i:s'),
                        'CREATED_BY'  => $USER->GetID(),
                        'ACTIVE'      => 'N',
                        'EVENT_ID'    => $resAdd->getId()
                    ]
                );

                if (isset($resProduct['status']) && $resProduct['status'] == 'error') throw new Exception($resProduct['message']);

                echo json_encode(['status' => 'success', 'step' => 2, 'id' => $resAdd->getId(), 'uuid' => $eventUUID, 'code' => $resProduct['code']], JSON_UNESCAPED_UNICODE);
            } else
                echo json_encode(['status' => 'error', 'message' => str_replace('<br>', ';', implode(', ', $resAdd->getErrors()))], JSON_UNESCAPED_UNICODE);
        }
        die;
    }

    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'setLocation'
    ) {
        $APPLICATION->RestartBuffer();
        if ((int)$arParams['ELEMENT_ID'] < 1) throw new Exception('Wrong param Event id');

        $hlblockEvents  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entityEvents   = HL\HighloadBlockTable::compileEntity($hlblockEvents);
        $hlbClassEvents = $entityEvents->getDataClass();
        $objEvent       = $hlbClassEvents::getByPrimary((int)$arParams['ELEMENT_ID'])->fetchObject();
        if (!is_object($objEvent) || $objEvent->getUfCompanyId() != $companyID) throw new Exception('Event not found');

        $hlblockLocations = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_LOCATION_ID"])->fetch();
        $entityLocation   = HL\HighloadBlockTable::compileEntity($hlblockLocations);
        $hlbClassLocation = $entityLocation->getDataClass();

        $actualLocations        = getLocationsIDByEventID($arParams['ELEMENT_ID']);
        $eventDataBeforeChanges = getEventData($arParams['ELEMENT_ID']);

        foreach ($actualLocations as $locationID) {
            if (is_array($request['LOCATION']) && !key_exists($locationID, $request['LOCATION'])) {
                $resLocation = $hlbClassLocation::delete($locationID);
                if (!$resLocation->isSuccess()) throw new Exception(implode(', ', $resLocation->getErrors()));
            }
        }

        foreach ($request['LOCATION'] as $locationID => $location) {
            $arDate = [];
            foreach ($location['DATE_TIME'] as $dateTime) {
                $arDate[] = (new DateTime($dateTime['DATE'] . ' ' . $dateTime['TIME']))->format('d.m.Y H:i:s');
            }
            $locationData = [
                'UF_EVENT_ID'    => $arParams['ELEMENT_ID'],
                'UF_DATE_TIME'   => $arDate,
                'UF_ADDRESS'     => $location['UF_ADDRESS'],
                'UF_ROOM'        => $location['UF_ROOM'],
                'UF_DURATION'    => $location['UF_DURATION'],
                'UF_COORDINATES' => $location['UF_COORDINATES'],
                'UF_LINK'        => [
                    json_encode($location['UF_LINK'][0], JSON_UNESCAPED_UNICODE),
                    json_encode($location['UF_LINK'][1], JSON_UNESCAPED_UNICODE)
                ],
            ];

            if (strpos($locationID, 'n_') === 0) {
                $resLocation = $hlbClassLocation::add($locationData);
                if (!$resLocation->isSuccess()) throw new Exception(implode(', ', $resLocation->getErrors()));
            }

            if (in_array($locationID, $actualLocations)) {
                $resLocation = $hlbClassLocation::update($locationID, $locationData);
                if (!$resLocation->isSuccess()) throw new Exception(implode(', ', $resLocation->getErrors()));
            }

        }


        \Custom\Core\Helper::removeUnnecessaryDatesInTicket($request['EVENT']);

        $eventDataAfterChanges = getEventData($arParams['ELEMENT_ID']);
        $arChanges             = [];
        $comparator            = new ArrayComparator();
        $arChanges             = $comparator->compareArrays($eventDataBeforeChanges, $eventDataAfterChanges);

        if (count($arChanges) > 0) {
            $serverName           = 'https://' . Option::get('main', 'server_name', '');
            $defaultMessageFields = [
                'SERVER_NAME'           => $serverName,
                'NEW_EVENT_PARAM_VALUE' => implode('<br>', $arChanges),
                'EVENT_ID'              => $arParams['ELEMENT_ID'],
                'EVENT_NAME'            => $objEvent->getUfName(),
                'EVENT_LINK'            => $serverName . '/event/' . getTicketIdByEventId($arParams['ELEMENT_ID']) . '/',
            ];

            // Определяем затронутые типы билетов
            $affectedTicketTypes = getAffectedTicketTypes($arChanges, $arParams['ELEMENT_ID']);

            // Получаем заказы только для затронутых типов билетов
            if (!empty($affectedTicketTypes)) {
                $orders = getOrdersByEventIDAndTicketTypes($arParams['ELEMENT_ID'], $affectedTicketTypes, $serverName);
            } else {
                // Если не удалось определить затронутые типы, используем старую логику
                $linkChanged = false;
                foreach ($arChanges as $change) {
                    if (strrpos($change, "Ссылка:") !== false) $linkChanged = true;
                }
                $orders = getOrdersByEventID($arParams['ELEMENT_ID'], $serverName, $linkChanged);
            }

            $objEvent->set('UF_DATE_OF_SIGNIFICANT_CHANGES', (new DateTime())->format('d.m.Y H:i:s'));
            $objEvent->save();

            foreach ($orders as $order) {
                $defaultMessageFields['REFUND_LINK'] = $serverName . '/refund/' . $order['ORDER_UUID'] . '/';
                \CEvent::Send('EVENT_HAS_BEEN_CHANGED', SITE_ID, array_merge($defaultMessageFields, $order));
            }
        }
        if ($objEvent->getUfType() != 6) {
            if (!is_array($request['LOCATION'])) throw new Exception('Адрес не заполнен');
            $loc = array_shift($request['LOCATION']);
            if (empty($loc) || empty($loc['UF_ADDRESS'])) throw new Exception('Адрес не заполнен');
        }

        setEventStep($request['EVENT'], 3);
        echo json_encode(['status' => 'success', 'step' => 3], JSON_UNESCAPED_UNICODE);

        die;
    }

    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'setSitMap'
    ) {
        $APPLICATION->RestartBuffer();

        if (
            USE_SEATMAP
            && isset($arResult['EVENT'])
            && isset($arResult['EVENT']['UF_TYPE'])
            && ($arResult['EVENT']['UF_TYPE'] === '7' || $arResult['EVENT']['UF_TYPE'] === '8')
            && $arResult['EVENT']['UF_SIT_MAP'] === '1'
            && !isset($this->arResult['SeatMap'])
        ) {
            $this->arResult['SeatMap'] = getSeatMapData($this->arResult);
        }

        setEventStep($request['EVENT'], 4);
        echo json_encode(['status' => 'success', 'step' => 4], JSON_UNESCAPED_UNICODE);

        die;
    }

    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'setVisibility'
    ) {
        $APPLICATION->RestartBuffer();
        if ((int)$request['EVENT'] < 1) throw new Exception('Wrong param Event id');
        if (!isset($request['VISIBILITY'])) throw new Exception('Wrong param visibility');

        $productEntity     = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $propFieldEventID  = $productEntity->getField('EVENT_ID');
        $propEventIDEntity = $propFieldEventID->getRefEntity();

        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $query       = $eventEntity
            ->setSelect(
                [
                    'ID',
                    'UF_COMPANY_ID',
                    'PRODUCT_ID' => 'PRODUCT.IBLOCK_ELEMENT_ID',
                ]
            )
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PRODUCT',
                    $propEventIDEntity,
                    ['this.ID' => 'ref.VALUE'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->setFilter(['ID' => $request['EVENT'], 'UF_COMPANY_ID' => $companyID])
            ->exec();
        $resEvent    = $query->fetch();
        if ((int)$resEvent['PRODUCT_ID'] < 1) throw new Exception('Product not found');

        if(\Custom\Core\Events::isClosedEvent($arParams['ELEMENT_ID']))
        {
            sendToModeration($arParams);
        }

        $objProduct = $productEntity->wakeUpObject($resEvent['PRODUCT_ID']);
        $objProduct->set('IS_CLOSED_EVENT', (bool)$request['VISIBILITY'] ? 19 : null);
        $result = $objProduct->save();
        if (!$result->isSuccess()) throw new Exception(implode(', ', $result->getErrors()));

        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'setTickets'
    ) {
        $APPLICATION->RestartBuffer();
        $arTickets = $request->get('tickets') ?: [];

        if (!isset($request['EVENT'])) throw new Exception('Wrong param Event id');
        if (count($arTickets) < 1) throw new Exception('Не задано ни одного типа билета');

        $hlblockEvents  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entityEvents   = HL\HighloadBlockTable::compileEntity($hlblockEvents);
        $hlbClassEvents = $entityEvents->getDataClass();
        $objEvent       = $hlbClassEvents::getByPrimary((int)$request['EVENT'])->fetchObject();

        $isSigned = contract_is_signed($companyID);

        if ($objEvent->get('UF_COMPANY_ID') != $companyID) throw new Exception('Нельзя редактировать чужие события');
        $eventUUID = $objEvent->get('UF_UUID');
        if (!$eventUUID) throw new Exception('Нельзя редактировать события без UUID');

        $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $query         = new ORM\Query\Query($productEntity);
        $resProduct    = $query
            ->setSelect(['ID', 'NAME', 'EVENT_ID.VALUE'])
            ->setFilter(['EVENT_ID.VALUE' => $request['EVENT']])
            ->exec();
        $objProduct    = $resProduct->fetchObject();

        if (!$objProduct || $objProduct->getId() < 1) throw new Exception('Такого продукта нет');

        if (
            USE_SEATMAP
            && !isset($this->arResult['SeatMap'])
            && $objEvent->get('UF_SIT_MAP')
        ) {
            $this->arResult['SeatMap'] = getSeatMapData($this->arResult, $request);
        }

        $offerEntity    = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $offerDataClass = $offerEntity->getDataClass();

        $arEventDates = \Custom\Core\Helper::getAllDatesFromEvent($request['EVENT']);

        foreach ($arTickets as $key => $ticket) {
            $errors = [];
            if ($arEventDates
                && count($arEventDates) > 1
                && ($ticket["DATES"] && !array_filter($ticket["DATES"], 'trim') || !$ticket["DATES"])
                && !$ticket["DATES_ALL"]
            ) {
                $errors[] = 'Не заполнено поле "Даты мероприятия"';
            }
            if ($ticket['MAX_QUANTITY'] < 1) $errors[] = 'Не заполнено поле "Max в заказе"';
            if ($ticket['TOTAL_QUANTITY'] < 1) $errors[] = 'Не заполнено поле "Количество"';
            if (empty($ticket['TYPE'])) $errors[] = 'Не заполнено поле "Название / Тип билета"';
            $ticket['CML2_LINK'] = $objProduct->getId();
            $ticket['NAME']      = $objProduct->getName();

            $ticket['PREVIEW_TEXT_TYPE'] = "html";
            $ticket['PREVIEW_TEXT']      = str_replace("\n", "<br/>", $ticket['PREVIEW_TEXT']);
            $ticket['ACTIVE'] = $ticket['ACTIVE']?'Y':'N';

            \Custom\Core\Helper::modifyFormatDateOffers($ticket, true);

            if (strpos($key, 'n_') === 0) {
                $ticket['QUANTITY'] = (int)$ticket['TOTAL_QUANTITY'];
                $ticket['XML_ID']   = $offerUUID = \Custom\Core\UUID::uuid8();
                if ((int)$ticket['PRICE'] > 0 && !$isSigned) $errors[] = 'Цена билета не может быть больше 0 ₽, так как не подписан договор';
                if (count($errors) > 0) throw new Exception(implode(';', $errors));
                $resOffer = Products::getInstance()->createProduct($ticket, true);
                if ($resOffer['status'] == 'error') throw new Exception($resOffer['message']);
            } else {
                $price = \Bitrix\Catalog\PriceTable::getList(
                    [
                        "select" => ['PRICE'],
                        "filter" => [
                            "=PRODUCT_ID" => $key,
                        ],
                    ]
                )->fetch();

                $query           = new ORM\Query\Query($offerEntity);
                $resOffer        = $query
                    ->setSelect(['XML_ID', 'IS_CREATED_SEAT_MAP', 'TYPE', 'TOTAL_QUANTITY'])
                    ->setFilter(['ID' => $key])
                    ->exec();
                $objOffer        = $resOffer->fetchObject();
                $currentTotalQty = $objOffer->get('TOTAL_QUANTITY')->getValue();


                if ((bool)$objOffer->get('IS_CREATED_SEAT_MAP')->getValue() === true) {
                    $ticket['TYPE']           = $objOffer->get('TYPE')->getValue();
                    $ticket['TOTAL_QUANTITY'] = $objOffer->get('TOTAL_QUANTITY')->getValue();
                    //$ticket['PRICE']          = $objOffer->get('PRICE')->getValue();
                    // todo добавить тип (офлайн/онлайн)
                } else {
                    $difference         = (int)$ticket['TOTAL_QUANTITY'] - $currentTotalQty;
                    $objCatalog         = \Bitrix\Catalog\ProductTable::wakeUpObject($key);
                    $currentQty         = $objCatalog->fillQuantity();
                    $ticket['QUANTITY'] = $currentQty + $difference;
                }

                if ((int)$ticket['PRICE'] > 0 && !$isSigned) $errors[] = 'Цена билета не может быть больше 0 ₽, так как не подписан договор';
                if (count($errors) > 0) throw new Exception(implode(';', $errors));
                $resOffer = Products::getInstance()->updateProduct($key, $ticket, true);
                if ($resOffer['status'] == 'error') throw new Exception($resOffer['message']);

                $offerUUID = $objOffer->get('XML_ID');

            }
        }
        //todo временное решение, так как отключена модерация
        //if ($objEvent->get('UF_STATUS') == 5) {
        $hlbClassEvents::update($request['EVENT'], ['BARCODE_UPDATE' => true]);
        //}


        //Промокоды
        $arPriceRules = $request->get('PROMOCODES') ?: [];

        $keysPriceRules = array_keys($arPriceRules);
        $newPriceRules  = [];

        foreach ($keysPriceRules as $key => $value) {
            if (strpos($value, 'n_') === 0) {
                $newPriceRules[] = $arPriceRules[$value];
                unset($keysPriceRules[$key]);
            }
        }

        unset($key, $value);


        $hlblockPriceRules  = HL\HighloadBlockTable::getById(HL_PRICE_RULES_ID)->fetch();
        $entityPriceRules   = HL\HighloadBlockTable::compileEntity($hlblockPriceRules);
        $hlbClassPriceRules = $entityPriceRules->getDataClass();

        $hlblockPromoCodes  = HL\HighloadBlockTable::getById(HL_PROMOCODES_ID)->fetch();
        $entityPromoCodes   = HL\HighloadBlockTable::compileEntity($hlblockPromoCodes);
        $hlbClassPromoCodes = $entityPromoCodes->getDataClass();

        if (count($keysPriceRules) > 0) { // update
            $promoCodesIds = [];

            $priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');
            $query            = $priceRulesEntity->setSelect(
                [
                    '*',
                    'EVENT_ID'         => 'REF_EVENTS_ID.VALUE',
                    'REF_PROMOCODE_ID' => 'REF_PROMOCODE.ID',

                ]
            )->setFilter(
                [
                    'UF_XML_ID' => $keysPriceRules,
                    'EVENT_ID'  => $request['EVENT'],
                    'UF_TYPE'   => PRICE_RULE_TYPE_COUPON
                ]
            )->exec();

            $obElementPriceRules = $query->fetchCollection();

            //validate and get promocode ids
            foreach ($obElementPriceRules as $objPriceRule) {
                $uuid = $objPriceRule->get('UF_XML_ID');
                validatePriceRulePromoCodeRequestItem($arPriceRules[$uuid], $request['EVENT'], false, $uuid);

                // получаем идентификаторы промокодов
                $promoCode = $objPriceRule->get('REF_PROMOCODE');
                if (!is_null($promoCode)) {
                    $promoCodesIds[] = $promoCode->get('ID');
                }
            }

            if (isset($promoCodesIds) && count($promoCodesIds) > 0) {
                $obElementPromoCodes = $hlbClassPromoCodes::getList(
                    [
                        'select' => ['*'],
                        'filter' => [
                            'ID' => $promoCodesIds,
                        ],
                    ]
                );

                $collectionPromoCodes = $obElementPromoCodes->fetchCollection();
            }


            foreach ($obElementPriceRules as $objPriceRule) {
                $priceRuleId = $objPriceRule->get('ID');
                $uuid        = $objPriceRule->get('UF_XML_ID');

                fillModelUpdatePriceRuleForPromoCode($arPriceRules[$uuid], $objPriceRule);

                $resUpdate = $objPriceRule->save();

                if (!$resUpdate->isSuccess()) {
                    throw new \Exception(implode(', ', $resUpdate->getErrors()));
                }

                unset($uuid);
            }
        }

        if (count($newPriceRules) > 0) {
            foreach ($newPriceRules as $priceRule) {
                validatePriceRulePromoCodeRequestItem($priceRule, $request['EVENT']);
            }

            foreach ($newPriceRules as $priceRule) {
                $objPriceRule = $hlbClassPriceRules::createObject();
                $code         = mb_strtoupper($priceRule['UF_CODE']);

                fillModelCreatePriceRuleForPromoCode($priceRule, $objPriceRule, $code, $request['EVENT']);

                $resAdd = $objPriceRule->save();

                if ($resAdd->isSuccess()) {
                    $priceRuleId = $resAdd->getId();

                    $objCoupon  = $hlbClassPromoCodes::createObject();
                    $uuidCoupon = \Custom\Core\UUID::uuid4();

                    $objCoupon->set('UF_XML_ID', $uuidCoupon);
                    $objCoupon->set('UF_CODE', $code);
                    $objCoupon->set('UF_RULE_ID', (int)$priceRuleId);
                    $objCoupon->set('UF_IS_USE', 0);

                    $resAddPromoCode = $objCoupon->save();

                    if (!$resAddPromoCode->isSuccess()) {
                        throw new \Exception(implode(', ', $resAddPromoCode->getErrors()));
                    }

                    unset($priceRuleId);
                    unset($uuidCoupon);
                } else {
                    throw new \Exception(implode(', ', $resAdd->getErrors()));
                }

                unset($code);
            }
        }


        //скидки
        $arPriceRulesDiscounts = $request->get('DISCOUNTS') ?: [];

        $keysPriceRulesDiscounts = array_keys($arPriceRulesDiscounts);
        $newPriceRulesDiscounts  = [];

        foreach ($keysPriceRulesDiscounts as $key => $value) {
            if (strpos($value, 'n_') === 0) {
                $newPriceRulesDiscounts[] = $arPriceRulesDiscounts[$value];
                unset($keysPriceRulesDiscounts[$key]);
            }
        }

        unset($key, $value);

        if (count($keysPriceRulesDiscounts) > 0) { // update
            $priceRulesDiscountsEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');

            $query = $priceRulesDiscountsEntity->setSelect(
                [
                    '*',
                    'EVENT_ID' => 'REF_EVENTS_ID.VALUE',
                ]
            )->setFilter(
                [
                    'UF_XML_ID' => $keysPriceRulesDiscounts,
                    'EVENT_ID'  => $request['EVENT'],
                    'UF_TYPE'   => PRICE_RULE_TYPE_DISCOUNT
                ]
            )->exec();

            $obElementPriceRulesDiscounts = $query->fetchCollection();

            foreach ($obElementPriceRulesDiscounts as $objPriceRuleDiscount) {
                $uuid = $objPriceRuleDiscount->get('UF_XML_ID');
                validatePriceRuleDiscountRequestItem($arPriceRulesDiscounts[$uuid], $request['EVENT'], false, $uuid);
            }

            foreach ($obElementPriceRulesDiscounts as $objPriceRuleDiscount) {
                $uuid = $objPriceRuleDiscount->get('UF_XML_ID');

                $objPriceRuleDiscount = fillModelUpdatePriceRuleForDiscount(
                    $arPriceRulesDiscounts[$uuid],
                    $objPriceRuleDiscount
                );

                $resUpdate = $objPriceRuleDiscount->save();

                if (!$resUpdate->isSuccess()) {
                    throw new \Exception(implode(', ', $resUpdate->getErrors()));
                }

                unset($uuid);
            }
        }

        if (count($newPriceRulesDiscounts) > 0) {
            //validate
            foreach ($newPriceRulesDiscounts as $priceRuleDiscount) {
                validatePriceRuleDiscountRequestItem($priceRuleDiscount, $request['EVENT']);
            }

            foreach ($newPriceRulesDiscounts as $priceRuleDiscount) {
                $objPriceRuleDiscount = $hlbClassPriceRules::createObject();
                $objPriceRuleDiscount = fillModelCreatePriceRuleForDiscount(
                    $priceRuleDiscount,
                    $objPriceRuleDiscount,
                    $request['EVENT']
                );

                $resAdd = $objPriceRuleDiscount->save();

                if (!$resAdd->isSuccess()) {
                    throw new \Exception(implode(', ', $resAdd->getErrors()));
                }
            }
        }

        setEventStep($request['EVENT'], 5);
        echo json_encode(['status' => 'success', 'step' => 5, 'uuid' => $eventUUID, 'id' => $request['EVENT']], JSON_UNESCAPED_UNICODE);
        die;
    }

    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'sendToModeration'
    ) {
        $APPLICATION->RestartBuffer();
        if (!isset($arParams['ELEMENT_ID'])) throw new Exception('Wrong param Event id');
        $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
        $hlbClass = $entity->getDataClass();
        $event    = $hlbClass::getList(
            [
                'select' => [
                    'ID',
                    'UF_NAME',
                    'UF_IMG',
                    'UF_TYPE',
                    'UF_AGE_LIMIT',
                    'UF_DESCRIPTION',
                    'UF_CATEGORY',
                    'UF_COMPANY_ID',
                    'STATUS_CODE' => 'STATUS.UF_XML_ID',
                ],
                'filter' => ['ID' => $arParams['ELEMENT_ID']],
                "runtime" => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'STATUS',
                        '\Custom\Core\Events\EventsStatusTable',
                        ['this.UF_STATUS' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ],
                'limit'  => 1
            ]
        );
        $resEvent = $event->fetch();

        if ($resEvent['ID'] < 1) throw new Exception('Такого события нет');
        if ($resEvent['UF_COMPANY_ID'] != $companyID) throw new Exception('Нельзя редактировать чужие события');
        if ($resEvent['STATUS_CODE'] == 'cancelled') throw new Exception('Нельзя отправить на модерацию отмененное событие');
        //\Bitrix\Main\Diag\Debug::writeToFile($resEvent, '', 'VALIDATIONS.txt');
        $errors = [];
        global $USER_FIELD_MANAGER;
        $fieldsTitles = $USER_FIELD_MANAGER->getUserFieldsWithReadyData(
            'HLBLOCK_' . $arParams["HLDB_EVENTS_ID"],
            [],
            'ru'
        );
        foreach ($resEvent as $key => $value) {
            if (in_array($key, ['UF_IMG', 'UF_TYPE', 'UF_AGE_LIMIT', 'UF_CATEGORY']) && intval($value) < 1) {
                $errors[$key] = "Не заполнено поле «" . $fieldsTitles[$key]['EDIT_FORM_LABEL'] . "»";
            }

            if (in_array($key, ['UF_DESCRIPTION', 'UF_NAME']) && strlen(strip_tags(trim($value))) < 1) {
                $errors[$key] = "Не заполнено поле «" . $fieldsTitles[$key]['EDIT_FORM_LABEL'] . "»";
            }

            if (in_array($key, ['UF_DESCRIPTION']) && mb_strlen(strip_tags(trim($value)), 'UTF-8') > 10000) {
                $errors[$key] = "Максимальная длина поля «" . $fieldsTitles[$key]['EDIT_FORM_LABEL'] . "» 10000 символов";
            }
        }

        $query  = new ORM\Query\Query('\Custom\Core\Events\EventsDateAndLocationTable');
        $result = [];
        $obRes  = $query
            ->setSelect(['ID', 'UF_EVENT_ID', 'UF_DATE_TIME', 'UF_DURATION', 'UF_ADDRESS', 'UF_ROOM', 'UF_LINK'])
            ->setFilter(['UF_EVENT_ID' => $arParams['ELEMENT_ID']])
            ->countTotal(true)
            ->exec();
        if ($obRes->getCount() < 1) $errors[] = "Не заполнены дата и время мероприятия";
        $arDates      = [];
        $fieldsTitles = $USER_FIELD_MANAGER->getUserFieldsWithReadyData(
            'HLBLOCK_' . HL_EVENTS_LOCATION_ID,
            [],
            'ru'
        );
        while ($location = $obRes->fetch()) {
            $location['UF_DATE_TIME'] = unserialize($location['UF_DATE_TIME']) ?? [];
            $arDates                  = array_merge($arDates, $location['UF_DATE_TIME']);
            if (count($location['UF_DATE_TIME']) < 1) $errors[] = "Не заполнено поле «" . $fieldsTitles['UF_DATE_TIME']['ERROR_MESSAGE'] . "»";
            if ((int)$location['UF_DURATION'] < 1) $errors[] = "Не заполнено поле «" . $fieldsTitles['UF_DURATION']['ERROR_MESSAGE'] . "»";

            if ($resEvent['UF_TYPE'] == 6 || $resEvent['UF_TYPE'] == 8) {
                //ДЛЯ “ОНЛАЙН” И “ОФЛАЙН И ОНЛАЙН” обязательна ссылка на трансляцию
                $link = json_decode($location['UF_LINK'][0], true);
                if (strlen($link[0]) < 1) $errors[] = "Не заполнено поле «Название ссылки»";

                if (!preg_match("/^(http:\/\/|https:\/\/)*[а-яА-ЯёЁa-z0-9\-_]+(\.[а-яА-ЯёЁa-z0-9\-_]+)+(\/\S*)*$/iu", stripslashes($link[1]))) $errors[] = "Неправильная ссылка на трансляцию";
            }
            if ($resEvent['UF_TYPE'] == 7 || $resEvent['UF_TYPE'] == 8) {
                //ТОЛЬКО ДЛЯ “ОФЛАЙН” или “ОФЛАЙН И ОНЛАЙН” мероприятий - Локация и помещение
                if (strlen($location['UF_ADDRESS']) < 1) $errors[] = "Не заполнено поле «" . $fieldsTitles['UF_ADDRESS']['ERROR_MESSAGE'] . "»";
                //if (strlen($location['UF_ROOM']) < 1) $errors[] = "Не заполнено поле «" . $fieldsTitles['UF_ROOM']['ERROR_MESSAGE'] . "»";
            }
        }

        $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $query         = new ORM\Query\Query($productEntity);
        $elementEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $propField     = $elementEntity->getField('CML2_LINK');
        $propEntity    = $propField->getRefEntity();

        checkEvent($arParams, $companyID);

        sendToModeration($arParams);

        echo json_encode(['status' => 'success', 'step' => 7, 'id' => $arParams['ELEMENT_ID']], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'deleteTicket'
    ) {
        $APPLICATION->RestartBuffer();
        if (!isset($request['ID'])) throw new Exception('Wrong param ID');

        $offerEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $query       = new ORM\Query\Query($offerEntity);
        $resOffer    = $query
            ->setSelect(['ID', 'TYPE', 'XML_ID', 'IS_CREATED_SEAT_MAP'])
            ->setFilter(['ID' => $request['ID']])
            ->exec();
        $objOffer    = $resOffer->fetchObject();
        if (!is_object($objOffer)) throw new Exception('Такого билета нет');
        $offerUUID = $objOffer->get('XML_ID');
        if ($objOffer->getId() > 0) {
            if ((bool)$objOffer->get('IS_CREATED_SEAT_MAP')->getValue() === true) {
                throw new Exception('Сначала удалите цену в SeatMap!');
            }
            if (checkOrdersExistsByOfferID($request['ID'])) {
                $objCatalog = \Bitrix\Catalog\ProductTable::wakeUpObject($request['ID']);
                $objCatalog->setQuantity(0);
                $resCatalog = $objCatalog->save();
                $objOffer->setTotalQuantity(0);
                $objOffer->save();

                $objBarcode = new \Custom\Core\Barcode();
                $objBarcode->deleteTicketBarcode($request['ID'], ["new", "booked"]);
                $objBarcode->clearBasketThisTicket($request['ID']);

                echo json_encode(['status' => 'error', 'message' => 'Нельзя удалить тип билета, использующийся в заказах. Остатки по данному типу были обнулены.', 'clear_count' => true], JSON_UNESCAPED_UNICODE);
                die;
            } else {
                $resDelete = $objOffer->delete();

                $objBarcode = new \Custom\Core\Barcode();
                $objBarcode->deleteTicketBarcode($request['ID']);
                $objBarcode->clearBasketThisTicket($request['ID']);

                if (!$resDelete->isSuccess()) throw new Exception(implode(', ', $resDelete->getErrors()));
            }
        }
        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }

    if (isset($arParams['ACTION']) && $arParams['ACTION'] == 'deletePriceRule') {
        $APPLICATION->RestartBuffer();
        if (!(isset($request['ID']) && is_string($request['ID']) && strlen($request['ID']) === 36)) {
            throw new Exception('Wrong param ID');
        }

        $priceRuleEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');
        $query           = $priceRuleEntity->setSelect(['ID', 'UF_NUMBER_OF_USES'])->setFilter(['UF_XML_ID' => $request['ID']])->exec();

        if ($priceRule = $query->fetchObject()) {

            if ((int)$priceRule->get('UF_NUMBER_OF_USES') > 0) {
                throw new Exception('Удаление невозможно, так как правило уже используется!');
            }

            $promoCodesEntity = new ORM\Query\Query('Custom\Core\Events\PromoCodesTable');
            $promoCodeQuery   = $promoCodesEntity->setSelect(['ID'])->setFilter(
                ['UF_RULE_ID' => $priceRule->get('ID')]
            )->exec();

            while ($promoCodeItem = $promoCodeQuery->fetchObject()) {
                $promoCodeItem->delete();
            }

            $priceRule->delete();
        } else {
            throw new Exception('Такого правила не существует');
        }

        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }


    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'setQuestionnaire'
    ) {

        $APPLICATION->RestartBuffer();
        $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
        $hlbClass = $entity->getDataClass();
        if ((int)$arParams['ELEMENT_ID'] < 1) throw new Exception('Wrong param Event id');

        $query = $hlbClass::getList(
            [
                'select' => [
                    'ID',
                    'UF_COMPANY_ID',
                    'UF_QUESTIONNAIRE_FIELDS',
                    'UF_QUESTIONNAIRE_DESCRIPTION',
                    'UF_QUESTIONNAIRE_ACTIVE',
                    'UF_QUESTIONNAIRE_FOREACH_TICKETS',
                ],
                'filter' => ['ID' => $arParams['ELEMENT_ID'], 'UF_COMPANY_ID' => $companyID],
            ]
        );

        $objEvent = $query->fetchObject();
        if ($objEvent->getId() < 1) throw new Exception('Такого события нет');

        $objQuestionnaire = new \Custom\Core\Questionnaires($request);
        if (!$objQuestionnaire->isFilled((int)$objEvent->getId())) {
            $json = json_encode($objQuestionnaire->getFields());
            $objEvent->set('UF_QUESTIONNAIRE_FIELDS', $json);
        }

        $objEvent->set('UF_QUESTIONNAIRE_DESCRIPTION', $objQuestionnaire->getDescription());
        $objEvent->set('UF_QUESTIONNAIRE_ACTIVE', $objQuestionnaire->getQuestionnaireActive());
        $objEvent->set('UF_QUESTIONNAIRE_FOREACH_TICKETS', $objQuestionnaire->getForeachTickets());
        $resEvent = $objEvent->save();

        if (!$resEvent->isSuccess()) throw new Exception(implode(', ', $resEvent->getErrors()));
        setEventStep($request['EVENT'], 6);
        echo json_encode(['status' => 'success', 'step' => 6], JSON_UNESCAPED_UNICODE);

        die;
    }

    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'setPaySystem'
    ) {
        $APPLICATION->RestartBuffer();
        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $query       = $eventEntity
            ->setSelect(['ID', 'UF_PAY_SYSTEM'])
            ->setFilter(['ID' => $request['EVENT']])
            ->exec();
        $objEvent    = $query->fetchObject();
        if ($objEvent->getId() < 1) throw new Exception('Такого события нет');
        if (isset($request['UF_RESERVATION_VALIDITY_PERIOD'])) $objEvent->set('UF_RESERVATION_VALIDITY_PERIOD', $request['UF_RESERVATION_VALIDITY_PERIOD']);
        $objEvent->set('UF_PAY_SYSTEM', $request['payment']);
        $resEvent = $objEvent->save();
        if (!$resEvent->isSuccess()) throw new Exception(implode(', ', $resEvent->getErrors()));
        setEventStep($request['EVENT'], 7);
        echo json_encode(['status' => 'success', 'step' => 7], JSON_UNESCAPED_UNICODE);
        die;
    }

    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'setWidgets'
    ) {
        $APPLICATION->RestartBuffer();
        if (check_bitrix_sessid()) {
            setEventStep($arParams['ELEMENT_ID'], 8);
            echo json_encode(['status' => 'success', 'step' => 8], JSON_UNESCAPED_UNICODE);
        }
        die;
    }

    if (
        isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'delAttachment' &&
        !empty($request['ID'])
    ) {
        $APPLICATION->RestartBuffer();
        $query    = new ORM\Query\Query('\Bitrix\Main\FileTable');
        $resFiles = $query
            ->setSelect(['ID'])
            ->setFilter(['EXTERNAL_ID' => $request['ID']])
            ->exec();
        $fid      = (int)($resFiles->fetch())['ID'];

        if ($fid > 0) {

            CFile::Delete($fid);
            $filePropsEntity    = Custom\Core\Events\EventsUfFilesTable::getEntity();
            $filePropsDataClass = $filePropsEntity->getDataClass();
            $resFile            = $filePropsDataClass::getByPrimary($fid);
            $resProp            = $resFile->fetchObject();
            $eventId            = $resProp->getId();
            $resDelProp         = $resProp->delete();
            if (!$resDelProp->isSuccess()) throw new Exception(implode(', ', $resDelProp->getErrors()));
            $eventEntity    = Custom\Core\Events\EventsTable::getEntity();
            $dataClassEvent = $eventEntity->getDataClass();
            $resEvent       = $dataClassEvent::getByPrimary($eventId);
            if ($objEvent = $resEvent->fetchObject()) {
                $arFiles = $objEvent->get('UF_FILES') ?? [];
                foreach ($arFiles as $key => $value) {
                    if ($value == $fid) {
                        unset($arFiles[$key]);
                    }
                }
                $objEvent->set('UF_FILES', $arFiles);
                $objEvent->save();
            }
        }
        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'delPhoto'
    ) {
        $APPLICATION->RestartBuffer();
        if ($request['ID'] < 1) throw new Exception('Wrong param Event id');
        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $query       = $eventEntity
            ->setSelect(['ID', 'UF_IMG', 'UF_COMPANY_ID', 'UF_STATUS'])
            ->setFilter(['ID' => $request['ID']])
            ->countTotal(true)
            ->exec();
        if ($query->getCount() < 1) throw new Exception('Event not found');
        $objEvent = $query->fetchObject();
        if ($objEvent->getUfCompanyId() != $companyID) throw new Exception('Access denied');
        if ($objEvent->getUfImg() < 1) throw new Exception('Photo not found');
        CFile::Delete($objEvent->getUfImg());
        $objEvent->setUfImg('');
        //todo временно отключено
        //if (in_array($objEvent->getUfStatus(), [2, 5])) $objEvent->setUfStatus(4);
        $objEvent->save();
        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'publish') {
        $APPLICATION->RestartBuffer();

        checkEvent($arParams, $companyID, true);

        $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
        $hlbClass = $entity->getDataClass();
        $resEvent = $hlbClass::getList(
            [
                'filter'      => ['ID' => $arParams['ELEMENT_ID']],
                'count_total' => true
            ]
        );
        if ($resEvent->getCount() < 1) throw new Exception('Event not found');
        $objEvent = $resEvent->fetchObject();
        $objEvent->setUfStatus(5);
        $objEvent->save();

        $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $productClass  = $productEntity->getDataClass();
        $query         = new ORM\Query\Query($productEntity);
        $resProduct    = $query
            ->setSelect(['ID'])
            ->setFilter(['EVENT_ID.VALUE' => $arParams['ELEMENT_ID']])
            ->exec();
        while ($product = $resProduct->fetch()) {
            $productClass::update($product['ID'], ['ACTIVE' => 'Y']);

            \Custom\Core\Products::addToIndex($product['ID']);
        }
        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'unpublish') {
        $APPLICATION->RestartBuffer();
        if ($arParams['ELEMENT_ID'] < 1) throw new Exception('Wrong param Event id');
        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $query       = $eventEntity
            ->setSelect(['ID', 'UF_STATUS', 'UF_COMPANY_ID'])
            ->setFilter(['ID' => $arParams['ELEMENT_ID']])
            ->countTotal(true)
            ->exec();
        if ($query->getCount() < 1) throw new Exception('Event not found');
        $objEvent = $query->fetchObject();
        if ($objEvent->getUfCompanyId() != $companyID) throw new Exception('Access denied');
        if ($objEvent->getUfStatus() != 5) throw new Exception('Отменить публикацию можно только в статусе "Опубликовано"');
        $objEvent->setUfStatus(2);
        $objEvent->save();

        $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $productClass  = $productEntity->getDataClass();
        $query         = new ORM\Query\Query($productEntity);
        $resProduct    = $query
            ->setSelect(['ID'])
            ->setFilter(['EVENT_ID.VALUE' => $arParams['ELEMENT_ID']])
            ->exec();
        while ($product = $resProduct->fetch()) {
            $productClass::update($product['ID'], ['ACTIVE' => 'N']);

            \Custom\Core\Products::addToIndex($product['ID']);
        }
        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'sendToUnModeration') {
        $APPLICATION->RestartBuffer();
        if ($arParams['ELEMENT_ID'] < 1) throw new Exception('Wrong param Event id');
        $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
        $hlbClass = $entity->getDataClass();
        $event    = $hlbClass::getList(
            [
                'select' => [
                    'ID',
                    'UF_COMPANY_ID'
                ],
                'filter' => ['ID' => $arParams['ELEMENT_ID']],
                'limit'  => 1
            ]
        );
        $resEvent = $event->fetch();
        if ($resEvent['ID'] < 1) throw new Exception('Такого события нет');
        if ($resEvent['UF_COMPANY_ID'] != $companyID) throw new Exception('Нельзя редактировать чужие события');

        $hlbClass::update($arParams['ELEMENT_ID'], ['UF_STATUS' => 4]);

        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'delEvent') {

        $APPLICATION->RestartBuffer();
        if ($arParams['ELEMENT_ID'] < 1) throw new Exception('Wrong param Event id');
        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $query       = $eventEntity
            ->setSelect(['ID', 'UF_STATUS', 'UF_COMPANY_ID'])
            ->setFilter(['ID' => $arParams['ELEMENT_ID']])
            ->countTotal(true)
            ->exec();
        if ($query->getCount() < 1) throw new Exception('Event not found');
        $objEvent = $query->fetchObject();
        if ($objEvent->getUfCompanyId() != $companyID) throw new Exception('Access denied');
        if ($objEvent->getUfStatus() != 4) throw new Exception('Нельзя удалить событие');
        $dbRes = \Bitrix\Sale\Order::getList(
            [
                'select'      => [
                    'ORGANIZER_ID' => 'PROPERTY_ORGANIZER.VALUE',
                    'EVENT_ID'     => 'PROPERTY_EVENT_ID.VALUE',
                ],
                'filter'      => [
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID', //по свойству
                    "PROPERTY_ORGANIZER.VALUE" => $companyID, //и по его значению
                    "PROPERTY_EVENT_ID.CODE"   => "EVENT_ID", //и по его значению
                    "PROPERTY_EVENT_ID.VALUE"  => $arParams['ELEMENT_ID'], //и по его значению
                ],
                'runtime'     => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_EVENT_ID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                ],
                'group'       => ['EVENT_ID'],
                'limit'       => 1,
                'count_total' => true,
            ]
        );
        if ($dbRes->getCount() > 0) throw new Exception('Нельзя удалить событие, которое используется в заказах');

        $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $query         = new ORM\Query\Query($productEntity);
        $resProduct    = $query
            ->setSelect(['ID', 'NAME', 'EVENT_ID.VALUE'])
            ->setFilter(['EVENT_ID.VALUE' => $arParams['ELEMENT_ID']])
            ->countTotal(true)
            ->exec();

        if ($resProduct->getCount() > 0) {
            $objProduct     = $resProduct->fetchObject();
            $offerEntity    = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
            $offerDataClass = $offerEntity->getDataClass();
            $query          = new ORM\Query\Query($offerEntity);
            $resOffer       = $query
                ->setSelect(['ID'])
                ->setFilter(['CML2_LINK.VALUE' => $objProduct->getId()])
                ->exec();
            while ($offer = $resOffer->fetch()) {
                $offerDataClass::delete($offer['ID']);
            }

            $productDataClass = $productEntity->getDataClass();
            $productDataClass::delete($objProduct->getId());
        }

        $query = new ORM\Query\Query('\Custom\Core\Events\EventsDateAndLocationTable');
        $obRes = $query
            ->setSelect(['ID', 'UF_EVENT_ID'])
            ->setFilter(['UF_EVENT_ID' => $arParams['ELEMENT_ID']])
            ->countTotal(true)
            ->exec();
        while ($location = $obRes->fetchObject()) {
            $location->delete();
        }

        $widgetEntity = new ORM\Query\Query('Custom\Core\Tickets\WidgetsTable');
        $query        = $widgetEntity
            ->setSelect(['UF_EVENT_ID', 'ID'])
            ->setFilter(['UF_EVENT_ID' => $arParams['ELEMENT_ID']])
            ->exec();
        while ($widget = $query->fetchObject()) {
            $widget->delete();
        }

        $objEvent->delete();
        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'getQuestionnaires') {
        $APPLICATION->RestartBuffer();
        require_once __DIR__ . '/export_excel.php';
        //        //echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'cancellationForm') {
        $APPLICATION->RestartBuffer();
        require_once __DIR__ . '/cancellation_form.php';
        exit;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'cancellationEvent') {
        $APPLICATION->RestartBuffer();
        $requestEntity   = HL\HighloadBlockTable::compileEntity('TicketRefundRequests');
        $hlbClassRequest = $requestEntity->getDataClass();

        $reasonID = \Bitrix\Main\UserFieldTable::getList(
            [
                "filter"  => [
                    "HL.NAME"     => 'TicketRefundRequests',
                    "FIELD_NAME"  => "UF_REASON_FOR_RETURN",
                    "ENUM.XML_ID" => 'cancellation',
                ],
                "select"  => [
                    "ENUM_ID"     => "ENUM.ID",
                    "ENUM_XML_ID" => "ENUM.XML_ID",
                    "ENUM_NAME"   => "ENUM.VALUE",
                ],
                "runtime" => [
                    new \Bitrix\Main\Entity\ExpressionField(
                        'HL_ID',
                        'REPLACE(%s, "HLBLOCK_", "")',
                        ['ENTITY_ID']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'HL',
                        '\Bitrix\Highloadblock\HighloadBlockTable',
                        ['this.HL_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'ENUM',
                        '\Custom\Core\FieldEnumTable',
                        ['this.ID' => 'ref.USER_FIELD_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ],
                'order'   => ['ENUM_ID' => 'ASC'],
                'cache'   => ['ttl' => 3600],
            ]
        )->fetch()['ENUM_ID'];

        $statusRejectedID = \Bitrix\Main\UserFieldTable::getList(
            [
                "filter"  => [
                    "HL.NAME"     => 'TicketRefundRequests',
                    "FIELD_NAME"  => "UF_REVIEW_STATUS",
                    "ENUM.XML_ID" => 'reject',
                ],
                "select"  => [
                    "ENUM_ID"     => "ENUM.ID",
                    "ENUM_XML_ID" => "ENUM.XML_ID",
                    "ENUM_NAME"   => "ENUM.VALUE",
                ],
                "runtime" => [
                    new \Bitrix\Main\Entity\ExpressionField(
                        'HL_ID',
                        'REPLACE(%s, "HLBLOCK_", "")',
                        ['ENTITY_ID']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'HL',
                        '\Bitrix\Highloadblock\HighloadBlockTable',
                        ['this.HL_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'ENUM',
                        '\Custom\Core\FieldEnumTable',
                        ['this.ID' => 'ref.USER_FIELD_ID'],
                        ['join_type' => 'LEFT'],
                    ),
                ],
                'order'   => ['ENUM_ID' => 'ASC'],
                'cache'   => ['ttl' => 3600],
            ]
        )->fetch()['ENUM_ID'];

        if ((int)$statusRejectedID < 1) throw new \Exception('Status rejected not found');

        $orders = Bitrix\Sale\Order::getList(
            [
                'select'      => [
                    'ID',
                    'EVENT_ID'     => 'PROPERTY_EVENT_ID.VALUE',
                    'ORGANIZER_ID' => 'PROPERTY_ORGANIZER.VALUE',
                    'FULL_NAME'    => 'PROPERTY_FIO.VALUE',
                    'EMAIL'        => 'PROPERTY_EMAIL.VALUE',
                    'PHONE'        => 'PROPERTY_PHONE.VALUE',
                    'BASKET_ITEM_ID',
                    'BASKET_ITEM_SUM',
                    'PRICE',
                    'REFUND_REF.UF_REVIEW_STATUS'
                ],
                'filter'      => [
                    "PROPERTY_EVENT_ID.CODE"   => "EVENT_ID",
                    "PROPERTY_EVENT_ID.VALUE"  => $arParams['ELEMENT_ID'],
                    "PROPERTY_ORGANIZER.CODE"  => 'ORGANIZER_ID',
                    "PROPERTY_ORGANIZER.VALUE" => $companyID,
                    "PROPERTY_FIO.CODE"        => 'FIO',
                    "PROPERTY_EMAIL.CODE"      => 'EMAIL',
                    "PROPERTY_PHONE.CODE"      => 'PHONE',
                    "STATUS.STATUS_ID"         => ['P', 'F'],
                    [
                        'LOGIC' => 'OR',
                        [
                            "REFUND_TICKET_REFS.ID" => false,
                        ],
                        [
                            'REFUND_REF.UF_REVIEW_STATUS' => $statusRejectedID,
                        ]
                    ]
                ],
                'runtime'     => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_EVENT_ID',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_ORGANIZER',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'inner']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_FIO',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_EMAIL',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPERTY_PHONE',
                        'Bitrix\Sale\Internals\OrderPropsValueTable',
                        ['=this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'BASKET_REFS',
                        'Bitrix\Sale\Internals\BasketTable',
                        ['this.ID' => 'ref.ORDER_ID'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'BASKET_ITEM_ID', 'GROUP_CONCAT(%s)', ['BASKET_REFS.ID']
                    ),
                    new \Bitrix\Main\Entity\ExpressionField(
                        'BASKET_ITEM_SUM', 'SUM(%s)', ['BASKET_REFS.PRICE']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'REFUND_TICKET_REFS',
                        'Custom\Core\Tickets\TicketRefundRequestsUfBasketItemIdTable',
                        ['this.BASKET_REFS.ID' => 'ref.VALUE'],
                        ['join_type' => 'left']
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'REFUND_REF',
                        'Custom\Core\Tickets\TicketRefundRequestsTable',
                        ['this.REFUND_TICKET_REFS.ID' => 'ref.ID'],
                        ['join_type' => 'left']
                    ),
                ],
                'count_total' => true
            ]
        );

        if ($orders->getCount() < 1) throw new Exception('Заказы для события не найдены');

        $hlblock = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entity  = HL\HighloadBlockTable::compileEntity($hlblock);

        $objEvent = $entity->wakeUpObject($arParams['ELEMENT_ID']);
        $objEvent->set('UF_STATUS', 7);
        $objEvent->save();

        while ($order = $orders->fetch()) {
            $arData = [
                'UF_FULL_NAME'         => $order['FULL_NAME'],
                'UF_EMAIL'             => $order['EMAIL'],//
                'UF_PHONE'             => preg_replace('~\D+~', '', $order['PHONE']),
                'UF_REASON_FOR_RETURN' => $reasonID,
                'UF_BASKET_ITEM_ID'    => explode(',', $order['BASKET_ITEM_ID']),
                'UF_DATE_TIME'         => (new DateTime())->format('d.m.Y H:i:s'),
                'UF_COMPANY_ID'        => $order['ORGANIZER_ID'],
                'UF_ORDER_ID'          => $order['ID'],
                'UF_ACTUAL_REFUND_SUM' => $order['BASKET_ITEM_SUM'],
            ];
            $hlbClassRequest::add($arData);
        }
        echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'copyEvent') {
        $APPLICATION->RestartBuffer();
        if ($arParams['ELEMENT_ID'] < 1) throw new Exception('Wrong param Event id');
        // Копируем событие
        $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
        $eventClass  = $eventEntity->getEntity()->getDataClass();
        $query       = $eventEntity
            ->setSelect(['*'])
            ->setFilter(['ID' => $arParams['ELEMENT_ID'], 'UF_COMPANY_ID' => $companyID])
            ->setGroup('ID')
            ->countTotal(true)
            ->exec();
        if ($query->getCount() < 1) throw new Exception('Event not found');

        $arNewEvent = $query->fetch();
        unset($arNewEvent['UF_DATE_CREATE'], $arNewEvent['UF_DATE_UPDATE'], $arNewEvent['ID'], $arNewEvent['UF_XML_ID']);

        $copyEventName = Custom\Core\Helper::trimIBElementName($arNewEvent['UF_NAME'], "", "(копия)");

        $eventUUID                    = \Custom\Core\UUID::uuid8();
        $oldEventUUID                 = $arNewEvent['UF_UUID'];
        $arNewEvent['UF_NAME']        = $copyEventName;
        $arNewEvent['UF_CREATED_BY']  = $USER->GetID();
        $arNewEvent['UF_COMPANY_ID']  = $companyID;
        $arNewEvent['UF_MODIFIED_BY'] = $USER->GetID();
        $arNewEvent['UF_STATUS']      = 4;
        $arNewEvent['UF_UUID']        = $eventUUID;

        $resEvent = $eventClass::add($arNewEvent);
        if (!$resEvent->isSuccess()) throw new Exception(implode(', ', $resEvent->getErrors()));


        //Создание продукта
        $resProduct = Products::getInstance()->createProduct(
            [
                'NAME'        => $copyEventName,
                'MODIFIED_BY' => $USER->GetID(),
                'DATE_CREATE' => (new \DateTime())->format('d.m.Y H:i:s'),
                'CREATED_BY'  => $USER->GetID(),
                'ACTIVE'      => 'N',
                'EVENT_ID'    => $resEvent->getId()
            ]
        );

        $productID = $resProduct['id'];

        if (isset($resProduct['status']) && $resProduct['status'] == 'error') throw new Exception($resProduct['message']);

        //Копируем локации
        $hlblockLocations = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_LOCATION_ID"])->fetch();
        $entityLocation   = HL\HighloadBlockTable::compileEntity($hlblockLocations);
        $hlbClassLocation = $entityLocation->getDataClass();
        $query            = $hlbClassLocation::getList(
            [
                'select' => ['*'],
                'filter' => ['UF_EVENT_ID' => $arParams['ELEMENT_ID']]
            ]
        );
        while ($location = $query->fetchObject()) {
            $dateTime = [];

            foreach ($location->get('UF_DATE_TIME') as $date) {
                $dateTime[] = (new DateTime($date))->format('d.m.Y H:i:s');
            }

            $locationObj = $entityLocation->createObject();
            $locationObj->set('UF_EVENT_ID', $resEvent->getId());
            $locationObj->set('UF_DATE_TIME', $dateTime);
            $locationObj->set('UF_ADDRESS', $location->get('UF_ADDRESS'));
            $locationObj->set('UF_ROOM', $location->get('UF_ROOM'));
            $locationObj->set('UF_COORDINATES', $location->get('UF_COORDINATES'));
            $locationObj->set('UF_DURATION', $location->get('UF_DURATION'));
            $locationObj->set('UF_LINK', $location->get('UF_LINK'));
            $locationObj->save();
        }

        //Копирование билетов
        $body = [
            'schema_id'   => $eventUUID,
            'copy_option' => 'without_payment_groups',
        ];

        $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
        $productClass  = $productEntity->getDataClass();
        $query         = new ORM\Query\Query($productEntity);
        $resProduct    = $query
            ->setSelect(['ID', 'XML_ID'])
            ->setFilter(['EVENT_ID.VALUE' => $arParams['ELEMENT_ID']])
            ->setLimit(1)
            ->countTotal(true)
            ->exec();
        if ($resProduct->getCount() > 0) {
            $mainProduct   = $resProduct->fetch();
            $copyTypeMap   = [];
            $offerEntity   = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
            $query         = new ORM\Query\Query($offerEntity);
            $resOffer      = $query
                ->setSelect(
                    [
                        'ID',
                        'NAME',
                        'PROP_MAX_QUANTITY'    => 'MAX_QUANTITY.VALUE',
                        'PROP_RESERVE_TIME'    => 'RESERVE_TIME.VALUE',
                        'PROP_TYPE'            => 'TYPE.VALUE',
                        'PROP_TOTAL_QUANTITY'  => 'TOTAL_QUANTITY.VALUE',
                        'PROP_DATES',
                        'PROP_DATES_ALL'       => 'DATES_ALL.VALUE',
                        'SKU_PRICE'            => 'PRICE.PRICE',
                        'IS_CREATED_SEAT_MAP_' => 'IS_CREATED_SEAT_MAP.VALUE',
                        'XML_ID',
                        'ACTIVE_FROM',
                        'ACTIVE_TO',
                        'PREVIEW_TEXT'
                    ]
                )
                ->setFilter(['CML2_LINK.VALUE' => $mainProduct['ID']])
                ->registerRuntimeField(
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PRICE',
                        '\Bitrix\Catalog\PriceTable',
                        ['this.ID' => 'ref.PRODUCT_ID'],
                        ['join_type' => 'LEFT'],
                    )
                )
                ->registerRuntimeField(
                    new \Bitrix\Main\Entity\ExpressionField(
                        'PROP_DATES',
                        "GROUP_CONCAT(%s SEPARATOR ';')",
                        ['DATES.VALUE']
                    )
                )
                ->exec();
            $offers        = $resOffer->fetchAll();
            $arTicketTypes = [];
            foreach ($offers as $offer) {
                $oldOfferID = $offer['ID'];
                if ((bool)$offer['IS_CREATED_SEAT_MAP_'] === true) {
                    continue;
                }
                $oldOfferUUID       = $offer['XML_ID'];
                $offer['XML_ID']    = $offerUUID = \Custom\Core\UUID::uuid8();
                $offer['CML2_LINK'] = $productID;
                $offer['NAME']      = $arNewEvent['UF_NAME'] . ' [' . $offer['PROP_TYPE'] . ']';
                $offer['QUANTITY']  = $offer['PROP_TOTAL_QUANTITY'];
                !empty($offer['PROP_DATES']) ? $offer['PROP_DATES'] = explode(';', $offer['PROP_DATES']) : $offer['PROP_DATES'] = [];

                foreach ($offer as $key => $value) {
                    if (strpos($key, 'PROP_') !== false || strpos($key, 'SKU_') !== false) {
                        unset($offer[$key]);
                        $key         = str_replace('PROP_', '', $key);
                        $key         = str_replace('SKU_', '', $key);
                        $offer[$key] = $value;
                    }
                }
                $copyTypeMap[$oldOfferUUID] = $offerUUID;
                unset($offer['ID']);
                $resOffer                   = Products::getInstance()->createProduct($offer, true);
                $arTicketTypes[$oldOfferID] = $resOffer['id'];
            }

            if (count($copyTypeMap) > 0) {
                $body['copy_option']        = 'with_exact_payment_groups';
                $body['payment_groups_map'] = $copyTypeMap;
            }

        }

        if ($arNewEvent['UF_SIT_MAP']) {
            copySeatMapSchema($arParams['ELEMENT_ID'], $resEvent->getId());
        }

        //Копирование скидок и промокодов
        copyDiscounts($arParams['ELEMENT_ID'], $resEvent->getId(), $arTicketTypes);
        //Копирование групп промокодов
        copyPromoGroups($arParams['ELEMENT_ID'], $resEvent->getId(), $arTicketTypes);

        echo json_encode(['status' => 'success', 'id' => $resEvent->getId()], JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'getTypes') {
        $APPLICATION->RestartBuffer();
        if ($arParams['ELEMENT_ID'] < 1) throw new Exception('Wrong param Event id');
        $elementEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $propField     = $elementEntity->getField('CML2_LINK');
        $propEntity    = $propField->getRefEntity();

        $elements = \Bitrix\Iblock\Elements\ElementTicketsTable::getList(
            [
                'select'  => [
                    'SKU_ID'   => 'OFFER.ID',
                    'SKU_TYPE' => 'OFFER.TYPE.VALUE',
                    'SKU_PRICE' => 'PRICE.PRICE'
                ],
                'filter'  => ['EVENT_ID.VALUE' => $arParams['ELEMENT_ID']],
                'runtime' => [
                    new \Bitrix\Main\Entity\ReferenceField(
                        'TICKETS',
                        $propEntity,
                        ['this.ID' => 'ref.VALUE'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'OFFER',
                        $elementEntity,
                        ['this.TICKETS.IBLOCK_ELEMENT_ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PROPS',
                        '\Bitrix\Catalog\ProductTable',
                        ['this.OFFER.ID' => 'ref.ID'],
                        ['join_type' => 'LEFT'],
                    ),
                    new \Bitrix\Main\Entity\ReferenceField(
                        'PRICE',
                        '\Bitrix\Catalog\PriceTable',
                        ['=this.OFFER.ID' => 'ref.PRODUCT_ID'],
                        ['join_type' => 'inner']
                    ),
                ]
            ]
        )->fetchAll();

        foreach ($elements as &$element)
        {
            $element["SKU_TYPE"] = $element["SKU_TYPE"].". ".\Custom\Core\Helper::priceFormat($element["SKU_PRICE"]);
        }unset($element);

        echo json_encode($elements, JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'getDates') {
        $APPLICATION->RestartBuffer();
        if ($arParams['ELEMENT_ID'] < 1) throw new Exception('Wrong param Event id');

        $hlblLocation     = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_LOCATION_ID"])->fetch();
        $entityLocation   = HL\HighloadBlockTable::compileEntity($hlblLocation);
        $hlbClassLocation = $entityLocation->getDataClass();

        $obElement = $hlbClassLocation::getList(
            [
                'select' => [
                    'ID',
                    'UF_EVENT_ID',
                    'UF_DATE_TIME',
                ],
                'filter' => ['UF_EVENT_ID' => $arParams['ELEMENT_ID']]
            ]
        );

        $arDatesAndLocations = [];
        $arLocations         = [];
        while ($location = $obElement->fetch()) {
            if (is_array($location['UF_DATE_TIME']) && count($location['UF_DATE_TIME']) > 0) {
                foreach ($location['UF_DATE_TIME'] as $key => &$dateItem) {
                    $dateTimeStart                   = ($dateItem)->format('d.m.Y H:i');
                    $currentDate                     = ($dateItem)->format('d.m.y');
                    $timeStamp                       = strtotime($dateTimeStart);
                    $dateItem                        =
                        [
                            'DATE'              => $currentDate,
                            'DATE_PRESENTATION' => Custom\Core\Helper::getFormatDate($currentDate),
                        ];
                    $arDatesAndLocations[$timeStamp] = [
                        'LOCATION_ID' => $location['ID'],
                        'EVENT_DATE'  => $dateItem,
                    ];
                }
                unset($dateItem, $key);
            } else {
                $dateTimeStart                   = (new DateTime())->format('d.m.Y H:i');
                $currentDate                     = (new DateTime())->format('d.m.y');
                $timeStamp                       = strtotime($dateTimeStart);
                $dateItem                        =
                    [
                        'DATE'              => $currentDate,
                        'DATE_PRESENTATION' => Custom\Core\Helper::getFormatDate($currentDate),
                    ];
                $arDatesAndLocations[$timeStamp] = [
                    'LOCATION_ID' => $location['ID'],
                    'EVENT_DATE'  => $dateItem,
                ];
            }
            unset($location['UF_DATE_TIME']);
        }

        ksort($arDatesAndLocations, SORT_NUMERIC);
        $arDatesAndLocations = array_values($arDatesAndLocations);

        echo json_encode($arDatesAndLocations, JSON_UNESCAPED_UNICODE);
        die;
    }
    if (isset($arParams['ACTION']) &&
        $arParams['ACTION'] == 'getTypeParticipationList') {
        $APPLICATION->RestartBuffer();

        $TypeParticipationList = [];

        $query                                     = new ORM\Query\Query('\Bitrix\Iblock\PropertyEnumerationTable');
        $this->arResult['TYPE_PARTICIPATION_LIST'] = [];
        $resType                                   = $query
            ->setSelect(['ID', 'VALUE', 'XML_ID'])
            ->setOrder(['SORT' => 'ASC'])
            ->setFilter(['PROPERTY.CODE' => 'TYPE_PARTICIPATION'])
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'PROPERTY',
                    '\Bitrix\Iblock\PropertyTable',
                    ['this.PROPERTY_ID' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                )
            )
            ->setCacheTtl(3600)
            ->exec();
        while ($type = $resType->fetch()) {
            $TypeParticipationList[] = $type;
        }
        unset($query, $resType, $type);

        echo json_encode($TypeParticipationList, JSON_UNESCAPED_UNICODE);
        die;
    }

    if (isset($arParams['ACTION']) && $arParams['ACTION'] === 'getSeatmapSectors') {
        $APPLICATION->RestartBuffer();
        $seatmapEventId = $request->get('seatmapEventId');

        if (!USE_SEATMAP) {
            throw new Exception('SeatMap disabled.');
        }
        if (!isset($request['EVENT'])) {
            throw new Exception('Wrong param Event Id.');
        }
        if (!$seatmapEventId) {
            throw new Exception('Wrong SeatMap Event Id.');
        }

        $hlblockEvents  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entityEvents   = HL\HighloadBlockTable::compileEntity($hlblockEvents);
        $hlbClassEvents = $entityEvents->getDataClass();
        $objEvent       = $hlbClassEvents::getByPrimary((int)$request['EVENT'])->fetchObject();

        if ($objEvent->get('UF_COMPANY_ID') != $companyID) {
            throw new Exception('Нельзя редактировать чужие события');
        }

        if (
            !isset($this->arResult['SeatMap'])
            && $objEvent->get('UF_SIT_MAP')
        ) {
            $this->arResult['SeatMap'] = getSeatMapData($this->arResult, $request);
        } else {
            throw new Exception('SeatMap disabled.');
        }

        $seatMapPrices = $arResult['SeatMap']['bookingApi']->getPrices($seatmapEventId);
        echo json_encode(
            [
                'status' => 'success',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      'sectors' => $arResult['SeatMap']['sectors'] ?? [],
            ], JSON_UNESCAPED_UNICODE
        );
        die;
    }

    if (isset($arParams['ACTION']) && $arParams['ACTION'] === 'getSeatmapPrices') {
        $APPLICATION->RestartBuffer();
        $seatmapEventId = $request->get('seatmapEventId');

        if (!USE_SEATMAP) {
            throw new Exception('SeatMap disabled.');
        }
        if (!isset($request['EVENT'])) {
            throw new Exception('Wrong param Event Id.');
        }
        if (!$seatmapEventId) {
            throw new Exception('Wrong SeatMap Event Id.');
        }

        $hlblockEvents  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
        $entityEvents   = HL\HighloadBlockTable::compileEntity($hlblockEvents);
        $hlbClassEvents = $entityEvents->getDataClass();
        $objEvent       = $hlbClassEvents::getByPrimary((int)$request['EVENT'])->fetchObject();

        if ($objEvent->get('UF_COMPANY_ID') != $companyID) {
            throw new Exception('Нельзя редактировать чужие события');
        }

        if (
            !isset($this->arResult['SeatMap'])
            && $objEvent->get('UF_SIT_MAP')
        ) {
            $this->arResult['SeatMap'] = getSeatMapData($this->arResult, $request);
        } else {
            throw new Exception('SeatMap disabled.');
        }

        $seatMapPrices = $arResult['SeatMap']['bookingApi']->getPrices($seatmapEventId);
        echo json_encode(
            [
                'status' => 'success',
                'prices' => $seatMapPrices
            ], JSON_UNESCAPED_UNICODE
        );
        die;
    }

    $this->IncludeComponentTemplate();
} catch (\Exception $e) {
    $APPLICATION->RestartBuffer();
    // header("Content-type: application/json; charset=utf-8");
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    die;
}

function getFormatedDates(array $arDates = []): array
{
    $result    = [];
    $startDate = null;
    $prevDate  = null;

    foreach ($arDates as $date) {
        $currentDate = new \DateTime($date);

        if ($startDate === null) {
            $startDate = $currentDate;
            $prevDate  = $currentDate;
        } else {
            $diff     = $currentDate->diff($prevDate);
            $sameTime = $currentDate->format('H:i:s') === $prevDate->format('H:i:s');

            if ($diff->days === 1 && $sameTime) {
                $prevDate = $currentDate;
            } else {
                if ($startDate === $prevDate) {
                    $result[] = FormatDate("d F Y", $startDate->getTimestamp()) . ' в ' . FormatDate("H:i", $startDate->getTimestamp());
                } else {
                    $result[] = FormatDate("d F Y", $startDate->getTimestamp()) . " - " . FormatDate("d F Y", $prevDate->getTimestamp()) . ' в ' . FormatDate("H:i", $prevDate->getTimestamp());
                }
                $startDate = $currentDate;
                $prevDate  = $currentDate;
            }
        }
    }

    // Добавляем последний диапазон или дату
    if ($startDate === $prevDate) {
        $result[] = FormatDate("d F Y", $startDate->getTimestamp()) . ' в ' . FormatDate("H:i", $startDate->getTimestamp());
    } else {
        $result[] = FormatDate("d F Y", $startDate->getTimestamp()) . " - " . FormatDate("d F Y", $prevDate->getTimestamp()) . ' в ' . FormatDate("H:i", $prevDate->getTimestamp());
    }

    return $result;
}

function getOrdersByEventID(int $eventID, string $severName = '', bool $notOffline = false): array
{
    $result = [];

    $runtime = [
        new \Bitrix\Main\Entity\ReferenceField(
            'PROPERTY_BUYER',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'PROPERTY_BUYER_EMAIL',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'PROPERTY_EVENT_ID',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'PROPERTY_ORDER_UUID',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'EVENT',
            'Custom\Core\Events\EventsTable',
            ['=this.EVENT_ID' => 'ref.ID'],
            ['join_type' => 'inner']
        ),
    ];
    $filter  = [
        "PAYED"                     => "Y",
        '!CANCELED'                 => "Y",
        'STATUS_ID' => ['P', 'F', 'PR'],
        "PROPERTY_EVENT_ID.CODE"    => "EVENT_ID",
        "PROPERTY_EVENT_ID.VALUE"   => $eventID,
        "PROPERTY_ORDER_UUID.CODE"  => "UUID",
        "PROPERTY_BUYER_EMAIL.CODE" => "EMAIL",
        "PROPERTY_BUYER.CODE"       => 'FIO',
    ];

    if ($notOffline) {
        $elementEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
        $propField     = $elementEntity->getField('TYPE_PARTICIPATION');
        $propEntity    = $propField->getRefEntity();
        $propID        = getPropEnumIdByXmlID('offline');
        $runtime[]     = new \Bitrix\Main\Entity\ReferenceField(
            'BASKET_REFS',
            'Bitrix\Sale\Internals\BasketTable',
            ['this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'left']
        );
        $runtime[]     = new \Bitrix\Main\Entity\ReferenceField(
            'TYPE_PARTICIPATION',
            $propEntity,
            ['this.BASKET_REFS.PRODUCT_ID' => 'ref.IBLOCK_ELEMENT_ID'],
            ['join_type' => 'LEFT'],
        );

        $filter[] = ['!TYPE_PARTICIPATION.VALUE' => $propID];
    }

    $dbRes = \Bitrix\Sale\Order::getList(
        [
            'select'  => [
                'EVENT_ID'   => 'PROPERTY_EVENT_ID.VALUE',
                'FULL_NAME'  => 'PROPERTY_BUYER.VALUE',
                'EMAIL'      => 'PROPERTY_BUYER_EMAIL.VALUE',
                'ADDRESS'    => 'EVENT.UF_LOCATION_REF.UF_ADDRESS',
                'ORDER_UUID' => 'PROPERTY_ORDER_UUID.VALUE',
            ],
            'filter'  => $filter,
            'runtime' => $runtime,
            'group'   => ['EVENT_ID', 'EMAIL']
        ]
    );
    while ($order = $dbRes->fetch()) {
        $result[] = [
            'FULL_NAME'   => $order['FULL_NAME'],
            'EMAIL'       => $order['EMAIL'],
            'REFUND_LINK' => $severName . '/refund/' . $order['ORDER_UUID'] . '/',
        ];
    }

    return $result;
}

function getEventData(int $eventID): array
{
    $eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
    $query       = $eventEntity
        ->setSelect(
            [
                //'DATE_TIME' => 'UF_LOCATION_REF.DATE_TIME.VALUE',
                'ADDRESS'  => 'UF_LOCATION_REF.UF_ADDRESS',
                'LINK'     => 'UF_LOCATION_REF.UF_LINK',
                'DURATION' => 'UF_LOCATION_REF.UF_DURATION',
                'DATE_TIME',
            ]
        )
        ->registerRuntimeField(new \Bitrix\Main\Entity\ExpressionField('DATE_TIME', 'GROUP_CONCAT(%s)', ['UF_LOCATION_REF.DATE_TIME.VALUE']))
        ->setFilter(['ID' => $eventID])
        ->exec();
    $result      = [];
    while ($res = $query->fetch()) {
        !empty($res['DATE_TIME']) ? $res['DATE_TIME'] = explode(',', $res['DATE_TIME']) : $res['DATE_TIME'] = [];
        $res['LINK'] = is_array($res['LINK']) && isset($res['LINK'][0]) ? json_decode($res['LINK'][0]) : null;
        $result[]    = $res;
    }
    return $result;
}

function checkOrdersExistsByOfferID(int $offerID): bool
{
    $dbRes = \Bitrix\Sale\Order::getList(
        [
            'select'      => [
                'ID',
                'STATUS_ID',
                'STATUS_NAME'    => 'STATUS.NAME',
                'TICKET_TYPE_ID' => 'BASKET_REFS.PRODUCT_ID'
            ],
            'filter'      => [
                //                "!STATUS_ID" => "CD",
                "TICKET_TYPE_ID" => $offerID
            ],
            'runtime'     => [
                new \Bitrix\Main\Entity\ReferenceField(
                    'BASKET_REFS',
                    'Bitrix\Sale\Internals\BasketTable',
                    ['this.ID' => 'ref.ORDER_ID'],
                    ['join_type' => 'left']
                ),
            ],
            'count_total' => true
        ]
    );
    return $dbRes->getCount() > 0;
}

function contract_is_signed($companyID): bool
{
    $signedPropId = \Custom\Core\Helper::getPropertiesEnum('Company', 'UF_CONTRACT', 'signed');
    if ($signedPropId < 1) return false;

    $query = new ORM\Query\Query('\Custom\Core\Users\CompaniesTable');
    $obRes = $query
        ->setSelect(['ID'])
        ->setFilter(['ID' => $companyID, 'UF_CONTRACT' => $signedPropId])
        ->countTotal(true)
        ->exec();
    return $obRes->getCount() > 0;
}

function getLocationsIDByEventID($id)
{
    $query  = new ORM\Query\Query('\Custom\Core\Events\EventsDateAndLocationTable');
    $result = [];
    $obRes  = $query
        ->setSelect(['ID', 'UF_EVENT_ID'])
        ->setFilter(['UF_EVENT_ID' => $id])
        ->exec();
    while ($location = $obRes->fetch()) {
        $result[] = $location['ID'];
    }
    return $result;
}

function setEventStep($eventID, $step)
{
    $companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
    if ((int)$eventID < 1 || (int)$step < 1 || (int)$companyID < 1) return false;
    global $USER;
    $query    = new ORM\Query\Query('\Custom\Core\Events\EventsTable');
    $res      = $query
        ->setSelect(['ID', 'UF_STEP'])
        ->setFilter(['ID' => $eventID, 'UF_COMPANY_ID' => $companyID])
        ->exec();
    $objEvent = $res->fetchObject();
    if ($objEvent->getId() < 1 || $objEvent->getUfStep() >= $step) return false;
    $objEvent->set('UF_STEP', $step);
    $resEvent = $objEvent->save();
}

function copyDiscounts(int $eventIdFrom, int $eventIdTo, array $arTicketTypes = []): void
{
    $entityRules   = HL\HighloadBlockTable::compileEntity('PriceRules');
    $hlbClassRules = $entityRules->getDataClass();

    $entityBarcodes   = HL\HighloadBlockTable::compileEntity('PromoCodes');
    $hlbClassBarcodes = $entityBarcodes->getDataClass();

    $priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');

    $filter = [
        'REF_EVENTS_ID.VALUE' => $eventIdFrom,
        '!UF_TYPE'            => PRICE_RULE_TYPE_GROUP
    ];

    $query = $priceRulesEntity->setSelect(
        [
            'UF_NAME',
            'UF_DISCOUNT_TYPE',
            'UF_DISCOUNT',
            'UF_FOR_ALL_TYPES',
            'UF_MIN_COUNT_TICKETS',
            'UF_IS_SUM',
            'UF_TYPE',
            'UF_MAX_NUMBER_OF_USES',
            'UF_NUMBER_OF_USES',
            'UF_IS_ACTIVITY',
            'UF_TYPE_APPLY_ALL_ORDER',
            'UF_TYPE_APPLY_MIN',
            'UF_TYPE_APPLY_MAX',
            'UF_TICKETS_TYPE',
            'UF_DATE_START',
            'UF_DATE_END',
            'UF_FOR_EACH_TICKET',
            'PROMOCODE_ID'     => 'REF_PROMOCODE.ID',
            'PROMOCODE_NAME'   => 'REF_PROMOCODE.UF_CODE',
            'PROMOCODE_XML_ID' => 'REF_PROMOCODE.UF_XML_ID',
            'PROMOCODE_IS_USE' => 'REF_PROMOCODE.UF_IS_USE',
        ]
    )->setFilter($filter)->countTotal(true)->exec();

    while ($priceRule = $query->fetch()) {
        $priceRule['UF_XML_ID']     = \Custom\Core\UUID::uuid8();
        $priceRule['UF_EVENT_ID'][] = $eventIdTo;

        if (count($priceRule['UF_TICKETS_TYPE']) > 0 && count($arTicketTypes) > 0) {
            $arOldTicketTypes = $priceRule['UF_TICKETS_TYPE'];
            $arNewTicketTypes = [];
            foreach ($arTicketTypes as $oldID => $newID) {
                if (in_array($oldID, $arOldTicketTypes)) $arNewTicketTypes[] = $newID;
            }
            $priceRule['UF_TICKETS_TYPE'] = $arNewTicketTypes;
        } else {
            unset($priceRule['UF_TICKETS_TYPE']);
        }

        $newRuleID = $hlbClassRules::add($priceRule)->getId();
        if ($priceRule['PROMOCODE_ID'] > 0) {
            $hlbClassBarcodes::add(
                [
                    'UF_XML_ID'  => \Custom\Core\UUID::uuid8(),
                    'UF_CODE'    => $priceRule['PROMOCODE_NAME'],
                    'UF_IS_USE'  => 0,
                    'UF_RULE_ID' => $newRuleID
                ]
            );
        }
    }
}

function copyPromoGroups(int $eventIdFrom, int $eventIdTo, array $arTicketTypes = [])
{
    $entityRules   = HL\HighloadBlockTable::compileEntity('PriceRules');
    $hlbClassRules = $entityRules->getDataClass();

    $entityBarcodes   = HL\HighloadBlockTable::compileEntity('PromoCodes');
    $hlbClassBarcodes = $entityBarcodes->getDataClass();

    $priceRulesEntity = new ORM\Query\Query('Custom\Core\Events\PriceRulesTable');

    $filter = [
        'REF_EVENTS_ID.VALUE' => $eventIdFrom,
        'UF_TYPE'             => PRICE_RULE_TYPE_GROUP
    ];

    $query = $priceRulesEntity->setSelect(
        [
            'UF_NAME',
            'UF_DISCOUNT_TYPE',
            'UF_DISCOUNT',
            'UF_FOR_ALL_TYPES',
            'UF_MIN_COUNT_TICKETS',
            'UF_IS_SUM',
            'UF_TYPE',
            'UF_MAX_NUMBER_OF_USES',
            'UF_NUMBER_OF_USES',
            'UF_IS_ACTIVITY',
            'UF_TYPE_APPLY_ALL_ORDER',
            'UF_TYPE_APPLY_MIN',
            'UF_TYPE_APPLY_MAX',
            'UF_TICKETS_TYPE',
            'UF_DATE_START',
            'UF_DATE_END',
        ]
    )->setFilter($filter)->countTotal(true)->exec();

    while ($priceRule = $query->fetch()) {
        $priceRule['UF_XML_ID']         = \Custom\Core\UUID::uuid8();
        $priceRule['UF_NUMBER_OF_USES'] = 0;
        $priceRule['UF_EVENT_ID'][]     = $eventIdTo;

        if (count($priceRule['UF_TICKETS_TYPE']) > 0 && count($arTicketTypes) > 0) {
            $arOldTicketTypes = $priceRule['UF_TICKETS_TYPE'];
            $arNewTicketTypes = [];
            foreach ($arTicketTypes as $oldID => $newID) {
                if (in_array($oldID, $arOldTicketTypes)) $arNewTicketTypes[] = $newID;
            }
            $priceRule['UF_TICKETS_TYPE'] = $arNewTicketTypes;
        } else {
            unset($priceRule['UF_TICKETS_TYPE']);
        }

        $countCodes = $priceRule['UF_MAX_NUMBER_OF_USES'];
        $newRuleID  = $hlbClassRules::add($priceRule)->getId();
        if ($countCodes > 0) {
            createPromoCodes($newRuleID, $countCodes, $hlbClassBarcodes);
        }
    }
}

function generateCode()
{
    $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $res   = "";
    for ($i = 0; $i < 8; $i++) {
        $res .= $chars[mt_rand(0, strlen($chars) - 1)];
    }

    return $res;
}

function generateGroupCode(int $count, array $alreadyCreatedPromoCode): array
{
    $buffer = [];
    $tries  = 10;

    for ($i = 0; $i < $count; $i++) {
        for ($j = 0; $j < $tries; $j++) {
            $code = generateCode();
            if (!in_array($code, $buffer) && !in_array($code, $alreadyCreatedPromoCode)) {
                $buffer[] = $code;
                break;
            }
        }
    }

    return $buffer;
}

function createPromoCodes(
    int    $ruleId,
    int    $needCreatePromoCodeCount,
    string $hlbClassPromoCodes,
    array  $alreadyCreatedPromoCode = []
) {
    $alreadyCreatedPromoCodeCount = count($alreadyCreatedPromoCode);

    if ($needCreatePromoCodeCount > $alreadyCreatedPromoCodeCount) {
        $needCount     = $needCreatePromoCodeCount - $alreadyCreatedPromoCodeCount;
        $notCreate     = 0;
        $genPromoCodes = generateGroupCode($needCount, $alreadyCreatedPromoCode);
        for ($i = 0; $i < $needCount; $i++) {
            if (!isset($genPromoCodes[$i])) {
                $notCreate++;
                continue;
            }
            $objCoupon  = $hlbClassPromoCodes::createObject();
            $uuidCoupon = \Custom\Core\UUID::uuid4();

            $objCoupon->set('UF_XML_ID', $uuidCoupon);
            $objCoupon->set('UF_CODE', $genPromoCodes[$i]);
            $objCoupon->set('UF_RULE_ID', $ruleId);
            $objCoupon->set('UF_IS_USE', 0);

            $resAddPromoCode = $objCoupon->save();

            if (!$resAddPromoCode->isSuccess()) {
                throw new \Exception(implode(', ', $resAddPromoCode->getErrors()));
            }

            unset($priceRuleId);
            unset($uuidCoupon);
        }

        return max($needCreatePromoCodeCount - $notCreate, 0);
    } elseif ($needCreatePromoCodeCount === $alreadyCreatedPromoCodeCount) {
        return $needCreatePromoCodeCount;
    } elseif ($needCreatePromoCodeCount < $alreadyCreatedPromoCodeCount) {
        throw new Exception('Удалите из формы лишние промокоды');
    }
}

/**
 * @param $priceRule
 * @param $eventId
 * @param $uuid
 *
 * @return void
 * @throws Exception
 */
function validatePriceRulePromoCodeRequestItem($priceRule, $eventId, $isCreate = true, $uuid = null)
{
    if ($isCreate) {
        if (!isset($priceRule['UF_CODE']) || ($priceRule['UF_CODE'] === '')) {
            throw new \Exception('Поле «Промокод» обязательно для заполнения');
        }

        if (PriceRules::isPromoCodeUnique($priceRule['UF_CODE'], $eventId, $uuid)) {
            throw new \Exception('Промокод «' . $priceRule['UF_CODE'] . '» уже существует');
        }

        if (isset($priceRule['UF_DISCOUNT'])) {
            if ((float)$priceRule['UF_DISCOUNT'] <= 0) {
                throw new \Exception('Поле «Размер скидки» должно быть больше 0');
            }

            // не более 100%
            if (!isset($priceRule['UF_DISCOUNT_TYPE']) && (float)$priceRule['UF_DISCOUNT'] > 100) {
                throw new \Exception('Поле «Размер скидки» не должно быть больше 100%');
            }
        } else {
            throw new \Exception('Поле «Размер скидки» обязательно для заполнения');
        }
    }


    if (!(isset($priceRule['UF_TICKETS_TYPE']) && is_array($priceRule['UF_TICKETS_TYPE']) && count(
            $priceRule['UF_TICKETS_TYPE']
        ) > 0)) {
        throw new \Exception('Поле «Типы билетов» обязательно для заполнения');
    }

    if (isset($priceRule['UF_DATE_START']) && $priceRule['UF_DATE_START'] && !preg_match(
            '/^[0-3][0-9]\.[0-1][0-9]\.[0-9][0-9]$/',
            $priceRule['UF_DATE_START']
        )) {
        throw new \Exception('Дата начала указана некорректно');
    }

    if (isset($priceRule['UF_DATE_END']) && $priceRule['UF_DATE_END'] && !preg_match(
            '/^[0-3][0-9]\.[0-1][0-9]\.[0-9][0-9]$/',
            $priceRule['UF_DATE_END']
        )) {
        throw new \Exception('Дата окончания указана некорректно');
    }

    if (isset($priceRule['UF_DATE_START']) && $priceRule['UF_DATE_START'] && isset($priceRule['UF_DATE_END']) && $priceRule['UF_DATE_END']) {
        $start = DateTime::createFromFormat('d.m.y', $priceRule['UF_DATE_START']);
        $end   = DateTime::createFromFormat('d.m.y', $priceRule['UF_DATE_END']);

        if ($start->getTimestamp() >= $end->getTimestamp()) {
            throw new \Exception('Срок действия указан некорректно!');
        }
    }

    if (!$priceRule['UF_TYPE_APPLY']) {
        throw new \Exception('Поле «Вид применения» обязательно для заполнения');
    }

    if (isset($priceRule['UF_TYPE_APPLY']) && $priceRule['UF_TYPE_APPLY'] === 'range') {
        if (isset($priceRule['UF_TYPE_APPLY_MIN']) && !is_numeric(
                $priceRule['UF_TYPE_APPLY_MIN']
            ) && isset($priceRule['UF_TYPE_APPLY_MAX']) && !is_numeric($priceRule['UF_TYPE_APPLY_MAX'])) {
            throw new \Exception('Поле «Вид применения» обязательно для заполнения');
        } else {
            if (isset($priceRule['UF_TYPE_APPLY_MIN']) && is_numeric(
                    $priceRule['UF_TYPE_APPLY_MIN']
                ) && (int)$priceRule['UF_TYPE_APPLY_MIN'] < 1) {
                throw new \Exception('Минимальное значение "Вида применения" не может быть меньше 1');
            }

            if (isset($priceRule['UF_TYPE_APPLY_MAX']) && is_numeric(
                    $priceRule['UF_TYPE_APPLY_MAX']
                ) && (int)$priceRule['UF_TYPE_APPLY_MAX'] < 1) {
                throw new \Exception('Максимальное значение "Вида применения" не может быть меньше 1');
            }

            if (isset($priceRule['UF_TYPE_APPLY_MIN']) && isset($priceRule['UF_TYPE_APPLY_MAX']) && is_numeric(
                    $priceRule['UF_TYPE_APPLY_MIN']
                ) && is_numeric(
                    $priceRule['UF_TYPE_APPLY_MAX']
                ) && (int)$priceRule['UF_TYPE_APPLY_MIN'] > (int)$priceRule['UF_TYPE_APPLY_MAX']) {
                throw new \Exception('Минимальное значение "Вида применения" не может быть больше максимального');
            }
        }
    }
}


/**
 * @param $priceRule
 * @param $key
 *
 * @return string|null
 */
function getDatePriceRuleRequestItem($priceRule, $key)
{
    return isset($priceRule[$key]) && $priceRule[$key] ? DateTime::createFromFormat(
        'd.m.y',
        $priceRule[$key]
    )->setTime(0, 0)->format('d.m.Y H:i:s') : null;
}


/**
 * @param $priceRule
 * @param $objPriceRule
 *
 * @return mixed
 */
function setTicketsTypeRequestItem($priceRule, $objPriceRule)
{
    if (is_array($priceRule['UF_TICKETS_TYPE']) && in_array('all', $priceRule['UF_TICKETS_TYPE'])) {
        $objPriceRule->set('UF_TICKETS_TYPE', []);
        $objPriceRule->set('UF_FOR_ALL_TYPES', 1);
    } else {
        $objPriceRule->set('UF_TICKETS_TYPE', $priceRule['UF_TICKETS_TYPE']);
        $objPriceRule->set('UF_FOR_ALL_TYPES', 0);
    }

    return $objPriceRule;
}


/**
 * @param $priceRule
 * @param $objPriceRule
 *
 * @return mixed
 */
function setTypeApplyRequestItem($priceRule, $objPriceRule)
{
    if (isset($priceRule['UF_TYPE_APPLY']) && in_array($priceRule['UF_TYPE_APPLY'], ['all', 'range'])) {
        if ($priceRule['UF_TYPE_APPLY'] === 'all') {
            $objPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', 1);
            $objPriceRule->set('UF_TYPE_APPLY_MIN', null);
            $objPriceRule->set('UF_TYPE_APPLY_MAX', null);
        } else {
            $objPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', 0);
            $objPriceRule->set(
                'UF_TYPE_APPLY_MIN',
                isset($priceRule['UF_TYPE_APPLY_MIN']) && is_numeric(
                    $priceRule['UF_TYPE_APPLY_MIN']
                ) ? (int)$priceRule['UF_TYPE_APPLY_MIN'] : null
            );
            $objPriceRule->set(
                'UF_TYPE_APPLY_MAX',
                isset($priceRule['UF_TYPE_APPLY_MAX']) && is_numeric(
                    $priceRule['UF_TYPE_APPLY_MAX']
                ) ? (int)$priceRule['UF_TYPE_APPLY_MAX'] : null
            );
        }
    } else {
        $objPriceRule->set('UF_TYPE_APPLY_ALL_ORDER', null);
        $objPriceRule->set('UF_TYPE_APPLY_MIN', null);
        $objPriceRule->set('UF_TYPE_APPLY_MAX', null);
    }

    return $objPriceRule;
}


/**
 * @param $priceRule
 * @param $objPriceRule
 * @param $code
 *
 * @return mixed
 */
function fillModelUpdatePriceRuleForPromoCode($priceRule, $objPriceRule)
{
    $dateStart = getDatePriceRuleRequestItem($priceRule, 'UF_DATE_START');
    $dateEnd   = getDatePriceRuleRequestItem($priceRule, 'UF_DATE_END');

    $objPriceRule = setTypeApplyRequestItem($priceRule, $objPriceRule);

    $objPriceRule->set('UF_DATE_START', $dateStart);
    $objPriceRule->set('UF_DATE_END', $dateEnd);
    $objPriceRule->set('UF_MIN_COUNT_TICKETS', null);
    $objPriceRule->set('UF_MAX_NUMBER_OF_USES', (int)$priceRule['UF_MAX_NUMBER_OF_USES']);
    $objPriceRule->set('UF_TYPE', PRICE_RULE_TYPE_COUPON);
    $objPriceRule->set('UF_IS_SUM', isset($priceRule['UF_IS_SUM']) ? 1 : 0);
    $objPriceRule->set('UF_FOR_EACH_TICKET', isset($priceRule['UF_FOR_EACH_TICKET']) ? 1 : 0);

    $objPriceRule = setTicketsTypeRequestItem($priceRule, $objPriceRule);

    unset($dateStart, $dateEnd);

    return $objPriceRule;
}


/**
 * @param $priceRule
 * @param $objPriceRule
 * @param $code
 * @param $eventId
 *
 * @return mixed
 */
function fillModelCreatePriceRuleForPromoCode($priceRule, $objPriceRule, $code, $eventId)
{
    $uuid = \Custom\Core\UUID::uuid4();

    $dateStart = getDatePriceRuleRequestItem($priceRule, 'UF_DATE_START');
    $dateEnd   = getDatePriceRuleRequestItem($priceRule, 'UF_DATE_END');

    $objPriceRule->set('UF_XML_ID', $uuid);
    $objPriceRule->set('UF_EVENT_ID', $eventId);

    $objPriceRule = setTypeApplyRequestItem($priceRule, $objPriceRule);

    $objPriceRule->set('UF_NAME', $code);
    $objPriceRule->set(
        'UF_DISCOUNT_TYPE',
        isset($priceRule['UF_DISCOUNT_TYPE']) ? DISCOUNT_TYPE_RUB : DISCOUNT_TYPE_PERCENT
    );
    $objPriceRule->set('UF_DISCOUNT', (float)$priceRule['UF_DISCOUNT']);

    $objPriceRule->set('UF_DATE_START', $dateStart);
    $objPriceRule->set('UF_DATE_END', $dateEnd);
    $objPriceRule->set('UF_MIN_COUNT_TICKETS', 0);
    $objPriceRule->set('UF_NUMBER_OF_USES', 0);
    $objPriceRule->set('UF_MAX_NUMBER_OF_USES', (int)$priceRule['UF_MAX_NUMBER_OF_USES']);
    $objPriceRule->set('UF_TYPE', PRICE_RULE_TYPE_COUPON);
    $objPriceRule->set('UF_IS_SUM', isset($priceRule['UF_IS_SUM']) ? 1 : 0);
    $objPriceRule->set('UF_FOR_EACH_TICKET', isset($priceRule['UF_FOR_EACH_TICKET']) ? 1 : 0);
    $objPriceRule->set('UF_IS_ACTIVITY', 1);

    $objPriceRule = setTicketsTypeRequestItem($priceRule, $objPriceRule);

    unset($uuid, $dateStart, $dateEnd);

    return $objPriceRule;
}


/**
 * @param $priceRuleDiscount
 * @param $eventId
 * @param $uuid
 *
 * @return void
 * @throws Exception
 */
function validatePriceRuleDiscountRequestItem($priceRuleDiscount, $eventId, $isCreate = true, $uuid = null)
{
    if ($isCreate) {
        if (isset($priceRuleDiscount['UF_DISCOUNT'])) {
            if ((float)$priceRuleDiscount['UF_DISCOUNT'] <= 0) {
                throw new \Exception('Поле «Размер скидки» должно быть больше 0');
            }

            // не более 100%
            if (!isset($priceRuleDiscount['UF_DISCOUNT_TYPE']) && (float)$priceRuleDiscount['UF_DISCOUNT'] > 100) {
                throw new \Exception('Поле «Размер скидки» не должно быть больше 100%');
            }
        } else {
            throw new \Exception('Поле «Размер скидки» обязательно для заполнения');
        }
    }

    if (!(isset($priceRuleDiscount['UF_TICKETS_TYPE']) && is_array($priceRuleDiscount['UF_TICKETS_TYPE']) && count(
            $priceRuleDiscount['UF_TICKETS_TYPE']
        ) > 0)) {
        throw new \Exception('Поле «Типы билетов» обязательно для заполнения');
    }

    if (!$priceRuleDiscount['UF_NAME']) {
        throw new \Exception('Поле «Скидка» обязательно для заполнения');
    }

    if (PriceRules::isPriceRuleNameUnique($priceRuleDiscount['UF_NAME'], $eventId, $uuid)) {
        throw new \Exception('Скидка с именем «' . $priceRuleDiscount['UF_NAME'] . '» уже существует');
    }


    if (isset($priceRuleDiscount['UF_DATE_START']) && $priceRuleDiscount['UF_DATE_START'] && !preg_match(
            '/^[0-3][0-9]\.[0-1][0-9]\.[0-9][0-9]$/',
            $priceRuleDiscount['UF_DATE_START']
        )) {
        throw new \Exception('Дата начала указана некорректно');
    }

    if (isset($priceRuleDiscount['UF_DATE_END']) && $priceRuleDiscount['UF_DATE_END'] && !preg_match(
            '/^[0-3][0-9]\.[0-1][0-9]\.[0-9][0-9]$/',
            $priceRuleDiscount['UF_DATE_END']
        )) {
        throw new \Exception('Дата окончания указана некорректно');
    }

    if (isset($priceRuleDiscount['UF_DATE_START']) && $priceRuleDiscount['UF_DATE_START'] && isset($priceRuleDiscount['UF_DATE_END']) && $priceRuleDiscount['UF_DATE_END']) {
        $start = DateTime::createFromFormat('d.m.y', $priceRuleDiscount['UF_DATE_START']);
        $end   = DateTime::createFromFormat('d.m.y', $priceRuleDiscount['UF_DATE_END']);

        if ($start->getTimestamp() >= $end->getTimestamp()) {
            throw new \Exception('Срок действия указан некорректно!');
        }
    }
}


/**
 * @param $priceRule
 * @param $objPriceRuleDiscount
 *
 * @return mixed
 */
function fillModelUpdatePriceRuleForDiscount($priceRule, $objPriceRuleDiscount)
{
    $dateStart = getDatePriceRuleRequestItem($priceRule, 'UF_DATE_START');
    $dateEnd   = getDatePriceRuleRequestItem($priceRule, 'UF_DATE_END');

    $objPriceRuleDiscount->set('UF_NAME', $priceRule['UF_NAME']);
    $objPriceRuleDiscount->set(
        'UF_DISCOUNT_TYPE',
        isset($priceRule['UF_DISCOUNT_TYPE']) ? DISCOUNT_TYPE_RUB : DISCOUNT_TYPE_PERCENT
    );
    $objPriceRuleDiscount->set('UF_DISCOUNT', (float)$priceRule['UF_DISCOUNT']);

    $objPriceRuleDiscount->set('UF_TYPE_APPLY_ALL_ORDER', null);
    $objPriceRuleDiscount->set('UF_TYPE_APPLY_MIN', null);
    $objPriceRuleDiscount->set('UF_TYPE_APPLY_MAX', null);

    $objPriceRuleDiscount->set('UF_DATE_START', $dateStart);
    $objPriceRuleDiscount->set('UF_DATE_END', $dateEnd);

    $objPriceRuleDiscount->set('UF_MIN_COUNT_TICKETS', (int)$priceRule['UF_MIN_COUNT_TICKETS']);
    $objPriceRuleDiscount->set('UF_MAX_NUMBER_OF_USES', 0);
    $objPriceRuleDiscount->set('UF_TYPE', PRICE_RULE_TYPE_DISCOUNT);
    $objPriceRuleDiscount->set('UF_IS_SUM', isset($priceRule['UF_IS_SUM']) && $priceRule['UF_IS_SUM'] ? 1 : 0);
    $objPriceRuleDiscount->set('UF_FOR_EACH_TICKET', isset($priceRule['UF_FOR_EACH_TICKET']) ? 1 : 0);

    $objPriceRuleDiscount = setTicketsTypeRequestItem($priceRule, $objPriceRuleDiscount);

    unset($dateStart, $dateEnd);

    return $objPriceRuleDiscount;
}


/**
 * @param $priceRule
 * @param $objPriceRuleDiscount
 * @param $eventId
 *
 * @return mixed
 */
function fillModelCreatePriceRuleForDiscount($priceRule, $objPriceRuleDiscount, $eventId)
{
    $uuid = \Custom\Core\UUID::uuid4();

    $dateStart = getDatePriceRuleRequestItem($priceRule, 'UF_DATE_START');
    $dateEnd   = getDatePriceRuleRequestItem($priceRule, 'UF_DATE_END');

    $objPriceRuleDiscount->set('UF_XML_ID', $uuid);
    $objPriceRuleDiscount->set('UF_EVENT_ID', $eventId);

    $objPriceRuleDiscount->set('UF_TYPE_APPLY_ALL_ORDER', null);
    $objPriceRuleDiscount->set('UF_TYPE_APPLY_MIN', null);
    $objPriceRuleDiscount->set('UF_TYPE_APPLY_MAX', null);

    $objPriceRuleDiscount->set('UF_NAME', $priceRule['UF_NAME']);
    $objPriceRuleDiscount->set(
        'UF_DISCOUNT_TYPE',
        isset($priceRule['UF_DISCOUNT_TYPE']) ? DISCOUNT_TYPE_RUB : DISCOUNT_TYPE_PERCENT
    );
    $objPriceRuleDiscount->set('UF_DISCOUNT', (float)$priceRule['UF_DISCOUNT']);

    $objPriceRuleDiscount->set('UF_DATE_START', $dateStart);
    $objPriceRuleDiscount->set('UF_DATE_END', $dateEnd);
    $objPriceRuleDiscount->set('UF_MIN_COUNT_TICKETS', (int)$priceRule['UF_MIN_COUNT_TICKETS']);
    $objPriceRuleDiscount->set('UF_NUMBER_OF_USES', 0);
    $objPriceRuleDiscount->set('UF_MAX_NUMBER_OF_USES', 0);
    $objPriceRuleDiscount->set('UF_TYPE', PRICE_RULE_TYPE_DISCOUNT);
    $objPriceRuleDiscount->set('UF_IS_SUM', isset($priceRule['UF_IS_SUM']) ? 1 : 0);
    $objPriceRuleDiscount->set('UF_FOR_EACH_TICKET', isset($priceRule['UF_FOR_EACH_TICKET']) ? 1 : 0);
    $objPriceRuleDiscount->set('UF_IS_ACTIVITY', 1);

    $objPriceRuleDiscount = setTicketsTypeRequestItem($priceRule, $objPriceRuleDiscount);

    unset($uuid, $dateStart, $dateEnd);

    return $objPriceRuleDiscount;
}

function checkFileSize($file = null)
{
    $Questionnaires = new \Custom\Core\Questionnaires();
    $maxSize        = $Questionnaires->fileSize;
    $maxSizeMB      = $maxSize / 1024 / 1024;

    if ($file['size'] > $maxSize) {
        throw new Exception('Размер файла для поля "Афиша мероприятия" не должен быть больше ' . $maxSizeMB . ' МБ');
    }
}

/**
 * @throws \Bitrix\Main\ObjectPropertyException
 * @throws \Bitrix\Main\ArgumentException
 * @throws \Bitrix\Main\SystemException
 * @throws Exception
 * @throws Exception
 */
function copySeatMapSchema(int $eventId, int $copyEventId): bool
{
    $entitySchema   = HL\HighloadBlockTable::compileEntity('SeatMapSchemas');
    $hlbClassSchema = $entitySchema->getDataClass();
    $hlSchema       = $hlbClassSchema::getList(
        [
            'select' => [
                'UF_SCHEMA_ID',
                'UF_EVENT_ID',
                'UF_ORG_ID',
                'UF_VENUE_ID',
            ],
            'filter' => [
                'UF_F_EVENT_ID' => $eventId,
            ],
            'limit'  => 1,
        ]
    );
    $resSchema      = $hlSchema->fetch();

    if (!$resSchema) {
        throw new Exception('Мероприятие не найдено (HL SeatMapSchema)');
    }

    $orgId    = $resSchema['UF_ORG_ID'];
    $schemaId = $resSchema['UF_SCHEMA_ID'];
    $eventId  = $resSchema['UF_EVENT_ID'];
    $venueId  = $resSchema['UF_VENUE_ID'];

    $entityOrg   = HL\HighloadBlockTable::compileEntity('SeatMapOrganizations');
    $hlbClassOrg = $entityOrg->getDataClass();
    $hlOrg       = $hlbClassOrg::getList(
        [
            'select' => [
                'UF_PUBLIC_KEY',
                'UF_PRIVATE_KEY',
                'UF_SEATMAP_ID',
            ],
            'filter' => ['UF_ORG_ID' => $orgId],
            'limit'  => 1
        ]
    );
    $resOrg      = $hlOrg->fetch();
    if (!$resOrg) {
        throw new Exception('Организация не найдено (HL SeatMapOrganization)');
    }

    $org = [
        'publicKey'  => $resOrg['UF_PUBLIC_KEY'],
        'privateKey' => $resOrg['UF_PRIVATE_KEY'],
    ];

    $entityUser   = HL\HighloadBlockTable::compileEntity('SeatMapUsers');
    $hlbClassUser = $entityUser->getDataClass();
    $hlUser       = $hlbClassUser::getList(
        [
            'select' => [
                'UF_LOGIN',
                'UF_PASSWORD',
            ],
            'filter' => ['UF_ORG_ID' => $orgId],
            'limit'  => 1
        ]
    );
    $resUser      = $hlUser->fetch();
    if (!$resUser) {
        throw new Exception('Пользователь не найден (HL SeatMapUsers)');
    }

    $user = [
        'login'    => $resUser['UF_LOGIN'],
        'password' => $resUser['UF_PASSWORD'],
    ];

    try {
        $editorApi = new SeatMap\EditorAPI(
            Option::get('custom.core', 'SEAT_MAP_EDITOR_API_Host'),
            $user['login'],
            $user['password']
        );
    } catch (Exception $e) {
        throw new Exception(
            'Ошибка подключения пользователя к SeatMap editor API! ' . $e->getMessage() .
            ' "' . Option::get('custom.core', 'SEAT_MAP_EDITOR_API_Host') . '", "' .
            Option::get('custom.core', 'SEAT_MAP_LOGIN') . '"'
        );
    }

    try {
        $bookingApi = new SeatMap\BookingAPI(
            Option::get('custom.core', 'SEAT_MAP_BOOKING_API_Host'),
            $editorApi->getOrganizationToken()
        );
    } catch (Exception $e) {
        throw new Exception('Ошибка подключения к пользователя SeatMap booking API!' . $e->getMessage() . "\n");
    }

    $schema = $editorApi->getSchema($venueId, $schemaId);
    if (!$schema) {
        throw new Exception('Не найдена схема в seatmap');
    }

    $data = $editorApi->getSchemaData($schemaId);
    if (!$data) {
        throw new Exception('seatmap не вернул данные схемы');
    }

    $originalPrices = $bookingApi->getPrices($schema->getEventId());

    $assignment = $editorApi->getAssignment($eventId);

    $copy = $editorApi->copySchema($venueId, $schemaId, $schema->getName() . ' test copy', false);

    $copy = $editorApi->publishSchema($copy);

    $resAdd = $hlbClassSchema::add(
        [
            'UF_ORG_ID'     => $orgId,
            'UF_NAME'       => $copy->getName(),
            'UF_VENUE_ID'   => $venueId,
            'UF_SCHEMA_ID'  => $copy->getId(),
            'UF_EVENT_ID'   => $copy->getEventId(),
            'UF_F_EVENT_ID' => $copyEventId,
        ]
    );
    if (!$resAdd->isSuccess()) {
        throw new Exception('Не удалось сохранить данные схемы в HL SeatMapSchema');
    }

    $dataCopy = $editorApi->getSchemaData($copy->getId());

    $sectors = []; // id => idCopy
    foreach ($data['sectors'] as $index => $sector) {
        if ($sector['name'] === $dataCopy['sectors'][$index]['name']) {
            $sectors[$sector['id']] = $dataCopy['sectors'][$index]['id'];
        }
    }

    $rows = [];
    foreach ($data['rows'] as $index => $row) {
        $rowCopy = array_values(
            array_filter(
                $dataCopy['rows'], function ($r) use ($sectors, $row) {
                return (
                    $sectors[$row['sectorId']] === $r['sectorId']
                    && $row['name'] === $r['name']
                    && $row['seatName'] === $r['seatName']
                    && $row['rowNumber'] === $r['rowNumber']
                );
            }
            )
        );
        if ($rowCopy) {
            $rows[$row['id']] = $rowCopy[0]['id'];
        }
    }

    $seats = [];
    foreach ($data['seats'] as $index => $seat) {
        $seatCopy = array_values(
            array_filter(
                $dataCopy['seats'], function ($s) use ($sectors, $rows, $seat) {
                return (
                    $sectors[$seat['sectorId']] === $s['sectorId']
                    && $seat['name'] === $s['name']
                    && $rows[$seat['rowId']] === $s['rowId']
                );
            }
            )
        );
        if ($seatCopy) {
            $seats[$seat['id']] = $seatCopy[0]['id'];
        }
    }

    $prices = [];
    foreach ($originalPrices as $price) {
        if (!$id = $bookingApi->createPrice($copy->getEventId(), $price['name'])) {
            continue;
        }
        $prices[$price['id']] = $id;
    }

    $copyAssignment = [];
    if (isset($assignment['seats'])) {
        foreach ($assignment['seats'] as $seat) {
            if (!isset($seats[$seat['id']]) || !isset($prices[$seat['priceId']])) {
                continue;
            }
            $copyAssignment['seats'][] = [
                'id'      => $seats[$seat['id']],
                'priceId' => $prices[$seat['priceId']],
            ];
        }
    }

    if (isset($assignment['groupOfSeats'])) {
        foreach ($assignment['groupOfSeats'] as $ga) {
            if (!isset($sectors[$ga['id']]) || !isset($prices[$ga['priceId']])) {
                continue;
            }
            $copyAssignment['groupOfSeats'][] = [
                'id'          => $sectors[$ga['id']],
                'priceId'     => $prices[$ga['priceId']],
                'activeCount' => $ga['activeCount'],
            ];
        }
    }

    if ($copyAssignment) {
        $editorApi->putAssignment($copy->getEventId(), $copyAssignment);
    }

    return true;
}

/**
 * Извлекает из базы данные SeatMap для данного мероприятия.
 * При необходимости создаёт в SeatMap новую организацию, пользователя, площадку, схему.
 *
 * @param array                         $data    Данные компонента
 * @param \Bitrix\Main\HttpRequest|null $request Данные запроса
 *
 * @return array
 * @throws Exception
 */
function getSeatMapData(array $data, Bitrix\Main\HttpRequest $request = null): array
{
    global $USER;
    $logger = new \Bitrix\Main\Diag\SysLogger('voroh', LOG_ODELAY, LOG_USER);

    $companyID = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];

    if (!USE_SEATMAP) {
        return [];
    }

    if (!isset($data['EVENT'])) {
        if (!$request) {
            $logger->warning(__FUNCTION__ . ' no eventId, empty request');
            return [];
        }
        $eventId       = (int)$request['EVENT'];
        $data['EVENT'] = [];
    } else {
        $eventId = (int)$data['EVENT']['ID'];
    }

    $entity         = HL\HighloadBlockTable::compileEntity('Events');
    $hlbClassEvents = $entity->getDataClass();

    $entityStatus   = HL\HighloadBlockTable::compileEntity('EventStatus');
    $hlbClassStatus = $entityStatus->getDataClass();

    $obElement = $hlbClassEvents::getList(
        [
            'select'  => [
                'ID',
                'UF_STATUS',
                'UF_NAME',
                'UF_CATEGORY',
                'UF_TYPE',
                'UF_TYPE_XML_ID' => 'TYPE_REF.XML_ID',
                'UF_DESCRIPTION',
                'UF_UUID',
                'UF_SIT_MAP',
                'STATUS_XML_ID'  => 'STATUS.UF_XML_ID',
            ],
            'filter'  => [
                'ID'            => $eventId,
                'UF_COMPANY_ID' => $companyID,
            ],
            'runtime' => [
                new \Bitrix\Main\Entity\ReferenceField(
                    'STATUS',
                    $hlbClassStatus,
                    ['this.UF_STATUS' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'TYPE_REF',
                    '\Custom\Core\FieldEnumTable',
                    ['this.UF_TYPE' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
                ),
            ]
        ]
    );
    $event     = $obElement->fetch();
    if (!$event) {
        $logger->error(__FUNCTION__ . ' eventId: ' . var_export($eventId, true) . ', event not found');
        throw new Exception('Мероприятие не найдено');
    }

    $data['EVENT'] = array_merge($data['EVENT'], $event);

    if (
        !(
            isset($data['EVENT']['UF_TYPE_XML_ID'])
            && ($data['EVENT']['UF_TYPE_XML_ID'] === 'offline' || $data['EVENT']['UF_TYPE_XML_ID'] === 'offline_online')
            && $data['EVENT']['UF_SIT_MAP'] === '1'
        )
    ) {
        $logger->warning(
            __FUNCTION__ . ' eventId: ' . var_export($eventId, true)
            . ', type: ' . var_export($data['EVENT']['UF_TYPE_XML_ID'], true)
            . ', use_seatmap: ' . var_export($data['EVENT']['UF_TYPE_XML_ID'], true)
        );
        return [];
    }

    try {
        $editorApi = new SeatMap\EditorAPI(
            Option::get('custom.core', 'SEAT_MAP_EDITOR_API_Host'),
            Option::get('custom.core', 'SEAT_MAP_LOGIN'),
            Option::get('custom.core', 'SEAT_MAP_PASSWORD')
        );
    } catch (Exception $e) {
        $message = 'Ошибка подключения к admin@SeatMap editor API! ' . $e->getMessage() .
            ' "' . Option::get('custom.core', 'SEAT_MAP_EDITOR_API_Host') . '", "' .
            Option::get('custom.core', 'SEAT_MAP_LOGIN') . '"';
        $logger->error(__FUNCTION__ . ' eventId: ' . var_export($eventId, true) . ', ' . $message);
        throw new Exception($message);
    }

    $arResult = [];

    $entityUser   = HL\HighloadBlockTable::compileEntity('SeatMapUsers');
    $hlbClassUser = $entityUser->getDataClass();

    $entityOrg   = HL\HighloadBlockTable::compileEntity('SeatMapOrganizations');
    $hlbClassOrg = $entityOrg->getDataClass();
    $hlOrg       = $hlbClassOrg::getList(
        [
            'select' => [
                'UF_PRIVATE_KEY',
                'UF_PUBLIC_KEY',
                'UF_SEATMAP_ID',
            ],
            'filter' => ['UF_ORG_ID' => $companyID],
            'limit'  => 1
        ]
    );
    $resOrg      = $hlOrg->fetch();
    if (!$resOrg) {
        $arResult = [
            'user' => [
                'login'    => $companyID . '-' . $USER->GetEmail(),
                'password' => \Custom\Core\UUID::uuid8(),
            ],
        ];

        $org = $editorApi->createOrganization(
            $_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_NAME'],
            $arResult['user']['login'],
            $arResult['user']['password']
        );
        if ($org) {
            $arResult['org'] = [
                'publicKey'  => $org['publicKey'],
                'privateKey' => $org['privateKey'],
                'id'         => $org['id'],
            ];
        } else {
            $logger->error(
                __FUNCTION__
                . ' eventId: ' . var_export($eventId, true) . ', '
                . ' company: ' . var_export($_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_NAME'], true) . ', '
                . ' user: ' . var_export($arResult['user']['login'], true)
            );
            throw new Exception('Не удалось создать организацию в SeatMap!');
        }

        $resOrg = [
            'UF_ORG_ID'      => $companyID,
            'UF_PUBLIC_KEY'  => $org['publicKey'],
            'UF_PRIVATE_KEY' => $org['privateKey'],
            'UF_SEATMAP_ID'  => $org['id'],
        ];

        $resAdd = $hlbClassUser::add(
            [
                'UF_USER_ID'  => $_SESSION['CURRENT_USER_PROFILE']['UF_USER_ID'],
                'UF_LOGIN'    => $arResult['user']['login'],
                'UF_PASSWORD' => $arResult['user']['password'],
                'UF_ORG_ID'   => $companyID,
            ]
        );
        if (!$resAdd->isSuccess()) {
            throw new Exception($resAdd->getErrors());
        }

        $resAdd = $hlbClassOrg::add($resOrg);
        if (!$resAdd->isSuccess()) {
            throw new Exception($resAdd->getErrors());
        }
    }

    $arResult = [
        'org' => [
            'publicKey'  => $resOrg['UF_PUBLIC_KEY'],
            'privateKey' => $resOrg['UF_PRIVATE_KEY'],
            'id'         => $resOrg['UF_SEATMAP_ID'],
        ],
    ];

    if (!isset($arResult['user'])) {
        $hlUser  = $hlbClassUser::getList(
            [
                'select' => [
                    'UF_LOGIN',
                    'UF_PASSWORD',
                ],
                'filter' => ['UF_ORG_ID' => $companyID],
                'limit'  => 1
            ]
        );
        $resUser = $hlUser->fetch();
        if (!$resUser) {
            $logger->error(
                __FUNCTION__
                . ' eventId: ' . var_export($eventId, true) . ', '
                . ' company: ' . var_export($_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_NAME'], true) . ', '
                . ' companyId: ' . var_export($companyID, true)
                . ' не найден пользователь в HL SeatMapUsers'
            );
            throw new Exception('Не найден пользователь для SeatMap!');
        }
        $arResult['user'] = [
            'login'    => $resUser['UF_LOGIN'],
            'password' => $resUser['UF_PASSWORD'],
        ];
    }

    $autologin = $editorApi->autologin(
        [
            'email'      => $arResult['user']['login'],
            'password'   => $arResult['user']['password'],
            'privateKey' => $arResult['org']['privateKey'],
        ]
    );
    if (!$autologin) {
        $logger->error(
            __FUNCTION__
            . ' eventId: ' . var_export($eventId, true) . ', '
            . ' user: ' . var_export($arResult['user']['login'], true) . ', '
            . ' seatmap autologin error'
        );
        throw new Exception('Не удалось выполнить autologin в SeatMap!');
    }

    $arResult['token']        = $autologin['token'];
    $arResult['refreshToken'] = $autologin['refreshToken'];

    try {
        $editorApi             = new SeatMap\EditorAPI(
            Option::get('custom.core', 'SEAT_MAP_EDITOR_API_Host'),
            $arResult['user']['login'],
            $arResult['user']['password']
        );
        $arResult['editorApi'] = $editorApi;
    } catch (Exception $e) {
        $message = 'Ошибка подключения пользователя к SeatMap editor API! ' . $e->getMessage() .
            ' "' . Option::get('custom.core', 'SEAT_MAP_EDITOR_API_Host') . '", "' .
            Option::get('custom.core', 'SEAT_MAP_LOGIN') . '"';
        $logger->error(
            __FUNCTION__
            . ' eventId: ' . var_export($eventId, true) . ', '
            . ' user: ' . var_export($arResult['user']['login'], true) . ', '
            . ' seatmap editor constructor error '
            . $e->getMessage()
        );
        throw new Exception($message);
    }

    try {
        $bookingApi             = new SeatMap\BookingAPI(
            Option::get('custom.core', 'SEAT_MAP_BOOKING_API_Host'),
            $editorApi->getOrganizationToken()
        );
        $arResult['bookingApi'] = $bookingApi;
    } catch (Exception $e) {
        $logger->error(
            __FUNCTION__
            . ' eventId: ' . var_export($eventId, true) . ', '
            . ' user: ' . var_export($arResult['user']['login'], true) . ', '
            . ' seatmap booking constructor error '
            . $e->getMessage()
        );
        throw new Exception('Ошибка подключения пользователя к SeatMap booking API! ' . $e->getMessage());
    }

    // SeatMap Venue
    $entityVenue   = HL\HighloadBlockTable::compileEntity('SeatMapVenues');
    $hlbClassVenue = $entityVenue->getDataClass();
    $hlVenue       = $hlbClassVenue::getList(
        [
            'select' => [
                'UF_VENUE_ID',
            ],
            'filter' => [
                'UF_ORG_ID' => $companyID,
            ],
            'limit'  => 1,
        ]
    );
    $resVenue      = $hlVenue->fetch();
    if (!$resVenue) {
        $venue = $bookingApi->createVenue(
            new SeatMap\Venue(
                $data['EVENT']['UF_TYPE'],
                false,
                0,
                0.0,
                0.0,
                $_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_NAME']
            )
        );
        if (!$venue) {
            $logger->error(
                __FUNCTION__
                . ' eventId: ' . var_export($eventId, true) . ', '
                . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                . ' seatmap venue creating  error '
            );
            throw new Exception('Не удалось создать площадку в SeatMap!');
        }

        $arResult['venueId'] = $venue->getId();

        $resAdd = $hlbClassVenue::add(
            [
                'UF_ORG_ID'   => $companyID,
                'UF_VENUE_ID' => $venue->getId(),
            ]
        );
        if (!$resAdd->isSuccess()) {
            $logger->error(
                __FUNCTION__
                . ' eventId: ' . var_export($eventId, true) . ', '
                . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                . ' seatmap venue creating HL error: '
                . $resAdd->getErrors()
            );
            throw new Exception($resAdd->getErrors());
        }
    } else {
        $arResult['venueId'] = $resVenue['UF_VENUE_ID'];
    }

    $entitySchema   = HL\HighloadBlockTable::compileEntity('SeatMapSchemas');
    $hlbClassSchema = $entitySchema->getDataClass();
    $schemaName     = $data['EVENT']['UF_NAME'];
    $hlSchema       = $hlbClassSchema::getList(
        [
            'select' => [
                'UF_SCHEMA_ID',
                'UF_EVENT_ID',
            ],
            'filter' => [
                'UF_ORG_ID'     => $companyID,
                'UF_VENUE_ID'   => $arResult['venueId'],
                'UF_F_EVENT_ID' => $data['EVENT']['ID'],
            ],
            'limit'  => 1,
        ]
    );
    $resSchema      = $hlSchema->fetch();
    if (!$resSchema) {
        $schema = $editorApi->createSchema(
            $arResult['venueId'],
            $schemaName,
            $arResult['org']['id'],
            true,
            $schemaName
        );
        if (!$schema) {
            $logger->error(
                __FUNCTION__
                . ' eventId: ' . var_export($eventId, true) . ', '
                . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                . ' seatmap schema creating error'
            );
            throw new Exception('Не удалось создать схему в SeatMap!');
        }

        $arResult['schemaId'] = $schema->getId();
        $arResult['eventId']  = $schema->getEventId();

        $resAdd = $hlbClassSchema::add(
            [
                'UF_ORG_ID'     => $companyID,
                'UF_NAME'       => $schemaName,
                'UF_VENUE_ID'   => $arResult['venueId'],
                'UF_SCHEMA_ID'  => $arResult['schemaId'],
                'UF_EVENT_ID'   => $arResult['eventId'],
                'UF_F_EVENT_ID' => $data['EVENT']['ID'],
            ]
        );
        if (!$resAdd->isSuccess()) {
            $logger->error(
                __FUNCTION__
                . ' eventId: ' . var_export($eventId, true) . ', '
                . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                . ' seatmap schema creating HL error: '
                . $resAdd->getErrors()
            );
            throw new Exception($resAdd->getErrors());
        }
        $arResult['editorUrl'] = makeSeatmapEditorUrl($arResult);
        return $arResult;
    }

    $arResult['schemaId'] = (int)$resSchema['UF_SCHEMA_ID'];
    $arResult['eventId']  = $resSchema['UF_EVENT_ID'];

    $prices = [];
    if (!empty($arResult['eventId'])) {
        if ($seatMapPrices = $bookingApi->getPrices($arResult['eventId'])) {
            foreach ($seatMapPrices as $price) {
                $prices[$price['id']]['name']  = $price['name'];
                $prices[$price['id']]['id']    = $price['id'];
                $prices[$price['id']]['count'] = 0;
            }
        }
    }

    $assignment = $editorApi->getAssignment($arResult['eventId']);

    $schemaData = $editorApi->getSchemaData($arResult['schemaId']);
    $sectors    = [];
    foreach ($schemaData['sectors'] as $sector) {
        $sectors[$sector['id']]['name'] = $sector['name'];
        $sectors[$sector['id']]['ga']   = $sector['ga'];
    }

    $seats = [];
    foreach ($schemaData['seats'] as $seat) {
        $seats[$seat['id']] = [
            'sectorId' => $seat['sectorId'],
        ];
    }

    if (isset($assignment['seats'])) {
        foreach ($assignment['seats'] as $seat) {
            $seatId   = $seat['id'];
            $priceId  = $seat['priceId'];
            $sectorId = $seats[$seatId]['sectorId'];
            if (!isset($prices[$priceId]['sectors'][$sectorId])) {
                $prices[$priceId]['sectors'][$sectorId] = 0;
            }
            $prices[$priceId]['sectors'][$sectorId] += 1;
            $prices[$priceId]['count']              += 1;
        }
    }

    if (isset($assignment['groupOfSeats'])) {
        foreach ($assignment['groupOfSeats'] as $ga) {
            $prices[$ga['priceId']]['sectors'][$ga['id']] += $ga['activeCount'];
            $prices[$ga['priceId']]['count']              += $ga['activeCount'];
        }
    }

    $prices = array_filter($prices, fn($price) => preg_match('/^\d+$/', $price['name']));

    $arResult['sectors'] = $sectors;

    $tickets = \Custom\Core\Helper::getTicketsOffers($eventId);

    $prices2offers  = [];
    $offers2prices  = [];
    $prices2hl      = [];
    $entityPrices   = HL\HighloadBlockTable::compileEntity('SeatMapPricingZones');
    $hlbClassPrices = $entityPrices->getDataClass();
    $hlPrices       = $hlbClassPrices::getList(
        [
            'select' => [
                'ID',
                'UF_OFFER_ID',
                'UF_SEATMAP_ID',
                'UF_SEATMAP_SECTOR_ID',
                'UF_UUID',
            ],
            'filter' => ['UF_EVENT_ID' => $eventId],
        ]
    );
    while ($resPrices = $hlPrices->fetch()) {
        $prices2offers[$resPrices['UF_SEATMAP_ID'] . '-' . $resPrices['UF_SEATMAP_SECTOR_ID']] = $resPrices['UF_OFFER_ID'];
        $offers2prices[$resPrices['UF_OFFER_ID']]                                              = [
            'price'  => $resPrices['UF_SEATMAP_ID'],
            'sector' => $resPrices['UF_SEATMAP_SECTOR_ID'],
        ];
        $prices2hl[$resPrices['UF_OFFER_ID']]                                                  = $resPrices['ID'];
    }

    $arResult['prices2offers'] = $prices2offers;
    $arResult['offers2prices'] = $offers2prices;

    $eventUUID = $data['EVENT']['UF_UUID'];
    if (!$eventUUID) {
        $logger->error(
            __FUNCTION__
            . ' eventId: ' . var_export($eventId, true) . ', '
            . ' user: ' . var_export($arResult['user']['login'], true) . ', '
            . ' Event without UUID'
        );
        throw new Exception('Нельзя редактировать события без UUID');
    }

    $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
    $query         = new ORM\Query\Query($productEntity);
    $resProduct    = $query
        ->setSelect(['ID', 'NAME', 'EVENT_ID.VALUE'])
        ->setFilter(['EVENT_ID.VALUE' => $eventId])
        ->exec();
    $objProduct    = $resProduct->fetchObject();

    if ($objProduct->getId() < 1) {
        $logger->error(
            __FUNCTION__
            . ' eventId: ' . var_export($eventId, true) . ', '
            . ' user: ' . var_export($arResult['user']['login'], true) . ', '
            . ' objProduct->getId < 1'
        );
        throw new Exception('Такого продукта нет');
    }

    $arResult['productId'] = $objProduct->getId();

    $mainProductID = $objProduct->getId();

    if ($sectors && $prices) {
        foreach ($prices as $price) {
            if (!isset($price['sectors'])) {
                continue;
            }

            foreach ($price['sectors'] as $id => $count) {
                if (!$count || isset($prices2offers[$price['id'] . '-' . $id])) {
                    continue;
                }

                // create
                $offerUUID = \Custom\Core\UUID::uuid8();
                $offer     = [
                    'NAME'                => $schemaName . ' [' . $sectors[$id]['name'] . ']',
                    'XML_ID'              => $offerUUID,
                    'CML2_LINK'           => $mainProductID,
                    'MAX_QUANTITY'        => ((int)Option::get('custom.core', 'SEAT_MAP_MAX_QUANTITY')) ?: 10,
                    'RESERVE_TIME'        => TICKET_RESERVE_MIN_DEF,
                    'TYPE'                => $sectors[$id]['name'],
                    'TOTAL_QUANTITY'      => $count,
                    'QUANTITY'            => $count,
                    'PRICE'               => $prices[$price['id']]['name'],
                    'IS_CREATED_SEAT_MAP' => 1,
                ];
                $resOffer  = Products::getInstance()->createProduct($offer, true);
                if ($resOffer['status'] === 'success') {
                    $resAdd = $hlbClassPrices::add(
                        [
                            'UF_OFFER_ID'          => $resOffer['id'],
                            'UF_EVENT_ID'          => $eventId,
                            'UF_SEATMAP_ID'        => $price['id'],
                            'UF_SEATMAP_SECTOR_ID' => $id,
                            'UF_PRODUCT_ID'        => $mainProductID,
                            'UF_UUID'              => $offerUUID,
                        ]
                    );
                } else {
                    $logger->error(
                        __FUNCTION__
                        . ' eventId: ' . var_export($eventId, true) . ', '
                        . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                        . ' createProduct error, '
                        . ' offer: ' . var_export($offer, true) . ', '
                        . var_export($resOffer['message'], true)
                    );
                }
            }
        }

        $wasPublish = !empty(array_filter(getEventStatusHistory($eventId), fn($item) => $item['STATUS_ID'] === '5'));

        foreach ($tickets as $offer) {
            $update = [];
            if (!isset($offers2prices[$offer['SKU_ID']])) {
                continue;
            }

            $priceId  = $offers2prices[$offer['SKU_ID']]['price'];
            $sectorId = $offers2prices[$offer['SKU_ID']]['sector'];

            if (!isset($prices[$priceId]) || !$prices[$priceId]['count'] || !isset($prices[$priceId]['sectors'][$sectorId])) {
                // delete
                $offerEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
                $query       = new ORM\Query\Query($offerEntity);
                $resOffer    = $query
                    ->setSelect(['ID', 'TYPE', 'XML_ID', 'IS_CREATED_SEAT_MAP'])
                    ->setFilter(['ID' => $offer['SKU_ID']])
                    ->exec();
                $objOffer    = $resOffer->fetchObject();
                if (!is_object($objOffer)) {
                    continue;
                }
                $offerId = $objOffer->getId();
                if ($offerId > 0) {
                    $mayBeDeleted = true;
                    if ($wasPublish) {
                        $bookedCount = count(getSalesByOffer($offerId));
                        if ($bookedCount) {
                            $mayBeDeleted = false;
                            $logger->info(
                                __FUNCTION__
                                . ' eventId: ' . var_export($eventId, true) . ', '
                                . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                                . ' updateProduct '
                            );
                            $resOffer = Products::getInstance()->updateProduct(
                                $offer['SKU_ID'],
                                [
                                    'CML2_LINK' => $mainProductID,
                                    'QUANTITY'       => $bookedCount,
                                    'TOTAL_QUANTITY' => $bookedCount,
                                ],
                                true
                            );

                            $objBarcode = new \Custom\Core\Barcode();
                            $objBarcode->deleteTicketBarcode($offerId, ["new", "booked"]);
                            $objBarcode->clearBasketThisTicket($offerId);

                            if ($resOffer['status'] === 'error') {
                                $logger->error(
                                    __FUNCTION__
                                    . ' eventId: ' . var_export($eventId, true) . ', '
                                    . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                                    . ' updateProduct error'
                                );
                                throw new Exception('Ошибка синхронизации цен seatmap.');
                            }
                        }
                    }
                    if ($mayBeDeleted) {
                        $resDelete = $objOffer->delete();
                        if ($resDelete->isSuccess()) {

                            $objBarcode = new \Custom\Core\Barcode();
                            $objBarcode->deleteTicketBarcode($offerId);
                            $objBarcode->clearBasketThisTicket($offerId);

                            $hlbClassPrices::delete($prices2hl[$offerId]);
                        }
                    }
                }
                continue;
            }

            // update
            $name = $sectors[$sectorId]['name'];
            if ($offer['SKU_TYPE'] !== $name) {
                $update['TYPE'] = $name;
                $update['NAME'] = $schemaName;
            }
            if ((float)$offer['SKU_PRICE'] !== (float)$prices[$priceId]['name']) {
                $update['PRICE'] = $prices[$priceId]['name'];
            }
            if ((int)$offer['SKU_TOTAL_QUANTITY'] !== $prices[$priceId]['sectors'][$sectorId]) {
                $difference = $prices[$priceId]['sectors'][$sectorId] - (int)$offer['SKU_TOTAL_QUANTITY'];
                $objCatalog = \Bitrix\Catalog\ProductTable::wakeUpObject($offer['SKU_ID']);
                $currentQty = $objCatalog->fillQuantity();

                $update['QUANTITY']       = $currentQty + $difference;
                $update['TOTAL_QUANTITY'] = $prices[$priceId]['sectors'][$sectorId];
            }

            if ($update) {
                $update['CML2_LINK'] = $mainProductID;
                $resOffer = Products::getInstance()->updateProduct((int) $offer['SKU_ID'], $update, true);
                $logger->info(
                    __FUNCTION__
                    . ' eventId: ' . var_export($eventId, true) . ', '
                    . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                    . ' updateProduct '
                );
                if ($resOffer['status'] === 'error') {
                    $logger->error(
                        __FUNCTION__
                        . ' eventId: ' . var_export($eventId, true) . ', '
                        . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                        . ' updateProduct error'
                    );
                    throw new Exception('Ошибка синхронизации цен seatmap.');
                }
            }
        }
    } else {
        $wasPublish = !empty(array_filter(getEventStatusHistory($eventId), fn($item) => $item['STATUS_ID'] === '5'));

        foreach ($tickets as $offer) {
            if (!isset($offers2prices[$offer['SKU_ID']])) {
                continue;
            }

            // delete
            $offerEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
            $query       = new ORM\Query\Query($offerEntity);
            $resOffer    = $query
                ->setSelect(['ID', 'TYPE', 'XML_ID', 'IS_CREATED_SEAT_MAP'])
                ->setFilter(['ID' => $offer['SKU_ID']])
                ->exec();
            $objOffer    = $resOffer->fetchObject();
            if (!is_object($objOffer)) {
                continue;
            }
            $offerId = $objOffer->getId();
            if ($offerId > 0) {
                $mayBeDeleted = true;
                if ($wasPublish) {
                    $bookedCount = count(getSalesByOffer($offerId));
                    if ($bookedCount) {
                        $mayBeDeleted = false;
                        $logger->info(
                            __FUNCTION__
                            . ' eventId: ' . var_export($eventId, true) . ', '
                            . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                            . ' updateProduct '
                        );
                        $resOffer = Products::getInstance()->updateProduct(
                            (int) $offer['SKU_ID'],
                            [
                                'CML2_LINK' => $mainProductID,
                                'QUANTITY'       => $bookedCount,
                                'TOTAL_QUANTITY' => $bookedCount,
                            ],
                            true
                        );
                        if ($resOffer['status'] === 'error') {
                            $logger->error(
                                __FUNCTION__
                                . ' eventId: ' . var_export($eventId, true) . ', '
                                . ' user: ' . var_export($arResult['user']['login'], true) . ', '
                                . ' updateProduct error'
                            );
                            throw new Exception('Ошибка синхронизации цен seatmap.');
                        }
                    }
                }
                if ($mayBeDeleted) {
                    $resDelete = $objOffer->delete();
                    if ($resDelete->isSuccess()) {
                        $hlbClassPrices::delete($prices2hl[$offerId]);
                    }
                }
            }
        }
    }

    //if ($data['EVENT']['STATUS_XML_ID'] === 'published') {
        $hlbClassEvents::update($eventId, ['BARCODE_UPDATE' => true]);
    //}

    $arResult['prices'] = $prices;

    $arResult['editorUrl'] = makeSeatmapEditorUrl($arResult);

    return $arResult;
}

/**
 * Возвращает историю статусов мероприятия
 *
 * @param int $eventId Id мероприятия
 *
 * @return array
 * @throws \Bitrix\Main\ArgumentException
 * @throws \Bitrix\Main\ObjectPropertyException
 * @throws \Bitrix\Main\SystemException
 */
function getEventStatusHistory(int $eventId): array
{
    $query      = new ORM\Query\Query('\Custom\Core\Events\EventsStatusHistoryTable');
    $result     = [];
    $resElement = $query
        ->setSelect(['ID', 'STATUS_NAME' => 'STATUS.UF_NAME', 'STATUS_ID' => 'STATUS.ID', 'UF_DATE_UPDATE', 'UF_COMMENT'])
        ->setOrder(['UF_DATE_UPDATE' => 'ASC'])
        ->setFilter(['UF_EVENT_ID' => $eventId])
        ->exec();
    while ($r = $resElement->fetch()) {
        $result[$r['ID']] = $r;
    }

    return $result;
}

/**
 * Возвращает список ШК со статусом "продан", "использован" или "забронирован"
 *
 * @param int $offerId Id типа билета
 *
 * @return array
 * @throws \Bitrix\Main\ArgumentException
 * @throws \Bitrix\Main\ObjectPropertyException
 * @throws \Bitrix\Main\SystemException
 */
function getSalesByOffer(int $offerId): array
{
    return \Custom\Core\Tickets\BarcodesTable::getList(
        [
            'select'  => [
                'ID',
                'UF_SEATMAP_ID',
                'UF_STATUS'
            ],
            'filter'  => [
                'UF_OFFER_ID' => $offerId,
                [
                    "LOGIC" => "AND",
                    [
                        "LOGIC" => "OR",
                        ["STATUS.XML_ID" => "sold"],
                        ["STATUS.XML_ID" => "used"],
                        ["STATUS.XML_ID" => "booked"],
                    ],
                ],
            ],
            "runtime" => [
                new \Bitrix\Main\Entity\ReferenceField(
                    'STATUS',
                    '\Custom\Core\FieldEnumTable',
                    ['this.UF_STATUS' => 'ref.ID'],
                    ['join_type' => 'LEFT'],
            ),
            ],
        ]
    )->fetchAll();
}

function checkExistsOrders(int $eventID): bool
{
    $dbRes = \Bitrix\Sale\Order::getList(
        [
            'select'      => [
                'ID',
                'EVENT_ID' => 'PROPERTY_EVENT_ID.VALUE',
            ],
            'filter'      => [
                "PROPERTY_EVENT_ID.CODE"  => "EVENT_ID", //и по его значению
                "PROPERTY_EVENT_ID.VALUE" => $eventID, //и по его значению
            ],
            'runtime'     => [
                new \Bitrix\Main\Entity\ReferenceField(
                    'PROPERTY_EVENT_ID',
                    'Bitrix\Sale\Internals\OrderPropsValueTable',
                    ['=this.ID' => 'ref.ORDER_ID'],
                    ['join_type' => 'inner']
                ),
            ],
            'limit'       => 1,
            'count_total' => true,
        ]
    );
    return $dbRes->getCount() > 0;
}

/**
 * Формирует ссылку для открытия редактора
 *
 * @param array $data Данные пользователя и мероприятия
 *
 * @return string
 */
function makeSeatmapEditorUrl(array $data): string
{
    return Option::get('custom.core', 'SEAT_MAP_EDITOR_API_Host') .
        '/app/venues/' . $data['venueId'] .
        '/schemas/' .
        $data['schemaId'] .
        '?' .
        'hideNavbar=true&showPricing=true&hidden=pricingZones&' .
        'token=' . $data['token'] . '&refreshToken=' . $data['refreshToken'];
}

function getPropEnumIdByXmlID(string $xmlID): int
{
    $propRes = Bitrix\Iblock\PropertyEnumerationTable::getList(
        [
            'select' => ['ID', 'XML_ID', 'VALUE'],
            'filter' => ['XML_ID' => $xmlID]
        ]
    );

    return (int)$propRes->fetch()['ID'];
}

function getAffectedTicketTypes(array $arChanges, int $eventID): array
{
    $affectedTicketTypes = [];

    if (empty($arChanges)) {
        return $affectedTicketTypes;
    }

    $hasDateChanges    = false;
    $hasLinkChanges    = false;
    $hasAddressChanges = false;
    $changedDates      = [];

    // Анализируем типы изменений
    foreach ($arChanges as $change) {
        if (strpos($change, 'Дата:') !== false || strpos($change, 'Время:') !== false) {
            $hasDateChanges = true;
            // Пытаемся извлечь конкретные измененные даты из строки изменения
            // Это приблизительный анализ, можно улучшить парсинг
            if (preg_match_all('/(\d{2}\.\d{2}\.\d{4})/', $change, $matches)) {
                foreach ($matches[1] as $dateStr) {
                    $changedDates[] = $dateStr;
                }
            }
        }
        if (strpos($change, 'Ссылка:') !== false) {
            $hasLinkChanges = true;
        }
        if (strpos($change, 'Адрес:') !== false) {
            $hasAddressChanges = true;
        }
    }

    // Получаем все типы билетов для события с их датами
    $offerEntity   = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
    $elementEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
    $propField     = $elementEntity->getField('EVENT_ID');
    $propEntity    = $propField->getRefEntity();

    $dbRes = \Bitrix\Iblock\Elements\ElementTicketsTable::getList(
        [
            'select'  => [
                'OFFER_ID'                 => 'OFFER.ID',
                'OFFER_DATES'              => 'OFFER_DATES_CONCAT',
                'OFFER_DATES_ALL'          => 'OFFER.DATES_ALL.VALUE',
                'OFFER_TYPE_PARTICIPATION' => 'OFFER.TYPE_PARTICIPATION.VALUE'
            ],
            'filter'  => [
                'EVENT_ID.VALUE' => $eventID,
                'OFFER.ACTIVE'   => 'Y'
            ],
            'runtime' => [
                new \Bitrix\Main\Entity\ReferenceField(
                    'TICKETS',
                    $propEntity,
                    ['this.ID' => 'ref.VALUE'],
                    ['join_type' => 'LEFT']
                ),
                new \Bitrix\Main\Entity\ReferenceField(
                    'OFFER',
                    $offerEntity,
                    ['this.TICKETS.IBLOCK_ELEMENT_ID' => 'ref.ID'],
                    ['join_type' => 'LEFT']
                ),
                new \Bitrix\Main\Entity\ExpressionField(
                    'OFFER_DATES_CONCAT',
                    "GROUP_CONCAT(%s SEPARATOR ';')",
                    ['OFFER.DATES.VALUE']
                )
            ],
            'group'   => ['OFFER_ID']
        ]
    );

    $onlinePropID = getPropEnumIdByXmlID('online');

    while ($offer = $dbRes->fetch()) {
        $offerId        = $offer['OFFER_ID'];
        $offerDatesAll  = $offer['OFFER_DATES_ALL'];
        $offerDates     = !empty($offer['OFFER_DATES']) ? explode(';', $offer['OFFER_DATES']) : [];
        $isOnlineTicket = ($offer['OFFER_TYPE_PARTICIPATION'] == $onlinePropID);

        $shouldAddTicket = false;

        // Если у билета установлено DATES_ALL - он затрагивается любыми изменениями дат
        if ($hasDateChanges && $offerDatesAll) {
            $shouldAddTicket = true;
        } // Если у билета есть конкретные даты - проверяем пересечение с измененными датами
        elseif ($hasDateChanges && !empty($offerDates)) {
            if (empty($changedDates)) {
                // Если не удалось извлечь конкретные даты из изменений, считаем что затронуты все билеты
                $shouldAddTicket = true;
            } else {
                // Проверяем пересечение дат билета с измененными датами
                foreach ($offerDates as $offerDate) {
                    $offerDateFormatted = date('d.m.Y', strtotime($offerDate));
                    if (in_array($offerDateFormatted, $changedDates)) {
                        $shouldAddTicket = true;
                        break;
                    }
                }
            }
        }

        // Изменения ссылок затрагивают только онлайн билеты
        if ($hasLinkChanges && $isOnlineTicket) {
            $shouldAddTicket = true;
        }

        // Изменения адреса затрагивают офлайн билеты (не онлайн)
        if ($hasAddressChanges && !$isOnlineTicket) {
            $shouldAddTicket = true;
        }

        if ($shouldAddTicket) {
            $affectedTicketTypes[] = $offerId;
        }
    }

    return array_unique($affectedTicketTypes);
}

function getOrdersByEventIDAndTicketTypes(int $eventID, array $ticketTypeIds, string $severName = ''): array
{
    if (empty($ticketTypeIds)) {
        return [];
    }

    $result = [];

    $runtime = [
        new \Bitrix\Main\Entity\ReferenceField(
            'PROPERTY_BUYER',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'PROPERTY_BUYER_EMAIL',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'PROPERTY_EVENT_ID',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'PROPERTY_ORDER_UUID',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'BASKET_REFS',
            'Bitrix\Sale\Internals\BasketTable',
            ['this.ID' => 'ref.ORDER_ID'],
            ['join_type' => 'inner']
        ),
        new \Bitrix\Main\Entity\ReferenceField(
            'EVENT',
            'Custom\Core\Events\EventsTable',
            ['=this.EVENT_ID' => 'ref.ID'],
            ['join_type' => 'inner']
        ),
    ];

    $filter = [
        "PAYED"                     => "Y",
        '!CANCELED'                 => "Y",
        "PROPERTY_EVENT_ID.CODE"    => "EVENT_ID",
        "PROPERTY_EVENT_ID.VALUE"   => $eventID,
        "PROPERTY_ORDER_UUID.CODE"  => "UUID",
        "PROPERTY_BUYER_EMAIL.CODE" => "EMAIL",
        "PROPERTY_BUYER.CODE"       => 'FIO',
        "BASKET_REFS.PRODUCT_ID"    => $ticketTypeIds,
    ];

    $dbRes = \Bitrix\Sale\Order::getList(
        [
            'select'  => [
                'EVENT_ID'   => 'PROPERTY_EVENT_ID.VALUE',
                'FULL_NAME'  => 'PROPERTY_BUYER.VALUE',
                'EMAIL'      => 'PROPERTY_BUYER_EMAIL.VALUE',
                'ADDRESS'    => 'EVENT.UF_LOCATION_REF.UF_ADDRESS',
                'ORDER_UUID' => 'PROPERTY_ORDER_UUID.VALUE',
            ],
            'filter'  => $filter,
            'runtime' => $runtime,
            'group'   => ['EVENT_ID', 'EMAIL']
        ]
    );

    while ($order = $dbRes->fetch()) {
        $result[] = [
            'FULL_NAME'   => $order['FULL_NAME'],
            'EMAIL'       => $order['EMAIL'],
            'REFUND_LINK' => $severName . '/refund/' . $order['ORDER_UUID'] . '/',
        ];
    }

    return $result;
}

function checkEvent($arParams, $companyID, $publish = false)
{
    if (!isset($arParams['ELEMENT_ID'])) throw new Exception('Wrong param Event id');
    $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
    $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
    $hlbClass = $entity->getDataClass();
    $event    = $hlbClass::getList(
        [
            'select' => [
                'ID',
                'UF_NAME',
                'UF_IMG',
                'UF_TYPE',
                'UF_AGE_LIMIT',
                'UF_DESCRIPTION',
                'UF_CATEGORY',
                'UF_COMPANY_ID',
                'UF_STATUS',
            ],
            'filter' => ['ID' => $arParams['ELEMENT_ID']],
            'limit'  => 1
        ]
    );
    $resEvent = $event->fetch();
    if ($resEvent['ID'] < 1) throw new Exception('Такого события нет');
    if ($resEvent['UF_COMPANY_ID'] != $companyID) throw new Exception('Нельзя редактировать чужие события');

    if($publish)
    {
        if ($resEvent['UF_STATUS'] != 2 && !\Custom\Core\Events::isClosedEvent($arParams['ELEMENT_ID']))
        {
            throw new Exception('Опубликовать можно только в статусе "Подтверждено"');
        }
    }

    //\Bitrix\Main\Diag\Debug::writeToFile($resEvent, '', 'VALIDATIONS.txt');
    $errors = [];
    global $USER_FIELD_MANAGER;
    $fieldsTitles = $USER_FIELD_MANAGER->getUserFieldsWithReadyData(
        'HLBLOCK_' . $arParams["HLDB_EVENTS_ID"],
        [],
        'ru'
    );
    foreach ($resEvent as $key => $value) {
        if (in_array($key, ['UF_IMG', 'UF_TYPE', 'UF_AGE_LIMIT', 'UF_CATEGORY']) && intval($value) < 1) {
            $errors[$key] = "Не заполнено поле «" . $fieldsTitles[$key]['EDIT_FORM_LABEL'] . "»";
        }

        if (in_array($key, ['UF_DESCRIPTION', 'UF_NAME']) && strlen(strip_tags(trim($value))) < 1) {
            $errors[$key] = "Не заполнено поле «" . $fieldsTitles[$key]['EDIT_FORM_LABEL'] . "»";
        }

        if (in_array($key, ['UF_DESCRIPTION']) && mb_strlen(strip_tags(trim($value)), 'UTF-8') > 10000) {
            $errors[$key] = "Максимальная длина поля «" . $fieldsTitles[$key]['EDIT_FORM_LABEL'] . "» 10000 символов";
        }
    }

    $query  = new ORM\Query\Query('\Custom\Core\Events\EventsDateAndLocationTable');
    $result = [];
    $obRes  = $query
        ->setSelect(['ID', 'UF_EVENT_ID', 'UF_DATE_TIME', 'UF_DURATION', 'UF_ADDRESS', 'UF_ROOM', 'UF_LINK'])
        ->setFilter(['UF_EVENT_ID' => $arParams['ELEMENT_ID']])
        ->countTotal(true)
        ->exec();
    if ($obRes->getCount() < 1) $errors[] = "Не заполнены дата и время мероприятия";
    $arDates      = [];
    $fieldsTitles = $USER_FIELD_MANAGER->getUserFieldsWithReadyData(
        'HLBLOCK_' . HL_EVENTS_LOCATION_ID,
        [],
        'ru'
    );
    while ($location = $obRes->fetch()) {
        $location['UF_DATE_TIME'] = unserialize($location['UF_DATE_TIME']) ?? [];
        $arDates                  = array_merge($arDates, $location['UF_DATE_TIME']);
        if (count($location['UF_DATE_TIME']) < 1) $errors[] = "Не заполнено поле «" . $fieldsTitles['UF_DATE_TIME']['ERROR_MESSAGE'] . "»";
        if ((int)$location['UF_DURATION'] < 1) $errors[] = "Не заполнено поле «" . $fieldsTitles['UF_DURATION']['ERROR_MESSAGE'] . "»";

        if ($resEvent['UF_TYPE'] == 6 || $resEvent['UF_TYPE'] == 8) {
            //ДЛЯ “ОНЛАЙН” И “ОФЛАЙН И ОНЛАЙН” обязательна ссылка на трансляцию
            $link = json_decode($location['UF_LINK'][0], true);
            if (strlen($link[0]) < 1) $errors[] = "Не заполнено поле «Название ссылки»";

            if (!preg_match("/^(http:\/\/|https:\/\/)*[а-яА-ЯёЁa-z0-9\-_]+(\.[а-яА-ЯёЁa-z0-9\-_]+)+(\/\S*)*$/iu", stripslashes($link[1]))) $errors[] = "Неправильная ссылка на трансляцию";
        }
        if ($resEvent['UF_TYPE'] == 7 || $resEvent['UF_TYPE'] == 8) {
            //ТОЛЬКО ДЛЯ “ОФЛАЙН” или “ОФЛАЙН И ОНЛАЙН” мероприятий - Локация и помещение
            if (strlen($location['UF_ADDRESS']) < 1) $errors[] = "Не заполнено поле «" . $fieldsTitles['UF_ADDRESS']['ERROR_MESSAGE'] . "»";
            //if (strlen($location['UF_ROOM']) < 1) $errors[] = "Не заполнено поле «" . $fieldsTitles['UF_ROOM']['ERROR_MESSAGE'] . "»";
        }
    }

    $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
    $query         = new ORM\Query\Query($productEntity);
    $elementEntity = \Bitrix\Iblock\IblockTable::compileEntity('ticketsOffers');
    $propField     = $elementEntity->getField('CML2_LINK');
    $propEntity    = $propField->getRefEntity();

    $resProduct = $query
        ->setSelect(
            ['SKU_ID'           => 'OFFER.ID',
                'SKU_NAME'         => 'OFFER.NAME',
                'SKU_MAX_QUANTITY' => 'OFFER.MAX_QUANTITY.VALUE',
                'SKU_RESERVE_TIME' => 'OFFER.RESERVE_TIME.VALUE',
                'SKU_TYPE'         => 'OFFER.TYPE.VALUE',
                'SKU_QUANTITY'     => 'PROPS.QUANTITY',
                'SKU_PRICE'        => 'PRICE.PRICE',
                'SKU_DATES',
                'SKU_DATES_ALL'    => 'OFFER.DATES_ALL.VALUE',
            ]
        )
        ->setFilter(['EVENT_ID.VALUE' => $arParams['ELEMENT_ID']])
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ReferenceField(
                'TICKETS',
                $propEntity,
                ['this.ID' => 'ref.VALUE'],
                ['join_type' => 'LEFT'],
            )
        )
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ReferenceField(
                'OFFER',
                $elementEntity,
                ['this.TICKETS.IBLOCK_ELEMENT_ID' => 'ref.ID'],
                ['join_type' => 'LEFT'],
            )
        )
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ReferenceField(
                'PROPS',
                '\Bitrix\Catalog\ProductTable',
                ['this.OFFER.ID' => 'ref.ID'],
                ['join_type' => 'LEFT'],
            )
        )
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ReferenceField(
                'PRICE',
                '\Bitrix\Catalog\PriceTable',
                ['this.OFFER.ID' => 'ref.PRODUCT_ID'],
                ['join_type' => 'LEFT'],
            )
        )
        ->registerRuntimeField(
            new \Bitrix\Main\Entity\ExpressionField(
                'SKU_DATES',
                "GROUP_CONCAT(%s SEPARATOR ';')",
                ['OFFER.DATES.VALUE']
            )
        )
        ->setGroup(['SKU_ID'])
        ->countTotal(true)
        ->exec();

    if ($resProduct->getCount() <= 0) $errors[] = 'Не задано ни одного типа билетов';
    $skuSum = 0;
    while ($offer = $resProduct->fetch()) {
        $skuSum             += $offer['SKU_PRICE'];
        $offer['SKU_DATES'] = !empty($offer['SKU_DATES']) ? explode(';', $offer['SKU_DATES']) : [];

        if (count($arDates) > 1 && empty($offer['SKU_DATES_ALL']) && count($offer['SKU_DATES']) < 1) {
            $errors[] = "{$offer['SKU_TYPE']} не задано поле «Даты мероприятия»";
        }

        if ((int)$offer['SKU_QUANTITY'] < 1) $errors[] = "Не задано «Количество» для типа билета «{$offer['SKU_TYPE']}»";
    }

    if ($skuSum > 0 && !contract_is_signed($companyID)) {
        $errors[] = 'Договор не подписан';
    }

    if (count($errors) > 0) {
        echo json_encode(['status' => 'error', 'errors' => $errors], JSON_UNESCAPED_UNICODE);
        die;
    }
}

function sendToModeration($arParams)
{
    $hlblock  = HL\HighloadBlockTable::getById($arParams["HLDB_EVENTS_ID"])->fetch();
    $entity   = HL\HighloadBlockTable::compileEntity($hlblock);
    $hlbClass = $entity->getDataClass();

    $hlbClass::update($arParams['ELEMENT_ID'], ['UF_STATUS' => 1]);
}

function getTicketIdByEventId($eventId)
{
    $productEntity = \Bitrix\Iblock\IblockTable::compileEntity('tickets');
    $query         = new ORM\Query\Query($productEntity);
    $resProduct    = $query
        ->setSelect(['ID', 'EVENT_ID.VALUE'])
        ->setFilter(['EVENT_ID.VALUE' => $eventId])
        ->exec();
    if($objProduct = $resProduct->fetchObject())
        return $objProduct->getId();
    return null;
}