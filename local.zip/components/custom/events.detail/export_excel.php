<? //use Bitrix\Main\Loader;
use Bitrix\Main\ORM;
use Custom\Core\ExportExcel;

//
//global $USER;
//Loader::includeModule('custom.core');
//Loader::includeModule('highloadblock');
//Loader::includeModule('iblock');
//Loader::includeModule('sale');
$companyID  = (int)$_SESSION['CURRENT_USER_PROFILE']['UF_COMPANY_ID'];
$arrColumns = [
    '_number' => ['name' => 'Номер заказа'],
    '_status' => ['name' => 'Статус заказа'],
    '_sum'    => ['name' => 'Сумма заказа'],
    '_name'   => ['name' => 'Ф.И.О.'],
    '_phone'  => ['name' => 'Телефон'],
    '_email'  => ['name' => 'Email'],
];

$eventEntity = new ORM\Query\Query('Custom\Core\Events\EventsTable');
$query       = $eventEntity
    ->setSelect(['UF_NAME'])
    ->setFilter(
        [
            'ID'            => (int)$arParams['ELEMENT_ID'],
            'UF_COMPANY_ID' => $companyID
        ]
    )
    ->setGroup('ID')
    ->countTotal(true)
    ->exec();
if ($query->getCount() < 1) throw new Exception('Event not found');

$event = $query->fetch();

$questionnaireEntity = new ORM\Query\Query('Custom\Core\Events\EventsQuestionnaireTable');
$query               = $questionnaireEntity
    ->setSelect(
        [
            'ID',
            'ACCOUNT_NUMBER'          => 'ORDER.ACCOUNT_NUMBER',
            'STATUS_ID'               => 'ORDER.STATUS_ID',
            'STATUS_NAME'             => 'STATUS.NAME',
            'PRICE'                   => 'ORDER.PRICE',
            'UF_QUESTIONNAIRE_FIELDS' => 'EVENT.UF_QUESTIONNAIRE_FIELDS',
            'UF_FULL_NAME',
            'UF_PHONE',
            'UF_EMAIL',
            'UF_USER_DATA',
            'UF_ORDER_ID',
        ]
    )
    ->setFilter(
        [
            'UF_EVENT_ID' => (int)$arParams['ELEMENT_ID'],
            'STATUS.LID'  => 'ru'
        ]
    )
    ->registerRuntimeField(
        new \Bitrix\Main\Entity\ReferenceField(
            'EVENT',
            'Custom\Core\Events\EventsTable',
            ['this.UF_EVENT_ID' => 'ref.ID'],
            ['join_type' => 'left']
        )
    )
    ->registerRuntimeField(
        new \Bitrix\Main\Entity\ReferenceField(
            'REF_ORDER_PROPS',
            'Bitrix\Sale\Internals\OrderPropsValueTable',
            ['=this.ID' => 'ref.VALUE'],
            ['join_type' => 'left']
        ),
    )
    ->registerRuntimeField(
        new \Bitrix\Main\Entity\ReferenceField(
            'ORDER',
            'Bitrix\Sale\OrderTable',
            ['=this.UF_ORDER_ID' => 'ref.ID'],
            ['join_type' => 'left']
        ),
    )
    ->registerRuntimeField(
        new \Bitrix\Main\Entity\ReferenceField(
            'STATUS',
            'Bitrix\Sale\Internals\StatusLangTable',
            ['=this.STATUS_ID' => 'ref.STATUS_ID'],
            ['join_type' => 'inner']
        ),
    )
    ->setGroup(['ID'])
    ->countTotal(true)
    ->exec();
if ($query->getCount() < 1) throw new Exception('Questionnaire not found');
$obExport = new ExportExcel();
$obExport->setFileName("Анкеты покупателей по мероприятию [" . $event['UF_NAME'] . "].xlsx");
$date = new DateTime();
$date = $date->format('d.m.Y');
$obExport->setFilePath($_SERVER['DOCUMENT_ROOT'] . '/upload/tmp');
$xls = $obExport->createFile();
$xls->getProperties()->setTitle("Тестовый файл");
$xls->getProperties()->setCreated($date);
$xls->setActiveSheetIndex(0);
$sheet = $xls->getActiveSheet();
$sheet->setTitle('Отчет');
$sheet->getRowDimension("1")->setRowHeight(50);
$sheet->getRowDimension("2")->setRowHeight(30);
$sheet->getRowDimension("3")->setRowHeight(40);
$sheet->setCellValue("A1", "Анкеты покупателей по мероприятию [" . $event['UF_NAME'] . "]");
$sheet->mergeCells("A1:H1");
$sheet->getStyle("A1")->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$sheet->getStyle("A1")->getFont()->setSize(22);
$sheet->getStyle("A1")->getFont()->setBold(true);

$i            = 0;
$rowNum       = 4;
$columnsCount = 0;
$arTable      = [];
while ($row = $query->fetch()) {
    $colHead = array_merge($arrColumns, $row['UF_QUESTIONNAIRE_FIELDS'] ?? []);
    if ($i == 0) {
        $arTable['HEAD'] = array_values($colHead);
    }

    foreach ($colHead as $key => &$col) {
        if ($key == '_number') $col['value'] = $row['ACCOUNT_NUMBER'];
        elseif ($key == '_status') $col['value'] = $row['STATUS_NAME'];
        elseif ($key == '_sum') $col['value'] = $row['PRICE'];
        elseif ($key == '_name') $col['value'] = $row['UF_FULL_NAME'];
        elseif ($key == '_phone') $col['value'] = $row['UF_PHONE'];
        elseif ($key == '_email') $col['value'] = $row['UF_EMAIL'];
        elseif (is_array($row['UF_USER_DATA']) && key_exists($key, $row['UF_USER_DATA'])) {

            if ($row['UF_QUESTIONNAIRE_FIELDS'][$key]['type'] == 'boolean')
                $col['value'] = $row['UF_USER_DATA'][$key] ? 'Да' : 'Нет';
            elseif ($row['UF_QUESTIONNAIRE_FIELDS'][$key]['type'] == 'm_list')
                $col['value'] = implode(', ', is_array($row['UF_USER_DATA'][$key]) ? $row['UF_USER_DATA'][$key] : []);
            elseif ($row['UF_QUESTIONNAIRE_FIELDS'][$key]['type'] == 'file') {
                $arFiles = [];
                foreach ($row['UF_USER_DATA'][$key] as $fileID)
                    $arFiles[] = "https://" . COption::GetOptionString("main", "server_name") . '/admin_panel/events/?file=' . $fileID;
                if (count($arFiles) > 0) $col['value'] = implode(PHP_EOL, $arFiles);
                else $col['value'] = '';
            } else
                $col['value'] = $row['UF_USER_DATA'][$key];
        }
    }

    $arTable['BODY'][] = $colHead;
}
foreach ($arTable['HEAD'] as $key => $headItem) {
    $colLetter = $obExport->getColumnLetter($key + 1);
    $sheet->setCellValue($colLetter . '3', $headItem['name'] ?? '');
    $sheet->getStyle($colLetter . '3')->getFont()->setSize(14);
    $sheet->getStyle($colLetter . '3')->getFont()->setBold(true);
    $sheet->getStyle($colLetter . '3')->getFont()->setItalic(true);
    $sheet->getStyle($colLetter . '3')->applyFromArray(
        [
            'fill' => [
                'type'  => PHPExcel_Style_Fill::FILL_SOLID,
                'color' => ['rgb' => 'e4efdc']
            ]
        ]
    );
    $sheet->getStyle($colLetter . '3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle($colLetter . '3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
unset($key, $row, $i);
foreach ($arTable['BODY'] as $key => $row) {
    $i = 0;
    foreach ($row as $keyCol => $colID) {
        $indexCol  = $i + 1;
        $colLetter = $obExport->getColumnLetter($indexCol);
        if (strlen(strip_tags(is_string($colID['value']) ? $colID['value'] : '')) > 300) {
            $sheet->getColumnDimension($colLetter)->setAutoSize(false);
            $sheet->getColumnDimension($colLetter)->setWidth(150);
        }
        $sheet->setCellValue($colLetter . $rowNum, strip_tags(is_array($colID['value']) ? implode(', ', $colID['value']) : $colID['value']));
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setWrapText(true);
        $sheet->getStyle($colLetter . $rowNum)->getFont()->setSize(14);
        $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        if ($keyCol == '_status') {
            $styleStatus = $obExport->getStatusStyle(strip_tags($colID['value']));
            $sheet->getStyle($colLetter . $rowNum)->applyFromArray(
                [
                    'fill' => [
                        'type'  => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => ['rgb' => $styleStatus['background']]
                    ]
                ]
            );
            $sheet->getStyle($colLetter . $rowNum)->getFont()->getColor()->setRGB($styleStatus['color']);
            $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle($colLetter . $rowNum)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
        }
        $i++;
    }
    $rowNum++;
}
$endColLetter = $obExport->getColumnLetter(count($arTable['HEAD']));
$sheet->getStyle("A3:" . $endColLetter . ($rowNum - 1))->applyFromArray($obExport->getBorderStyle());
$obExport->downloadFile($xls);

exit;
