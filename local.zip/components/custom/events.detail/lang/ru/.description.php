<?
$MESS ['HLB_EVENTS_DETAIL'] = "Форма события";
$MESS ['HLB_EVENTS_DETAIL_DESC'] = "Показывает форму для создания/редактирования";
$MESS ['C_HLDB_CAT_EVENTS'] = "События";
?>