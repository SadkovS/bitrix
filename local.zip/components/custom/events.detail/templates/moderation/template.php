<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Page\Asset;

Loader::includeModule('custom.core');
?>
<div class="mx-auto">
	<div class="create-event moderator-event" id="create-event">
		<div class="create-event__content">
			<div class="create-event__body grey__body">
				<div class="row mb-5">
					<div class="col-8">
						<div class="poster__form">
							<div class="admin-form__item big">
								<label>Название</label>
								<span class="form__underline-input"><?= $arResult['EVENT']['UF_NAME'] ?></span>
								<small>Максимальная длина названия — 240 символов</small>
							</div>
							<div class="row gy-4">
								<div class="col-10">
									<div class="upload">
										<a href="https://<?= COption::GetOptionString("main", "server_name") . $arResult['EVENT']['IMG_SRC'] ?>" target="_blank" class="upload__icon upload-ibg_contain">
						<? if (!empty($arResult['EVENT']['IMG_SRC'])): ?>
													<img src="https://<?= COption::GetOptionString("main", "server_name") . $arResult['EVENT']['IMG_SRC'] ?>">
						<? endif; ?>
										</a>
										<div class="upload__info">
											<p>Афиша события <span class="star-required color__red me-1">*</span></p>
											<small>Рекомендуемое соотношение сторон изображения — 16:9<br> Поддерживаются JPEG, JPG и PNG
												<br> Перетащите файл на рамку или нажмите для обзора </small>
										</div>
									</div>
								</div>

								<div class="col-10">
									<div class="row">
										<div class="col-6">

											<div class="form-item">
												<label class="form-item__label">Категория мероприятия
													<span class="star-required color__red me-1">*</span></label>
												<div class="form-select borderless">
													<div class="form-select__selected-option cursor-auto"><?= $arResult['EVENT']['UF_CATEGORY'] ? $arResult['CATEGORY_LIST'][$arResult['EVENT']['UF_CATEGORY']]['UF_NAME'] : 'Выберите из списка' ?>
													</div>
												</div>
											</div>
										</div>
										<div class="col-6">

											<div class="form-item">
												<label class="form-item__label">Тип мероприятия
													<span class="star-required color__red me-1">*</span></label>
												<div class="form-select borderless">
													<div class="form-select__selected-option cursor-auto"><?= $arResult['EVENT']['UF_TYPE'] ? $arResult['TYPE_LIST'][$arResult['EVENT']['UF_TYPE']]['UF_NAME'] : 'Выберите из списка' ?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-10">
									<div class="form-item">
										<label class="form-item__label">Возрастное ограничение
											<span class="star-required color__red me-1">*</span></label>
										<div class="age__list">
						<? foreach ($arResult['AGE_LIMIT_LIST'] as $limit): ?>
													<label class="age__item cursor-auto">
														<input disabled type="radio" name="UF_AGE_LIMIT" <?= $arResult['EVENT']['UF_AGE_LIMIT'] != $limit['ID'] ?: 'checked' ?>
														       value="<?= $limit['ID'] ?>">
														<i class="icon-<?= str_replace('+', '', $limit['UF_NAME']) ?>"></i>
													</label>
						<? endforeach; ?>
										</div>
									</div>
								</div>
								<div class="col-10">
									<div class="form-item">
										<label class="form-item__label">Описание <span class="star-required color__red me-1">*</span>
										</label>
										<div class="form-item__textarea">
											<div><?= $arResult['EVENT']['UF_DESCRIPTION'] ?></div>
										</div>
									</div>
								</div>

								<div class="col-10">
									<label class="form-item__label form-item__label--margin">Галерея</label>
									<div class="js-file <?= !empty($arResult['EVENT']['UF_FILES']) ? 'has-file' : '' ?>">
										<label class="upload-btn cursor-auto">

											<div class="file-list js-file-list">
						  <? foreach ($arResult['EVENT']['UF_FILES'] as $file): ?>
														<a href="<?= $file['FILE_PATH'] ?>" target="_blank" class="file-list__itm js-exist">
															<div class="file-item">
																<img class="preview-image" src="<?= $file['FILE_PATH'] ?>">
															</div>
														</a>
						  <? endforeach; ?>
											</div>

											<div class="upload-btn-desc">
												Нажмите для выбора или перетащите картинку в рамку. Максимальное количество — 10 фотографий.<br> Можно настроить порядок фотографий.<br> Рекомендуемый размер изображения — 512 х 512 пикселей, не более 3 МБ.<br> Поддерживаются форматы PNG, JPG, JPEG, WEBP, HEIC.
											</div>

										</label>


										<!--	Это шаблон для копирования, его не удалять	-->
										<template class="js-file-template">
											<div class="draggable__item">
												<div class="file-item">
													<img class="preview-image" src="">
												</div>
											</div>
										</template>

									</div>

								</div>

							</div>

						</div>
					</div>
				</div>
				<div class="poster__form mb-5">
					<div class="event-place__body">
						<div class="events-date__list" data-event-date-list>
				<? $i = 0; ?>
				<? foreach ($arResult['EVENT_LOCATION']['ITEMS'] as $location): ?><? $address = htmlspecialchars(stripslashes($location['LOCATION_INFO']['UF_ADDRESS'])) ?>
									<div class="grey__body events-date__item mb-3 <?= $location['CHECKED'] ? '' : 'open'; ?>" data-location-id="<?= $location['LOCATION_ID'] ?>">
										<div class="d-flex  align-items-center">

											<h4 class="h4"><?= $location['EVENT_DATE']['DATE_PRESENTATION'] ?></h4>

											<label class="form-switch mx-2 cursor-auto events-date__switch"></label>

											<small class="events-date__switch-text">
						  <? if (isset($location['INHERIT_TEXT'])): ?>
							  <?= $location['INHERIT_TEXT'] ?><? endif; ?>
											</small>
										</div>
										<div class="row g-3 mt-3" data-event-repeat-body>
											<div class="col-12">
												<div class="row" data-event-time-row>
													<div class="col-5">
														<div class="events__select-block">
															<div class="events__form-item required">
																<label class="form-item__label">Начало
																	<span class="star-required color__red me-1">*</span></label>
																<div class="input__time" style="background-color: #fff;"><?= $location['EVENT_DATE']['TIME'] ?></div>
															</div>
															<div class="events__form-item required">
																<label class="form-item__label">Окончание
																	<span class="star-required color__red me-1">*</span></label>
																<div class="input__time" style="background-color: #fff;"><?= $location['EVENT_DATE']['TIME_END'] ?></div>
															</div>
														</div>
													</div>

													<div class="col-3">
														<div class="form-item required">
															<label class="form-item__label">Длительность, мин.
																<span class="star-required color__red me-1">*</span></label>
															<div class="form__underline-input"><?= $location['LOCATION_INFO']['UF_DURATION'] ?></div>
														</div>
													</div>
												</div>
											</div>
						<? if ($arResult['EVENT']['UF_TYPE'] == 7 || $arResult['EVENT']['UF_TYPE'] == 8): ?>
													<div class="col-5">
														<div class="form-item required">
															<label class="form-item__label">Локация
																<span class="star-required color__red me-1">*</span></label>
															<!-- <span class="form__error"></span> -->
															<div class="form-select js-form-select borderless">
																<div class="form-select__selected-option cursor-auto"><?= $address ?></div>
															</div>
														</div>
													</div>
													<div class="col-5">
														<div class="form-item">
															<label class="form-item__label">Помещение</label>
															<!-- <span class="form__error"></span> -->

															<div class="form-select js-form-select borderless">
																<div class="form-select__selected-option cursor-auto"><?= $location['LOCATION_INFO']['UF_ROOM'] ?></div>
															</div>
														</div>
													</div>
						<? endif; ?>
						<? if ($arResult['EVENT']['UF_TYPE'] == 6 || $arResult['EVENT']['UF_TYPE'] == 8): ?>
													<div class="col-12" data-input-link>
														<div class="row">
															<div class="col-12">
																<label class="form-item__label">Ссылка
																	<span class="star-required color__red me-1">*</span></label>
															</div>
															<div class="col-5">
																<div class="form-item  required">
																	<label class="form-item__label" hidden="hidden">Название ссылки</label>
																	<!-- <span class="form__error"></span> -->
																	<div class="form__underline-input"><?= $location['LOCATION_INFO']['UF_LINK'][0][0] ?></div>
																	<small>Название ссылки, например «Трансляция»</small>
																</div>
															</div>
															<div class="col-5">
																<div class="form-item required">
																	<label class="form-item__label" hidden="hidden">Ссылка</label>
																	<!-- <span class="form__error"></span> -->
																	<div class="form__underline-input"><?= $location['LOCATION_INFO']['UF_LINK'][0][1] ?></div>
																	<small>Укажите саму ссылку. http://..., https://...</small>
																</div>
															</div>
															<div class="col-2 control__links">
																<div class="clue__box">
																	<div class="" data-clue="">
																		<button class="btn__icon" data-input-link-to="" type="button">
																			<i class="_icon-link"></i>
																		</button>
																		<span class="clue-body" data-clue-body="" data-popper-placement="top">
																														Перейти по ссылке
																														<span data-popper-arrow=""></span>
																													</span>
																	</div>
																</div>
															</div>
														</div>
													</div>
						<? endif; ?>
										</div>
									</div>
					<? $i++; ?><? endforeach; ?>
						</div>
					</div>
				</div>

                <?php if (isset($arResult['SeatMap'])): ?>
                    <div class="row mb-5">
                        <div class="position-relative">
                            <script src="<?= Option::get('custom.core', 'SEAT_MAP_BOOKING_API_Host'); ?>/static/seatmap-booking-renderer.js"></script>
                            <script>
                                const seatMapSettings = {
                                    publicKey: '<?= $arResult['SeatMap']['publicKey'] ?>',
                                    baseUrl: '<?= $arResult['SeatMap']['bookingUrl'] ?>',
                                    eventId: '<?= $arResult['SeatMap']['eventId'] ?>',
                                };
                                document.addEventListener("DOMContentLoaded", () => {
                                    console.log('seatmap loaded');
                                    const el = document.getElementById('seatmap-schema');
                                    if (!el) {
                                        return;
                                    }
                                    seatmapRenderer = new SeatmapBookingRenderer(el, {
                                        publicKey: seatMapSettings.publicKey,
                                        baseUrl: seatMapSettings.baseUrl,
                                        height: 500,
                                    });
                                    seatmapRenderer.loadEvent(seatMapSettings.eventId);
                                });
                            </script>
                            <div id="seatmap-schema"></div>
                            <div class="seatmap-zoom-button-list">
                                <div class="seatmap-zoom-button" onclick="seatmapRenderer.zoomIn()">+</div>
                                <div class="seatmap-zoom-button" onclick="seatmapRenderer.zoomOut()">–</div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

				<div class="price__abs mb-5">
					<div data-tabs class="price grey__body p-0">
						<nav data-tabs-titles="async" class="price__navigation">
							<button type="button" class="price__title tab-active">Типы билетов</button>
							<button type="button" class="price__title">Промокоды</button>
							<button type="button" class="price__title">Группы промокодов</button>
							<button type="button" class="price__title ">Скидка</button>
						</nav>

						<div data-tabs-body class="price__content">
							<div class="price__body">

								<div class="adminpanel__header-item-title justify-content-between">
									<!--h3><?= \Custom\Core\Helper::getFormatDate($arResult['EVENT_LOCATION']['UF_DATE_TIME']['DATE']) . ' ' . $arResult['EVENT_LOCATION']['UF_DATE_TIME']['TIME'] ?></h3-->
								</div>

								<div class="scroll__table-x">
									<table class="price__table">
										<thead>
										<tr>
											<th>
												<div class="price__table-item">
													<div class="clue__box">
														<p class="me-1">Название / Тип билета <span class="star-required color__red me-1">*</span>
														</p>
														<div class="clue" data-clue="">
															<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
															<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																											Наименование категории билета, например “Партер” или “Входной на все дни”
																											<span data-popper-arrow=""></span>
																									</span>
														</div>
													</div>
												</div>
											</th>

											<th>
												<div class="price__table-item">
													<div class="clue__box">
														<p class="me-1">Количество, шт <span class="star-required color__red me-1">*</span></p>
														<div class="clue" data-clue="">
															<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
															<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																											Общее количество билетов данной категории
																											<span data-popper-arrow=""></span>
																									</span>
														</div>
													</div>
												</div>
											</th>
											<th>
												<div class="price__table-item">
													<div class="clue__box">
														<p class="me-1">Max в заказе, шт <span class="star-required color__red me-1">*</span></p>
														<div class="clue" data-clue="">
															<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
															<div class="clue-body" data-clue-body="" data-popper-placement="bottom">
																Максимальное количество билетов этой категории, доступное для приобретения одним покупателем в рамках одного заказа.
																<span data-popper-arrow=""></span>
															</div>
														</div>
													</div>
											</th>
						<? //todo временно скрыто
						/*<th>
														<div class="price__table-item">
															<div class="clue__box">
																<p class="me-1">Время резерва, мин <span class="star-required color__red me-1">*</span></p>
																<div class="clue" data-clue="">
																	<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
																	<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																			Время, в течение которого забронированные билеты будут удерживаться за покупателем (в минутах)
																			<span data-popper-arrow=""></span>
																	</span>
																</div>
															</div>
														</div>
													</th>*/ ?>
											<th>
												<div class="price__table-item">
													<div class="clue__box">
														<p class="me-1">Цена, ₽ <span class="star-required color__red me-1">*</span></p>
														<div class="clue" data-clue="">
															<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
															<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																											Стоимость данной категории билета
																											<span data-popper-arrow=""></span>
																									</span>
														</div>
													</div>
												</div>
											</th>
											<th data-show-event-type="8">
												<div class="price__table-item">
													<div class="clue__box">
														<p class="me-1">Тип участия <span class="star-required color__red me-1">*</span></p>
														<div class="clue" data-clue="">
															<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
															<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																												Укажите распространяется ли этот тип билета только на онлайн, на онлайн и офлайн или только на офлайн
																												<span data-popper-arrow=""></span>
																											</span>
														</div>
													</div>
												</div>
											</th>
						<? if ($arResult['EVENT_LOCATION']['ITEMS'] && count($arResult['EVENT_LOCATION']['ITEMS']) > 1): ?>
													<th>
														<div class="price__table-item">
															<div class="clue__box">
																<p class="me-1">Даты мероприятия <span class="star-required color__red me-1">*</span>
																</p>
																<div class="clue" data-clue="">
																	<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
																	<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																												Даты, на которые будет действителен данный тип билета. Обратите внимание: если вы планируете выпускать билеты только на одну конкретную дату, необходимо создать отдельный тип билета для каждой из дат.
																												<span data-popper-arrow=""></span>
																											</span>
																</div>
															</div>
														</div>
													</th>
						<? endif; ?>
											<th>
												<div class="price__table-item text-start">
													<div class="clue__box">
														<p class="me-1">Действие категории по времени</p>
														<div class="clue" data-clue="">
															<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
															<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																											Укажите временной интервал, в течение которого данная категория билетов будет доступна для продажи
																											<span data-popper-arrow=""></span>
																									</span>
														</div>
													</div>
												</div>
											</th>
											<th>
												<div class="price__table-item">
													<div class="clue__box">
														<p class="me-1">Описание</p>
														<div class="clue" data-clue="">
															<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
															<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																											Описание типа билетов, будет отображаться при покупке билета и на билете
																											<span data-popper-arrow=""></span>
																									</span>
														</div>
													</div>
												</div>
											</th>
											<th></th>
										</tr>
										</thead>
										<tbody>
					<? if (is_array($arResult['TICKETS']) && count($arResult['TICKETS']) > 0): ?>
					<? foreach ($arResult['TICKETS'] as $ticket): ?>
					<? $isSkuIsCreatedSeatMap = isset($ticket['SKU_IS_CREATED_SEAT_MAP']) && $ticket['SKU_IS_CREATED_SEAT_MAP']; ?>

										<tr>
											<td>
												<div class="price__table-item<?= $isSkuIsCreatedSeatMap ? ' disabled-td tooltip-hover' : ' required'; ?>">
													<div class="tooltip-hover-popup">
														<div class="tooltip-hover-popup__content">Данное значение можно изменить только в редактировании схемы зала
														</div>
													</div>
													<label class="form-item__label" hidden="hidden">Название / Тип билета</label>
													<div><?= $ticket['SKU_TYPE'] ?></div>
												</div>
											</td>
											<td>
												<div class="price__table-item <?= $isSkuIsCreatedSeatMap ? ' disabled-td tooltip-hover' : ' required'; ?>">
													<div class="tooltip-hover-popup">
														<div class="tooltip-hover-popup__content">Данное значение можно изменить только в редактировании схемы зала
														</div>
													</div>
													<label class="form-item__label" hidden="hidden">Количество</label>
													<div><?= (int)$ticket['SKU_TOTAL_QUANTITY'] ?: (int)$ticket['SKU_TOTAL_QUANTITY'] ?></div>
												</div>
											</td>
											<td>
												<div class="price__table-item required">
													<label class="form-item__label" hidden="hidden">Max в заказе</label>
													<div class="med"><?= !$ticket['SKU_MAX_QUANTITY'] ?: (int)$ticket['SKU_MAX_QUANTITY'] ?></div>
												</div>
											</td>
						<? //todo временно скрыто
						/*
			  <td>
				  <div class="price__table-item required">
																			  <label class="form-item__label" hidden="hidden">Время резерва</label>
					  <input name="tickets[<?= $ticket['SKU_ID'] ?>][RESERVE_TIME]"
							 type="text"
							 value="<?= !$ticket['SKU_RESERVE_TIME'] ?: (int)$ticket['SKU_RESERVE_TIME'] ?>"
							 class="lg"
							 placeholder="Время резерва"
							 data-filter-number>
				  </div>
			  </td>*/ ?>
											<td>
												<div class="price__table-item <?= $isSkuIsCreatedSeatMap ? ' disabled-td tooltip-hover' : ' required'; ?>">
													<div class="tooltip-hover-popup">
														<div class="tooltip-hover-popup__content">Данное значение можно изменить только в редактировании схемы зала
														</div>
													</div>
													<label class="form-item__label" hidden="hidden">Цена</label>
													<div><?= !$ticket['SKU_PRICE'] ?: (int)$ticket['SKU_PRICE'] ?></div>
												</div>
											</td>
											<td data-show-event-type="8">
												<div class="price__table-item <?= $isSkuIsCreatedSeatMap ? ' disabled-td tooltip-hover' : ''; ?>">
													<div class="tooltip-hover-popup">
														<div class="tooltip-hover-popup__content">Данное значение можно изменить только в редактировании схемы зала
														</div>
													</div>
													<!--	//todo нужно интегрировать это поле 	-->
													<div>Онлайн</div>
												</div>
											</td>

						<? if ($arResult['EVENT_LOCATION']['ITEMS'] && count($arResult['EVENT_LOCATION']['ITEMS']) > 1): ?>
													<td>
														<div class="price__table-item">
															<div class="form-select__split">

																<div class="promo__list hide-extra" data-ticket-dates-grid>
									<? if ($ticket['SKU_DATES_ALL']): ?>
																			<div class="promo__item">
																				<span>Все</span>
																			</div>
									<? else: ?><? foreach ($ticket['SKU_DATES'] as $keyDate => $date): ?>
																			<div class="promo__item">
													           <span>
	                                    <?= $date ?>
	                                   </span>
																			</div>
									<? endforeach; ?><? endif; ?>
																</div>


																<div class="form-select form-select__group js-form-select <? if ($ticket['SKU_DATES'] && !$ticket['SKU_DATES_ALL'] && count($ticket['SKU_DATES']) > 1) echo "show-counter"; ?>">
																	<div class="form-select__selected-option js-form-select-option js-option-change cursor-auto">
																		<div class="promo__item" data-multyple-select-counter>
																			<span><? if ($ticket['SKU_DATES'] && !$ticket['SKU_DATES_ALL'] && count($ticket['SKU_DATES']) > 1) echo "+" . (count($ticket['SKU_DATES']) - 1); ?></span>
																		</div>
																	</div>
																	<div class="form-select-options-wrap js-form-select-options-wrap">
																		<ul class="form-select-options form-select__options">
																			<li class="form-select-options__item" data-option="all">
																				<p><b>Все</b></p>
																			</li>
										<? foreach ($arResult['EVENT_LOCATION']['ITEMS'] as $item): ?>
																					<li class="form-select-options__item <? if ($ticket['SKU_DATES'] && !$ticket['SKU_DATES_ALL'] && in_array($item['EVENT_DATE']['DATE_SHORT'], $ticket['SKU_DATES'])) echo "_icon-checkbox"; ?>" data-option="<?= $item['EVENT_DATE']['DATE_SHORT'] ?>">
																						<p><?= $item['EVENT_DATE']['DATE_SHORT'] ?></p>
																					</li>
										<? endforeach; ?>
																		</ul>
																	</div>
																</div>
															</div>
														</div>
													</td>
						<? else: ?>
													<input type="hidden" value="all" name="tickets[<?= $ticket['SKU_ID'] ?>][DATES_ALL]">
						<? endif; ?>

											<td>
												<div class="price__table-item">
													<div class="date__split">
														<div class="">
															<span><?= $ticket['SKU_ACTIVE_FROM_YEAR'] ?></span>
															<span></span>
															<span><?= $ticket['SKU_ACTIVE_FROM_TIME'] ?></span>
														</div>
														<span>-</span>
														<div class="">
															<span><?= $ticket['SKU_ACTIVE_TO_YEAR'] ?></span>
															<span></span>
															<span><?= $ticket['SKU_ACTIVE_TO_TIME'] ?></span>
														</div>
													</div>
												</div>
											</td>
											<td>
												<div class="price__table-item">
													<div class="ticket__add-description" data-add-ticket-description>
							  <?= $ticket['SKU_PREVIEW_TEXT'] ?>
													</div>
												</div>
								</div>
								</td>
								<td></td>
								</tr>
				  <? endforeach; ?>
				  <? else: ?>
								<tr>
									<td>
										<div class="price__table-item"></div>
									</td>
									<td>
										<div class="price__table-item"></div>
									</td>
									<td>
										<div class="price__table-item"></div>
									</td>
									<!-- //todo временно скрыто
					<td>
						<div class="price__table-item">
							<input name="tickets[n_0][RESERVE_TIME]" type="text" value=""
								   class="lg"
								   placeholder="Время резерва"
								   data-filter-number>
						</div>
					</td> -->
									<td>
										<div class="price__table-item"></div>
									</td>
									<td data-show-event-type="8">
										<div class="price__table-item"></div>
									</td>
					<? if ($arResult['EVENT_LOCATION']['ITEMS'] && count($arResult['EVENT_LOCATION']['ITEMS']) > 1): ?>
											<td>
												<div class="price__table-item"></div>
											</td>
					<? endif; ?>
									<td>
										<div class="price__table-item"></div>
							</div>
							</td>
							<td>
								<div class="price__table-item"></div>
							</td>
							<td>
								<div class="events__table-controls"></div>
							</td>
							</tr>
				<? endif; ?>
							</tbody>              </table>
						</div>

					</div>
					<div class="price__body promocodes">
			  <? $APPLICATION->IncludeComponent(
				  "custom:price.rules",
				  ".default",
				  [
					  "HLB_COUPONS_ID" => HL_PROMOCODES_ID,
					  "HLB_PRICE_RULES_ID" => HL_PRICE_RULES_ID,
					  "EVENT_TYPES" => $arResult['TICKETS'],
					  "EVENT_ID" => (int)$arParams['ELEMENT_ID'],
					  "ADD_ELEMENT_CHAIN" => "N",
					  "ADD_SECTIONS_CHAIN" => "Y",
					  "AJAX_MODE" => "N",
					  "AJAX_OPTION_ADDITIONAL" => "",
					  "AJAX_OPTION_HISTORY" => "N",
					  "AJAX_OPTION_JUMP" => "N",
					  "AJAX_OPTION_STYLE" => "Y",
					  "BROWSER_TITLE" => "-",
					  "CACHE_FILTER" => "N",
					  "CACHE_GROUPS" => "Y",
					  "CACHE_TIME" => "36000000",
					  "CACHE_TYPE" => "A",
					  "CHECK_DATES" => "Y",
					  "DETAIL_ACTIVE_DATE_FORMAT" => "d.m.Y",
					  "DETAIL_DISPLAY_BOTTOM_PAGER" => "Y",
					  "DETAIL_DISPLAY_TOP_PAGER" => "N",
					  "DETAIL_FIELD_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "DETAIL_PAGER_SHOW_ALL" => "Y",
					  "DETAIL_PAGER_TEMPLATE" => "",
					  "DETAIL_PAGER_TITLE" => "Страница",
					  "DETAIL_PROPERTY_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "DETAIL_SET_CANONICAL_URL" => "N",
					  "DISPLAY_BOTTOM_PAGER" => "Y",
					  "DISPLAY_DATE" => "Y",
					  "DISPLAY_NAME" => "Y",
					  "DISPLAY_PICTURE" => "Y",
					  "DISPLAY_PREVIEW_TEXT" => "Y",
					  "DISPLAY_TOP_PAGER" => "N",
					  "PRICE_RULES_COUNT" => "10",
					  "HIDE_LINK_WHEN_NO_DETAIL" => "N",
					  "LIST_ACTIVE_DATE_FORMAT" => "d.m.Y",
					  "LIST_FIELD_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "LIST_PROPERTY_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "MESSAGE_404" => "",
					  "META_DESCRIPTION" => "-",
					  "META_KEYWORDS" => "-",
					  "PAGER_BASE_LINK_ENABLE" => "N",
					  "PAGER_DESC_NUMBERING" => "N",
					  "PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
					  "PAGER_SHOW_ALL" => "N",
					  "PAGER_SHOW_ALWAYS" => "N",
					  "PAGER_TEMPLATE" => ".default",
					  "PAGER_TITLE" => "События",
					  "PREVIEW_TRUNCATE_LEN" => "",
					  "SEF_MODE" => "Y",
					  "SET_LAST_MODIFIED" => "N",
					  "SET_STATUS_404" => "N",
					  "SET_TITLE" => "Y",
					  "SHOW_404" => "N",
					  "USE_FILTER" => "N",
					  "USE_PERMISSIONS" => "N",
					  "USE_SEARCH" => "N",
					  "USE_SHARE" => "N",
					  "COMPONENT_TEMPLATE" => "promocodes_moderator",
					  "SEF_FOLDER" => "/admin_panel/price_rules/",
					  "SEF_URL_TEMPLATES" => [
						  "list" => "list/",
						  "section" => "list/",
						  "detail" => "#ELEMENT_ID#/",
					  ]
				  ],
				  false
			  ); ?>
					</div>
					<div class="price__body promocodes">
			  <? $APPLICATION->IncludeComponent(
				  "custom:price.rules",
				  ".default",
				  [
					  "HLB_COUPONS_ID" => HL_PROMOCODES_ID,
					  "HLB_PRICE_RULES_ID" => HL_PRICE_RULES_ID,
					  "EVENT_TYPES" => $arResult['TICKETS'],
					  "EVENT_ID" => (int)$arParams['ELEMENT_ID'],
					  "ADD_ELEMENT_CHAIN" => "N",
					  "ADD_SECTIONS_CHAIN" => "Y",
					  "AJAX_MODE" => "N",
					  "AJAX_OPTION_ADDITIONAL" => "",
					  "AJAX_OPTION_HISTORY" => "N",
					  "AJAX_OPTION_JUMP" => "N",
					  "AJAX_OPTION_STYLE" => "Y",
					  "BROWSER_TITLE" => "-",
					  "CACHE_FILTER" => "N",
					  "CACHE_GROUPS" => "Y",
					  "CACHE_TIME" => "36000000",
					  "CACHE_TYPE" => "A",
					  "CHECK_DATES" => "Y",
					  "DETAIL_ACTIVE_DATE_FORMAT" => "d.m.Y",
					  "DETAIL_DISPLAY_BOTTOM_PAGER" => "Y",
					  "DETAIL_DISPLAY_TOP_PAGER" => "N",
					  "DETAIL_FIELD_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "DETAIL_PAGER_SHOW_ALL" => "Y",
					  "DETAIL_PAGER_TEMPLATE" => "",
					  "DETAIL_PAGER_TITLE" => "Страница",
					  "DETAIL_PROPERTY_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "DETAIL_SET_CANONICAL_URL" => "N",
					  "DISPLAY_BOTTOM_PAGER" => "Y",
					  "DISPLAY_DATE" => "Y",
					  "DISPLAY_NAME" => "Y",
					  "DISPLAY_PICTURE" => "Y",
					  "DISPLAY_PREVIEW_TEXT" => "Y",
					  "DISPLAY_TOP_PAGER" => "N",
					  "PRICE_RULES_COUNT" => "10",
					  "HIDE_LINK_WHEN_NO_DETAIL" => "N",
					  "LIST_ACTIVE_DATE_FORMAT" => "d.m.Y",
					  "LIST_FIELD_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "LIST_PROPERTY_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "MESSAGE_404" => "",
					  "META_DESCRIPTION" => "-",
					  "META_KEYWORDS" => "-",
					  "PAGER_BASE_LINK_ENABLE" => "N",
					  "PAGER_DESC_NUMBERING" => "N",
					  "PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
					  "PAGER_SHOW_ALL" => "N",
					  "PAGER_SHOW_ALWAYS" => "N",
					  "PAGER_TEMPLATE" => ".default",
					  "PAGER_TITLE" => "События",
					  "PREVIEW_TRUNCATE_LEN" => "",
					  "SEF_MODE" => "Y",
					  "SET_LAST_MODIFIED" => "N",
					  "SET_STATUS_404" => "N",
					  "SET_TITLE" => "Y",
					  "SHOW_404" => "N",
					  "USE_FILTER" => "N",
					  "USE_PERMISSIONS" => "N",
					  "USE_SEARCH" => "N",
					  "USE_SHARE" => "N",
					  "COMPONENT_TEMPLATE" => "groups_moderator",
					  "SEF_FOLDER" => "/admin_panel/price_rules/",
					  "SEF_URL_TEMPLATES" => [
						  "list" => "list/",
						  "section" => "list/",
						  "detail" => "#ELEMENT_ID#/",
					  ]
				  ],
				  false
			  ); ?>
					</div>
					<div class="price__body promocodes">
			  <? $APPLICATION->IncludeComponent(
				  "custom:price.rules",
				  ".default",
				  [
					  "HLB_COUPONS_ID" => HL_PROMOCODES_ID,
					  "HLB_PRICE_RULES_ID" => HL_PRICE_RULES_ID,
					  "EVENT_TYPES" => $arResult['TICKETS'],
					  "EVENT_ID" => (int)$arParams['ELEMENT_ID'],
					  "ADD_ELEMENT_CHAIN" => "N",
					  "ADD_SECTIONS_CHAIN" => "Y",
					  "AJAX_MODE" => "N",
					  "AJAX_OPTION_ADDITIONAL" => "",
					  "AJAX_OPTION_HISTORY" => "N",
					  "AJAX_OPTION_JUMP" => "N",
					  "AJAX_OPTION_STYLE" => "Y",
					  "BROWSER_TITLE" => "-",
					  "CACHE_FILTER" => "N",
					  "CACHE_GROUPS" => "Y",
					  "CACHE_TIME" => "36000000",
					  "CACHE_TYPE" => "A",
					  "CHECK_DATES" => "Y",
					  "DETAIL_ACTIVE_DATE_FORMAT" => "d.m.Y",
					  "DETAIL_DISPLAY_BOTTOM_PAGER" => "Y",
					  "DETAIL_DISPLAY_TOP_PAGER" => "N",
					  "DETAIL_FIELD_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "DETAIL_PAGER_SHOW_ALL" => "Y",
					  "DETAIL_PAGER_TEMPLATE" => "",
					  "DETAIL_PAGER_TITLE" => "Страница",
					  "DETAIL_PROPERTY_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "DETAIL_SET_CANONICAL_URL" => "N",
					  "DISPLAY_BOTTOM_PAGER" => "Y",
					  "DISPLAY_DATE" => "Y",
					  "DISPLAY_NAME" => "Y",
					  "DISPLAY_PICTURE" => "Y",
					  "DISPLAY_PREVIEW_TEXT" => "Y",
					  "DISPLAY_TOP_PAGER" => "N",
					  "PRICE_RULES_COUNT" => "10",
					  "HIDE_LINK_WHEN_NO_DETAIL" => "N",
					  "LIST_ACTIVE_DATE_FORMAT" => "d.m.Y",
					  "LIST_FIELD_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "LIST_PROPERTY_CODE" => [
						  0 => "",
						  1 => "",
					  ],
					  "MESSAGE_404" => "",
					  "META_DESCRIPTION" => "-",
					  "META_KEYWORDS" => "-",
					  "PAGER_BASE_LINK_ENABLE" => "N",
					  "PAGER_DESC_NUMBERING" => "N",
					  "PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
					  "PAGER_SHOW_ALL" => "N",
					  "PAGER_SHOW_ALWAYS" => "N",
					  "PAGER_TEMPLATE" => ".default",
					  "PAGER_TITLE" => "События",
					  "PREVIEW_TRUNCATE_LEN" => "",
					  "SEF_MODE" => "Y",
					  "SET_LAST_MODIFIED" => "N",
					  "SET_STATUS_404" => "N",
					  "SET_TITLE" => "Y",
					  "SHOW_404" => "N",
					  "USE_FILTER" => "N",
					  "USE_PERMISSIONS" => "N",
					  "USE_SEARCH" => "N",
					  "USE_SHARE" => "N",
					  "COMPONENT_TEMPLATE" => "discounts_moderator",
					  "SEF_FOLDER" => "/admin_panel/price_rules/",
					  "SEF_URL_TEMPLATES" => [
						  "list" => "list/",
						  "section" => "list/",
						  "detail" => "#ELEMENT_ID#/",
					  ]
				  ],
				  false
			  ); ?>
					</div>
				</div>
			</div>
		</div>

		<div class="form-item form-item__switch mb-3">
			<h3 class="h3 clue__box">Анкета посетителя <span class="clue" data-clue="">
          <i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
          <span class="clue-body" data-clue-body="">
            Вы не сможете изменить анкету после совершения первой продажи
            <span data-popper-arrow=""></span>
          </span>
        </span>
			</h3>

			<span class="ms-auto w-fit-content"></span>

			<div class="checkbox blue ms-5 cursor-auto">
				<p>Заполнение анкеты на каждый билет заказа</p>
				<label>
					<input type="checkbox" name="UF_QUESTIONNAIRE_FOREACH_TICKETS"
					       value="1" <?= $arResult['EVENT']['UF_QUESTIONNAIRE_FOREACH_TICKETS'] ? 'checked' : '' ?> disabled>
					<span class="_icon-checkbox"></span>
				</label>
			</div>

		</div>
		<div class="row g-2">
			<div class="col-12">
				<div class="form-item grey__body">
					<label class="form-item__label ">Текст перед анкетой регистрации</label>
					<div class="form__underline-textarea"><?= $arResult['EVENT']['UF_QUESTIONNAIRE_DESCRIPTION'] ?></div>
				</div>
			</div>
			<div class="col-4">
				<div class="form-item grey__body required">
					<label class="form-item__label">ФИО</label>
					<p class="form__underline-input">Ваши Фамилия Имя Отчество</p>
					<small class="form-item__required">Обязательное поле</small>
				</div>
			</div>
			<div class="col-4">
				<div class="form-item grey__body required">
					<label class="form-item__label d-flex justify-content-between align-items-center"><span>Телефон</span>
						<small>Обязательное поле</small></label>
					<p class="form__underline-input">+7</p>

				</div>
			</div>
			<div class="col-4">
				<div class="form-item grey__body required">
					<label class="form-item__label">Почта</label>
					<p class="form__underline-input">@</p>
					<small class="form-item__required">Обязательное поле</small>
				</div>
			</div>

			<div class="col-12">
				<div class="row g-2" data-questionnaire-body>
			<? foreach ($arResult['QUESTIONNAIRE_FIELDS'] as $key => $question): ?><? $pattern = '/^[a-f0-9]{8}\-[a-f0-9]{4}\-[a-f0-9]{4}\-[a-f0-9]{4}\-[a-f0-9]{12}$/'; ?><? if (preg_match($pattern, $key)): ?>

							<div class="col-12 draggable__item">
								<div class="form-item grey__body">
									<span class="form-item__label d-flex justify-content-between align-items-center">
                                                <? if ($question['type'] == 'file'): ?>
	                                                <span class="clue__box">Вопрос - <?= $arResult['QUESTIONNAIRE_FIELD_TYPES'][$question['type']] ?>
                                                 <span class="clue" data-clue="">
                                                  <i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
                                                  <span class="clue-body" data-clue-body="">
                                                   Покупатель сможет загрузить файл до 5 МБ. Доступные форматы: <br> jpg, jpeg, png, pdf, heic, doc, docx, xls, xlsx
                                                    <span data-popper-arrow=""></span>
                                                  </span>
                                                </span>
                                               </span>
                                                <? else: ?>
	                                                <span>Вопрос - <?= $arResult['QUESTIONNAIRE_FIELD_TYPES'][$question['type']] ?></span>
                                                <? endif; ?>

                                                <span class="d-flex align-items-center">
                                                <? if (!$arResult['IS_FILED']): ?>
	                                                <label class="form-switch mx-2 cursor-auto">
                                                        <input type="checkbox" <?= !$question['required'] ? '' : 'checked' ?>
                                               name="Q_FIELDS[<?= $key ?>][required]" value="1" disabled>
                                                        <i class="slider round"></i>
                                                    </label>  <small>Обязательное поле</small>

                                                <? elseif ($arResult['IS_FILED'] && $question['required']): ?>
	                                                <small>Обязательное поле</small>
                                                <? endif; ?>
                                            </span>
                                            </span>
											<div class="form__underline-input"><?= $question['name'] ?></div>
					<?
					if (
						$question['type'] == 'list' ||
						$question['type'] == 'm_list'
					):?>
											<lable class="form-item__label mt-3">Варианты ответа</lable>
						<? if (is_array($question['options']) && count($question['options']) > 0): ?><? foreach ($question['options'] as $optionValue): ?><? if (!$arResult['IS_FILED']): ?>
												<div class="form-item__block mt-1">
													<div class="form__underline-input"><?= $optionValue ?></div>
												</div>
						<? else: ?>
												<span class="form__underline-input mt-1"><?= $optionValue ?></span>
						<? endif; ?>

						<? endforeach; ?>

						<? endif; ?>

					<? endif; ?>
								</div>
							</div>
			<? endif; ?>

			<? endforeach; ?>
				</div>
			</div>

		</div>

	</div>
</div></div></div>
