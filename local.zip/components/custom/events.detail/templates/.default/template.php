<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;

Loader::includeModule('custom.core');
$APPLICATION->RestartBuffer();
$isFilledFull = isset($arResult['STATUS_HISTORY']) && is_array($arResult['STATUS_HISTORY']) && count($arResult['STATUS_HISTORY']) > 1;

$arSteps = [
    [
        'slug'        => 'description',
        'name'        => 'Описание',
        'description' => 'Описание и классификация'
    ],
    [
        'slug'        => 'date-place',
        'name'        => 'Дата, место, время',
        'description' => 'Настройка расписания, адреса и ссылок'
    ],
    [
        'slug'        => 'seatmap',
        'name'        => 'Схема зала',
        'description' => 'Настройка зала, мест и рассадки'
    ],
    [
        'slug'        => 'ticket-type',
        'name'        => 'Типы билетов и скидки',
        'description' => 'Настройка билетов, цен и промокодов'
    ],
    [
        'slug'        => 'anketa',
        'name'        => 'Анкета участника',
        'description' => 'Настройка вида и полей анкеты'
    ],
    [
        'slug'        => 'payment-type',
        'name'        => 'Способы оплаты',
        'description' => 'Выбор способа приема платежей'
    ],
    [
        'slug'        => 'widgets',
        'name'        => 'Виджеты',
        'description' => 'Просто виджеты'
    ],
    [
        'slug'        => 'statement',
        'name'        => $isFilledFull ? 'Размещение' : 'Утверждение',
        'description' => $isFilledFull ? 'Настройки видимости и доступности мероприятия' : 'Отправка на проверку',
    ]
];
?>

<div class="popup__content js-form-validate js-no-tab-select" data-event-id="<?= $arParams['ELEMENT_ID'] ?>">
    <div class="popup__content-top">
        <div class="popup__name h1 text-break"><?= isset($arResult['EVENT']['ID']) && (int)$arResult['EVENT']['ID'] > 0 ? ($arResult['EVENT']['UF_NAME'] ?? 'Имя мероприятия не определено') : 'Новое мероприятие' ?></div>
        <button data-event-close type="button" class="popup__close"><i class="_icon-plus"></i></button>
    </div>
    <div data-tabs class="create-event">
        <input <?=$arResult['DISABLED']?> type="hidden" name="ORDER_EXIST" value="<?= $arResult['ORDER_EXIST'] ?>">
        <nav data-tabs-titles="async" class="create-event__navigation">
            <? foreach ($arSteps as $key => $step):
                $curStep = (int)$arResult['EVENT']['UF_STEP'];
                $btn_class = '';

                if (($curStep < 1 && $key == 0) || ($curStep == $key + 1)) {
                    $btn_class = 'tab-active complete';
                } elseif ($curStep > $key + 1) {
                    $btn_class = 'complete';
                }
                ?>
                <button type="button" class="create-event__title <?= $btn_class ?>" data-id="<?= $step['slug'] ?>">
               <span class="tab-body">
								<i class="tab-number"><?= ($key + 1) ?></i>
								<span class="tab-info">
									<p><?= $step['name'] ?></p>
									<small><?= $step['description'] ?></small>
								</span>
								</span>
                </button>
            <? endforeach; ?>
        </nav>
        <div data-tabs-body class="create-event__content">
            <div class="create-event__body grey__body">
                <div class="row">
                    <div class="col-12 col-lg-8">
                        <form action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=setEvent"
                              enctype="multipart/form-data" class="poster__form">
                            <div class="admin-form__item big required">
                                <label class="form-item__label">Название <span
                                            class="star-required color__red me-1">*</span></label>

                                <span class="form__error"></span>
                                <input <?=$arResult['DISABLED']?> type="text" class="form__underline-input js-format-normal" name="UF_NAME"
                                       data-input-limit="240"
                                       value='<?= $arResult['EVENT']['UF_NAME'] ?>'>
                                <small>Максимальная длина названия — 240 символов</small>
                            </div>
                            <div class="row gy-4">

                                <div class="col-10">
                                    <div class="upload required" data-img-upload>
                                        <input <?=$arResult['DISABLED']?> type="file" class="upload__input" name="UF_IMG" data-file-size="3"
                                               accept=".png, .jpg, .jpeg">
                                        <div class="upload__icon upload-ibg_contain">
                                            <? if (!empty($arResult['EVENT']['IMG_SRC'])): ?>
                                                <img src="<?= $arResult['EVENT']['IMG_SRC'] ?>">
                                            <? endif; ?>
	                                        <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                            <button class="upload__delete" type="button"><i class="_icon-trash2"></i>
                                            </button>
                                            <i class="_icon-upload"></i>
	                                        <?php endif; ?>
                                        </div>
                                        <div class="upload__info">
                                            <p>Афиша события <span class="star-required color__red me-1">*</span></p>
                                            <small>Рекомендуемое соотношение сторон изображения — 16:9<br>
                                                Поддерживаются JPEG, JPG и PNG <br>
                                                Перетащите файл на рамку или нажмите для обзора<br>
                                                <br>
                                                При добавлении и загрузке изображений, Организатор подтверждает, что
                                                обладает всеми исключительными правами и согласиями на его
                                                использование, а также несёт за это полную ответственность.
                                            </small>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-10">
                                    <div class="row">
                                        <div class="col-6">

                                            <div class="form-item  required">
                                                <label class="form-item__label">Категория мероприятия <span
                                                            class="star-required color__red me-1">*</span></label>
                                                <div class="form-select <?=$arResult['DISABLED']?> js-form-select borderless">
                                                    <div class="form-select__selected-option js-form-select-option js-option-change"
                                                         data-placeholder="Выберите из списка"><?= $arResult['EVENT']['UF_CATEGORY'] ? $arResult['CATEGORY_LIST'][$arResult['EVENT']['UF_CATEGORY']]['UF_NAME'] : 'Выберите из списка' ?>
                                                    </div>
                                                    <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                                    <div class="form-select-options-wrap js-form-select-options-wrap">
                                                        <ul class="form-select-options form-select__options">
                                                            <? foreach ($arResult['CATEGORY_LIST'] as $category): ?>
                                                                <li class="form-select-options__item js-form-select-options-item"
                                                                    data-option="<?= $category['ID'] ?>"><?= $category['UF_NAME'] ?>
                                                                </li>
                                                            <? endforeach; ?>
                                                        </ul>
                                                    </div>
                                                    <input <?=$arResult['DISABLED']?> name="UF_CATEGORY" type="hidden"
                                                           value="<?= $arResult['EVENT']['UF_CATEGORY'] ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">

                                            <div class="form-item required">
                                                <label class="form-item__label">Тип мероприятия <span
                                                            class="star-required color__red me-1">*</span></label>
                                                <div class="form-select <?=$arResult['DISABLED']?> js-form-select borderless">
                                                    <div class="form-select__selected-option js-form-select-option js-option-change"
                                                         data-placeholder="Выберите из списка"><?= $arResult['EVENT']['UF_TYPE'] ? $arResult['TYPE_LIST'][$arResult['EVENT']['UF_TYPE']]['UF_NAME'] : 'Выберите из списка' ?>
                                                    </div>
                                                    <i class="form-select__icon js-form-select-icon _icon-chev"></i>
                                                    <div class="form-select-options-wrap js-form-select-options-wrap">
                                                        <ul class="form-select-options form-select__options">
                                                            <? foreach ($arResult['TYPE_LIST'] as $type): ?>
                                                                <li class="form-select-options__item js-form-select-options-item"
                                                                    data-option="<?= $type['ID'] ?>"><?= $type['UF_NAME'] ?>
                                                                </li>
                                                            <? endforeach; ?>
                                                        </ul>
                                                    </div>
                                                    <input <?=$arResult['DISABLED']?> type="hidden" name="UF_TYPE"
                                                           value="<?= $arResult['EVENT']['UF_TYPE'] ?>">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="d-flex mt-3 mb-1">
                                                <label class="form-switch me-3">
                                                    <input <?=$arResult['DISABLED']?> type="checkbox" data-uuid="<?= $arResult['EVENT']['UF_UUID'] ?>"
                                                           name="UF_SIT_MAP" <?= !$arResult['EVENT']['UF_SIT_MAP'] ?: 'checked' ?> <?= !$arParams['ELEMENT_ID'] == 0 ?: '' ?>
                                                           value="1" data-seating-switcher data-dop-question-switch
                                                           class="js-toggle-seatmap-checkbox">
                                                    <i class="slider round"></i>
                                                </label>
                                                <small>Включить карту рассадки</small>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-10">
                                    <div class="form-item required">
                                        <label class="form-item__label">Возрастное ограничение <span
                                                    class="star-required color__red me-1">*</span></label>
                                        <div class="age__list">
                                            <? foreach ($arResult['AGE_LIMIT_LIST'] as $limit): ?>
                                                <label class="age__item">
                                                    <input <?=$arResult['DISABLED']?> type="radio"
                                                           name="UF_AGE_LIMIT" <?= $arResult['EVENT']['UF_AGE_LIMIT'] != $limit['ID'] ?: 'checked' ?>
                                                           value="<?= $limit['ID'] ?>">
                                                    <i class="icon-<?= str_replace('+', '', $limit['UF_NAME']) ?>"></i>
                                                </label>
                                            <? endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-10">
                                    <div class="form-item required">
                                        <label class="form-item__label">Описание <span
                                                    class="star-required color__red me-1">*</span></label>
                                        <div class="form-item__textarea">
	                                        <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                            <div data-text-editor
                                                 data-max-length="10000"><?= $arResult['EVENT']['UF_DESCRIPTION'] ?></div>
                                            <div data-text-editor-toolbar>
                                                <span class="ql-formats">
                                                    <button class="ql-bold"></button>
                                                    <button class="ql-italic"></button>
                                                    <button class="ql-underline"></button>
                                                    <button class="ql-strike"></button>
                                                    <button class="ql-list" value="ordered"></button>
                                                    <button class="ql-list" value="bullet"></button>
	                                                  <button class="ql-link"></button>
                                                    <!--<button type="button" data-attach="file" class="attach">
                                                        <svg width="9" height="18" viewBox="0 0 9 18"
                                                             fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M0 3.375C0 1.51172 1.51172 0 3.375 0C5.23828 0 6.75 1.51172 6.75 3.375V12.375C6.75 13.616 5.74102 14.625 4.5 14.625C3.25898 14.625 2.25 13.616 2.25 12.375V5.0625C2.25 4.75313 2.50312 4.5 2.8125 4.5C3.12188 4.5 3.375 4.75313 3.375 5.0625V12.375C3.375 12.9973 3.87773 13.5 4.5 13.5C5.12227 13.5 5.625 12.9973 5.625 12.375V3.375C5.625 2.13398 4.61602 1.125 3.375 1.125C2.13398 1.125 1.125 2.13398 1.125 3.375V13.5C1.125 15.3633 2.63672 16.875 4.5 16.875C6.36328 16.875 7.875 15.3633 7.875 13.5V5.0625C7.875 4.75313 8.12813 4.5 8.4375 4.5C8.74687 4.5 9 4.75313 9 5.0625V13.5C9 15.9855 6.98555 18 4.5 18C2.01445 18 0 15.9855 0 13.5V3.375Z"
                                                                  fill="#2D4765" fill-opacity="0.5"/>
                                                        </svg>
                                                    </button>-->
                                                </span>
                                                <span class="ql-last ql-formats">
                                                    <button class="fullscreen" type="button"
                                                            data-text-editor-fullscreen
                                                            data-popup-second="#texteditor-fullscreen">
                                                        <svg width="16" height="14" viewBox="0 0 16 14"
                                                             fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M10.5739 0C10.284 0 10.0467 0.225 10.0467 0.5C10.0467 0.775 10.284 1 10.5739 1H13.5198L7.9378 6.29375L2.3558 1H5.30167C5.59165 1 5.8289 0.775 5.8289 0.5C5.8289 0.225 5.59165 0 5.30167 0H1.08387C0.793892 0 0.556641 0.225 0.556641 0.5V4.5C0.556641 4.775 0.793892 5 1.08387 5C1.37384 5 1.61109 4.775 1.61109 4.5V1.70625L7.19309 7L1.61109 12.2937V9.5C1.61109 9.225 1.37384 9 1.08387 9C0.793892 9 0.556641 9.225 0.556641 9.5V13.5C0.556641 13.775 0.793892 14 1.08387 14H5.30167C5.59165 14 5.8289 13.775 5.8289 13.5C5.8289 13.225 5.59165 13 5.30167 13H2.3558L7.9378 7.70625L13.5198 13H10.5739C10.284 13 10.0467 13.225 10.0467 13.5C10.0467 13.775 10.284 14 10.5739 14H14.7917C15.0817 14 15.319 13.775 15.319 13.5V9.5C15.319 9.225 15.0817 9 14.7917 9C14.5018 9 14.2645 9.225 14.2645 9.5V12.2937L8.68251 7L14.2645 1.70625V4.5C14.2645 4.775 14.5018 5 14.7917 5C15.0817 5 15.319 4.775 15.319 4.5V0.5C15.319 0.225 15.0817 0 14.7917 0H10.5739Z"
                                                                  fill="#2D4765" fill-opacity="0.5"/>
                                                        </svg>
                                                    </button>
                                                </span>
                                            </div>
	                                        <?php else: ?>
		                                        <textarea class="form-item__textarea" readonly><?= strip_tags($arResult['EVENT']['UF_DESCRIPTION']) ?></textarea>
	                                        <?php endif; ?>
                                        </div>
                                        <div class="form-item__count">
                                            <span class="js-form-item-count"><?= mb_strlen(strip_tags($arResult['EVENT']['UF_DESCRIPTION']), "UTF-8") ?></span> / 10 000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-10">
                                    <label class="form-item__label form-item__label--margin">Галерея</label>
                                    <div class="js-file <?= !empty($arResult['EVENT']['UF_FILES']) ? 'has-file' : '' ?>">
                                        <label class="upload-btn">
                                            <input <?=$arResult['DISABLED']?> accept=".jpeg, .jpg, .png, .webp, .heic"
                                                   name="UF_FILES[]" multiple type="file" data-max-files="10"
                                                   data-max-size="3"/>

                                            <div class="file-list js-file-list">
                                                <? foreach ($arResult['EVENT']['UF_FILES'] as $file): ?>
                                                    <div class="file-list__itm js-exist">
                                                        <i class="_icon-drag" data-draggable-handler=""></i>
                                                        <div class="file-item">
                                                            <img class="preview-image" src="<?= $file['FILE_PATH'] ?>">
                                                            <span class="delete-btn"
                                                                  data-attached-delete="<?= $file['EXTERNAL_ID'] ?>"></span>
                                                        </div>
                                                        <input <?=$arResult['DISABLED']?> type="hidden" name="FILE_SORT[]"
                                                               value="<?= $file['ID'] ?>">
                                                    </div>
                                                <? endforeach; ?>
                                            </div>

                                            <div class="upload-btn-desc">
                                                Нажмите для выбора или перетащите картинку в рамку. Максимальное
                                                количество — 10 фотографий.<br>
                                                Можно настроить порядок фотографий.<br>
                                                Рекомендуемый размер изображения — 512 х 512 пикселей, не более 3
                                                МБ.<br>
                                                Поддерживаются форматы PNG, JPG, JPEG, WEBP, HEIC.
                                                <br>
                                                <br>
                                                При добавлении и загрузке изображений, Организатор подтверждает, что
                                                обладает всеми исключительными правами и согласиями на его
                                                использование, а также несёт за это полную ответственность.

                                            </div>

                                        </label>


                                        <!--	Это шаблон для копирования, его не удалять	-->
                                        <template class="js-file-template">
                                            <div class="draggable__item">
                                                <i class="_icon-drag" data-draggable-handler=""></i>
                                                <div class="file-item">
                                                    <img class="preview-image" src="">
                                                    <span class="delete-btn"></span>
                                                </div>
                                            </div>
                                        </template>

                                    </div>

                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <div class="create-event__body">
                <form action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=setLocation"
                      class="poster__form">
                    <input <?=$arResult['DISABLED']?> type="hidden" name="EVENT" value="<?= $arResult['EVENT']['ID'] ?>">
                    <div class="event-place__body">
                        <div class="event__time <?=$arResult['DISABLED']?> required">
                            <label class="form-item__label" hidden="hidden">Дата события</label>
                            <input <?=$arResult['DISABLED']?> readonly type="text" data-static-date="1" value="<?= $arResult['EVENT_LOCATION']['DATE'] ?>"
                                   class="d-none"/>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <p class="color__grey"
                                       data-event-calendar-description><?= $arResult['EVENT_LOCATION']['DATE'] ? 'Нажмите, чтобы выбрать дату окончания мероприятия. Если событие однодневное - просто продолжайте заполнять информацию по мероприятию' : 'Нажмите, чтобы выбрать дату начала мероприятия' ?></p>
                                </div>
                                <div class="col-12 d-flex justify-content-between align-items-center mt-3">
	                                <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                    <button class="btn btn__grey-transparent btn__fix-width" type="button"
                                            data-static-date-reset="1"><i class="_icon-cross"></i><span>Сбросить</span>
                                    </button>
                                    <button class="btn btn__blue btn__fix-width " type="button" data-event-date-confirm>
                                        <span>Применить</span></button>
	                                <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <input <?=$arResult['DISABLED']?> type="hidden" name="event_location_data"
                               value='<?= json_encode($arResult['EVENT_LOCATION']['ITEMS'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>'>
                        <div class="events-date__list" data-event-date-list>
                            <? $i = 0; ?>
                            <? foreach ($arResult['EVENT_LOCATION']['ITEMS'] as $location): ?>
                                <? $address = htmlspecialchars(stripslashes($location['LOCATION_INFO']['UF_ADDRESS'])) ?>
                                <div class="grey__body events-date__item mb-3 <?= $location['CHECKED'] ? '' : 'open'; ?>"
                                     data-location-id="<?= $location['LOCATION_ID'] ?>"
                                     data-date-value="<?= $location['EVENT_DATE']['DATE'] ?>">

	                                <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                    <button type="button" class="btn__icon form-item__delete"
                                            data-datepicker-change="1">
                                        <i class="_icon-plus"></i>
                                    </button>
                                    <?php endif; ?>

                                    <div class="d-flex  align-items-center">
                                        <h4 class="h4"><?= $location['EVENT_DATE']['DATE_PRESENTATION'] ?></h4>
                                        <label class="form-switch mx-3 events-date__switch">
                                            <input <?=$arResult['DISABLED']?> type="checkbox"
                                                   data-event-repeat-switcher <?= $location['CHECKED'] && $i > 0 ? 'checked' : ''; ?>>
                                            <i class="slider round"></i>
                                        </label>
                                        <small class="events-date__switch-text">
                                            <? if (isset($location['INHERIT_TEXT'])): ?>
                                                <?= $location['INHERIT_TEXT'] ?>
                                            <? endif; ?>
                                        </small>
                                    </div>
                                    <div class="row g-3 mt-3" data-event-repeat-body>
                                        <div class="col-12">
                                            <div class="row" data-event-time-row>
                                                <div class="col-5">
                                                    <div class="events__select-block">
                                                        <div class="events__form-item required">
                                                            <label class="form-item__label">Начало <span
                                                                        class="star-required color__red me-1">*</span></label>
                                                            <input <?=$arResult['DISABLED']?> type="hidden"
                                                                   name="LOCATION[<?= $location['LOCATION_ID'] ?>][DATE_TIME][<?= $i ?>][DATE]"
                                                                   value="<?= $location['EVENT_DATE']['DATE'] ?>">
                                                            <input <?=$arResult['DISABLED']?> type="text" class="input__time" data-mask-time
                                                                   placeholder="чч:мм"
                                                                   name="LOCATION[<?= $location['LOCATION_ID'] ?>][DATE_TIME][<?= $i ?>][TIME]"
                                                                   value="<?= $location['EVENT_DATE']['TIME'] ?>"
                                                                   data-event-time="start">
                                                        </div>
                                                        <div class="events__form-item required">
                                                            <label class="form-item__label">Окончание <span
                                                                        class="star-required color__red me-1">*</span></label>
                                                            <input <?=$arResult['DISABLED']?> type="text" class="input__time" data-mask-time
                                                                   value="<?= $location['EVENT_DATE']['TIME_END'] ?>"
                                                                   data-event-time="end"
                                                                   data-linked-field/>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-3">
                                                    <div class="form-item required">
                                                        <label class="form-item__label">Длительность, мин. <span
                                                                    class="star-required color__red me-1">*</span></label>
                                                        <input <?=$arResult['DISABLED']?> type="number"
                                                               name="LOCATION[<?= $location['LOCATION_ID'] ?>][UF_DURATION]"
                                                               class="form__underline-input"
                                                               value="<?= $location['LOCATION_INFO']['UF_DURATION'] ?>"
                                                               data-event-duration
                                                               data-linked-field data-filter-number/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <? if ($arResult['EVENT']['UF_TYPE'] == 7 || $arResult['EVENT']['UF_TYPE'] == 8): ?>
                                            <div class="col-5">
                                                <div class="form-item required">
                                                    <label class="form-item__label">Локация <span
                                                                class="star-required color__red me-1">*</span></label>
                                                    <!-- <span class="form__error"></span> -->
                                                    <div class="form-select js-form-select borderless">
                                                        <input <?=$arResult['DISABLED']?> class="form-select__selected-option js-form-select-option js-option-change js-sync-location"
                                                               data-da-search value='<?= $address ?>'>
                                                        <div class="form-select-options-wrap js-form-select-options-wrap">
                                                            <ul class="form-select-options form-select__options">
                                                            </ul>
                                                        </div>
                                                        <input <?=$arResult['DISABLED']?> type="hidden"
                                                               name="LOCATION[<?= $location['LOCATION_ID'] ?>][UF_ADDRESS]"
                                                               value='<?= $address ?>' <?= $location['CHECKED'] && $i > 0 ? 'disabled' : ''; ?>
                                                               data-linked-field>
                                                        <input <?=$arResult['DISABLED']?> type="hidden"
                                                               name="LOCATION[<?= $location['LOCATION_ID'] ?>][UF_COORDINATES]"
                                                               value="<?= $location['LOCATION_INFO']['UF_COORDINATES'] ?>"
                                                               data-coords <?= $location['CHECKED'] && $i > 0 ? 'disabled' : ''; ?>
                                                               data-linked-field>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="form-item">
                                                    <label class="form-item__label">Помещение</label>
                                                    <!-- <span class="form__error"></span> -->
                                                    <input <?=$arResult['DISABLED']?>
                                                            type="text"
                                                            name="LOCATION[<?= $location['LOCATION_ID'] ?>][UF_ROOM]"
                                                            value="<?= $location['LOCATION_INFO']['UF_ROOM'] ?>"
                                                            class="form__underline-input  js-sync-room"
                                                            data-linked-field
                                                    />
                                                </div>
                                            </div>
                                        <? endif; ?>
                                        <? if ($arResult['EVENT']['UF_TYPE'] == 6 || $arResult['EVENT']['UF_TYPE'] == 8): ?>
                                            <div class="col-12" data-input-link>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label class="form-item__label">Ссылка <span
                                                                    class="star-required color__red me-1">*</span></label>
                                                    </div>
                                                    <div class="col-5">
                                                        <div class="form-item  required">
                                                            <label class="form-item__label" hidden="hidden">Название
                                                                ссылки</label>
                                                            <!-- <span class="form__error"></span> -->
                                                            <input <?=$arResult['DISABLED']?> type="text"
                                                                   name="LOCATION[<?= $location['LOCATION_ID'] ?>][UF_LINK][0][0]"
                                                                   class="form__underline-input"
                                                                   value="<?= $location['LOCATION_INFO']['UF_LINK'][0][0] ?>"
                                                                   data-linked-field>
                                                            <small>Название ссылки, например «Трансляция»</small>
                                                        </div>
                                                    </div>
                                                    <div class="col-5">
                                                        <div class="form-item required">
                                                            <label class="form-item__label"
                                                                   hidden="hidden">Ссылка</label>
                                                            <!-- <span class="form__error"></span> -->
                                                            <input <?=$arResult['DISABLED']?> type="text"
                                                                   name="LOCATION[<?= $location['LOCATION_ID'] ?>][UF_LINK][0][1]"
                                                                   class="form__underline-input"
                                                                   value="<?= $location['LOCATION_INFO']['UF_LINK'][0][1] ?>"
                                                                   data-linked-field>
                                                            <small>Укажите саму ссылку. http://..., https://...</small>
                                                        </div>
                                                    </div>
                                                    <div class="col-2 control__links">
                                                        <div class="clue__box">
                                                            <div class="" data-clue="">
                                                                <button class="btn__icon" data-input-link-to=""
                                                                        type="button"><i class="_icon-link"></i>
                                                                </button>
                                                                <span class="clue-body" data-clue-body=""
                                                                      data-popper-placement="top">
																														Перейти по ссылке
																														<span data-popper-arrow=""></span>
																													</span>
                                                            </div>
                                                        </div>
	                                                    <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                        <button type="button" class="btn__icon delete"
                                                                data-input-link-delete>
                                                            <i class="_icon-plus"></i>
                                                        </button>
                                                      <?php endif;?>
                                                    </div>
                                                </div>
                                            </div>
                                        <? endif; ?>
                                    </div>
                                </div>
                                <? $i++; ?>
                            <? endforeach; ?>
                        </div>
                    </div>
                </form>
            </div>
            <div class="create-event__body" id="SeatMap">
                <? if (isset($arResult['SeatMap']['editorUrl'])): ?>
                    <form action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=setSitMap"
                          enctype="multipart/form-data" class="poster__form">
                        <input <?=$arResult['DISABLED']?> type="hidden" name="EVENT" value="<?= $arResult['EVENT']['ID'] ?>">

                        <?php if (false): ?>
                            <div class="d-flex align-items-center mb-3">
                                <label class="form-switch d-flex flex-row align-items-center">
                                    <input <?=$arResult['DISABLED']?> type="checkbox" data-uuid="<?= $arResult['EVENT']['UF_UUID'] ?>"
                                           name="UF_SIT_MAP" <?= !$arResult['EVENT']['UF_SIT_MAP'] ?: 'checked' ?> <?= !$arParams['ELEMENT_ID'] == 0 ?: '' ?>
                                           value="1" data-seating-switcher data-dop-question-switch>
                                    <i class="slider round"></i>
                                    <small class="mx-2"><span>Выключить</span><span>Включить</span> карту мест</small>
                                </label>
                            </div>
                        <?php endif; ?>

                    </form>
                    <button class="sm-button">Показать на весь экран</button>
                    <div class="seating <?=$arResult['DISABLED']?>" data-seating>
                        <iframe src="<?= $arResult['SeatMap']['editorUrl'] ?>"
                                frameborder="0"
                                marginheight="0"
                                marginwidth="0"
                                allow="fullscreen"
                                width="100%"
                                height="100%"
                                scrolling="auto">
                        </iframe>
                    </div>
                    <div>
                    </div>
                <? else: ?>
                    Схема зала доступна только для офлайн мероприятий.
                <? endif; ?>
            </div>
            <div class="create-event__body price__abs">
                <div data-tabs class="price grey__body p-0">
                    <nav data-tabs-titles="async" class="price__navigation">
                        <button type="button" class="price__title tab-active">Типы билетов</button>
                        <button type="button" class="price__title">Промокоды</button>
                        <button type="button" class="price__title">Группы промокодов</button>
                        <button type="button" class="price__title ">Скидка</button>
                    </nav>
                    <form action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=setTickets">
                        <div data-tabs-body class="price__content">
                            <div class="price__body">

	                            <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                <div class="adminpanel__header-item-title justify-content-between">
                                    <!--h3><?= \Custom\Core\Helper::getFormatDate($arResult['EVENT_LOCATION']['UF_DATE_TIME']['DATE']) . ' ' . $arResult['EVENT_LOCATION']['UF_DATE_TIME']['TIME'] ?></h3-->
                                    <a href="#" class="btn" data-add-ticket-type>Добавить</a>
                                </div>
                              <?php endif;?>

                                <input <?=$arResult['DISABLED']?> type="hidden" name="EVENT" value="<?= $arResult['EVENT']['ID'] ?>">
                                <div class="">
                                    <table class="price__table ticket-type-table">
                                        <thead>
                                        <tr>
                                            <th>
                                                <div class="price__table-item">
                                                    <div class="clue__box">
                                                        <p class="me-1">Название / Тип билета <span
                                                                    class="star-required color__red me-1">*</span></p>
                                                        <div class="clue" data-clue="">
                                                            <i class="_icon-question-mark clue-icon"
                                                               data-clue-icon=""></i>
                                                            <span class="clue-body" data-clue-body=""
                                                                  data-popper-placement="bottom">
																											Наименование категории билета, например “Партер” или “Входной на все дни”
																											<span data-popper-arrow=""></span>
																									</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </th>

                                            <th>
                                                <div class="price__table-item">
                                                    <div class="clue__box">
                                                        <p class="me-1">Количество, шт <span
                                                                    class="star-required color__red me-1">*</span></p>
                                                        <div class="clue" data-clue="">
                                                            <i class="_icon-question-mark clue-icon"
                                                               data-clue-icon=""></i>
                                                            <span class="clue-body" data-clue-body=""
                                                                  data-popper-placement="bottom">
																											Общее количество билетов данной категории
																											<span data-popper-arrow=""></span>
																									</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="price__table-item">
                                                    <div class="clue__box">
                                                        <p class="me-1">Max в заказе, шт <span
                                                                    class="star-required color__red me-1">*</span></p>
                                                        <div class="clue" data-clue="">
                                                            <i class="_icon-question-mark clue-icon"
                                                               data-clue-icon=""></i>
                                                            <div class="clue-body" data-clue-body=""
                                                                 data-popper-placement="bottom">
                                                                Максимальное количество билетов этой категории,
                                                                доступное для приобретения одним покупателем в рамках
                                                                одного заказа.
                                                                <span data-popper-arrow=""></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </th>
                                            <? //todo временно скрыто
                                            /*<th>
																						<div class="price__table-item">
																							<div class="clue__box">
																								<p class="me-1">Время резерва, мин <span class="star-required color__red me-1">*</span></p>
																								<div class="clue" data-clue="">
																									<i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
																									<span class="clue-body" data-clue-body="" data-popper-placement="bottom">
																											Время, в течение которого забронированные билеты будут удерживаться за покупателем (в минутах)
																											<span data-popper-arrow=""></span>
																									</span>
																								</div>
																							</div>
																						</div>
																					</th>*/ ?>
                                            <th>
                                                <div class="price__table-item">
                                                    <div class="clue__box">
                                                        <p class="me-1">Цена, ₽</p>
                                                        <div class="clue" data-clue="">
                                                            <i class="_icon-question-mark clue-icon"
                                                               data-clue-icon=""></i>
                                                            <span class="clue-body" data-clue-body=""
                                                                  data-popper-placement="bottom">
																											Стоимость данной категории билета
																											<span data-popper-arrow=""></span>
																									</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </th>
                                            <th data-show-event-type="8">
                                                <div class="price__table-item">
                                                    <div class="clue__box">
                                                        <p class="me-1">Тип участия <span
                                                                    class="star-required color__red me-1">*</span></p>
                                                        <div class="clue" data-clue="">
                                                            <i class="_icon-question-mark clue-icon"
                                                               data-clue-icon=""></i>
                                                            <span class="clue-body" data-clue-body=""
                                                                  data-popper-placement="bottom">
																												Укажите распространяется ли этот тип билета только на онлайн, на онлайн и офлайн или только на офлайн
																												<span data-popper-arrow=""></span>
																											</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </th>
                                            <? if ($arResult['EVENT_LOCATION']['ITEMS'] && count($arResult['EVENT_LOCATION']['ITEMS']) > 1): ?>
                                                <th>
                                                    <div class="price__table-item">
                                                        <div class="clue__box">
                                                            <p class="me-1">Даты мероприятия <span
                                                                        class="star-required color__red me-1">*</span>
                                                            </p>
                                                            <div class="clue" data-clue="">
                                                                <i class="_icon-question-mark clue-icon"
                                                                   data-clue-icon=""></i>
                                                                <span class="clue-body" data-clue-body=""
                                                                      data-popper-placement="bottom">
																												Даты, на которые будет действителен данный тип билета. Обратите внимание: если вы планируете выпускать билеты только на одну конкретную дату, необходимо создать отдельный тип билета для каждой из дат.
																												<span data-popper-arrow=""></span>
																											</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </th>
                                            <? endif; ?>
                                            <th>
                                                <div class="price__table-item text-start">
                                                    <div class="clue__box">
                                                        <p class="me-1">Действие категории по времени</p>
                                                        <div class="clue" data-clue="">
                                                            <i class="_icon-question-mark clue-icon"
                                                               data-clue-icon=""></i>
                                                            <span class="clue-body" data-clue-body=""
                                                                  data-popper-placement="bottom">
																											Укажите временной интервал, в течение которого данная категория билетов будет доступна для продажи
																											<span data-popper-arrow=""></span>
																									</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="price__table-item">
                                                    <div class="clue__box">
                                                        <p class="me-1">Показать остаток билетов</p>
                                                        <div class="clue" data-clue="">
                                                            <i class="_icon-question-mark clue-icon"
                                                               data-clue-icon=""></i>
                                                            <span class="clue-body" data-clue-body=""
                                                                  data-popper-placement="bottom">Отображать оставшееся количество билетов <span
                                                                        data-popper-arrow=""></span></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="price__table-item">
                                                    <div class="clue__box">
                                                        <p class="me-1">Описание</p>
                                                        <div class="clue" data-clue="">
                                                            <i class="_icon-question-mark clue-icon"
                                                               data-clue-icon=""></i>
                                                            <span class="clue-body" data-clue-body=""
                                                                  data-popper-placement="bottom">
																											Описание типа билетов, будет отображаться при покупке билета и на билете
																											<span data-popper-arrow=""></span>
																									</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="price__table-item">
                                                    <p>Статус</p>
                                                </div>
                                            </th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <input <?=$arResult['DISABLED']?> name="EVENT_TYPE_XML_ID"
                                               value="<?= $arResult['EVENT']['UF_TYPE_XML_ID'] ?>" hidden>

                                        <? if (is_array($arResult['TICKETS']) && count($arResult['TICKETS']) > 0): ?>
                                            <? foreach ($arResult['TICKETS'] as $ticket): ?>
                                                <? $isSkuIsCreatedSeatMap = isset($ticket['SKU_IS_CREATED_SEAT_MAP']) && $ticket['SKU_IS_CREATED_SEAT_MAP']; ?>
                                                <tr>
                                                    <td>
                                                        <div class="price__table-item<?= $isSkuIsCreatedSeatMap ? ' disabled-td tooltip-hover' : ' required'; ?>">
                                                            <div class="tooltip-hover-popup">
                                                                <div class="tooltip-hover-popup__content">Данное
                                                                    значение можно изменить только в редактировании
                                                                    схемы зала
                                                                </div>
                                                            </div>
                                                            <label class="form-item__label" hidden="hidden">Название /
                                                                Тип билета</label>
                                                            <input <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][TYPE]"
                                                                   type="text" value="<?= $ticket['SKU_TYPE'] ?>"
                                                                <?= $isSkuIsCreatedSeatMap ? 'readonly' : ''; ?>
                                                                   placeholder="Введите тип">
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="price__table-item <?= $isSkuIsCreatedSeatMap ? ' disabled-td tooltip-hover' : ' required'; ?>">
                                                            <div class="tooltip-hover-popup">
                                                                <div class="tooltip-hover-popup__content">Данное
                                                                    значение можно изменить только в редактировании
                                                                    схемы зала
                                                                </div>
                                                            </div>
                                                            <label class="form-item__label"
                                                                   hidden="hidden">Количество</label>
                                                            <input <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][TOTAL_QUANTITY]"
                                                                   type="text"
                                                                   value="<?= (int)$ticket['SKU_TOTAL_QUANTITY'] ?: (int)$ticket['SKU_TOTAL_QUANTITY'] ?>"
                                                                   class="lg"
                                                                <?= $isSkuIsCreatedSeatMap ? 'readonly' : ''; ?>
                                                                   placeholder="Кол-во"
                                                                   data-filter-number>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="price__table-item required">
                                                            <label class="form-item__label" hidden="hidden">Max в
                                                                заказе</label>
                                                            <input <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][MAX_QUANTITY]"
                                                                   type="text"
                                                                   value="<?= !$ticket['SKU_MAX_QUANTITY'] ?: (int)$ticket['SKU_MAX_QUANTITY'] ?>"
                                                                   class="med"
                                                                   placeholder="Макс. в заказе"
                                                                   data-filter-number>
                                                        </div>
                                                    </td>
                                                    <? //todo временно скрыто
                                                    /*
                                                    <td>
                                                        <div class="price__table-item required">
																													<label class="form-item__label" hidden="hidden">Время резерва</label>
                                                            <input <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][RESERVE_TIME]"
                                                                   type="text"
                                                                   value="<?= !$ticket['SKU_RESERVE_TIME'] ?: (int)$ticket['SKU_RESERVE_TIME'] ?>"
                                                                   class="lg"
                                                                   placeholder="Время резерва"
                                                                   data-filter-number>
                                                        </div>
                                                    </td>*/ ?>
                                                    <td>
                                                        <div class="price__table-item <?= $isSkuIsCreatedSeatMap ? ' disabled-td tooltip-hover' : ' required'; ?>">
                                                            <div class="tooltip-hover-popup">
                                                                <div class="tooltip-hover-popup__content">Данное
                                                                    значение можно изменить только в редактировании
                                                                    схемы зала
                                                                </div>
                                                            </div>
                                                            <label class="form-item__label" hidden="hidden">Цена</label>
                                                            <input <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][PRICE]"
                                                                   type="text"
                                                                   value="<?= !$ticket['SKU_PRICE'] ?: (int)$ticket['SKU_PRICE'] ?>"
                                                                   class="min"
                                                                   placeholder="Цена"
                                                                   data-filter-number>
                                                        </div>
                                                    </td>
                                                    <td data-show-event-type="8">
                                                        <div class="price__table-item <?= $isSkuIsCreatedSeatMap ? ' disabled-td tooltip-hover' : ''; ?>">
                                                            <div class="tooltip-hover-popup">
                                                                <div class="tooltip-hover-popup__content">Данное
                                                                    значение можно изменить только в редактировании
                                                                    схемы зала
                                                                </div>
                                                            </div>
                                                            <!--	//todo нужно интегрировать это поле 	-->
                                                            <select <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][TYPE_PARTICIPATION]"
                                                                    id="" <?= $isSkuIsCreatedSeatMap ? 'disabled' : ''; ?>>
                                                                <? foreach ($arResult['TYPE_PARTICIPATION_LIST'] as $type): ?>
                                                                    <option
                                                                        <? if ($isSkuIsCreatedSeatMap): ?>
                                                                            <? if ($type['XML_ID'] == "offline"): ?>
                                                                                selected
                                                                            <? endif; ?>
                                                                        <? elseif (in_array($arResult['EVENT']['UF_TYPE_XML_ID'], ["offline", "online"])): ?>
                                                                            <? if ($arResult['EVENT']['UF_TYPE_XML_ID'] == $type['XML_ID']): ?>
                                                                                selected
                                                                            <? endif; ?>
                                                                        <? else: ?>
                                                                            <? if ($ticket['SKU_TYPE_PARTICIPATION']): ?>
                                                                                <? if ($ticket['SKU_TYPE_PARTICIPATION'] == $type['ID']): ?>
                                                                                    selected
                                                                                <? endif; ?>
                                                                            <? elseif ($arResult['EVENT']['UF_TYPE_XML_ID'] == $type['XML_ID']): ?>
                                                                                selected
                                                                            <? endif; ?>
                                                                        <? endif; ?>
                                                                            value="<?= $type['ID'] ?>">
                                                                        <?= $type['VALUE'] ?>
                                                                    </option>
                                                                <? endforeach; ?>
                                                            </select>

                                                            <? if ($isSkuIsCreatedSeatMap): ?>
                                                                <input <?=$arResult['DISABLED']?>
                                                                        name="tickets[<?= $ticket['SKU_ID'] ?>][TYPE_PARTICIPATION]"
                                                                        value="<?= $arResult['TYPE_PARTICIPATION_LIST']['offline']["ID"] ?>"
                                                                        hidden>
                                                            <? endif; ?>

                                                        </div>
                                                    </td>

                                                    <? if ($arResult['EVENT_LOCATION']['ITEMS'] && count($arResult['EVENT_LOCATION']['ITEMS']) > 1): ?>
                                                        <td>
                                                            <div class="price__table-item">
                                                                <div class="form-select__split">
                                                                    <input <?=$arResult['DISABLED']?> type="hidden" value=""
                                                                           name="tickets[<?= $ticket['SKU_ID'] ?>][DATES_ALL]">
                                                                    <input <?=$arResult['DISABLED']?> type="hidden" value=""
                                                                           name="tickets[<?= $ticket['SKU_ID'] ?>][DATES][]">

                                                                    <div class="promo__list hide-extra"
                                                                         data-ticket-dates-grid>
                                                                        <? if ($ticket['SKU_DATES_ALL']): ?>
                                                                            <div class="promo__item">
												                        <span>
                                                                            Все
                                                                        </span>
                                                                                <input <?=$arResult['DISABLED']?> type="hidden" value="all"
                                                                                       name="tickets[<?= $ticket['SKU_ID'] ?>][DATES_ALL]">
                                                                                <i class="_icon-plus"></i>
                                                                            </div>
                                                                        <? else: ?>
                                                                            <? foreach ($ticket['SKU_DATES'] as $keyDate => $date): ?>
                                                                                <div class="promo__item">
												                        <span>
                                                                            <?= $date ?>
                                                                        </span>
                                                                                    <input <?=$arResult['DISABLED']?> type="hidden"
                                                                                           value="<?= $date ?>"
                                                                                           name="tickets[<?= $ticket['SKU_ID'] ?>][DATES][]">
                                                                                    <i class="_icon-plus"></i>
                                                                                </div>
                                                                            <? endforeach; ?>
                                                                        <? endif; ?>
                                                                    </div>


                                                                    <div class="form-select form-select__group js-form-select <? if ($ticket['SKU_DATES'] && !$ticket['SKU_DATES_ALL'] && count($ticket['SKU_DATES']) > 1) echo "show-counter"; ?>"
                                                                         data-multyple-select="[data-ticket-dates-grid]"
                                                                         data-multyple-guid="tickets[<?= $ticket['SKU_ID'] ?>][DATES][]"
                                                                         data-all-guid="tickets[<?= $ticket['SKU_ID'] ?>][DATES_ALL]"
                                                                    >
                                                                        <div class="form-select__selected-option js-form-select-option js-option-change">
                                                                            <div class="promo__item"
                                                                                 data-multyple-select-counter>
                                                                                <span><? if ($ticket['SKU_DATES'] && !$ticket['SKU_DATES_ALL'] && count($ticket['SKU_DATES']) > 1) echo "+" . (count($ticket['SKU_DATES']) - 1); ?></span>
                                                                            </div>
                                                                            <button type="button"
                                                                                    class="form-select__add-btn">
                                                                                <i class="_icon-plus"></i>
                                                                            </button>
                                                                        </div>
                                                                        <div class="form-select-options-wrap js-form-select-options-wrap">
                                                                            <ul class="form-select-options form-select__options">
                                                                                <li class="form-select-options__item js-form-select-options-item"
                                                                                    data-option="all">
                                                                                    <p><b>Все</b></p>
                                                                                </li>
                                                                                <? foreach ($arResult['EVENT_LOCATION']['ITEMS'] as $item): ?>
                                                                                    <li class="form-select-options__item js-form-select-options-item <? if ($ticket['SKU_DATES'] && !$ticket['SKU_DATES_ALL'] && in_array($item['EVENT_DATE']['DATE_SHORT'], $ticket['SKU_DATES'])) echo "_icon-checkbox"; ?>"
                                                                                        data-option="<?= $item['EVENT_DATE']['DATE_SHORT'] ?>">
                                                                                        <p><?= $item['EVENT_DATE']['DATE_SHORT'] ?></p>
                                                                                    </li>
                                                                                <? endforeach; ?>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    <? else: ?>
                                                        <input <?=$arResult['DISABLED']?> type="hidden" value="all"
                                                               name="tickets[<?= $ticket['SKU_ID'] ?>][DATES_ALL]">
                                                    <? endif; ?>

                                                    <td>
                                                        <div class="price__table-item">
                                                            <div class="date__split">
                                                                <div class="input__split-wrapper">
                                                                    <input <?=$arResult['DISABLED']?>
                                                                            name="tickets[<?= $ticket['SKU_ID'] ?>][ACTIVE_FROM_YEAR]"
                                                                            type="text"
                                                                            data-date
                                                                            data-formatted-date
                                                                            placeholder="ДД.ММ.ГГ"
                                                                            readonly
                                                                            value="<?= $ticket['SKU_ACTIVE_FROM_YEAR'] ?>"/>
                                                                    <span></span>
                                                                    <input <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][ACTIVE_FROM_TIME]"
                                                                           value="<?= $ticket['SKU_ACTIVE_FROM_TIME'] ?>"
                                                                           type="text" data-mask-time
                                                                           placeholder="ЧЧ:ММ"/>
	                                                                <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                                    <button type="button" data-clear-date><i
                                                                                class="_icon-plus"></i></button>
	                                                                <?php endif; ?>
                                                                </div>
                                                                <span>-</span>
                                                                <div class="input__split-wrapper">
                                                                    <input <?=$arResult['DISABLED']?>
                                                                            name="tickets[<?= $ticket['SKU_ID'] ?>][ACTIVE_TO_YEAR]"
                                                                            type="text"
                                                                            data-date
                                                                            data-formatted-date
                                                                            placeholder="ДД.ММ.ГГ"
                                                                            readonly
                                                                            value="<?= $ticket['SKU_ACTIVE_TO_YEAR'] ?>"/>
                                                                    <span></span>
                                                                    <input <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][ACTIVE_TO_TIME]"
                                                                           value="<?= $ticket['SKU_ACTIVE_TO_TIME'] ?>"
                                                                           type="text" data-mask-time
                                                                           placeholder="ЧЧ:ММ"/>
	                                                                <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                                    <button type="button" data-clear-date><i
                                                                                class="_icon-plus"></i></button>
                                                                  <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="price__table-item">

                                                            <label class="form-bool-switch">
                                                                <input <?=$arResult['DISABLED']?> type="checkbox"
                                                                       name="tickets[<?= $ticket['SKU_ID'] ?>][SHOW_STOCK]"
                                                                       value="1"
                                                                    <?= !(int)$ticket['SKU_SHOW_STOCK'] ? "" : "checked" ?>
                                                                >
                                                                <span>НЕТ</span>
                                                                <span>ДА</span>
                                                            </label>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="price__table-item">
                                                            <div class="ticket__add-description"
                                                                 data-add-ticket-description>
                                                                <button type="button"
                                                                        class="ticket__add-description-btn <?= !$ticket['SKU_PREVIEW_TEXT'] ?: "filled"; ?>"
                                                                        <?php if($arResult['DISABLED'] !== 'disabled'):?>data-add-ticket-description-toggle<?php endif;?>>
                                                                    <span>Добавить</span>
                                                                    <span><span data-add-ticket-description-text><?= $ticket['SKU_PREVIEW_TEXT'] ?></span> <i
                                                                                class="_icon-pen"></i></span>
                                                                </button>
                                                                <div class="ticket__description-body"
                                                                     data-add-ticket-description-body>
                                                                    <input <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][PREVIEW_TEXT]"
                                                                           type="hidden"
                                                                           value="<?= $ticket['SKU_PREVIEW_TEXT'] ?>">
	                                                                <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                                    <button class="btn__icon ticket__description-close"
                                                                            data-add-ticket-description-close
                                                                            type="button">
                                                                        <i class="_icon-cross"></i>
                                                                    </button>
	                                                                <?php endif;?>
                                                                    <p class="text-start">Описание типа билетов</p>
                                                                    <textarea <?=$arResult['DISABLED']?>
                                                                            class="form-item__textarea-default"
                                                                            data-textarea-auto-height
                                                                            placeholder="Добавьте описание типа билета"><?= $ticket['SKU_PREVIEW_TEXT'] ?></textarea>
                                                                    <div class="d-flex align-center justify-content-between">
                                                                        <button class="btn__simple" type="button"
                                                                                data-add-ticket-description-clean>
                                                                            <i class="_icon-cross"></i>
                                                                            <span>Удалить описание</span>
                                                                        </button>
                                                                        <button class="btn__simple" type="button"
                                                                                data-add-ticket-description-save>
                                                                            <span>Сохранить</span>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="price__table-item">
                                                            <div class="form-select select__transparent"
                                                                 data-content-select style="min-width: 6rem">
                                                                <select <?=$arResult['DISABLED']?> name="tickets[<?= $ticket['SKU_ID'] ?>][ACTIVE]">
                                                                    <option value="1" <?= $ticket['SKU_ACTIVE'] !== 'N' ? "selected" : "" ?>>
                                                                        В продаже
                                                                    </option>
                                                                    <option value="0" <?= $ticket['SKU_ACTIVE'] !== 'N' ? "" : "selected" ?>>
                                                                        Не в продаже
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="events__table-controls">
	                                                        <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                            <button class="price__table-item-delete" type="button"
                                                                    data-price-serv-delete="<?= $ticket['SKU_ID'] ?>"><i
                                                                        class="_icon-plus"></i></button>
                                                          <?php endif;?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <? endforeach; ?>
                                        <? else: ?>
                                        <tr>
                                            <td>
                                                <div class="price__table-item">
                                                    <input <?=$arResult['DISABLED']?> name="tickets[n_0][TYPE]" type="text" value=""

                                                           placeholder="Введите тип">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="price__table-item">
                                                    <input <?=$arResult['DISABLED']?> name="tickets[n_0][TOTAL_QUANTITY]" type="text" value=""
                                                           class="lg"
                                                           placeholder="Введите кол-во"
                                                           data-filter-number>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="price__table-item">
                                                    <input <?=$arResult['DISABLED']?> name="tickets[n_0][MAX_QUANTITY]" type="text" value=""
                                                           class="med"
                                                           placeholder="Макс. в заказе"
                                                           data-filter-number>
                                                </div>
                                            </td>
                                            <!-- //todo временно скрыто
                                            <td>
                                                <div class="price__table-item">
                                                    <input <?=$arResult['DISABLED']?> name="tickets[n_0][RESERVE_TIME]" type="text" value=""
                                                           class="lg"
                                                           placeholder="Время резерва"
                                                           data-filter-number>
                                                </div>
                                            </td> -->
                                            <td>
                                                <div class="price__table-item">
                                                    <input <?=$arResult['DISABLED']?> name="tickets[n_0][PRICE]" type="text" value=""
                                                           class="min"
                                                           placeholder="Цена"
                                                           data-filter-number>
                                                </div>
                                            </td>
                                            <td data-show-event-type="8">
                                                <div class="price__table-item">
                                                    <select <?=$arResult['DISABLED']?> name="tickets[n_0][TYPE_PARTICIPATION]"
                                                            id="" <?= $isSkuIsCreatedSeatMap ? 'disabled' : ''; ?>>
                                                        <? foreach ($arResult['TYPE_PARTICIPATION_LIST'] as $type): ?>
                                                            <option
                                                                <? if ($isSkuIsCreatedSeatMap): ?>
                                                                    <? if ($type['XML_ID'] == "offline"): ?>
                                                                        selected
                                                                    <? endif; ?>
                                                                <? else: ?>
                                                                    <? if ($arResult['EVENT']['UF_TYPE_XML_ID'] == $type['XML_ID']): ?>
                                                                        selected
                                                                    <? endif; ?>
                                                                <? endif; ?>
                                                                    value="<?= $type['ID'] ?>">
                                                                <?= $type['VALUE'] ?>
                                                            </option>
                                                        <? endforeach; ?>
                                                    </select>
                                                    <? if ($isSkuIsCreatedSeatMap): ?>
                                                        <input <?=$arResult['DISABLED']?>
                                                                name="tickets[n_0][TYPE_PARTICIPATION]"
                                                                value="<?= $arResult['TYPE_PARTICIPATION_LIST']['offline']["ID"] ?>"
                                                                hidden>
                                                    <? endif; ?>
                                                </div>
                                            </td>
                                            <? if ($arResult['EVENT_LOCATION']['ITEMS'] && count($arResult['EVENT_LOCATION']['ITEMS']) > 1): ?>
                                                <td>
                                                    <div class="price__table-item">
                                                        <div class="form-select__split">
                                                            <input <?=$arResult['DISABLED']?> type="hidden" value=""
                                                                   name="tickets[n_0][DATES_ALL]">
                                                            <input <?=$arResult['DISABLED']?> type="hidden" value="" name="tickets[n_0][DATES][]">

                                                            <div class="promo__list hide-extra" data-ticket-dates-grid>
                                                            </div>

                                                            <div class="form-select form-select__group js-form-select"
                                                                 data-multyple-select="[data-ticket-dates-grid]"
                                                                 data-multyple-guid="tickets[n_0][DATES][]"
                                                                 data-all-guid="tickets[n_0][DATES_ALL]"
                                                            >
                                                                <div class="form-select__selected-option js-form-select-option js-option-change">
                                                                    <div class="promo__item"
                                                                         data-multyple-select-counter>
                                                                        <span></span>
                                                                    </div>
                                                                    <button type="button" class="form-select__add-btn">
                                                                        <i class="_icon-plus"></i>
                                                                    </button>
                                                                </div>
                                                                <div class="form-select-options-wrap js-form-select-options-wrap">
                                                                    <ul class="form-select-options form-select__options">
                                                                        <li class="form-select-options__item js-form-select-options-item"
                                                                            data-option="all">
                                                                            <p><b>Все</b></p>
                                                                        </li>
                                                                        <? foreach ($arResult['EVENT_LOCATION']['ITEMS'] as $item): ?>
                                                                            <li class="form-select-options__item js-form-select-options-item"
                                                                                data-option="<?= $item['EVENT_DATE']['DATE_SHORT'] ?>">
                                                                                <p><?= $item['EVENT_DATE']['DATE_SHORT'] ?></p>
                                                                            </li>
                                                                        <? endforeach; ?>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            <? else: ?>
                                                <input <?=$arResult['DISABLED']?> type="hidden" value="all"
                                                       name="tickets[n_0][DATES_ALL]">
                                            <? endif; ?>
                                            <td>
                                                <div class="price__table-item">
                                                    <div class="date__split">
                                                        <div class="input__split-wrapper">
                                                            <input <?=$arResult['DISABLED']?> name="tickets[n_0][ACTIVE_FROM_YEAR]" type="text"
                                                                   data-date data-formatted-date placeholder="ДД.ММ.ГГ"
                                                                   readonly/>
                                                            <span></span>
                                                            <input <?=$arResult['DISABLED']?> name="tickets[n_0][ACTIVE_FROM_TIME]" type="text"
                                                                   data-mask-time placeholder="ЧЧ:ММ"/>
	                                                        <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                            <button type="button" data-clear-date><i
                                                                        class="_icon-plus"></i>
                                                            </button>
                                                          <?php endif; ?>
                                                        </div>
                                                        <span>-</span>
                                                        <div class="input__split-wrapper">
                                                            <input <?=$arResult['DISABLED']?> name="tickets[n_0][ACTIVE_TO_YEAR]" type="text"
                                                                   data-date
                                                                   data-formatted-date placeholder="ДД.ММ.ГГ" readonly/>
                                                            <span></span>
                                                            <input <?=$arResult['DISABLED']?> name="tickets[n_0][ACTIVE_TO_TIME]" type="text"
                                                                   data-mask-time placeholder="ЧЧ:ММ"/>
	                                                        <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                            <button type="button" data-clear-date><i
                                                                        class="_icon-plus"></i>
                                                            </button>
                                                          <?php endif; ?>

                                                        </div>
                                                    </div>
                                                </div>
                                </div>
                                </td>
                                <td>
                                    <div class="price__table-item">

                                        <label class="form-bool-switch">
                                            <input <?=$arResult['DISABLED']?> type="checkbox" name="tickets[n_0][SHOW_STOCK]" value="1">
                                            <span>НЕТ</span>
                                            <span>ДА</span>
                                        </label>

                                    </div>
                                </td>
                                <td>
                                    <div class="price__table-item">
                                        <div class="ticket__add-description" data-add-ticket-description>
                                            <button type="button" class="ticket__add-description-btn"
                                                    data-add-ticket-description-toggle>
                                                <span>Добавить</span>
                                                <span><span data-add-ticket-description-text>Заполненное описание</span> <i
                                                            class="_icon-pen"></i></span>
                                            </button>
                                            <div class="ticket__description-body"
                                                 data-add-ticket-description-body>
                                                <input <?=$arResult['DISABLED']?> name="tickets[n_0][PREVIEW_TEXT]"
                                                       type="hidden"
                                                       value="">
                                                <button class="btn__icon ticket__description-close"
                                                        data-add-ticket-description-close type="button">
                                                    <i class="_icon-cross"></i>
                                                </button>
                                                <p class="text-start">Описание типа билетов</p>
                                                <textarea <?=$arResult['DISABLED']?>
                                                        class="form-item__textarea-default"
                                                        data-textarea-auto-height
                                                        placeholder="Добавьте описание типа билета"></textarea>
                                                <div class="d-flex align-center justify-content-between">
                                                    <button class="btn__simple" type="button"
                                                            data-add-ticket-description-clean>
                                                        <i class="_icon-cross"></i>
                                                        <span>Удалить описание</span>
                                                    </button>
                                                    <button class="btn__simple" type="button"
                                                            data-add-ticket-description-save>
                                                        <span>Сохранить</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="price__table-item">
                                        <select <?=$arResult['DISABLED']?> name="tickets[n_0][ACTIVE]">
                                            <option value="1">В продаже</option>
                                            <option value="0">Не в продаже</option>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="events__table-controls">
                                        <button class="price__table-item-delete" type="button"><i
                                                    class="_icon-plus"></i></button>
                                    </div>
                                </td>
                                </tr>
                                <? endif; ?>
                                </tbody>
                                </table>
                            </div>
                            <div class="price__save-wrapper">
	                            <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                <a href="javascript:void(0);" class="btn btn__fix-width btn-right"
                                   data-event-price-save>Сохранить</a>
                              <?php endif;?>
                            </div>
                        </div>
                        <div class="price__body promocodes">
                            <? $APPLICATION->IncludeComponent(
                                "custom:price.rules",
                                ".default",
                                [
                                    "HLB_COUPONS_ID"                  => HL_PROMOCODES_ID,
                                    "HLB_PRICE_RULES_ID"              => HL_PRICE_RULES_ID,
                                    "EVENT_TYPES"                     => $arResult['TICKETS'],
                                    "EVENT_ID"                        => (int)$arParams['ELEMENT_ID'],
                                    "DISABLED"                        => $arResult['DISABLED'],
                                    "ADD_ELEMENT_CHAIN"               => "N",
                                    "ADD_SECTIONS_CHAIN"              => "Y",
                                    "AJAX_MODE"                       => "N",
                                    "AJAX_OPTION_ADDITIONAL"          => "",
                                    "AJAX_OPTION_HISTORY"             => "N",
                                    "AJAX_OPTION_JUMP"                => "N",
                                    "AJAX_OPTION_STYLE"               => "Y",
                                    "BROWSER_TITLE"                   => "-",
                                    "CACHE_FILTER"                    => "N",
                                    "CACHE_GROUPS"                    => "Y",
                                    "CACHE_TIME"                      => "36000000",
                                    "CACHE_TYPE"                      => "A",
                                    "CHECK_DATES"                     => "Y",
                                    "DETAIL_ACTIVE_DATE_FORMAT"       => "d.m.Y",
                                    "DETAIL_DISPLAY_BOTTOM_PAGER"     => "Y",
                                    "DETAIL_DISPLAY_TOP_PAGER"        => "N",
                                    "DETAIL_FIELD_CODE"               => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "DETAIL_PAGER_SHOW_ALL"           => "Y",
                                    "DETAIL_PAGER_TEMPLATE"           => "",
                                    "DETAIL_PAGER_TITLE"              => "Страница",
                                    "DETAIL_PROPERTY_CODE"            => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "DETAIL_SET_CANONICAL_URL"        => "N",
                                    "DISPLAY_BOTTOM_PAGER"            => "Y",
                                    "DISPLAY_DATE"                    => "Y",
                                    "DISPLAY_NAME"                    => "Y",
                                    "DISPLAY_PICTURE"                 => "Y",
                                    "DISPLAY_PREVIEW_TEXT"            => "Y",
                                    "DISPLAY_TOP_PAGER"               => "N",
                                    "PRICE_RULES_COUNT"               => "10",
                                    "HIDE_LINK_WHEN_NO_DETAIL"        => "N",
                                    "LIST_ACTIVE_DATE_FORMAT"         => "d.m.Y",
                                    "LIST_FIELD_CODE"                 => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "LIST_PROPERTY_CODE"              => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "MESSAGE_404"                     => "",
                                    "META_DESCRIPTION"                => "-",
                                    "META_KEYWORDS"                   => "-",
                                    "PAGER_BASE_LINK_ENABLE"          => "N",
                                    "PAGER_DESC_NUMBERING"            => "N",
                                    "PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
                                    "PAGER_SHOW_ALL"                  => "N",
                                    "PAGER_SHOW_ALWAYS"               => "N",
                                    "PAGER_TEMPLATE"                  => ".default",
                                    "PAGER_TITLE"                     => "События",
                                    "PREVIEW_TRUNCATE_LEN"            => "",
                                    "SEF_MODE"                        => "Y",
                                    "SET_LAST_MODIFIED"               => "N",
                                    "SET_STATUS_404"                  => "N",
                                    "SET_TITLE"                       => "Y",
                                    "SHOW_404"                        => "N",
                                    "USE_FILTER"                      => "N",
                                    "USE_PERMISSIONS"                 => "N",
                                    "USE_SEARCH"                      => "N",
                                    "USE_SHARE"                       => "N",
                                    "COMPONENT_TEMPLATE"              => "promocodes",
                                    "SEF_FOLDER"                      => "/admin_panel/price_rules/",
                                    "SEF_URL_TEMPLATES"               => [
                                        "list"    => "list/",
                                        "section" => "list/",
                                        "detail"  => "#ELEMENT_ID#/",
                                    ]
                                ],
                                false
                            ); ?>
                        </div>
                        <div class="price__body promocodes">
                            <? $APPLICATION->IncludeComponent(
                                "custom:price.rules",
                                ".default",
                                [
                                    "HLB_COUPONS_ID"                  => HL_PROMOCODES_ID,
                                    "HLB_PRICE_RULES_ID"              => HL_PRICE_RULES_ID,
                                    "EVENT_TYPES"                     => $arResult['TICKETS'],
                                    "EVENT_ID"                        => (int)$arParams['ELEMENT_ID'],
                                    "DISABLED"                        => $arResult['DISABLED'],
                                    "ADD_ELEMENT_CHAIN"               => "N",
                                    "ADD_SECTIONS_CHAIN"              => "Y",
                                    "AJAX_MODE"                       => "N",
                                    "AJAX_OPTION_ADDITIONAL"          => "",
                                    "AJAX_OPTION_HISTORY"             => "N",
                                    "AJAX_OPTION_JUMP"                => "N",
                                    "AJAX_OPTION_STYLE"               => "Y",
                                    "BROWSER_TITLE"                   => "-",
                                    "CACHE_FILTER"                    => "N",
                                    "CACHE_GROUPS"                    => "Y",
                                    "CACHE_TIME"                      => "36000000",
                                    "CACHE_TYPE"                      => "A",
                                    "CHECK_DATES"                     => "Y",
                                    "DETAIL_ACTIVE_DATE_FORMAT"       => "d.m.Y",
                                    "DETAIL_DISPLAY_BOTTOM_PAGER"     => "Y",
                                    "DETAIL_DISPLAY_TOP_PAGER"        => "N",
                                    "DETAIL_FIELD_CODE"               => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "DETAIL_PAGER_SHOW_ALL"           => "Y",
                                    "DETAIL_PAGER_TEMPLATE"           => "",
                                    "DETAIL_PAGER_TITLE"              => "Страница",
                                    "DETAIL_PROPERTY_CODE"            => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "DETAIL_SET_CANONICAL_URL"        => "N",
                                    "DISPLAY_BOTTOM_PAGER"            => "Y",
                                    "DISPLAY_DATE"                    => "Y",
                                    "DISPLAY_NAME"                    => "Y",
                                    "DISPLAY_PICTURE"                 => "Y",
                                    "DISPLAY_PREVIEW_TEXT"            => "Y",
                                    "DISPLAY_TOP_PAGER"               => "N",
                                    "PRICE_RULES_COUNT"               => "10",
                                    "HIDE_LINK_WHEN_NO_DETAIL"        => "N",
                                    "LIST_ACTIVE_DATE_FORMAT"         => "d.m.Y",
                                    "LIST_FIELD_CODE"                 => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "LIST_PROPERTY_CODE"              => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "MESSAGE_404"                     => "",
                                    "META_DESCRIPTION"                => "-",
                                    "META_KEYWORDS"                   => "-",
                                    "PAGER_BASE_LINK_ENABLE"          => "N",
                                    "PAGER_DESC_NUMBERING"            => "N",
                                    "PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
                                    "PAGER_SHOW_ALL"                  => "N",
                                    "PAGER_SHOW_ALWAYS"               => "N",
                                    "PAGER_TEMPLATE"                  => ".default",
                                    "PAGER_TITLE"                     => "События",
                                    "PREVIEW_TRUNCATE_LEN"            => "",
                                    "SEF_MODE"                        => "Y",
                                    "SET_LAST_MODIFIED"               => "N",
                                    "SET_STATUS_404"                  => "N",
                                    "SET_TITLE"                       => "Y",
                                    "SHOW_404"                        => "N",
                                    "USE_FILTER"                      => "N",
                                    "USE_PERMISSIONS"                 => "N",
                                    "USE_SEARCH"                      => "N",
                                    "USE_SHARE"                       => "N",
                                    "COMPONENT_TEMPLATE"              => "groups",
                                    "SEF_FOLDER"                      => "/admin_panel/price_rules/",
                                    "SEF_URL_TEMPLATES"               => [
                                        "list"    => "list/",
                                        "section" => "list/",
                                        "detail"  => "#ELEMENT_ID#/",
                                    ]
                                ],
                                false
                            ); ?>
                        </div>
                        <div class="price__body promocodes">
                            <? $APPLICATION->IncludeComponent(
                                "custom:price.rules",
                                ".default",
                                [
                                    "HLB_COUPONS_ID"                  => HL_PROMOCODES_ID,
                                    "HLB_PRICE_RULES_ID"              => HL_PRICE_RULES_ID,
                                    "EVENT_TYPES"                     => $arResult['TICKETS'],
                                    "EVENT_ID"                        => (int)$arParams['ELEMENT_ID'],
                                    "DISABLED"                        => $arResult['DISABLED'],
                                    "ADD_ELEMENT_CHAIN"               => "N",
                                    "ADD_SECTIONS_CHAIN"              => "Y",
                                    "AJAX_MODE"                       => "N",
                                    "AJAX_OPTION_ADDITIONAL"          => "",
                                    "AJAX_OPTION_HISTORY"             => "N",
                                    "AJAX_OPTION_JUMP"                => "N",
                                    "AJAX_OPTION_STYLE"               => "Y",
                                    "BROWSER_TITLE"                   => "-",
                                    "CACHE_FILTER"                    => "N",
                                    "CACHE_GROUPS"                    => "Y",
                                    "CACHE_TIME"                      => "36000000",
                                    "CACHE_TYPE"                      => "A",
                                    "CHECK_DATES"                     => "Y",
                                    "DETAIL_ACTIVE_DATE_FORMAT"       => "d.m.Y",
                                    "DETAIL_DISPLAY_BOTTOM_PAGER"     => "Y",
                                    "DETAIL_DISPLAY_TOP_PAGER"        => "N",
                                    "DETAIL_FIELD_CODE"               => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "DETAIL_PAGER_SHOW_ALL"           => "Y",
                                    "DETAIL_PAGER_TEMPLATE"           => "",
                                    "DETAIL_PAGER_TITLE"              => "Страница",
                                    "DETAIL_PROPERTY_CODE"            => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "DETAIL_SET_CANONICAL_URL"        => "N",
                                    "DISPLAY_BOTTOM_PAGER"            => "Y",
                                    "DISPLAY_DATE"                    => "Y",
                                    "DISPLAY_NAME"                    => "Y",
                                    "DISPLAY_PICTURE"                 => "Y",
                                    "DISPLAY_PREVIEW_TEXT"            => "Y",
                                    "DISPLAY_TOP_PAGER"               => "N",
                                    "PRICE_RULES_COUNT"               => "10",
                                    "HIDE_LINK_WHEN_NO_DETAIL"        => "N",
                                    "LIST_ACTIVE_DATE_FORMAT"         => "d.m.Y",
                                    "LIST_FIELD_CODE"                 => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "LIST_PROPERTY_CODE"              => [
                                        0 => "",
                                        1 => "",
                                    ],
                                    "MESSAGE_404"                     => "",
                                    "META_DESCRIPTION"                => "-",
                                    "META_KEYWORDS"                   => "-",
                                    "PAGER_BASE_LINK_ENABLE"          => "N",
                                    "PAGER_DESC_NUMBERING"            => "N",
                                    "PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
                                    "PAGER_SHOW_ALL"                  => "N",
                                    "PAGER_SHOW_ALWAYS"               => "N",
                                    "PAGER_TEMPLATE"                  => ".default",
                                    "PAGER_TITLE"                     => "События",
                                    "PREVIEW_TRUNCATE_LEN"            => "",
                                    "SEF_MODE"                        => "Y",
                                    "SET_LAST_MODIFIED"               => "N",
                                    "SET_STATUS_404"                  => "N",
                                    "SET_TITLE"                       => "Y",
                                    "SHOW_404"                        => "N",
                                    "USE_FILTER"                      => "N",
                                    "USE_PERMISSIONS"                 => "N",
                                    "USE_SEARCH"                      => "N",
                                    "USE_SHARE"                       => "N",
                                    "COMPONENT_TEMPLATE"              => "discounts",
                                    "SEF_FOLDER"                      => "/admin_panel/price_rules/",
                                    "SEF_URL_TEMPLATES"               => [
                                        "list"    => "list/",
                                        "section" => "list/",
                                        "detail"  => "#ELEMENT_ID#/",
                                    ]
                                ],
                                false
                            ); ?>
                        </div>
                </div>

                </form>

            </div>
        </div>

        <div class="create-event__body">
            <form action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=setQuestionnaire"
                  class="questionnaire__form">
                <input <?=$arResult['DISABLED']?> type="hidden" name="EVENT" value="<?= $arResult['EVENT']['ID'] ?>">
                <div class="form-item form-item__switch mb-2">
                    <h3 class="h3 clue__box">Анкета посетителя
                        <span class="clue" data-clue="">
                              <i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
                              <span class="clue-body" data-clue-body="">
                                Вы не сможете изменить анкету после совершения первой продажи
                                <span data-popper-arrow=""></span>
                              </span>
                            </span>
                    </h3>
                    <? if ($arResult['IS_FILED']): ?>
                        <a href="/admin_panel/events/<?= $arResult['EVENT']['ID'] ?>/?action=getQuestionnaires"
                           download class="btn btn__clear  ms-auto">
                            <i class="_icon-papers"></i>
                            <span>Скачать анкеты посетителей</span>
                        </a>
                    <? else: ?>
                        <span class="ms-auto w-fit-content"></span>
                    <? endif; ?>
                    <div class="checkbox blue ms-5">
                        <p>Заполнение анкеты на каждый билет заказа</p>
                        <label>
                            <input <?=$arResult['DISABLED']?> type="checkbox" name="UF_QUESTIONNAIRE_FOREACH_TICKETS"
                                   value="1" <?= $arResult['EVENT']['UF_QUESTIONNAIRE_FOREACH_TICKETS'] ? 'checked' : '' ?>>
                            <span class="_icon-checkbox"></span>
                        </label>
                    </div>
                </div>
                <div class="row g-2">
                    <div class="col-12">
                        <div class="form-item grey__body">
                            <label class="form-item__label ">Текст перед анкетой регистрации</label>
                            <textarea <?=$arResult['DISABLED']?>
                                    class="form__underline-textarea"
                                    name="UF_QUESTIONNAIRE_DESCRIPTION"
                                    data-textarea-auto-height
                                    placeholder="Опишите анкету (не обязательно)"
                            ><?= $arResult['EVENT']['UF_QUESTIONNAIRE_DESCRIPTION'] ?></textarea>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-item grey__body required">
                            <label class="form-item__label">ФИО</label>
                            <p class="form__underline-input">Ваши Фамилия Имя Отчество</p>
                            <small class="form-item__required">Обязательное поле</small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-item grey__body required">
                            <label class="form-item__label d-flex justify-content-between align-items-center"><span>Телефон</span>
                                <small>Обязательное поле</small></label>
                            <p class="form__underline-input">+7</p>

                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-item grey__body required">
                            <label class="form-item__label">Почта</label>
                            <p class="form__underline-input">@</p>
                            <small class="form-item__required">Обязательное поле</small>
                        </div>
                    </div>
                    <? if (!$arResult['IS_FILED'] || (is_array($arResult['QUESTIONNAIRE_FIELDS']) && count($arResult['QUESTIONNAIRE_FIELDS']) > 0)): ?>
                        <div class="col-12 d-flex align-items-center mt-4 mb-3">
                            <p class="paragraph color__blue-three">Дополнительные вопросы</p>
                            <label class="form-switch mx-3 d-flex align-items-center flex-row">
                                <input <?=$arResult['DISABLED']?> type="checkbox" name="UF_QUESTIONNAIRE_ACTIVE" data-dop-question-switch
                                       value="1" <?= $arResult['EVENT']['UF_QUESTIONNAIRE_ACTIVE'] ? 'checked' : '' ?>>
                                <i class="slider round"></i>
                                <small class="ms-3"><span>Выключить</span><span>Включить</span> отображение</small>
                            </label>

                        </div>
                    <? endif; ?>
                    <div class="col-12">
                        <div class="row g-2" <?php if($arResult['DISABLED'] !== 'disabled'):?>data-draggable-container="" data-questionnaire-body<?php endif;?>>
                            <? foreach ($arResult['QUESTIONNAIRE_FIELDS'] as $key => $question): ?>
                                <? $pattern = '/^[a-f0-9]{8}\-[a-f0-9]{4}\-[a-f0-9]{4}\-[a-f0-9]{4}\-[a-f0-9]{12}$/'; ?>
                                <? if (preg_match($pattern, $key)): ?>

                                    <div class="col-12 draggable__item">
                                        <div class="form-item grey__body">
                                            <? if (!$arResult['IS_FILED']): ?>
                                                <input <?=$arResult['DISABLED']?> type="hidden"
                                                       name="Q_FIELDS[<?= $key ?>][type]"
                                                       value="<?= $question['type'] ?>">
                                            	<?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                <i class="_icon-drag" data-draggable-handler=""></i>
	                                            <?php endif;?>
                                            <? endif; ?>
                                            <span class="form-item__label d-flex justify-content-between align-items-center">
                                                <? if ($question['type'] == 'file'): ?>
                                                    <span class="clue__box">Вопрос - <?= $arResult['QUESTIONNAIRE_FIELD_TYPES'][$question['type']] ?>
                                                 <span class="clue" data-clue="">
                                                  <i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
                                                  <span class="clue-body" data-clue-body="">
                                                   Покупатель сможет загрузить файл до 5 МБ. Доступные форматы: <br> jpg, jpeg, png, pdf, heic, doc, docx, xls, xlsx
                                                    <span data-popper-arrow=""></span>
                                                  </span>
                                                </span>
                                               </span>
                                                <? else: ?>
                                                    <span>Вопрос - <?= $arResult['QUESTIONNAIRE_FIELD_TYPES'][$question['type']] ?></span>
                                                <? endif; ?>

                                                <span class="d-flex align-items-center">
                                                <? if (!$arResult['IS_FILED']): ?>
                                                    <label class="form-switch mx-2">
                                                        <input <?=$arResult['DISABLED']?> type="checkbox" <?= !$question['required'] ? '' : 'checked' ?>
                                               name="Q_FIELDS[<?= $key ?>][required]" value="1">
                                                        <i class="slider round"></i>
                                                    </label>
                                                    <small>Обязательное поле</small>
																										<?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                    <button type="button"
                                                            class="btn__icon form-item__delete"
                                                            data-form-item-delete="">
                                                        <i class="_icon-plus"></i>
                                                    </button>
	                                                <?php endif;?>

                                                <? elseif ($arResult['IS_FILED'] && $question['required']): ?>
                                                    <small>Обязательное поле</small>
                                                <? endif; ?>
                                            </span>
                                            </span>
                                            <? if (!$arResult['IS_FILED']): ?>
                                                <input <?=$arResult['DISABLED']?> type="text" class="form__underline-input"
                                                       name="Q_FIELDS[<?= $key ?>][name]"
                                                       value="<?= $question['name'] ?>"
                                                       placeholder="Введите вопрос">
                                            <? else: ?>
                                                <span class="form__underline-input"><?= $question['name'] ?></span>
                                            <? endif; ?>
                                            <?
                                            if (
                                                $question['type'] == 'list' ||
                                                $question['type'] == 'm_list'
                                            ):?>
                                                <lable class="form-item__label mt-3">Варианты ответа</lable>
                                                <? if (is_array($question['options']) && count($question['options']) > 0): ?>
                                                    <? foreach ($question['options'] as $optionValue): ?>
                                                        <? if (!$arResult['IS_FILED']): ?>
                                                            <div class="form-item__block mt-1">
	                                                            <?php if($arResult['DISABLED'] !== 'disabled'):?>
                                                                <button class="form-item__block-delete btn__icon"
                                                                        type="button"
                                                                        data-questionnaire-variant-delete><i
                                                                            class="_icon-plus"></i></button>
                                                              <?php endif;?>

                                                                <input <?=$arResult['DISABLED']?> type="text" class="form__underline-input"
                                                                       name="Q_FIELDS[<?= $key ?>][options][]"
                                                                       value="<?= $optionValue ?>"
                                                                       placeholder="Добавить вариант ответа"
                                                                       data-questionnaire-variant
                                                                >
                                                            </div>
                                                        <? else: ?>
                                                            <span class="form__underline-input mt-1"><?= $optionValue ?></span>
                                                        <? endif; ?>
                                                    <? endforeach; ?>
                                                <? endif; ?>
                                                <? if (!$arResult['IS_FILED'] && $arResult['DISABLED'] !== 'disabled'): ?>
                                                    <button class="btn__add" type="button"
                                                            data-questionnaire-variant-add="Q_FIELDS[<?= $key ?>][options][]">
                                                        <i class="_icon-plus"></i><span>Добавить вариант</span>
                                                    </button>
                                                <? endif; ?>
                                            <? endif; ?>
                                        </div>
                                    </div>
                                <? endif; ?>
                            <? endforeach; ?>
                        </div>
                    </div>
                    <? if (!$arResult['IS_FILED'] && $arResult['DISABLED'] !== 'disabled'): ?>
                        <div class="form-static-select mt-3" data-static-select="">
                            <div class="form-static-select__name _icon-plus" data-static-select-name=""
                                 data-placeholder="Выберите из списка"><span>Добавить вопрос</span><span>Выберите тип вопроса</span>
                            </div>
                            <i class="form-static-select__icon _icon-chev" data-static-select-icon=""></i>
                            <div class="form-static-select__wrapper" data-static-select-wrapper="">
                                <ul class="form-static-select__options" data-questionnaire-select>
                                    <? foreach ($arResult['QUESTIONNAIRE_FIELD_TYPES'] as $key => $type): ?>
                                        <li class="form-select-options__item"
                                            data-option="<?= $key ?>"><?= $type ?></li>
                                    <? endforeach;
                                    unset($key, $type); ?>
                                </ul>
                            </div>
                        </div>
                    <? endif; ?>
                </div>
            </form>
        </div>
        <div class="create-event__body">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <h3 class="mb-3">Способы оплаты</h3>
                    <form action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=setPaySystem"
                          class="payment__form js-show-checkbox-wrap">
                        <input <?=$arResult['DISABLED']?> type="hidden" name="EVENT" value="<?= $arResult['EVENT']['ID'] ?>">

                        <? foreach ($arResult['PAY_SYSTEMS'] as $paySystem): ?>
                            <label class="payment__form-item">
                                    <span class="chekbox">
                                        <input <?=$arResult['DISABLED']?> type="checkbox" <?= ($paySystem['CHECKED'] == 'Y' || in_array($paySystem['ID'], [5, 10])) ? 'checked' : '' ?> <?=in_array($paySystem['ID'], [5, 10]) ? 'disabled':''?> name="payment[]"
                                               value="<?= $paySystem['ID'] ?>" class="<?= $paySystem['CODE'] === 'invoice' ? "js-show-checkbox-input" : "" ?>">
                                        <span class="_icon-checkbox"></span>
                                    </span>
                                <span class="payment__form-item-info">
                                        <p><?= $paySystem['NAME'] ?></p>
                                    <? if (!empty($paySystem['DESCRIPTION'])): ?>
                                        <small><?= $paySystem['DESCRIPTION'] ?></small>
                                    <? endif; ?>
                                    </span>
                                <span class="payment__form-item-pic">
                                        <img src="<?= $paySystem['LOGO_SRC'] ?>" alt="<?= $paySystem['NAME'] ?>">
                                    </span>
                            </label>
                            <? if ($paySystem['CODE'] == 'invoice'): ?>
                                <div class="form-item grey__body payment-widget js-show-checkbox-true <?= ($paySystem['CHECKED'] == 'Y' || in_array($paySystem['ID'], [5, 10])) ? '' : 'hide' ?>">
	                                <label class="form-item__label">
		                                <p class="clue__box">
			                                Срок действия брони в днях <span class="clue" data-clue>
																			<i class="_icon-question-mark clue-icon" data-clue-icon></i>
																			<span class="clue-body" data-clue-body>
																				Рекомендуем устанавливать срок брони не менее 5 рабочих дней, чтобы у покупателя было достаточно времени на согласование и оплату счета в бухгалтерии. Максимальный срок — 21 календарных дней. Обратите внимание: если до начала мероприятия остаётся менее 48 часов, юридическая оплата будет автоматически недоступна, независимо от установленного срока брони.
																				<span data-popper-arrow></span>
																			</span>
																		</span>
		                                </p>
	                                </label>
	                                <div class="form-select <?=$arResult['DISABLED']?> js-form-select borderless">
		                                <div class="form-select__selected-option js-form-select-option js-option-change" data-placeholder="Выберите из списка"><?= $arResult['EVENT']['UF_RESERVATION_VALIDITY_PERIOD'] ?? 5 ?></div>
		                                <i class="form-select__icon js-form-select-icon _icon-chev"></i>
		                                <div class="form-select-options-wrap js-form-select-options-wrap">
			                                <ul class="form-select-options form-select__options">
		                                  <?php for ($i = 1; $i <= 21; $i++): ?>
						                                <li class="form-select-options__item js-form-select-options-item" data-option="<?= $i ?>"><?= $i ?></li>
		                                  <?php endfor; ?>
			                                </ul>
		                                </div>
		                                <input <?=$arResult['DISABLED']?> name="UF_RESERVATION_VALIDITY_PERIOD" type="hidden" value="<?= $arResult['EVENT']['UF_RESERVATION_VALIDITY_PERIOD'] ?? 5 ?>">
	                                </div>

                                </div>
                            <? endif; ?>
                        <? endforeach; ?>
	                    <!--<label class="payment__form-item">
                          <span class="chekbox">
                              <input <?=$arResult['DISABLED']?> type="checkbox" name="payment[]"
                                     value="">
                              <span class="_icon-checkbox"></span>
                          </span>
                          <span class="payment__form-item-info">
                              <p>По счету на юридическое лицо</p>
															<small>Доступно для ИП и юридических сил</small>
                          </span>
                          <span class="payment__form-item-pic">
                              <img src="<?php /*= $paySystem['LOGO_SRC'] */?>" alt="<?php /*= $paySystem['NAME'] */?>">
                          </span>
	                    </label>

	                    <div class="form-item grey__body payment__form-item payment-widget">
		                    <label class="form-item__label ">Срок действия брони в днях</label>
		                    <div class="form-select js-form-select borderless">
			                    <div class="form-select__selected-option js-form-select-option js-option-change" data-placeholder="Выберите из списка">Выберите из списка</div>
			                    <i class="form-select__icon js-form-select-icon _icon-chev"></i>
			                    <div class="form-select-options-wrap js-form-select-options-wrap">
				                    <ul class="form-select-options form-select__options">
					                    <?php /*for ($i = 1; $i<=10; $i++): */?>
					                    <li class="form-select-options__item js-form-select-options-item" data-option="<?php /*=$i*/?>"><?php /*=$i*/?></li>
					                    <?php /*endfor; */?>
				                    </ul>
			                    </div>
			                    <input <?=$arResult['DISABLED']?> name="UF_reservation" type="hidden" value="19">
		                    </div>

	                    </div>-->

                    </form>
                </div>
            </div>
        </div>
        <div class="create-event__body">
            <form action="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=setWidgets">
                <?= bitrix_sessid_post() ?>
            </form>
            <? $APPLICATION->IncludeComponent(
                "custom:admin.widgets.list",
                "simple",
                [
                    "ACTION"     => $_REQUEST['action'],
                    "SEF_FOLDER" => '/admin_panel/widgets/',
                    "EVENT_ID"   => $arParams['ELEMENT_ID'],
                    "DISABLED"   => $arResult['DISABLED'],
                ],
                false
            ); ?>
        </div>
        <div class="create-event__body">
            <div class="d-flex flex-column h-100 ">
                <div class="d-flex align-items-center mb-3">
	                <?php if($arResult['DISABLED'] !== 'disabled'):?>
                    <a href="/event/<?= $arResult['EVENT']['PRODUCT_ID'] ?>/?preview=Y" target="_blank"
                       class="btn btn__clear">
                        <i class="_icon-prewatch"></i>
                        <span>Предпросмотр</span>
                    </a>
                  <?php endif;?>
                    <button class="btn btn__clear ms-3"
                            data-copy-link="/event/<?= $arResult['EVENT']['PRODUCT_ID'] ?>/">
                        <i class="_icon-papers"></i>
                        <span>Скопировать ссылку на мероприятие</span>
                    </button>
                </div>
                <? if ($arResult['EVENT']['STATUS_XML_ID'] != "completed" && $arResult['DISABLED'] !== 'disabled'): ?>
                    <div class="grey__body mb-4 finish-button-panel">
                        <div class="d-flex align-items-center justify-content-between mw-100">
                            <div class="d-flex align-items-center">
                                <? if ($arResult['EVENT']['STATUS_XML_ID'] == "confirmed" || ($arResult["EVENT"]["IS_CLOSED"] && $arResult['EVENT']['STATUS_XML_ID'] != "published")): ?>
                                    <button class="btn btn__blue btn__big"
                                            type="button"
                                            data-url="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=publish"
                                            data-examination-send>Опубликовать мероприятие
                                    </button>
                                <? elseif ($arResult['EVENT']['STATUS_XML_ID'] == "published"): ?>
                                    <button class="btn btn__red btn__big"
                                            type="button"
                                            data-url="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=unpublish"
                                            data-examination-send>Снять с публикации
                                    </button>
                                <? elseif ($arResult['EVENT']['STATUS_XML_ID'] == "review"): ?>
                                    <button class="btn btn__red btn__big"
                                            type="button"
                                            data-url="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=sendToUnModeration"
                                            data-examination-send="popup-open">Отозвать с проверки
                                    </button>
                                <? elseif ($arResult['EVENT']['STATUS_XML_ID'] != "completed"): ?>
                                    <button class="btn btn__blue btn__big"
                                            data-url="<?= $arParams['SEF_FOLDER'] . $arParams['ELEMENT_ID'] ?>/?action=sendToModeration"
                                            data-examination-send>Отправить на проверку
                                    </button>
                                    <button data-close class="btn btn__white btn__big ms-3"><i
                                                class="_icon-download"> </i>Оставить
                                        в
                                        черновиках
                                    </button>
                                <? endif; ?>
                            </div>
                            <div class="d-flex align-items-center">
                                <label class="switcher__big js-change-visibility-type">
                                    <input <?=$arResult['DISABLED']?> type="checkbox"
                                           data-event-open-switcher="action=setVisibility&EVENT=" <?= !$arResult["EVENT"]["IS_CLOSED"] ? "" : "checked" ?> />
                                    <span class="switcher__big-text">Открытое</span>
                                    <span class="switcher__big-text">Закрытое</span>
                                </label>
                                <div class="clue static" data-clue>
                                    <i class="_icon-question-mark clue-icon" data-clue-icon=""></i>
                                    <span class="clue-body" data-clue-body="">
	                                    Открытое мероприятие будет отображаться на афише voroh.ru. Закрытое будет доступно только по прямой ссылке
	                                    <div data-popper-arrow></div>
	                                  </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <? endif; ?>
                <? if (!is_array($arResult['STATUS_HISTORY']) || count($arResult['STATUS_HISTORY']) < 2): ?>
                    <div class="grey__body h-100 d-flex align-items-center justify-content-center mb-4">
                        <div class="text-center">
                            <div class="h1 mb-3">Создание мероприятия <br> успешно завершено</div>
                            <p class="color__grey paragraph">Здесь будут выводиться статусы <br> по утверждению
                                мероприятия</p>
                        </div>
                    </div>
                <? else: ?>
                    <div class="grey__body no-padding max-h-50vh">
                        <div class="scrolltable h-100">
                            <table class="adminpanel__table">
                                <thead>
                                <tr>
                                    <th>
                                        <div class="adminpanel__item">
                                            <p>Статус</p>
                                        </div>
                                    </th>

                                    <th>
                                        <div class="adminpanel__item">
                                            <label class="events__table-btn"
                                                   data-table-sort="">
                                                <span>Время</span>
                                                <input <?=$arResult['DISABLED']?> type="checkbox"
                                                       data-event-sort-table-time
                                                       class="d-none"
                                                       value="1">
                                                <i class="_icon-vector"></i>
                                            </label>
                                        </div>
                                    </th>
                                    <th>
                                        <div class="adminpanel__item">
                                            <p>Комментарий</p>
                                        </div>
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <? foreach (array_reverse($arResult['STATUS_HISTORY']) as $status): ?>
                                    <tr <?= ($status['STATUS_ID'] == 3) ? 'class="error"' : '' ?>>
                                        <td>
                                            <div class="adminpanel__item">
                                                <p><?= ($arResult['EVENT']['IS_CLOSED'] && $status['STATUS_NAME'] == 'Опубликовано') ? $status['STATUS_NAME'] . ' по ссылке' : $status['STATUS_NAME']; ?></p>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="adminpanel__item">
                                                <p><?= $status['UF_DATE_UPDATE'] ?></p>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="adminpanel__item">
                                                <p><?= $status['UF_COMMENT'] ?: '-' ?></p>
                                            </div>
                                        </td>
                                    </tr>
                                <? endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <? endif; ?>
            </div>
        </div>

    </div>
</div>
<div class="event-create__navigation">
    <button <?=$arResult['DISABLED']?> type="button" class="btn btn__blue btn__event-next js-form-validate-btn">Сохранить и продолжить</button>
</div>
</div>

<? die(); ?>
