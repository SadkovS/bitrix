<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixComponent $component */

use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
?>

    <div class="admin-body__item wide events">
        <div class="admin-body__item-header">
            <h1><?=$APPLICATION->ShowTitle(false)?></h1>
        </div>
        <table class="events__table table-standard-th">
            <thead>
            <tr>
                <td>Наименование документа</td>
                <td>Ссылка на документ</td>
                <td>Дата подписания&nbsp;</td>
                <td>Дата загрузки в систему</td>
            </tr>
            </thead>
            <tbody>

            <?foreach ($arResult["ITEMS"] as $item):?>
                <tr class="">
                    <td>
                        <div class="events__table-item">
                            <div class="events__table-item-name">
                                <p class="wrap"><?=$item["UF_NAME"]?></p>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <a class="btn btn__grey-transparent btn__medium-width" target="_blank" href="<?=$item["UF_LINK"]?>">Посмотреть</a>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <?=$item["UF_DATE_SIGNED"]?>
                        </div>
                    </td>
                    <td>
                        <div class="events__table-item">
                            <?=$item["UF_DATE_LOAD"]?>
                        </div>
                    </td>
                </tr>
            <?endforeach;?>


            </tbody>
        </table>

    </div>